# V3 双机主动 SLAM 探索

V3 位于 `src/active_slam_explore`，V2 的 `src/dual_explore` 与既有 baseline 文件不修改。实验由 `scripts/run_active_slam_v3.py` 创建独立目录，世界、两份机器人 SDF、两份 SLAM 参数、两份 Nav2 参数、运行代码快照、运行日志和结果都保存在该目录。每次运行使用新的 ROS domain 和 Gazebo 端口；相同地图/种子/奖励组也不能复用旧目录或 Q 表。

## 数据流

1. Gazebo 为两车分别发布 `/robotN/scan`、`/robotN/odom` 与带前缀的 TF。
2. 两个 `slam_toolbox` 异步 mapper 用各自激光和里程计做扫描匹配与位姿图建图，各自发布 `/robotN/map`。当前仿真关闭在线回环闭合。Gazebo 里程计从世界原点开始，仿真专用的 `robotN/map→robotN/odom` 固定为单位变换，避免静止或长距离运行后动态 SLAM TF 停更使 Nav2 停住。扫描匹配和地图仍持续运行；真实机器人必须改用 SLAM 的动态定位变换与实测初始对齐。固定变换与关闭回环会增加长距离地图漂移风险。
3. 协调器把两张局部 SLAM 栅格投到 `map` 公共坐标并发布 `/map`。当前 Gazebo 差速插件的 odom 原点就是世界原点，因此两个 `map → robotN/map` 的初始对齐为单位变换；真实机器人需要实测初始外参或跨机器人回环对齐。融合时只把已知占用、但被机器人足迹证明可通行的格改为空闲，足迹不把未知格凭空计为已探索。
4. 已知空闲格与未知格相邻的是 frontier。门口边界可能被 SLAM 噪声切成 1–2 格的小簇，候选生成保留小簇并用预测可见未知格过滤。候选点按空间分散选取，并过滤靠近固定 ROI 外边界的假 frontier，避免反复观察外墙。候选观测位姿必须在已知空闲格，距**已知障碍**至少 0.38 m；未知格不是墙，机器人可以在已知地面上的门洞边缘观察门外。两车目标间至少 1.5 m，候选点距另一车当前位置至少 0.8 m；出生时两车仅相隔 1 m，故当前位置约束不能设到 1.5 m。朝向面对 frontier。
5. 信息收益是从观测位姿做 36 束预测射线、统计首次可见未知格数量的近似量，不宣称等于严格期望熵下降。目标评分包括该收益、另一车已走区域的复访惩罚、Nav2 `ComputePathToPose` 的路径长度，以及障碍距离和失败次数。
6. 两个 `/robotN/navigate_to_pose` 执行目标。目标距本车当前位置至少 0.6 米，避免 Nav2 把出生点附近的目标直接判为到达却没有获得新视野。地图变化使目标没有信息收益、导航失败、目标超时或导航成功时重新规划。已成功到达的观测点进入两车共用的去重条件；路径探测先覆盖不同区域，避免多个门口候选被同一区域近邻目标挤掉。
7. **V2 的 `SharedLearner` 类不修改，也只实例化一张 Q 表**。由于 Nav2 接管底层速度控制，原来的三个 Q 动作解释为观测朝向的“正面、偏左、偏右”选择。`shared` 组按融合图在该目标期间新增的已知格给两车各自完成的动作奖励；`independent` 组按本车局部 SLAM 图新增的已知空闲格给奖励。两组均保留同一共享 Q 表的数据结构和更新算法，改变的是奖励信号来源。Nav2 是导航器，不能说成 Q 学习控制器。

## 两个 95% 和返回

`exploration_pct` = 真值**可达空闲格**中，被至少一张 SLAM 图标记为已知空闲的比例。真值只供独立评估器使用，规划和 Q 奖励不会读取障碍真值。

`known_area_pct` = 预先固定 ROI（SDF 外墙包围矩形）内，融合图已判定为空闲或占用的格数 / ROI 总格数。世界文件及其 SHA256 保存在 manifest；障碍坐标不会传给 planner。

只有这两项**同时 ≥95%**，才停止探索并由 Nav2 送两车回同一房间中的各自初始位置 `(-1.7,-2.5)` 和 `(-0.7,-2.5)`。两车按顺序返航；先调用 Nav2 `ComputePathToPose` 求完整回程，再沿该路径每隔约 1.2 米设置已知路径上的中途目标。成功后沿同一路径推进，只有目标失败或超时才重新规划。导航报告成功后还需距初始点不超过 0.35 m 才记为返回成功。单段超过 75 秒会取消后重试，连续三次失败以 `status=return_failed` 结束。`status=completed` 仅在双指标达标且两车返回后出现；超时/中断/返航失败的地图和指标仍导出，但必须按 `status` 区分。

## 运行

```bash
cd /home/lemuel/single_ros2_prototype
source /opt/ros/humble/setup.bash
source install/setup.bash
colcon build --packages-select active_slam_explore --symlink-install
source install/setup.bash
DISPLAY=:0 python3 -B scripts/run_active_slam_v3.py \
  --stage formal --world worlds/fast/room.world --seed 7 --reward-mode shared \
  --gui true --max-wall-seconds 3600 --background
```

短时联调使用 `--stage pilot`，正式试验使用 `--stage formal`，二者路径完全分开。独立奖励组使用 `--reward-mode independent`，它会自动得到新的组目录。输出路径会在启动时打印。`summary.csv` 是单次运行的最终一行指标表，`metrics.csv` 是五秒一次的覆盖率和奖励曲线，`result.json` 有状态和详细面积；`fused_slam_map.pgm/.yaml` 是 ROS 地图，`fused_slam_map_preview.png` 使用约定的蓝色空闲、深色障碍、琥珀色未知与 8 倍最近邻显示。运行 `python3 -B scripts/summarize_active_slam_v3.py` 可生成包含阶段、地图、种子、奖励组和状态的 `experiments/active_slam_v3/comparison.csv`。

V3 用固定初始对齐融合地图，没有跨机器人联合位姿图优化。大地图中 95% ROI 已知面积可能受封闭不可见空间限制；超时结果应如实记录，而不是调整分母或把未知格当成已探索。

为了降低虚拟机负载，V3 机器人 SDF 移除未参与建图的相机传感器和激光可视化；激光改为 180 束、10 米量程，使穿过门洞的射线打到相邻房间边界，避免短量程未命中射线留下大片未知区。SLAM 地图更新间隔为 2 秒，Nav2 局部代价地图更新频率也低于官方示例。探索和分段返航均由 Nav2 DWB 控制器跟踪路径；动态障碍由局部代价地图的激光层检查。Gazebo 窗口的实际帧率还取决于虚拟机图形加速和主机负载，脚本不会把仿真时间误报成墙上时间。
