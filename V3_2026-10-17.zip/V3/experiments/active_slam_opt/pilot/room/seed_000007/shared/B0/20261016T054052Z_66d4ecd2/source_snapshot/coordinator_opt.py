"""Isolated B0-B4 V3 ablations; the V3 coordinator remains untouched."""
import csv
import json
import math
import time

import rclpy
from action_msgs.msg import GoalStatus

from .coordinator import ActiveSlamCoordinator, path_length, pose_message
from .optimization import (assign_regions, free_region_graph, graph_hops,
                           normalized_score, should_switch, zone)
from .planning import best_unreserved, diverse_choices, frontiers, separated, utility
from dual_explore.core import scan_bins, state_from_sensors
from nav2_msgs.action import ComputePathToPose


class OptimizedCoordinator(ActiveSlamCoordinator):
    def __init__(self):
        super().__init__()
        self.declare_parameter('ablation', 'B0')
        self.ablation = str(self.get_parameter('ablation').value).upper()
        if self.ablation not in ('B0', 'B1', 'B2', 'B3', 'B4'):
            raise ValueError('ablation must be B0, B1, B2, B3, or B4')
        self.level = int(self.ablation[1])
        self.path_m = {n: 0.0 for n in self.names}
        self.repeat_m = {n: 0.0 for n in self.names}
        self.stop_s = {n: 0.0 for n in self.names}
        self.last_motion = {n: None for n in self.names}
        self.switches = {n: 0 for n in self.names}
        self.nav_success = {n: 0 for n in self.names}
        self.nav_failure = {n: 0 for n in self.names}
        self.planning_s = {n: 0.0 for n in self.names}
        self.plan_started = {n: 0.0 for n in self.names}
        self.plan_counts = {n: (0, 0) for n in self.names}
        self.map_update_s = 0.0
        self.frontier_s = 0.0
        self.last_map_sim = None
        self.map_interval_sim = 0.0
        self.last_assignment = {}
        self.region_failures = {}
        self.region_revision = -1
        self.graph_revision = -1
        self.region_graph = {}
        self.thresholds = {}
        self.frontier_counts = (0, 0)
        self.frontier_revision = -1
        self.switch_check_revision = {n: -1 for n in self.names}
        self.decisions_file = (self.run_dir / 'decisions.csv').open('x', newline='', encoding='utf-8')
        self.decisions = csv.writer(self.decisions_file)
        self.decisions.writerow(['robot', 'sim_s', 'x', 'y', 'frontiers', 'clusters',
                                 'reachable_candidates', 'zone', 'candidate_x', 'candidate_y',
                                 'visible_unknown_proxy', 'nav2_path_m', 'risk', 'score',
                                 'chosen', 'reason', 'nav_result', 'goal_duration_s',
                                 'actual_new_known_cells'])
        self.profile_file = (self.run_dir / 'profile.csv').open('x', newline='', encoding='utf-8')
        self.profile = csv.writer(self.profile_file)
        self.profile.writerow(['sim_s', 'wall_s', 'phase', 'exploration_pct', 'known_area_pct',
                               'known_roi_cells', 'robot1_path_m', 'robot2_path_m',
                               'robot1_repeat_m', 'robot2_repeat_m', 'robot1_stopped_s',
                               'robot2_stopped_s', 'planning_wall_s', 'frontier_wall_s',
                               'map_fusion_wall_s', 'map_update_interval_sim_s',
                               'sim_per_wall', 'robot1_switches', 'robot2_switches',
                               'robot1_nav_success', 'robot2_nav_success',
                               'robot1_nav_failure', 'robot2_nav_failure'])
        self.get_logger().info(f'V3 optimization ablation {self.ablation}')

    def current_candidates(self):
        started = time.monotonic()
        result = super().current_candidates()
        if self.frontier_revision != self.map_revision:
            groups = frontiers(self.region, self.values)
            self.frontier_counts = (sum(map(len, groups)), len(groups))
            self.frontier_revision = self.map_revision
        self.frontier_s += time.monotonic() - started
        return result

    def rebuild_map(self):
        started = time.monotonic()
        super().rebuild_map()
        self.map_update_s += time.monotonic() - started
        now = self.sim_seconds()
        if self.last_map_sim is not None:
            self.map_interval_sim = now - self.last_map_sim
        self.last_map_sim = now
        if self.level >= 4 and self.map_revision != self.region_revision:
            self.region_failures = {key: (count, rev) for key, (count, rev)
                                    in self.region_failures.items()
                                    if count < 2 or self.map_revision - rev < 4}
            self.region_revision = self.map_revision

    def tick(self):
        previous = dict(self.poses)
        previous_cells = {n: set(self.visited[n]) for n in self.names}
        super().tick()
        if self.level >= 2 and self.phase == 'explore' and not self.done:
            for name in self.names:
                goal = self.goal[name]
                if not goal or goal['mode'] != 'explore' or self.plan_busy[name]:
                    continue
                age = time.monotonic()-self.goal_sent_at[name]
                if age < 7 or self.switch_check_revision[name] == self.map_revision:
                    continue
                self.switch_check_revision[name] = self.map_revision
                old = goal['candidate']
                from .planning import visible_unknown
                old_gain = visible_unknown(self.region, self.values, old.cell)
                if old_gain < 2:
                    continue  # V3 already cancels obsolete targets.
                other = self.names[1-self.names.index(name)]
                old_score = normalized_score(old, goal['path_length'], self.visited[other],
                                             self.region)
                choices = [c for c in self.current_candidates()
                           if math.hypot(c.x-old.x, c.y-old.y) >= 1.2]
                if choices:
                    best = max(choices, key=lambda c: normalized_score(
                        c, math.hypot(c.x-self.poses[name][0], c.y-self.poses[name][1]),
                        self.visited[other], self.region))
                    new_score = normalized_score(
                        best, math.hypot(best.x-self.poses[name][0],
                                         best.y-self.poses[name][1]),
                        self.visited[other], self.region)
                    # A path request is still required before dispatch. Use a
                    # wider trigger because this precheck uses straight distance.
                    if should_switch(max(.05, old_score), new_score, age, old_gain,
                                     True, margin=.25):
                        if self.goal_handle[name] is not None:
                            self.goal_handle[name].cancel_goal_async()
                        self._decision(name, old, goal['path_length'], old_score,
                                       'better_target_replan')
                        self.goal[name] = None
                        self.switches[name] += 1
        for name in self.names:
            old, new = previous[name], self.poses[name]
            if old is None or new is None:
                continue
            distance = math.hypot(new[0]-old[0], new[1]-old[1])
            if distance < 1.0:  # Ignore a discontinuous TF correction.
                self.path_m[name] += distance
                cell = self.region.cell(*new[:2])
                if cell in previous_cells[name]:
                    self.repeat_m[name] += distance
            now = self.sim_seconds()
            last = self.last_motion[name]
            if last is not None and self.goal[name] is not None and distance < .02:
                self.stop_s[name] += max(0.0, min(now-last, 2.0))
            self.last_motion[name] = now

    def log_metrics(self):
        super().log_metrics()
        if not hasattr(self, 'profile'):
            return
        _, _, coverage, known, _, area = self.metrics()
        wall = time.monotonic()-self.start_wall
        sim = self.sim_seconds()
        self.profile.writerow([round(sim, 2), round(wall, 2), self.phase,
                               round(coverage, 4), round(area, 4), known,
                               *[round(self.path_m[n], 3) for n in self.names],
                               *[round(self.repeat_m[n], 3) for n in self.names],
                               *[round(self.stop_s[n], 3) for n in self.names],
                               round(sum(self.planning_s.values()), 3),
                               round(self.frontier_s, 3), round(self.map_update_s, 3),
                               round(self.map_interval_sim, 3), round(sim/wall, 3) if wall else 0,
                               *[self.switches[n] for n in self.names],
                               *[self.nav_success[n] for n in self.names],
                               *[self.nav_failure[n] for n in self.names]])
        self.profile_file.flush()
        for metric, value in (('reachable_free', coverage), ('known_roi', area)):
            for pct in (80, 90, 95):
                key = f'{metric}_{pct}'
                if key not in self.thresholds and value >= pct:
                    self.thresholds[key] = round(sim, 2)

    def _held(self, name):
        return {other: self.goal[other]['candidate'] for other in self.names
                if other != name and self.goal[other] and
                self.goal[other]['mode'] == 'explore'}

    def begin_plan(self, name):
        if self.level == 0:
            self.plan_counts[name] = self.frontier_counts
            return super().begin_plan(name)
        if not self.paths[name].server_is_ready() or not self.nav[name].server_is_ready():
            return
        started = time.monotonic()
        pose = self.poses[name]
        other = self.names[1-self.names.index(name)]
        held = self._held(name)
        reserved = held.get(other)
        all_choices = self.current_candidates()
        choices = [c for c in all_choices
                   if math.hypot(c.x-pose[0], c.y-pose[1]) >= .6
                   and separated(c, reserved, self.poses[other])
                   and self.failures[name].get(c.cell, 0) < (2 if self.level >= 2 else 3)
                   and all(math.hypot(c.x-self.region.center(old)[0],
                                      c.y-self.region.center(old)[1]) >= .55
                           for completed in self.completed_targets.values() for old in completed)]
        if self.level >= 3 and choices:
            assigned = assign_regions(self.names, self.poses, choices, held)
            selected = assigned.get(name)
            if selected is not None:
                near = [c for c in choices if zone(c) == zone(selected)]
                far = [c for c in choices if zone(c) != zone(selected)]
                choices = near + far
                self.last_assignment[name] = zone(selected)
        if self.level >= 4:
            # Coarse region ordering favors remaining information and future
            # frontier choices, with a temporary penalty for failed areas.
            if self.graph_revision != self.map_revision:
                self.region_graph = free_region_graph(self.region, self.values)
                self.graph_revision = self.map_revision
            start_zone = (math.floor(pose[0]/2.0), math.floor(pose[1]/2.0))
            hops = graph_hops(self.region_graph, start_zone)
            counts = {}
            for c in choices:
                counts[zone(c)] = counts.get(zone(c), 0) + 1
            choices.sort(key=lambda c: utility(c, math.hypot(c.x-pose[0], c.y-pose[1]),
                                               self.visited[other], self.region)
                         + .35*min(counts[zone(c)], 6)
                         + .08*len(self.region_graph.get(zone(c), ()))
                         - .15*hops.get(zone(c), 20)
                         - self.region_failures.get(zone(c), (0, 0))[0], reverse=True)
        else:
            choices.sort(key=lambda c: utility(c, math.hypot(c.x-pose[0], c.y-pose[1]),
                                               self.visited[other], self.region), reverse=True)
        if self.level >= 3 and name in self.last_assignment:
            key = self.last_assignment[name]
            choices.sort(key=lambda c: zone(c) != key)
        self.plan_queue[name] = diverse_choices(choices, limit=6)
        self.plan_scored[name] = []
        self.plan_counts[name] = self.frontier_counts
        self.plan_started[name] = started
        if self.plan_queue[name]:
            self.plan_busy[name] = True
            self.probe_next(name)
        else:
            self._decision(name, None, 0, 0, 'no_candidate')

    def _decision(self, name, candidate, length, score, reason, chosen=False,
                  nav_result='', duration='', actual_gain=''):
        if not hasattr(self, 'decisions'):
            return
        p = self.poses[name] or (None, None, None)
        total, clusters = self.plan_counts[name]
        self.decisions.writerow([name, round(self.sim_seconds(), 2), p[0], p[1],
                                 total, clusters, len(self.plan_scored[name]),
                                 zone(candidate) if candidate else '',
                                 candidate.x if candidate else '',
                                 candidate.y if candidate else '',
                                 candidate.information if candidate else '',
                                 round(length, 3) if candidate else '',
                                 round(1/max(candidate.clearance, .1), 3) if candidate else '',
                                 round(score, 4) if candidate else '',
                                 int(chosen), reason, nav_result, duration, actual_gain])
        self.decisions_file.flush()

    def on_path_result(self, name, candidate, future):
        if self.level == 0:
            before = len(self.plan_scored[name])
            result = super().on_path_result(name, candidate, future)
            if len(self.plan_scored[name]) > before:
                score, _, length = self.plan_scored[name][-1]
                self._decision(name, candidate, length, score, 'path_ok')
            else:
                self._decision(name, candidate, 0, 0, 'path_failed')
            return result
        try:
            result = future.result()
            if result.status == GoalStatus.STATUS_SUCCEEDED and result.result.path.poses:
                length = path_length(result.result.path)
                other = self.names[1-self.names.index(name)]
                other_target = self._held(name).get(other)
                score = normalized_score(candidate, length, self.visited[other],
                                         self.region, self.failures[name].get(candidate.cell, 0),
                                         other_target)
                if self.level >= 4:
                    score -= .2*self.region_failures.get(zone(candidate), (0, 0))[0]
                self.plan_scored[name].append((score, candidate, length))
                self._decision(name, candidate, length, score, 'path_ok')
            else:
                self.mark_failure(name, candidate)
                self._decision(name, candidate, 0, 0, 'path_failed')
        except Exception as exc:
            self.get_logger().warn(f'{name} path result failed: {exc}')
            self.mark_failure(name, candidate)
            self._decision(name, candidate, 0, 0, 'path_error')
        self.probe_next(name)

    def probe_next(self, name):
        if self.level == 0:
            return super().probe_next(name)
        if not self.plan_queue[name]:
            self.plan_busy[name] = False
            self.planning_s[name] += time.monotonic()-self.plan_started[name]
            other = self.names[1-self.names.index(name)]
            selected = best_unreserved(self.plan_scored[name], self._held(name).get(other),
                                       self.poses[other])
            if selected and self.phase == 'explore' and self.goal[name] is None:
                score, candidate, length = selected
                scan = self.scans[name]
                bins = scan_bins(scan.ranges, scan.range_min, scan.range_max) if scan else None
                state = state_from_sensors(bins, None) if bins else (2, 2, 2, 0, 0, 0)
                action = self.learner.choose(state, train=True)
                yaw = candidate.yaw + (0.0, .35, -.35)[action]
                self.goal_state[name] = (state, action)
                self._decision(name, candidate, length, score, 'selected', chosen=True)
                self.send_navigation(name, pose_message(candidate.x, candidate.y, yaw,
                                     self.get_clock().now().to_msg()), mode='explore',
                                     candidate=candidate, path_length=length)
            elif not selected:
                self._decision(name, None, 0, 0, 'no_reachable_candidate')
            return
        candidate = self.plan_queue[name].pop(0)
        action = ComputePathToPose.Goal()
        action.goal = pose_message(candidate.x, candidate.y, candidate.yaw,
                                   self.get_clock().now().to_msg())
        action.use_start = False
        self.paths[name].send_goal_async(action).add_done_callback(
            lambda future, n=name, c=candidate: self.on_path_goal(n, c, future))

    def on_nav_result(self, name, mode, token, future):
        current = self.goal[name]
        valid = current is not None and current.get('token') is token
        elapsed = time.monotonic()-self.goal_sent_at[name] if valid else 0
        gain = max(0, sum(v >= 0 for v in self.values)-self.goal_known_at[name]) if valid else 0
        status = 'error'
        try:
            status = 'success' if future.result().status == GoalStatus.STATUS_SUCCEEDED else 'failed'
        except Exception:
            pass
        if valid and mode == 'explore':
            self.nav_success[name] += int(status == 'success')
            self.nav_failure[name] += int(status != 'success')
            if self.level >= 4 and status != 'success':
                key = zone(current['candidate'])
                count, _ = self.region_failures.get(key, (0, self.map_revision))
                self.region_failures[key] = (count+1, self.map_revision)
            self._decision(name, current['candidate'], current['path_length'], 0,
                           'goal_finished', nav_result=status,
                           duration=round(elapsed, 2), actual_gain=gain)
        super().on_nav_result(name, mode, token, future)

    def send_navigation(self, name, pose, mode, candidate=None, path_length=0.0):
        if mode == 'explore' and self.level == 0 and candidate is not None:
            self._decision(name, candidate, path_length, 0, 'selected', chosen=True)
        super().send_navigation(name, pose, mode, candidate, path_length)

    def finish(self, status):
        if self.done:
            return
        super().finish(status)
        self.decisions_file.close()
        self.profile_file.close()
        result_path = self.run_dir / 'result.json'
        result = json.loads(result_path.read_text())
        result.update(version=f'v3_opt_{self.ablation}', ablation=self.ablation,
                      threshold_times_sim_s=self.thresholds, path_m=self.path_m,
                      repeat_path_m=self.repeat_m, stopped_sim_s=self.stop_s,
                      switches=self.switches, nav_success=self.nav_success,
                      nav_failure=self.nav_failure, planning_wall_s=self.planning_s,
                      frontier_wall_s=self.frontier_s, fusion_wall_s=self.map_update_s,
                      decisions_csv='decisions.csv', profile_csv='profile.csv')
        result_path.write_text(json.dumps(result, indent=2), encoding='utf-8')
        with (self.run_dir / 'opt_summary.csv').open('x', newline='', encoding='utf-8') as stream:
            fields = ['version', 'ablation', 'status', 'reward_mode', 'exploration_pct',
                      'known_area_pct', 'explored_area_m2', 'known_roi_area_m2',
                      'exploration_time_sim_s', 'total_time_sim_s', 'wall_time_s',
                      'reachable_free_80', 'reachable_free_90', 'reachable_free_95',
                      'known_roi_80', 'known_roi_90', 'known_roi_95',
                      'robot1_reward', 'robot2_reward', 'robot1_path_m', 'robot2_path_m',
                      'robot1_nav_failure', 'robot2_nav_failure']
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerow({**{key: result.get(key) for key in fields},
                             **self.thresholds,
                             **{f'{n}_reward': self.reward_total[n] for n in self.names},
                             **{f'{n}_path_m': self.path_m[n] for n in self.names},
                             **{f'{n}_nav_failure': self.nav_failure[n] for n in self.names}})


def main():
    rclpy.init()
    node = OptimizedCoordinator()
    try:
        while rclpy.ok() and not node.done:
            rclpy.spin_once(node, timeout_sec=.5)
    except KeyboardInterrupt:
        node.finish('interrupted')
    finally:
        if not node.done:
            node.finish('interrupted')
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
