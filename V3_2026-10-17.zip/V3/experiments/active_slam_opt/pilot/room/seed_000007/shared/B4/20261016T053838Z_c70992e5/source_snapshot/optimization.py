"""ROS-free policy helpers for isolated V3 optimization ablations."""
import math


def zone(candidate, width=2.0):
    """Stable coarse area key; a corridor/room proxy, not room recognition."""
    return (math.floor(candidate.x / width), math.floor(candidate.y / width))


def normalized_score(candidate, path_m, other_visited, region, failures=0,
                     other_target=None, nominal_speed=.22):
    """Visible unknown cells per travel second, with explicit risk/overlap costs."""
    nearby = sum((candidate.cell[0]+dx, candidate.cell[1]+dy) in other_visited
                 for dx in range(-5, 6) for dy in range(-5, 6)) / 121.0
    overlap = 0.0 if other_target is None else max(
        0.0, 1.0 - math.hypot(candidate.x-other_target.x,
                              candidate.y-other_target.y) / 2.0)
    travel = path_m / nominal_speed + abs(candidate.yaw) / 1.5 + 2.0
    gain = min(candidate.information / 50.0, 1.0)
    risk = min(.4 / max(candidate.clearance, .1), 2.0) / 2.0
    return gain / max(travel / 30.0, .1) - .25*risk - .25*nearby - .5*overlap - .2*failures


def should_switch(current_score, new_score, age_s, current_gain, current_safe,
                  min_interval=7.0, margin=.20):
    if not current_safe or current_gain < 2:
        return True
    return age_s >= min_interval and new_score > current_score * (1.0 + margin)


def assign_regions(names, poses, choices, held=None, width=2.0):
    """Small deterministic greedy matching of robots to distinct candidate areas."""
    held = held or {}
    used = {zone(c, width) for c in held.values() if c is not None}
    result = {}
    pairs = []
    for name in names:
        if name in held or poses.get(name) is None:
            continue
        for candidate in choices:
            key = zone(candidate, width)
            if key in used:
                continue
            distance = math.hypot(candidate.x-poses[name][0],
                                  candidate.y-poses[name][1])
            score = min(candidate.information, 50)/50.0 - distance/12.0
            pairs.append((score, name, key, candidate))
    for _, name, key, candidate in sorted(pairs, key=lambda row: row[0], reverse=True):
        if name not in result and key not in used:
            result[name] = candidate
            used.add(key)
    return result
