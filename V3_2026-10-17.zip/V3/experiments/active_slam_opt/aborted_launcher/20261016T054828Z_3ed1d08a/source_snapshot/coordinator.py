"""V3 active SLAM loop: fuse local SLAM maps, choose safe views, use Nav2.

Only the evaluator reads SDF collisions. The planner and Q rewards use maps,
laser scans, TF poses, and Nav2 paths. Every run has an exclusive directory.
"""
import csv
import json
import math
from pathlib import Path
import time

import rclpy
from action_msgs.msg import GoalStatus
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import ComputePathToPose, NavigateToPose
from nav_msgs.msg import OccupancyGrid
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy, qos_profile_sensor_data
from sensor_msgs.msg import LaserScan
from tf2_ros import Buffer, TransformListener, TransformException

from dual_explore.core import SharedLearner, scan_bins, state_from_sensors
from dual_explore.mapping import GroundTruth, write_map_preview
from .planning import (Region, best_unreserved, candidates, clear_traversed_occupied,
                       diverse_choices, fused_maps, segment_endpoint, separated,
                       utility, visible_unknown, yaw_of)


def pose_message(x, y, yaw, stamp):
    pose = PoseStamped()
    pose.header.frame_id = 'map'
    pose.header.stamp = stamp
    pose.pose.position.x, pose.pose.position.y = float(x), float(y)
    pose.pose.orientation.z = math.sin(yaw / 2)
    pose.pose.orientation.w = math.cos(yaw / 2)
    return pose


def path_length(path):
    points = [p.pose.position for p in path.poses]
    return sum(math.hypot(a.x-b.x, a.y-b.y) for a, b in zip(points, points[1:]))


class ActiveSlamCoordinator(Node):
    def __init__(self):
        super().__init__('active_slam_coordinator')
        for name, value in (
            ('run_dir', ''), ('world_path', ''), ('seed', 7), ('reward_mode', 'shared'),
            ('start_xy', [-1.7, -2.5, -.7, -2.5]), ('map_resolution', .1),
            ('coverage_target_pct', 95.0), ('known_area_target_pct', 95.0),
            ('max_wall_seconds', 3600.0)):
            self.declare_parameter(name, value)
        self.run_dir = Path(self.get_parameter('run_dir').value).resolve()
        world = Path(self.get_parameter('world_path').value).resolve()
        if not self.run_dir.is_dir() or not world.is_file():
            raise ValueError('Runner must provide an existing isolated run_dir and world_path')
        self.names = ('robot1', 'robot2')
        start_xy = [float(v) for v in self.get_parameter('start_xy').value]
        if len(start_xy) != 4:
            raise ValueError('start_xy requires four coordinates')
        self.starts = {name: (*start_xy[2*i:2*i+2], 0.0) for i, name in enumerate(self.names)}
        self.truth = GroundTruth.from_sdf(world, [(v[0], v[1]) for v in self.starts.values()],
                                          resolution=float(self.get_parameter('map_resolution').value))
        grid = self.truth.grid
        self.region = Region(grid.x_min, grid.y_min, grid.width, grid.height, grid.resolution)
        self.coverage_target = float(self.get_parameter('coverage_target_pct').value)
        self.known_target = float(self.get_parameter('known_area_target_pct').value)
        self.max_wall_seconds = float(self.get_parameter('max_wall_seconds').value)
        if not (0 < self.coverage_target <= 100 and 0 < self.known_target <= 100):
            raise ValueError('Both target percentages must be in (0,100]')
        self.reward_mode = str(self.get_parameter('reward_mode').value)
        if self.reward_mode not in ('shared', 'independent'):
            raise ValueError('reward_mode must be shared or independent')
        self.learner = SharedLearner(seed=int(self.get_parameter('seed').value))
        if (self.run_dir / 'q_table.json').exists() or (self.run_dir / 'metrics.csv').exists():
            raise FileExistsError('Refusing to reuse a previous experimental output')
        self.qos_map = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                                  durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.map_pub = self.create_publisher(OccupancyGrid, '/map', self.qos_map)
        self.map_subs = []
        self.scan_subs = []
        self.local_maps = {n: None for n in self.names}
        self.scans = {n: None for n in self.names}
        self.poses = {n: None for n in self.names}
        self.tf_fresh_wall = {n: time.monotonic() for n in self.names}
        self.visited = {n: set() for n in self.names}
        self.local_free = {n: set() for n in self.names}
        self.values = [-1] * (grid.width * grid.height)
        self.map_dirty = False
        self.last_map_at = 0.0
        self.map_revision = 0
        self.candidate_cache_revision = -1
        self.candidate_cache = []
        self.last_log_at = 0.0
        self.start_wall = time.monotonic()
        self.start_sim = None
        self.explore_end_sim = None
        self.phase = 'explore'
        self.done = False
        self.status = None
        self.goal = {n: None for n in self.names}
        self.goal_handle = {n: None for n in self.names}
        self.goal_sent_at = {n: 0.0 for n in self.names}
        self.goal_state = {n: None for n in self.names}
        self.plan_queue = {n: [] for n in self.names}
        self.plan_scored = {n: [] for n in self.names}
        self.plan_busy = {n: False for n in self.names}
        self.failures = {n: {} for n in self.names}
        self.completed_targets = {n: set() for n in self.names}
        self.failure_decay_known = 0
        self.reward_total = {n: 0.0 for n in self.names}
        self.goal_known_at = {n: 0 for n in self.names}
        self.goal_local_free_at = {n: 0 for n in self.names}
        self.return_ok = {n: False for n in self.names}
        self.return_attempts = {n: 0 for n in self.names}
        self.return_order = list(self.names)
        self.return_planning = {n: False for n in self.names}
        self.return_route = {n: None for n in self.names}
        self.return_cursor = {n: 0 for n in self.names}
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.nav = {}
        self.paths = {}
        for name in self.names:
            self.map_subs.append(self.create_subscription(
                OccupancyGrid, f'/{name}/map', lambda msg, n=name: self.on_map(n, msg), self.qos_map))
            self.scan_subs.append(self.create_subscription(
                LaserScan, f'/{name}/scan', lambda msg, n=name: self.on_scan(n, msg),
                qos_profile_sensor_data))
            self.nav[name] = ActionClient(self, NavigateToPose, f'/{name}/navigate_to_pose')
            self.paths[name] = ActionClient(self, ComputePathToPose,
                                            f'/{name}/compute_path_to_pose')
        self.csv_file = (self.run_dir / 'metrics.csv').open('x', newline='', encoding='utf-8')
        self.writer = csv.writer(self.csv_file)
        self.writer.writerow(['sim_seconds', 'wall_seconds', 'phase', 'reachable_free_seen',
                              'reachable_free_total', 'exploration_pct', 'known_roi_cells',
                              'roi_cells', 'known_area_pct', 'robot1_reward', 'robot2_reward',
                              'robot1_visited', 'robot2_visited'])
        self.create_timer(1.0, self.tick)
        self.get_logger().info('V3 active SLAM coordinator started: two 95% gates, then return')

    def on_map(self, name, msg):
        if msg.info.width and msg.info.height and len(msg.data) == msg.info.width*msg.info.height:
            self.local_maps[name] = msg
            self.map_dirty = True

    def on_scan(self, name, msg):
        self.scans[name] = msg

    def sim_seconds(self):
        now = self.get_clock().now().nanoseconds / 1e9
        if now <= 0:
            return 0.0
        if self.start_sim is None:
            self.start_sim = now
        return now - self.start_sim

    def current_pose(self, name):
        try:
            tf = self.tf_buffer.lookup_transform('map', f'{name}/base_footprint',
                                                 rclpy.time.Time())
        except TransformException:
            return None
        stamp = tf.header.stamp.sec + tf.header.stamp.nanosec / 1e9
        now = self.get_clock().now().nanoseconds / 1e9
        if now > 0 and now - stamp > 3.0:
            return None
        self.tf_fresh_wall[name] = time.monotonic()
        p, q = tf.transform.translation, tf.transform.rotation
        return p.x, p.y, yaw_of(q)

    def rebuild_map(self):
        if not all(self.local_maps.values()):
            return
        # The Gazebo odom frames begin in world coordinates, so each local
        # SLAM map is aligned with the shared map by an identity transform.
        alignments = {name: (0.0, 0.0, 0.0) for name in self.names}
        self.values, self.local_free = fused_maps(self.region, self.local_maps, alignments)
        # The physical footprint is known traversable. Clear ghost obstacles
        # that the other mapper may have recorded when seeing a teammate.
        clear_traversed_occupied(self.region, self.values, self.visited.values())
        known_now = sum(v >= 0 for v in self.values)
        if known_now - self.failure_decay_known >= 150:
            # A new corridor can make a formerly unreachable goal feasible.
            for name in self.names:
                self.failures[name] = {cell: count-1 for cell, count in self.failures[name].items()
                                       if count > 1}
            self.failure_decay_known = known_now
        msg = OccupancyGrid()
        msg.header.frame_id = 'map'
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.info.resolution = self.region.resolution
        msg.info.width, msg.info.height = self.region.width, self.region.height
        msg.info.origin.position.x, msg.info.origin.position.y = self.region.x, self.region.y
        msg.info.origin.orientation.w = 1.0
        msg.data = self.values
        self.map_pub.publish(msg)
        self.map_dirty = False
        self.last_map_at = time.monotonic()
        self.map_revision += 1

    def current_candidates(self):
        if self.candidate_cache_revision != self.map_revision:
            self.candidate_cache = candidates(self.region, self.values, limit=64)
            self.candidate_cache_revision = self.map_revision
        return self.candidate_cache

    def metrics(self):
        observed = set().union(*self.local_free.values())
        seen = len(observed & self.truth.reachable_free)
        total = len(self.truth.reachable_free)
        known = sum(v >= 0 for v in self.values)
        roi = len(self.values)
        return seen, total, 100*seen/total if total else 0.0, known, roi, 100*known/roi

    def log_metrics(self):
        seen, total, coverage, known, roi, area = self.metrics()
        self.writer.writerow([round(self.sim_seconds(), 2),
                              round(time.monotonic()-self.start_wall, 2), self.phase,
                              seen, total, round(coverage, 4), known, roi,
                              round(area, 4), round(self.reward_total['robot1'], 4),
                              round(self.reward_total['robot2'], 4),
                              len(self.visited['robot1']), len(self.visited['robot2'])])
        self.csv_file.flush()
        self.get_logger().info(f'coverage={coverage:.2f}% known area={area:.2f}% '
                               f'phase={self.phase}')

    def tick(self):
        if self.done:
            return
        elapsed = time.monotonic() - self.start_wall
        if elapsed >= self.max_wall_seconds:
            self.finish('timeout')
            return
        for name in self.names:
            pose = self.current_pose(name)
            if pose is not None:
                self.poses[name] = pose
                cell = self.region.cell(*pose[:2])
                if cell:
                    self.visited[name].add(cell)
        stale = [name for name in self.names
                 if time.monotonic() - self.tf_fresh_wall[name] > 30]
        if stale:
            self.get_logger().error(f'SLAM/TF stale for {stale}; stopping incomplete run')
            self.finish('slam_tf_stale')
            return
        if self.map_dirty and time.monotonic()-self.last_map_at >= 1.5:
            self.rebuild_map()
        if time.monotonic()-self.last_log_at >= 5:
            self.log_metrics()
            self.last_log_at = time.monotonic()
        if self.phase == 'explore':
            if not all(self.local_maps.values()) or not all(self.poses.values()):
                return
            _, _, coverage, _, _, area = self.metrics()
            if coverage >= self.coverage_target and area >= self.known_target:
                self.phase = 'return'
                self.explore_end_sim = self.sim_seconds()
                self.return_order = sorted(
                    self.names, key=lambda n: math.hypot(
                        self.poses[n][0]-self.starts[n][0],
                        self.poses[n][1]-self.starts[n][1]))
                for name in self.names:
                    if self.goal_handle[name] is not None:
                        self.goal_handle[name].cancel_goal_async()
                    self.goal[name] = None
                    self.plan_queue[name] = []
                    self.plan_busy[name] = False
                self.get_logger().info(
                    f'Both 95% gates reached; sequential return {self.return_order}')
                return
            for name in self.names:
                if self.goal[name] is not None:
                    goal = self.goal[name]
                    # A newly updated SLAM map can make a frontier obsolete.
                    if goal['mode'] == 'explore' and time.monotonic()-self.goal_sent_at[name] > 12:
                        if visible_unknown(self.region, self.values,
                                           goal['candidate'].cell) < 2:
                            if self.goal_handle[name] is not None:
                                self.goal_handle[name].cancel_goal_async()
                            self.goal[name] = None
                    if self.goal[name] is not None and time.monotonic()-self.goal_sent_at[name] > 60:
                        if self.goal_handle[name] is not None:
                            self.goal_handle[name].cancel_goal_async()
                        self.mark_failure(name, goal['candidate'])
                        self.goal[name] = None
                if self.goal[name] is None and not self.plan_busy[name]:
                    self.begin_plan(name)
        else:
            # A narrow door can become impassable if both robots drive home
            # through it together. The second robot waits for the first.
            for name in self.return_order:
                if any(not self.return_ok[earlier]
                       for earlier in self.return_order[:self.return_order.index(name)]):
                    break
                if (self.goal[name] is not None and
                        time.monotonic()-self.goal_sent_at[name] > 75):
                    if self.goal_handle[name] is not None:
                        self.goal_handle[name].cancel_goal_async()
                    self.goal[name] = None
                    self.return_route[name] = None
                    self.return_attempts[name] += 1
                if (not self.return_ok[name] and self.goal[name] is None and
                        not self.return_planning[name]):
                    if self.return_attempts[name] >= 3:
                        self.finish('return_failed')
                        return
                    self.begin_return_plan(name)
            if all(self.return_ok.values()):
                self.finish('completed')

    def begin_return_plan(self, name):
        if self.return_route[name] is not None:
            self.send_return_segment(name)
            return
        if not self.paths[name].server_is_ready():
            return
        x, y, yaw = self.starts[name]
        request = ComputePathToPose.Goal()
        request.goal = pose_message(x, y, yaw, self.get_clock().now().to_msg())
        request.use_start = False
        self.return_planning[name] = True
        self.paths[name].send_goal_async(request).add_done_callback(
            lambda future, n=name: self.on_return_path_goal(n, future))

    def on_return_path_goal(self, name, future):
        try:
            handle = future.result()
            if handle.accepted:
                handle.get_result_async().add_done_callback(
                    lambda result, n=name: self.on_return_path_result(n, result))
                return
        except Exception as exc:
            self.get_logger().warn(f'{name} return path request failed: {exc}')
        self.return_planning[name] = False
        self.return_attempts[name] += 1

    def on_return_path_result(self, name, future):
        self.return_planning[name] = False
        try:
            response = future.result()
            points = response.result.path.poses
            if response.status != GoalStatus.STATUS_SUCCEEDED or not points:
                raise RuntimeError('Nav2 returned no path home')
            xy = [(p.pose.position.x, p.pose.position.y) for p in points]
            self.return_route[name] = xy
            self.return_cursor[name] = 0
            self.get_logger().info(f'{name} return path {path_length(response.result.path):.1f}m')
            self.send_return_segment(name)
        except Exception as exc:
            self.get_logger().warn(f'{name} return path failed: {exc}')
            self.return_attempts[name] += 1

    def send_return_segment(self, name):
        route = self.return_route[name]
        cursor = self.return_cursor[name]
        index = cursor + segment_endpoint(route[cursor:])
        x, y = route[index]
        if index == len(route)-1:
            x, y, yaw = self.starts[name]
        else:
            following = route[min(index+1, len(route)-1)]
            yaw = math.atan2(following[1]-y, following[0]-x)
        self.get_logger().info(f'{name} return segment {cursor}->{index} '
                               f'via ({x:.2f}, {y:.2f})')
        self.send_navigation(name, pose_message(x, y, yaw,
                                                 self.get_clock().now().to_msg()),
                             mode='return')
        if self.goal[name] is not None:
            self.goal[name]['route_index'] = index

    def begin_plan(self, name):
        if not self.paths[name].server_is_ready() or not self.nav[name].server_is_ready():
            return
        pose = self.poses[name]
        other = self.names[1-self.names.index(name)]
        other_goal = self.goal[other]
        reserved = other_goal['candidate'] if other_goal and other_goal['mode'] == 'explore' else None
        choices = [c for c in self.current_candidates()
                   if math.hypot(c.x-pose[0], c.y-pose[1]) >= .6 and
                   separated(c, reserved, self.poses[other]) and
                   self.failures[name].get(c.cell, 0) < 3 and
                   all(math.hypot(c.x-self.region.center(old)[0],
                                  c.y-self.region.center(old)[1]) >= .55
                       for completed in self.completed_targets.values() for old in completed)]
        choices.sort(key=lambda c: utility(c, math.hypot(c.x-pose[0], c.y-pose[1]),
                                           self.visited[other], self.region,
                                           self.failures[name].get(c.cell, 0)), reverse=True)
        self.plan_queue[name] = diverse_choices(choices, limit=8)
        self.plan_scored[name] = []
        if self.plan_queue[name]:
            self.plan_busy[name] = True
            self.probe_next(name)

    def probe_next(self, name):
        if not self.plan_queue[name]:
            self.plan_busy[name] = False
            other = self.names[1-self.names.index(name)]
            other_goal = self.goal[other]
            reserved = (other_goal['candidate'] if other_goal and
                        other_goal['mode'] == 'explore' else None)
            selected = best_unreserved(self.plan_scored[name], reserved, self.poses[other])
            if selected and self.phase == 'explore' and self.goal[name] is None:
                _, candidate, length = selected
                scan = self.scans[name]
                bins = scan_bins(scan.ranges, scan.range_min, scan.range_max) if scan else None
                state = state_from_sensors(bins, None) if bins else (2, 2, 2, 0, 0, 0)
                action = self.learner.choose(state, train=True)
                yaw = candidate.yaw + (0.0, .35, -.35)[action]
                pose = pose_message(candidate.x, candidate.y, yaw,
                                    self.get_clock().now().to_msg())
                self.goal_state[name] = (state, action)
                self.send_navigation(name, pose, mode='explore', candidate=candidate,
                                     path_length=length)
            return
        candidate = self.plan_queue[name].pop(0)
        action = ComputePathToPose.Goal()
        action.goal = pose_message(candidate.x, candidate.y, candidate.yaw,
                                   self.get_clock().now().to_msg())
        action.use_start = False
        self.paths[name].send_goal_async(action).add_done_callback(
            lambda future, n=name, c=candidate: self.on_path_goal(n, c, future))

    def on_path_goal(self, name, candidate, future):
        try:
            handle = future.result()
            if not handle.accepted:
                self.probe_next(name)
                return
            handle.get_result_async().add_done_callback(
                lambda result, n=name, c=candidate: self.on_path_result(n, c, result))
        except Exception as exc:
            self.get_logger().warn(f'{name} path request failed: {exc}')
            self.probe_next(name)

    def on_path_result(self, name, candidate, future):
        try:
            result = future.result()
            if result.status == GoalStatus.STATUS_SUCCEEDED and result.result.path.poses:
                length = path_length(result.result.path)
                other = self.names[1-self.names.index(name)]
                score = utility(candidate, length, self.visited[other], self.region,
                                self.failures[name].get(candidate.cell, 0))
                self.plan_scored[name].append((score, candidate, length))
            else:
                self.mark_failure(name, candidate)
        except Exception as exc:
            self.get_logger().warn(f'{name} path result failed: {exc}')
            self.mark_failure(name, candidate)
        self.probe_next(name)

    def send_navigation(self, name, pose, mode, candidate=None, path_length=0.0):
        if not self.nav[name].server_is_ready():
            return
        action = NavigateToPose.Goal()
        action.pose = pose
        self.goal[name] = {'mode': mode, 'candidate': candidate, 'path_length': path_length}
        self.goal_sent_at[name] = time.monotonic()
        self.goal_known_at[name] = sum(v >= 0 for v in self.values)
        self.goal_local_free_at[name] = len(self.local_free[name])
        token = object()
        self.goal[name]['token'] = token
        self.nav[name].send_goal_async(action).add_done_callback(
            lambda future, n=name, m=mode, t=token: self.on_nav_goal(n, m, t, future))
        self.get_logger().info(f'{name} {mode} goal=({pose.pose.position.x:.2f}, '
                               f'{pose.pose.position.y:.2f}) route={path_length:.1f}m')

    def on_nav_goal(self, name, mode, token, future):
        try:
            handle = future.result()
            if not handle.accepted:
                if self.goal[name] and self.goal[name].get('token') is token:
                    self.goal[name] = None
                    if mode == 'return':
                        self.return_route[name] = None
                        self.return_attempts[name] += 1
                return
            if self.goal[name] and self.goal[name].get('token') is token:
                self.goal_handle[name] = handle
            handle.get_result_async().add_done_callback(
                lambda result, n=name, m=mode, t=token: self.on_nav_result(n, m, t, result))
        except Exception as exc:
            self.get_logger().warn(f'{name} Nav2 rejected request: {exc}')
            if self.goal[name] and self.goal[name].get('token') is token:
                self.goal[name] = None
                if mode == 'return':
                    self.return_route[name] = None
                    self.return_attempts[name] += 1

    def on_nav_result(self, name, mode, token, future):
        try:
            result = future.result()
            success = result.status == GoalStatus.STATUS_SUCCEEDED
        except Exception as exc:
            self.get_logger().warn(f'{name} Nav2 result failed: {exc}')
            success = False
        current = self.goal[name]
        if current is None or current.get('token') is not token:
            return  # old canceled goal completed after a new assignment
        if mode == 'explore':
            team_gain = max(0, sum(v >= 0 for v in self.values)-self.goal_known_at[name])
            own_gain = max(0, len(self.local_free[name])-self.goal_local_free_at[name])
            gain = team_gain if self.reward_mode == 'shared' else own_gain
            reward = -.01 + min(gain, 100)*.02 if success else -1.0
            self.reward_total[name] += reward
            state, action = self.goal_state[name]
            scan = self.scans[name]
            bins = scan_bins(scan.ranges, scan.range_min, scan.range_max) if scan else None
            next_state = state_from_sensors(bins, None) if bins else state
            self.learner.learn(state, action, reward, next_state)
            if success:
                self.completed_targets[name].add(current['candidate'].cell)
            if not success:
                self.mark_failure(name, current['candidate'])
        else:
            if success:
                self.return_attempts[name] = 0
                self.return_cursor[name] = current['route_index']
                pose = self.poses[name]
                start = self.starts[name]
                self.return_ok[name] = bool(pose and math.hypot(pose[0]-start[0],
                                                                pose[1]-start[1]) <= .35)
            else:
                self.return_route[name] = None
                self.return_attempts[name] += 1
        self.goal[name] = None
        self.goal_handle[name] = None

    def mark_failure(self, name, candidate):
        if candidate is not None:
            self.failures[name][candidate.cell] = self.failures[name].get(candidate.cell, 0) + 1

    def write_map(self):
        width, height = self.region.width, self.region.height
        pgm = self.run_dir / 'fused_slam_map.pgm'
        with pgm.open('wb') as stream:
            stream.write(f'P5\n{width} {height}\n255\n'.encode())
            for y in reversed(range(height)):
                stream.write(bytes({-1: 205, 0: 254, 100: 0}[v]
                                   for v in self.values[y*width:(y+1)*width]))
        (self.run_dir / 'fused_slam_map.yaml').write_text(
            f'image: {pgm.name}\nresolution: {self.region.resolution}\n'
            f'origin: [{self.region.x}, {self.region.y}, 0.0]\n'
            'negate: 0\noccupied_thresh: 0.65\nfree_thresh: 0.196\n', encoding='utf-8')
        write_map_preview(self.run_dir / 'fused_slam_map_preview.png', self.values,
                          width, height, scale=8)

    def finish(self, status):
        if self.done:
            return
        self.status = status
        self.log_metrics()
        self.done = True
        self.write_map()
        self.learner.save(self.run_dir / 'q_table.json')
        seen, total, coverage, known, roi, area = self.metrics()
        result = {
            'version': 'v3_active_slam', 'status': status,
            'slam': 'two independent slam_toolbox async mappers, fixed-start fusion',
            'coverage_target_pct': self.coverage_target,
            'known_area_target_pct': self.known_target,
            'exploration_pct': round(coverage, 4),
            'explored_area_m2': round(seen*self.region.resolution**2, 4),
            'reachable_free_area_m2': round(total*self.region.resolution**2, 4),
            'known_area_pct': round(area, 4),
            'known_roi_area_m2': round(known*self.region.resolution**2, 4),
            'roi_area_m2': round(roi*self.region.resolution**2, 4),
            'exploration_time_sim_s': self.explore_end_sim,
            'total_time_sim_s': self.sim_seconds(),
            'wall_time_s': round(time.monotonic()-self.start_wall, 2),
            'reward_mode': self.reward_mode, 'reward_total': self.reward_total,
            'returned_to_deployment': self.return_ok,
            'map_pgm': 'fused_slam_map.pgm',
            'map_preview': 'fused_slam_map_preview.png',
            'metrics_csv': 'metrics.csv',
        }
        (self.run_dir / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
        with (self.run_dir / 'summary.csv').open('x', newline='', encoding='utf-8') as stream:
            fields = ['version', 'status', 'exploration_pct', 'explored_area_m2',
                      'reachable_free_area_m2', 'known_area_pct', 'known_roi_area_m2',
                      'roi_area_m2', 'exploration_time_sim_s', 'total_time_sim_s',
                      'wall_time_s', 'reward_mode', 'robot1_reward', 'robot2_reward',
                      'robot1_returned', 'robot2_returned']
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerow({**{k: result.get(k) for k in fields},
                             'robot1_reward': self.reward_total['robot1'],
                             'robot2_reward': self.reward_total['robot2'],
                             'robot1_returned': self.return_ok['robot1'],
                             'robot2_returned': self.return_ok['robot2']})
        self.csv_file.close()
        self.get_logger().info(f'V3 {status}: exploration={coverage:.2f}% area={area:.2f}%')


def main():
    rclpy.init()
    node = ActiveSlamCoordinator()
    try:
        while rclpy.ok() and not node.done:
            rclpy.spin_once(node, timeout_sec=.5)
    except KeyboardInterrupt:
        node.finish('interrupted')
    finally:
        if not node.done:
            node.finish('interrupted')
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
