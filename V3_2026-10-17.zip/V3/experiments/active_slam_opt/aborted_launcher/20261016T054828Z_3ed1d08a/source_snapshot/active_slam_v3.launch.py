"""Launch isolated Gazebo, two real SLAM nodes, two Nav2 stacks, one coordinator."""
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, IncludeLaunchDescription, RegisterEventHandler, TimerAction
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.descriptions import ParameterFile
from nav2_common.launch import RewrittenYaml


def robot_nodes(name, x, y, run_dir):
    nav_file = str(Path(run_dir) / f'{name}_nav2.yaml')
    slam_file = str(Path(run_dir) / f'{name}_slam.yaml')
    model_file = str(Path(run_dir) / f'{name}.sdf')
    params = ParameterFile(RewrittenYaml(source_file=nav_file, root_key=name,
                                         param_rewrites={'use_sim_time': 'true'},
                                         convert_types=True), allow_substs=True)

    def static(parent, child, sx=0.0, sy=0.0, sz=0.0):
        return Node(package='tf2_ros', executable='static_transform_publisher', output='log',
                    arguments=['--x', str(sx), '--y', str(sy), '--z', str(sz),
                               '--frame-id', parent, '--child-frame-id', child])

    nodes = [
        # Gazebo's diff-drive odom already uses world coordinates at spawn.
        # An additional start translation here would double the robot pose.
        static('map', f'{name}/map'),
        static(f'{name}/map', f'{name}/odom'),
        static(f'{name}/base_footprint', f'{name}/base_link', 0.0, 0.0, .01),
        static(f'{name}/base_link', f'{name}/base_scan', -.064, 0.0, .121),
        Node(package='gazebo_ros', executable='spawn_entity.py', output='screen',
             arguments=['-entity', name, '-robot_namespace', f'/{name}', '-file', model_file,
                        '-x', str(x), '-y', str(y), '-z', '.01']),
        Node(package='slam_toolbox', executable='async_slam_toolbox_node', name='slam_toolbox',
             namespace=name, output='screen', parameters=[slam_file, {'use_sim_time': True}],
             # Humble slam_toolbox publishes absolute /map; keep each raw map
             # separate so only the coordinator owns the shared /map topic.
             remappings=[('/map', f'/{name}/map'),
                         ('/map_metadata', f'/{name}/map_metadata')]),
    ]
    nav_nodes = [
        ('nav2_controller', 'controller_server', 'controller_server', [('cmd_vel', 'cmd_vel_nav')]),
        ('nav2_smoother', 'smoother_server', 'smoother_server', []),
        ('nav2_planner', 'planner_server', 'planner_server', []),
        ('nav2_behaviors', 'behavior_server', 'behavior_server', []),
        ('nav2_bt_navigator', 'bt_navigator', 'bt_navigator', []),
        ('nav2_waypoint_follower', 'waypoint_follower', 'waypoint_follower', []),
        ('nav2_velocity_smoother', 'velocity_smoother', 'velocity_smoother',
         [('cmd_vel', 'cmd_vel_nav'), ('cmd_vel_smoothed', 'cmd_vel')]),
    ]
    # All TF frames are explicitly prefixed, so keep /tf global for the shared tree.
    for package, executable, node_name, remaps in nav_nodes:
        nodes.append(Node(package=package, executable=executable, name=node_name,
                          namespace=name, output='log', parameters=[params], remappings=remaps))
    nodes.append(Node(package='nav2_lifecycle_manager', executable='lifecycle_manager',
                      name='lifecycle_manager_navigation', namespace=name, output='screen',
                      parameters=[{'use_sim_time': True, 'autostart': True,
                                   'node_names': [item[2] for item in nav_nodes]}]))
    return nodes


def generate_launch_description():
    run_dir = LaunchConfiguration('run_dir')
    world = LaunchConfiguration('world')
    gazebo_share = get_package_share_directory('gazebo_ros')
    # OpaqueFunction evaluates the run path only after launch arguments are set.
    from launch.actions import OpaqueFunction

    def build(context):
        folder = run_dir.perform(context)
        world_file = world.perform(context)
        positions = [('robot1', -1.7, -2.5), ('robot2', -.7, -2.5)]
        gazebo = IncludeLaunchDescription(
            PythonLaunchDescriptionSource(str(Path(gazebo_share) / 'launch' / 'gazebo.launch.py')),
            launch_arguments={'world': world_file, 'gui': LaunchConfiguration('gui'),
                              'seed': LaunchConfiguration('seed'),
                              'verbose': 'false'}.items())
        coordinator = Node(package='active_slam_explore', executable='active_slam_coordinator',
                           output='screen', parameters=[{'use_sim_time': True, 'run_dir': folder,
                               'world_path': world_file, 'seed': LaunchConfiguration('seed'),
                               'reward_mode': LaunchConfiguration('reward_mode'),
                               'start_xy': [-1.7, -2.5, -.7, -2.5],
                               'coverage_target_pct': 95.0, 'known_area_target_pct': 95.0,
                               'max_wall_seconds': LaunchConfiguration('max_wall_seconds')}])
        return [gazebo,
                TimerAction(period=5.0, actions=robot_nodes(*positions[0], folder)),
                TimerAction(period=8.0, actions=robot_nodes(*positions[1], folder)),
                TimerAction(period=12.0, actions=[coordinator]),
                RegisterEventHandler(OnProcessExit(target_action=coordinator,
                                                   on_exit=[EmitEvent(event=Shutdown())]))]

    return LaunchDescription([
        DeclareLaunchArgument('world', description='Absolute SDF world path'),
        DeclareLaunchArgument('run_dir', description='Exclusive run directory prepared by runner'),
        DeclareLaunchArgument('seed', default_value='7'),
        DeclareLaunchArgument('reward_mode', default_value='shared'),
        DeclareLaunchArgument('max_wall_seconds', default_value='3600'),
        DeclareLaunchArgument('gui', default_value='true'),
        OpaqueFunction(function=build),
    ])
