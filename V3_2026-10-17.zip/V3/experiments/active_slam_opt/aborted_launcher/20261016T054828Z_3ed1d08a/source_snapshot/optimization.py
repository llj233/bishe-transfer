"""ROS-free policy helpers for isolated V3 optimization ablations."""
import math
from collections import deque


def zone(candidate, width=2.0):
    """Stable coarse area key; a corridor/room proxy, not room recognition."""
    return (math.floor(candidate.x / width), math.floor(candidate.y / width))


def normalized_score(candidate, path_m, other_visited, region, failures=0,
                     other_target=None, nominal_speed=.22, current_yaw=0.0):
    """Visible unknown cells per travel second, with explicit risk/overlap costs."""
    nearby = sum((candidate.cell[0]+dx, candidate.cell[1]+dy) in other_visited
                 for dx in range(-5, 6) for dy in range(-5, 6)) / 121.0
    overlap = 0.0 if other_target is None else max(
        0.0, 1.0 - math.hypot(candidate.x-other_target.x,
                              candidate.y-other_target.y) / 2.0)
    turn = math.atan2(math.sin(candidate.yaw-current_yaw),
                      math.cos(candidate.yaw-current_yaw))
    travel = path_m / nominal_speed + abs(turn) / 1.5 + 2.0
    gain = min(candidate.information / 50.0, 1.0)
    risk = min(.4 / max(candidate.clearance, .1), 2.0) / 2.0
    return gain / max(travel / 30.0, .1) - .25*risk - .25*nearby - .5*overlap - .2*failures


def should_switch(current_score, new_score, age_s, current_gain, current_safe,
                  min_interval=7.0, margin=.20):
    if not current_safe or current_gain < 2:
        return True
    return age_s >= min_interval and new_score > current_score * (1.0 + margin)


def assign_regions(names, poses, choices, held=None, width=2.0, score_fn=None):
    """Small deterministic greedy matching of robots to distinct candidate areas."""
    held = held or {}
    used = {zone(c, width) for c in held.values() if c is not None}
    result = {}
    pairs = []
    for name in names:
        if name in held or poses.get(name) is None:
            continue
        for candidate in choices:
            key = zone(candidate, width)
            if key in used:
                continue
            distance = math.hypot(candidate.x-poses[name][0],
                                  candidate.y-poses[name][1])
            score = (score_fn(name, candidate, distance) if score_fn else
                     min(candidate.information, 50)/50.0 - distance/12.0)
            pairs.append((score, name, key, candidate))
    for _, name, key, candidate in sorted(pairs, key=lambda row: row[0], reverse=True):
        if name not in result and key not in used:
            result[name] = candidate
            used.add(key)
    return result


def free_region_graph(region, values, width=2.0):
    """Sparse graph of coarse areas connected through observed free cells."""
    graph = {}
    for cy in range(region.height):
        for cx in range(region.width):
            cell = (cx, cy)
            if values[region.index(cell)] != 0:
                continue
            x, y = region.center(cell)
            key = (math.floor(x/width), math.floor(y/width))
            graph.setdefault(key, set())
            for other in ((cx+1, cy), (cx, cy+1)):
                if (other[0] >= region.width or other[1] >= region.height or
                        values[region.index(other)] != 0):
                    continue
                ox, oy = region.center(other)
                next_key = (math.floor(ox/width), math.floor(oy/width))
                if key != next_key:
                    graph[key].add(next_key)
                    graph.setdefault(next_key, set()).add(key)
    return graph


def graph_hops(graph, start):
    """Shortest region hop count from a robot's present area."""
    if start not in graph:
        return {}
    distances = {start: 0}
    queue = deque([start])
    while queue:
        current = queue.popleft()
        for neighbor in graph[current]:
            if neighbor not in distances:
                distances[neighbor] = distances[current] + 1
                queue.append(neighbor)
    return distances
