"""ROS-free map fusion, safe frontier candidates, and joint goal assignment.

The planner sees SLAM maps and a fixed rectangular ROI only. SDF ground truth
is held by the coordinator's evaluator and never passed into this module.
"""
from collections import deque
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class Region:
    x: float
    y: float
    width: int
    height: int
    resolution: float

    def cell(self, x, y):
        cx = math.floor((x - self.x) / self.resolution)
        cy = math.floor((y - self.y) / self.resolution)
        return (cx, cy) if 0 <= cx < self.width and 0 <= cy < self.height else None

    def center(self, cell):
        return self.x + (cell[0] + .5) * self.resolution, self.y + (cell[1] + .5) * self.resolution

    def index(self, cell):
        return cell[1] * self.width + cell[0]

    def neighbors(self, cell):
        x, y = cell
        return [(a, b) for a, b in ((x-1,y), (x+1,y), (x,y-1), (x,y+1))
                if 0 <= a < self.width and 0 <= b < self.height]


def yaw_of(q):
    return math.atan2(2 * (q.w*q.z + q.x*q.y), 1 - 2 * (q.y*q.y + q.z*q.z))


def fused_maps(region, local_maps, starts):
    """Project two SLAM occupancy grids into the common map using known start poses.

    starts are the measured initial map-frame alignments. Cells are recomputed
    from each current SLAM map, so loop-closure changes replace earlier poses.
    """
    occupied = [0] * (region.width * region.height)
    free = [0] * len(occupied)
    local_free = {name: set() for name in starts}
    for name, msg in local_maps.items():
        if msg is None:
            continue
        sx, sy, syaw = starts[name]
        c, s = math.cos(syaw), math.sin(syaw)
        origin = msg.info.origin.position
        oyaw = yaw_of(msg.info.origin.orientation)
        oc, os = math.cos(oyaw), math.sin(oyaw)
        w, h, res = msg.info.width, msg.info.height, msg.info.resolution
        for j in range(h):
            for i in range(w):
                value = msg.data[j*w+i]
                if value < 0:
                    continue
                lx, ly = (i+.5)*res, (j+.5)*res
                mx, my = origin.x + oc*lx - os*ly, origin.y + os*lx + oc*ly
                cell = region.cell(sx + c*mx - s*my, sy + s*mx + c*my)
                if cell is None:
                    continue
                index = region.index(cell)
                if value >= 65:
                    occupied[index] += 1
                elif value <= 25:
                    free[index] += 1
                    local_free[name].add(cell)
    values = [-1] * len(occupied)
    for i, (o, f) in enumerate(zip(occupied, free)):
        if o or f:
            # A moving teammate can be seen as an occupied cell in one map
            # while the other robot has driven through it. Prefer confirmed
            # free evidence on a tie; local laser costmaps still guard motion.
            values[i] = 100 if o > f else 0
    return values, local_free


def clear_traversed_occupied(region, values, tracks, radius=.30):
    """Remove teammate obstacle ghosts within a traveled robot footprint.

    Unknown cells stay unknown so the ROI-known metric still means observed.
    """
    cells = math.ceil(radius / region.resolution)
    offsets = [(dx, dy) for dx in range(-cells, cells + 1)
               for dy in range(-cells, cells + 1)
               if math.hypot(dx, dy) * region.resolution <= radius]
    for track in tracks:
        for x, y in track:
            for dx, dy in offsets:
                nx, ny = x + dx, y + dy
                if 0 <= nx < region.width and 0 <= ny < region.height:
                    index = region.index((nx, ny))
                    if values[index] == 100:
                        values[index] = 0


def frontiers(region, values, min_cluster=1):
    """Known free cells touching unknown cells, clustered by 4-connectivity."""
    cells = set()
    for y in range(region.height):
        for x in range(region.width):
            p = (x, y)
            if values[region.index(p)] == 0 and any(
                    values[region.index(n)] == -1 for n in region.neighbors(p)):
                cells.add(p)
    groups = []
    while cells:
        first = cells.pop()
        group = {first}
        queue = deque((first,))
        while queue:
            for other in region.neighbors(queue.popleft()):
                if other in cells:
                    cells.remove(other)
                    group.add(other)
                    queue.append(other)
        if len(group) >= min_cluster:
            groups.append(group)
    return sorted(groups, key=len, reverse=True)


def clearance(region, values):
    """Metric distance to known obstacles; unknown is not a wall.

    A frontier observation pose must be known free, but may stand next to
    unknown space to look through a doorway. Nav2 and the local laser layer
    retain responsibility for the actual route and nearby obstacles.
    """
    distance = [10**9] * len(values)
    queue = deque()
    for y in range(region.height):
        for x in range(region.width):
            p = (x, y)
            index = region.index(p)
            if values[index] == 100:
                distance[index] = 0
                queue.append(p)
    while queue:
        p = queue.popleft()
        step = distance[region.index(p)] + 1
        for n in region.neighbors(p):
            index = region.index(n)
            if step < distance[index]:
                distance[index] = step
                queue.append(n)
    return distance


def visible_unknown(region, values, cell, max_range=3.2, rays=36):
    """Approximate information gain: distinct unknown cells visible by raycast.

    Unknown contributes only its first cell on a ray; this is a documented
    proxy for expected entropy reduction, not an exact sensor probability model.
    """
    seen = set()
    x, y = region.center(cell)
    for k in range(rays):
        angle = 2 * math.pi * k / rays
        dx, dy = region.resolution * math.cos(angle), region.resolution * math.sin(angle)
        for t in range(1, int(max_range / region.resolution) + 1):
            p = region.cell(x + t*dx, y + t*dy)
            if p is None:
                break
            value = values[region.index(p)]
            if value == 100:
                break
            if value == -1:
                seen.add(p)
                break
    return len(seen)


@dataclass(frozen=True)
class Candidate:
    cell: tuple
    x: float
    y: float
    yaw: float
    information: int
    clearance: float
    cluster_size: int


def candidates(region, values, limit=36, safe_radius=.38):
    """Select observation poses on known floor, behind each frontier boundary."""
    groups = frontiers(region, values)
    if not groups:
        return []
    gaps = clearance(region, values)
    output = []
    selected_groups = []
    group_margin = min(.7, .15*min(region.width, region.height)*region.resolution)
    pose_margin = min(.8, .15*min(region.width, region.height)*region.resolution)
    for group in groups:
        fx = sum(p[0] for p in group) / len(group)
        fy = sum(p[1] for p in group) / len(group)
        gx, gy = region.center((round(fx), round(fy)))
        boundary = min(gx-region.x, gy-region.y,
                       region.x+region.width*region.resolution-gx,
                       region.y+region.height*region.resolution-gy)
        if boundary < group_margin or any(math.hypot(gx-old[0], gy-old[1]) < 1.2
                               for old in selected_groups):
            continue
        selected_groups.append((gx, gy))
        if len(selected_groups) > 32:
            break
        choices = []
        pool = {}
        # Search a small annulus; the target itself is never an unknown cell.
        perimeter = sorted(group, key=lambda q: math.atan2(q[1]-fy, q[0]-fx))
        sampled = [perimeter[k*len(perimeter)//min(8, len(perimeter))]
                   for k in range(min(8, len(perimeter)))]
        for p in sampled:
            nearby = []
            for dx in range(-7, 8, 2):
                for dy in range(-7, 8, 2):
                    q = (p[0]+dx, p[1]+dy)
                    if not (0 <= q[0] < region.width and 0 <= q[1] < region.height):
                        continue
                    index = region.index(q)
                    gap = gaps[index]*region.resolution
                    if values[index] != 0 or gap < safe_radius:
                        continue
                    # Avoid goals too far from the boundary.
                    if math.hypot(dx, dy)*region.resolution > 1.1:
                        continue
                    nearby.append((math.hypot(dx, dy), -gap, q))
            # Raycast only a few close, safe poses per frontier sample.
            for _, _, q in sorted(nearby)[:3]:
                pool[q] = gaps[region.index(q)] * region.resolution
        for q, gap in pool.items():
            gain = visible_unknown(region, values, q)
            if gain < 4:
                continue
            x, y = region.center(q)
            if min(x-region.x, y-region.y,
                   region.x+region.width*region.resolution-x,
                   region.y+region.height*region.resolution-y) < pose_margin:
                continue
            tx, ty = region.center((round(fx), round(fy)))
            choices.append(Candidate(q, x, y, math.atan2(ty-y, tx-x),
                                     gain, gap, len(group)))
        choices.sort(key=lambda p: (p.information, p.clearance), reverse=True)
        spread = []
        for choice in choices:
            if all(math.hypot(choice.x-old.x, choice.y-old.y) >= .7 for old in spread):
                spread.append(choice)
            if len(spread) == 2:
                break
        output.extend(spread)
        if len(output) >= limit:
            break
    # Duplicate candidates from nearby groups are removed deterministically.
    unique = {c.cell: c for c in output}
    return sorted(unique.values(), key=lambda p: p.information, reverse=True)[:limit]


def utility(candidate, path_length, other_visited, region, failure_count=0):
    """Normalized gain, novelty, Nav2 distance, and collision/failure risk."""
    own_cell = candidate.cell
    nearby_other = sum((own_cell[0]+dx, own_cell[1]+dy) in other_visited
                       for dx in range(-5, 6) for dy in range(-5, 6)) / 121
    information = min(candidate.information / 25, 2)
    revisit_reduction = 1 - nearby_other
    risk = 1 / max(.1, candidate.clearance) + failure_count
    return 3*information + 1.2*revisit_reduction - .30*path_length - .25*risk


def diverse_choices(choices, limit=8, minimum=1.2):
    """Keep one promising view per area before spending Nav2 path probes."""
    selected = []
    for candidate in choices:
        if all(math.hypot(candidate.x-old.x, candidate.y-old.y) >= minimum
               for old in selected):
            selected.append(candidate)
        if len(selected) >= limit:
            break
    return selected


def segment_endpoint(points, segment_length=1.2):
    """Pick a short return waypoint on a Nav2 path; accept (x, y) points."""
    if not points:
        return None
    lengths = [0.0]
    for first, second in zip(points, points[1:]):
        lengths.append(lengths[-1] + math.hypot(second[0]-first[0],
                                                 second[1]-first[1]))
    if lengths[-1] <= segment_length + .5:
        return len(points)-1
    for index, distance in enumerate(lengths):
        if distance >= segment_length:
            return index
    return len(points)-1


def separated(candidate, other_goal, other_pose, minimum=1.5):
    """Reserve different work zones and keep Nav2 destinations apart."""
    return (other_goal is None or math.hypot(candidate.x-other_goal.x,
                                             candidate.y-other_goal.y) >= minimum) and (
            other_pose is None or math.hypot(candidate.x-other_pose[0],
                                              candidate.y-other_pose[1]) >= .8)


def best_unreserved(scored, other_goal, other_pose):
    """Recheck reservations at dispatch time after asynchronous path probes."""
    for entry in sorted(scored, key=lambda item: item[0], reverse=True):
        if separated(entry[1], other_goal, other_pose):
            return entry
    return None
