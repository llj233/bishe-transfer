#!/usr/bin/env python3
"""Prepare an isolated V3 optimization ablation run (B0-B4)."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET

import yaml


ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / 'models/turtlebot3_waffle_pi_fast/model.sdf'
NAV2 = Path('/opt/ros/humble/share/nav2_bringup/params/nav2_params.yaml')
SLAM = Path('/opt/ros/humble/share/slam_toolbox/config/mapper_params_online_async.yaml')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def model_for(name, output):
    tree = ET.parse(MODEL)
    root = tree.getroot()
    root.find('.//plugin[@name="turtlebot3_laserscan"]/frame_name').text = f'{name}/base_scan'
    # Max-range beams without a wall hit are not reliable free-space evidence
    # in slam_toolbox. Let scans through a doorway hit the next room's wall.
    laser = root.find('.//sensor[@name="hls_lfcd_lds"]')
    laser.find('./ray/range/max').text = '10.0'
    laser.find('./ray/scan/horizontal/samples').text = '180'
    laser.find('./update_rate').text = '3'
    drive = root.find('.//plugin[@name="turtlebot3_diff_drive"]')
    drive.find('odometry_frame').text = f'{name}/odom'
    drive.find('robot_base_frame').text = f'{name}/base_footprint'
    # The V2 camera contributes no information to active SLAM and costs GUI FPS.
    camera = root.find('.//sensor[@name="camera"]')
    if camera is not None:
        for link in root.findall('.//link'):
            if camera in list(link):
                link.remove(camera)
                break
    for visual in root.findall('.//sensor/visualize'):
        visual.text = 'false'
    # gazebo_ros/spawn_entity.py reads the file as Unicode; lxml rejects an
    # encoding declaration in that API, so write the SDF without one.
    tree.write(output, encoding='unicode', xml_declaration=False)


def configs(name, folder):
    slam = yaml.safe_load(SLAM.read_text())['slam_toolbox']['ros__parameters']
    slam.update({'odom_frame': f'{name}/odom', 'map_frame': f'{name}/map',
                 'base_frame': f'{name}/base_footprint', 'scan_topic': f'/{name}/scan',
                 'resolution': .1, 'map_update_interval': 2.0,
                 'minimum_travel_distance': .25, 'minimum_travel_heading': .25,
                 'enable_interactive_mode': False, 'max_laser_range': 10.0,
                 'do_loop_closing': False, 'transform_publish_period': 0.0,
                 # Gazebo odom starts in the common world coordinates. A
                 # static map->odom TF avoids SLAM TF stalls in this sim.
                 'use_sim_time': True})
    (folder / f'{name}_slam.yaml').write_text(
        yaml.safe_dump({f'/{name}/slam_toolbox': {'ros__parameters': slam}}, sort_keys=False))
    nav = yaml.safe_load(NAV2.read_text())
    nav['bt_navigator']['ros__parameters']['robot_base_frame'] = f'{name}/base_footprint'
    nav['bt_navigator']['ros__parameters']['odom_topic'] = f'/{name}/odom'
    controller = nav['controller_server']['ros__parameters']
    controller['controller_frequency'] = 8.0
    controller['progress_checker']['required_movement_radius'] = .08
    controller['progress_checker']['movement_time_allowance'] = 25.0
    controller['general_goal_checker']['xy_goal_tolerance'] = .35
    controller['general_goal_checker']['yaw_goal_tolerance'] = .8
    controller['FollowPath']['vx_samples'] = 8
    controller['FollowPath']['vtheta_samples'] = 12
    controller['FollowPath']['max_vel_x'] = .30
    controller['FollowPath']['max_speed_xy'] = .30
    controller['FollowPath']['BaseObstacle.scale'] = .1
    for layer, frame in (('local_costmap', f'{name}/odom'), ('global_costmap', 'map')):
        costmap = nav[layer][layer]['ros__parameters']
        costmap['global_frame'] = frame
        costmap['robot_base_frame'] = f'{name}/base_footprint'
        costmap['update_frequency'] = 2.0 if layer == 'local_costmap' else 1.0
        costmap['publish_frequency'] = 1.0
        for key in ('obstacle_layer', 'voxel_layer'):
            if key in costmap:
                costmap[key]['scan']['topic'] = f'/{name}/scan'
        if layer == 'local_costmap':
            costmap['plugins'] = ['obstacle_layer', 'inflation_layer']
            costmap['obstacle_layer'] = {
                'plugin': 'nav2_costmap_2d::ObstacleLayer', 'observation_sources': 'scan',
                'scan': {'topic': f'/{name}/scan', 'data_type': 'LaserScan',
                         'clearing': True, 'marking': True, 'obstacle_max_range': 3.0,
                         'raytrace_max_range': 3.5}}
            costmap['width'] = 4
            costmap['height'] = 4
            costmap['inflation_layer']['inflation_radius'] = .55
        else:
            # Shared SLAM map supplies fixed walls. The local obstacle layer
            # still detects the other robot; global scan obstacles can make
            # a known narrow doorway appear permanently impassable.
            costmap['plugins'] = ['static_layer', 'inflation_layer']
            costmap['static_layer']['map_topic'] = '/map'
            costmap['static_layer']['map_subscribe_transient_local'] = True
            costmap['inflation_layer']['inflation_radius'] = .60
    nav['planner_server']['ros__parameters']['GridBased']['allow_unknown'] = False
    nav['behavior_server']['ros__parameters']['global_frame'] = f'{name}/odom'
    nav['behavior_server']['ros__parameters']['robot_base_frame'] = f'{name}/base_footprint'
    nav['velocity_smoother']['ros__parameters']['odom_topic'] = f'/{name}/odom'
    (folder / f'{name}_nav2.yaml').write_text(yaml.safe_dump(nav, sort_keys=False))
    model_for(name, folder / f'{name}.sdf')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--world', type=Path, default=ROOT / 'worlds/fast/room.world')
    parser.add_argument('--seed', type=int, default=7)
    parser.add_argument('--reward-mode', choices=['shared', 'independent'], default='shared')
    parser.add_argument('--ablation', choices=['B0', 'B1', 'B2', 'B3', 'B4'], default='B0')
    parser.add_argument('--stage', choices=['pilot', 'formal'], default='pilot')
    parser.add_argument('--gui', choices=['true', 'false'], default='true')
    parser.add_argument('--max-wall-seconds', type=float, default=3600)
    parser.add_argument('--background', action='store_true',
                        help='Detach the Gazebo/ROS launch so it survives terminal closure')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    world = args.world.resolve()
    if not all(p.is_file() for p in (world, MODEL, NAV2, SLAM)):
        parser.error('World, robot model, Nav2 and slam_toolbox parameter files are required')
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8]
    folder = (ROOT / 'experiments/active_slam_opt' / args.stage / world.stem /
              f'seed_{args.seed:06d}' / args.reward_mode / args.ablation / run_id)
    folder.mkdir(parents=True, exist_ok=False)
    frozen_world = folder / 'world.sdf'
    shutil.copy2(world, frozen_world)
    source_files = {
        'planning.py': ROOT / 'src/active_slam_explore/active_slam_explore/planning.py',
        'coordinator.py': ROOT / 'src/active_slam_explore/active_slam_explore/coordinator.py',
        'active_slam_v3.launch.py': ROOT / 'src/active_slam_explore/launch/active_slam_v3.launch.py',
        'run_active_slam_v3.py': Path(__file__).resolve(),
        'coordinator_opt.py': ROOT / 'src/active_slam_explore/active_slam_explore/coordinator_opt.py',
        'optimization.py': ROOT / 'src/active_slam_explore/active_slam_explore/optimization.py',
        'active_slam_opt.launch.py': ROOT / 'src/active_slam_explore/launch/active_slam_opt.launch.py',
        'dual_explore_core.py': ROOT / 'src/dual_explore/dual_explore/core.py',
        'dual_explore_mapping.py': ROOT / 'src/dual_explore/dual_explore/mapping.py',
    }
    snapshot = folder / 'source_snapshot'
    snapshot.mkdir()
    for filename, original in source_files.items():
        shutil.copy2(original, snapshot / filename)
    for name in ('robot1', 'robot2'):
        configs(name, folder)
    domain = 20 + (int(uuid.uuid4().hex[:4], 16) % 180)
    gazebo_port = 12000 + (int(uuid.uuid4().hex[:4], 16) % 16000)
    manifest = {
        'version': f'v3_opt_{args.ablation}', 'ablation': args.ablation,
        'created_utc': run_id, 'source_world': str(world),
        'world_sha256': sha(world), 'model_sha256': sha(MODEL), 'seed': args.seed,
        'source_sha256': {name: sha(path) for name, path in source_files.items()},
        'stage': args.stage, 'reward_mode': args.reward_mode,
        'start_xy': [-1.7, -2.5, -.7, -2.5],
        'coverage_target_pct': 95.0, 'known_area_target_pct': 95.0,
        'roi_definition': 'SDF outer wall bounds at 0.1m; only evaluator reads collisions',
        'ros_domain_id': domain, 'gazebo_master_uri': f'http://127.0.0.1:{gazebo_port}',
        'gui': args.gui, 'max_wall_seconds': args.max_wall_seconds,
    }
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    cmd = ['ros2', 'launch', 'active_slam_explore', 'active_slam_opt.launch.py',
           f'world:={frozen_world}', f'run_dir:={folder}', f'seed:={args.seed}',
           f'reward_mode:={args.reward_mode}', f'ablation:={args.ablation}',
           f'gui:={args.gui}',
           f'max_wall_seconds:={args.max_wall_seconds}']
    print(f'run_dir={folder}', flush=True)
    print(' '.join(cmd), flush=True)
    if args.dry_run:
        return
    env = os.environ.copy()
    env['ROS_DOMAIN_ID'] = str(domain)
    env['GAZEBO_MASTER_URI'] = manifest['gazebo_master_uri']
    env['LIBGL_ALWAYS_SOFTWARE'] = env.get('LIBGL_ALWAYS_SOFTWARE', '1')
    env['RCUTILS_LOGGING_BUFFERED_STREAM'] = '1'
    with (folder / 'launch.log').open('x', encoding='utf-8') as output:
        process = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=output,
                                   stderr=subprocess.STDOUT,
                                   start_new_session=args.background)
        if args.background:
            (folder / 'launch.pid').write_text(f'{process.pid}\n', encoding='utf-8')
            print(f'detached_pid={process.pid} monitor={folder / "metrics.csv"}', flush=True)
            return
        try:
            code = process.wait()
        except KeyboardInterrupt:
            process.send_signal(__import__('signal').SIGINT)
            code = process.wait(timeout=40)
    print(f'launch_exit={code} result={folder / "result.json"}', flush=True)
    if not (folder / 'result.json').exists():
        print('No result.json; inspect launch.log', file=sys.stderr)
        sys.exit(2)
    result = json.loads((folder / 'result.json').read_text())
    print(json.dumps({k: result[k] for k in ('status', 'exploration_pct', 'known_area_pct',
                                           'exploration_time_sim_s', 'reward_total')},
                     ensure_ascii=False), flush=True)
    sys.exit(0 if result['status'] == 'completed' else 1)


if __name__ == '__main__':
    main()
