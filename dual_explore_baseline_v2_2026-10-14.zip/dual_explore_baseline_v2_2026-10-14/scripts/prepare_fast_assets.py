"""Build non-destructive, lighter Gazebo assets for two-camera experiments."""

from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SOURCE_MODEL = Path('/opt/ros/humble/share/turtlebot3_gazebo/models/turtlebot3_waffle_pi/model.sdf')


def create_model():
    tree = ET.parse(SOURCE_MODEL)
    sdf = tree.getroot()
    camera = sdf.find('.//sensor[@name="camera"]')
    if camera is None:
        raise ValueError('Waffle Pi camera sensor missing')
    camera.find('update_rate').text = '5'
    camera.find('always_on').text = 'false'  # No GPU camera work without subscribers.
    camera.find('./camera/image/width').text = '160'
    camera.find('./camera/image/height').text = '120'
    camera.find('./camera/clip/far').text = '10'
    visualize = camera.find('visualize')
    if visualize is not None:
        visualize.text = 'false'
    imu = sdf.find('.//sensor[@name="tb3_imu"]/update_rate')
    if imu is not None:
        imu.text = '50'
    destination = ROOT / 'models' / 'turtlebot3_waffle_pi_fast' / 'model.sdf'
    destination.parent.mkdir(parents=True, exist_ok=True)
    # spawn_entity.py parses the file as a Unicode string and rejects an XML
    # encoding declaration, although Gazebo itself accepts one.
    tree.write(destination, encoding='utf-8', xml_declaration=False)
    print(destination)


def create_worlds():
    for source in sorted((ROOT / 'worlds' / 'prepared').glob('*.world')):
        tree = ET.parse(source)
        world = tree.getroot().find('world')
        world.find('./scene/shadows').text = '0'
        for light in world.findall('light'):
            cast = light.find('cast_shadows')
            if cast is not None:
                cast.text = '0'
        physics = world.find('physics')
        physics.find('max_step_size').text = '0.005'
        physics.find('real_time_update_rate').text = '200'
        destination = ROOT / 'worlds' / 'fast' / source.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        tree.write(destination, encoding='utf-8', xml_declaration=True)
        print(destination)


if __name__ == '__main__':
    create_model()
    create_worlds()
