"""Export per-run and paired reward comparisons from isolated run folders."""

import argparse
import csv
import json
from pathlib import Path
import statistics


RUN_FIELDS = ('map', 'seed', 'reward_mode', 'frontier_assist', 'status', 'stop_reason',
              'coverage_target_pct', 'target_reached', 'fused_coverage_pct',
              'truth_reachable_free_cells', 'fused_true_free_cells',
              'robot1_coverage_pct', 'robot2_coverage_pct',
              'overlap_true_free_cells', 'robot1_total_reward',
              'robot2_total_reward', 'team_cumulative_reward',
              'robot1_near_collision_ticks',
              'robot2_near_collision_ticks', 'q_states', 'sim_elapsed_s',
              'wall_elapsed_s', 'real_time_factor', 'run_dir')
CURVE_FIELDS = ('map', 'seed', 'reward_mode', 'frontier_assist', 'step', 'exploration_elapsed_s',
                'fused_coverage_pct', 'robot1_reward', 'robot2_reward',
                'robot1_cumulative_reward', 'robot2_cumulative_reward',
                'team_cumulative_reward', 'run_dir')
PAIR_FIELDS = ('map', 'seed', 'independent_coverage_pct',
               'shared_coverage_pct', 'shared_minus_independent_pp',
               'independent_rtf', 'shared_rtf', 'pair_status')


def _write_csv(path, fields, rows):
    with path.open('w', newline='', encoding='utf-8-sig') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def export(root):
    root = Path(root)
    rows = []
    curve_rows = []
    run_dirs = ({path.parent for path in root.glob('*/seed_*/*/summary.json')} |
                {path.parent for path in root.glob('*/seed_*/*/run_config.json')})
    plan_path = root / 'plan.json'
    if plan_path.exists():
        plan = json.loads(plan_path.read_text(encoding='utf-8'))
        run_dirs.update(root / map_name / f'seed_{seed:06d}' / mode
                        for map_name in plan['maps']
                        for seed in plan['seeds'] for mode in plan['groups'])
    for run_dir in sorted(run_dirs):
        path = run_dir / 'summary.json'
        summary = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
        config_path = run_dir / 'run_config.json'
        config = json.loads(config_path.read_text(encoding='utf-8')) if config_path.exists() else {}
        per = summary.get('per_robot', {})
        status = summary.get('status', 'interrupted' if (run_dir / 'operator_stop.txt').exists()
                             else 'failed' if (run_dir / 'runner_error.txt').exists()
                             else 'not_run')
        row = {
            'map': run_dir.parents[1].name,
            'seed': int(run_dir.parent.name.removeprefix('seed_')),
            'reward_mode': run_dir.name,
            'frontier_assist': summary.get('frontier_assist', config.get('frontier_assist', '')),
            'status': status,
            'stop_reason': summary.get('stop_reason', ''),
            'coverage_target_pct': summary.get('coverage_target_pct', config.get('coverage_target_pct', '')),
            'target_reached': summary.get('target_reached', ''),
            'fused_coverage_pct': summary.get('fused_coverage_pct', ''),
            'truth_reachable_free_cells': summary.get('truth_reachable_free_cells', ''),
            'fused_true_free_cells': summary.get('fused_true_free_cells', ''),
            'robot1_coverage_pct': per.get('robot1', {}).get('coverage_pct', ''),
            'robot2_coverage_pct': per.get('robot2', {}).get('coverage_pct', ''),
            'overlap_true_free_cells': summary.get('overlap_true_free_cells', ''),
            'robot1_total_reward': per.get('robot1', {}).get('total_reward', ''),
            'robot2_total_reward': per.get('robot2', {}).get('total_reward', ''),
            'team_cumulative_reward': summary.get('team_cumulative_reward', ''),
            'robot1_near_collision_ticks': per.get('robot1', {}).get('near_collision_ticks', ''),
            'robot2_near_collision_ticks': per.get('robot2', {}).get('near_collision_ticks', ''),
            'q_states': summary.get('q_states', ''),
            'sim_elapsed_s': summary.get('sim_elapsed_s', ''),
            'wall_elapsed_s': summary.get('wall_elapsed_s', ''),
            'real_time_factor': summary.get('real_time_factor', ''),
            'run_dir': str(run_dir),
        }
        rows.append(row)
        metrics_path = run_dir / 'metrics.csv'
        if metrics_path.exists():
            steps = {}
            with metrics_path.open(newline='', encoding='utf-8') as stream:
                for metric in csv.DictReader(stream):
                    steps.setdefault(int(metric['step']), {})[metric['robot']] = metric
            if not summary and steps:
                latest = next((pair for _, pair in sorted(steps.items(), reverse=True)
                               if 'robot1' in pair and 'robot2' in pair), None)
                if latest:
                    first, second = latest['robot1'], latest['robot2']
                    r1, r2 = float(first['cumulative_reward']), float(second['cumulative_reward'])
                    row.update(status=('interrupted' if (run_dir / 'operator_stop.txt').exists()
                                       else 'failed' if (run_dir / 'runner_error.txt').exists()
                                       else 'running'),
                               fused_coverage_pct=first['fused_coverage_pct'],
                               robot1_coverage_pct=first['local_coverage_pct'],
                               robot2_coverage_pct=second['local_coverage_pct'],
                               robot1_total_reward=r1, robot2_total_reward=r2,
                               team_cumulative_reward=(r1 + r2) / (2 if row['reward_mode'] == 'shared' else 1),
                               fused_true_free_cells=first['fused_true_free'],
                               truth_reachable_free_cells=first['truth_reachable_free'],
                               sim_elapsed_s=first['exploration_elapsed_s'])
            for step, robots in sorted(steps.items()):
                if 'robot1' not in robots or 'robot2' not in robots:
                    continue
                first, second = robots['robot1'], robots['robot2']
                r1, r2 = float(first['cumulative_reward']), float(second['cumulative_reward'])
                curve_rows.append({
                    'map': row['map'], 'seed': row['seed'], 'reward_mode': row['reward_mode'],
                    'frontier_assist': row['frontier_assist'],
                    'step': step, 'exploration_elapsed_s': first['exploration_elapsed_s'],
                    'fused_coverage_pct': first['fused_coverage_pct'],
                    'robot1_reward': first['reward'], 'robot2_reward': second['reward'],
                    'robot1_cumulative_reward': r1, 'robot2_cumulative_reward': r2,
                    'team_cumulative_reward': (r1 + r2) / (2 if row['reward_mode'] == 'shared' else 1),
                    'run_dir': str(run_dir),
                })
    _write_csv(root / 'runs.csv', RUN_FIELDS, rows)
    _write_csv(root / 'reward_coverage.csv', CURVE_FIELDS, curve_rows)
    groups = {}
    for row in rows:
        key = row['map'], row['seed']
        if row['reward_mode'] in groups.setdefault(key, {}):
            raise ValueError(f'Duplicate experiment for {key}, {row["reward_mode"]}')
        groups[key][row['reward_mode']] = row
    pairs = []
    for (map_name, seed), arms in sorted(groups.items()):
        independent, shared = arms.get('independent'), arms.get('shared')
        complete = bool(independent and shared and
                        independent['status'] == shared['status'] == 'completed')
        pair = {
            'map': map_name, 'seed': seed,
            'independent_coverage_pct': independent['fused_coverage_pct'] if independent else '',
            'shared_coverage_pct': shared['fused_coverage_pct'] if shared else '',
            'shared_minus_independent_pp':
                round(float(shared['fused_coverage_pct']) -
                      float(independent['fused_coverage_pct']), 4) if complete else '',
            'independent_rtf': independent['real_time_factor'] if independent else '',
            'shared_rtf': shared['real_time_factor'] if shared else '',
            'pair_status': 'complete' if complete else 'incomplete',
        }
        pairs.append(pair)
    _write_csv(root / 'comparison.csv', PAIR_FIELDS, pairs)
    lines = ['# 独立奖励与共享奖励对照', '',
             '| 地图 | 种子 | 独立覆盖率 % | 共享覆盖率 % | 共享－独立百分点 | 状态 |',
             '|---|---:|---:|---:|---:|---|']
    for row in pairs:
        lines.append('| {map} | {seed} | {independent_coverage_pct} | '
                     '{shared_coverage_pct} | {shared_minus_independent_pp} | '
                     '{pair_status} |'.format(**row))
    complete = [float(row['shared_minus_independent_pp']) for row in pairs
                if row['pair_status'] == 'complete']
    lines.extend(('', f'完整配对数：{len(complete)}。'
                  + (f'共享－独立平均差：{statistics.mean(complete):.3f} 个百分点。'
                     if complete else '尚无可比较的完整配对。'),
                  '覆盖率 = 融合图中已观测真值可达空闲格 / SDF 真值可达空闲格。',
                  '该指标依赖里程计对齐；它不是 SLAM 定位精度。'))
    (root / 'comparison.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return len(rows), len(complete)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('experiment_root', type=Path)
    args = parser.parse_args()
    print('runs, complete_pairs =', export(args.experiment_root))
