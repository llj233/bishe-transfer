"""Freeze the verified Baseline v2 source, assets, and experiment evidence."""

import hashlib
import json
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parents[1]
NAME = 'dual_explore_baseline_v2_2026-10-14'
RUN = Path('experiments/long_gui_room_seed7_target95_frontier_v4')
OUTPUT = Path.home() / 'Downloads' / f'baseline_upload_v2_2026-10-14'
EVIDENCE = (
    'plan.json', 'runs.csv', 'reward_coverage.csv', 'result_summary.zh-CN.md',
    'room/seed_000007/shared/room.world',
    'room/seed_000007/shared/run_config.json',
    'room/seed_000007/shared/summary.json',
    'room/seed_000007/shared/metrics.csv',
    'room/seed_000007/shared/q_table.json',
    'room/seed_000007/shared/fused_map.pgm',
    'room/seed_000007/shared/fused_map.yaml',
    'room/seed_000007/shared/launch.log',
)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def files_to_freeze():
    docs = ('BASELINE.md', 'EXPERIMENTS.zh-CN.md', 'README.md',
            'README_dual.md', 'CODE_WALKTHROUGH.zh-CN.md')
    files = [ROOT / name for name in docs]
    for directory in ('src/dual_explore', 'scripts', 'models', 'worlds', 'tests'):
        files.extend(path for path in (ROOT / directory).rglob('*')
                     if path.is_file() and '__pycache__' not in path.parts
                     and path.suffix not in ('.pyc', '.pyo'))
    files.extend(ROOT / RUN / name for name in EVIDENCE)
    return sorted(set(files), key=lambda path: str(path.relative_to(ROOT)))


def main():
    plan = json.loads((ROOT / RUN / 'plan.json').read_text(encoding='utf-8'))
    summary = json.loads((ROOT / RUN / 'room/seed_000007/shared/summary.json').read_text(
        encoding='utf-8'))
    if (summary['status'] != 'completed' or not summary['target_reached'] or
            summary['stop_reason'] != 'coverage_target' or
            summary['fused_coverage_pct'] < 95 or not summary['frontier_assist']):
        raise ValueError('Evidence is not the verified 95% frontier-assisted baseline')
    expected = dict(plan['code_sha256'])
    expected['worlds/fast/room.world'] = plan['world_sha256']['room']
    expected['models/turtlebot3_waffle_pi_fast/model.sdf'] = plan['model_sha256']
    for name, digest in expected.items():
        if sha256((ROOT / name).read_bytes()) != digest:
            raise ValueError(f'Source or asset changed since the verified run: {name}')
    files = files_to_freeze()
    if any(not path.is_file() for path in files):
        raise FileNotFoundError('A baseline file is missing')
    OUTPUT.mkdir(parents=True, exist_ok=False)
    archive = OUTPUT / f'{NAME}.zip'
    manifest = {'baseline': NAME, 'date': '2026-10-14',
                'experiment': str(RUN), 'files': {}}
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as stream:
        for path in files:
            relative = path.relative_to(ROOT).as_posix()
            data = path.read_bytes()
            manifest['files'][relative] = {'sha256': sha256(data), 'bytes': len(data)}
            info = zipfile.ZipInfo(f'{NAME}/{relative}', (2026, 10, 14, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            stream.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED,
                            compresslevel=9)
        data = (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()
        info = zipfile.ZipInfo(f'{NAME}/MANIFEST.json', (2026, 10, 14, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        stream.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    digest = sha256(archive.read_bytes())
    (OUTPUT / f'{archive.name}.sha256').write_text(f'{digest}  {archive.name}\n',
                                                    encoding='utf-8')
    (OUTPUT / 'README.md').write_text(
        '# Baseline v2 上传包\n\n'
        '当前基线：双机器人共享表格 Q-learning＋前沿导航辅助，room 地图、种子 7、'
        '融合真值覆盖率 95.0543%。旧 v1 为历史基线。\n\n'
        f'- 压缩包：`{archive.name}`\n'
        f'- SHA-256：`{digest}`\n'
        '- 推荐上传到 GitHub 仓库的 `baselines/dual_explore_v2_2026-10-14/`。\n'
        '- 包内 `BASELINE.md` 说明算法、运行命令和局限；`MANIFEST.json` 校验每个文件。\n'
        '- 包含源码、快速场景与模型、测试、95% 达标运行的最终表、逐步曲线和融合地图。\n',
        encoding='utf-8')
    with zipfile.ZipFile(archive) as stream:
        for relative, record in manifest['files'].items():
            if sha256(stream.read(f'{NAME}/{relative}')) != record['sha256']:
                raise ValueError(f'Archive verification failed: {relative}')
    print(f'{archive}\nSHA-256 {digest}\n{len(files)} files verified')


if __name__ == '__main__':
    main()
