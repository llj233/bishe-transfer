"""Run paired, isolated Gazebo experiments; never reuse Q tables or logs."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

from export_results import export


ROOT = Path(__file__).resolve().parents[1]
MAPS = tuple(path.stem for path in sorted((ROOT / 'worlds' / 'fast').glob('*.world')))
GROUPS = ('independent', 'shared')
CODE_PATHS = ('src/dual_explore/dual_explore/core.py',
              'src/dual_explore/dual_explore/frontier.py',
              'src/dual_explore/dual_explore/mapping.py',
              'src/dual_explore/dual_explore/experiment_node.py',
              'src/dual_explore/launch/mapped_experiment.launch.py')


def file_sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def simulator_running():
    return any(subprocess.run(['pgrep', '-x', name], capture_output=True).returncode == 0
               for name in ('gzserver', 'gzclient', 'mapped_explorer'))


def execute(command, environment, log_path, timeout):
    with log_path.open('w', encoding='utf-8') as log:
        process = subprocess.Popen(command, cwd=ROOT, env=environment,
                                   stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        try:
            deadline = time.monotonic() + timeout if timeout else None
            while True:
                try:
                    return process.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    if deadline is not None and time.monotonic() >= deadline:
                        raise TimeoutError(f'Experiment exceeded {timeout} wall seconds')
                    # A failed robot spawn will otherwise wait for sensors forever.
                    for line in log_path.read_text(encoding='utf-8', errors='replace').splitlines()[-20:]:
                        if 'process has died' in line and any(
                                name in line for name in ('spawn_entity.py', 'mapped_explorer')):
                            raise RuntimeError(line)
        except (TimeoutError, RuntimeError, KeyboardInterrupt):
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGINT)
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--maps', nargs='+', choices=MAPS, default=list(MAPS))
    parser.add_argument('--seeds', nargs='+', type=int, default=[7, 17, 27])
    parser.add_argument('--groups', nargs='+', choices=GROUPS, default=list(GROUPS))
    parser.add_argument('--steps', type=int, default=600,
                        help='Simulation-time control steps per robot, 0 disables step limit')
    parser.add_argument('--target-coverage', type=float, default=0.,
                        help='Stop at this fused true-map coverage percentage; 0 disables target')
    parser.add_argument('--timeout', type=int, default=1800,
                        help='Wall-clock timeout for each run; 0 waits for the stop condition')
    parser.add_argument('--output', type=Path,
                        default=ROOT / 'experiments' /
                        datetime.now(timezone.utc).strftime('experiment_%Y%m%dT%H%M%SZ'))
    parser.add_argument('--gui', action='store_true', help='Use Gazebo window for a manual run')
    parser.add_argument('--camera', action='store_true',
                        help='Subscribe to the 160x120 camera; default is laser-only for speed')
    parser.add_argument('--frontier-assist', action='store_true',
                        help='After coverage stagnates, navigate to frontiers in the fused laser map')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    if (args.steps < 0 or args.timeout < 0 or not 0 <= args.target_coverage <= 100 or
            not (args.steps or args.target_coverage) or not args.seeds or
            any(seed < 0 for seed in args.seeds)):
        parser.error('Need steps > 0 and/or target coverage > 0; timeout and seeds must be nonnegative')
    if len(set(args.seeds)) != len(args.seeds) or len(set(args.groups)) != len(args.groups):
        parser.error('duplicate seeds or groups are not allowed')
    combos = [(map_name, seed, group) for map_name in args.maps
              for seed in args.seeds for group in args.groups]
    if len(combos) > 170:
        parser.error('at most 170 runs per batch, for unique ROS_DOMAIN_ID values')
    output = args.output.resolve()
    if output.exists():
        parser.error(f'output already exists: {output}; choose a new directory')
    for map_name, seed, group in combos:
        print(f'{map_name:22s} seed={seed:<6d} {group:11s} -> '
              f'{output / map_name / f"seed_{seed:06d}" / group}')
    if args.dry_run:
        return 0
    if simulator_running():
        parser.error('Gazebo or mapped_explorer is already running; stop it before a formal batch')
    install = ROOT / 'install' / 'setup.bash'
    if not install.is_file():
        parser.error('Build the workspace first: colcon build --symlink-install')
    model = ROOT / 'models' / 'turtlebot3_waffle_pi_fast' / 'model.sdf'
    code_hashes = {name: file_sha256(ROOT / name) for name in CODE_PATHS}
    world_hashes = {name: file_sha256(ROOT / 'worlds' / 'fast' / f'{name}.world')
                    for name in args.maps}
    model_hash = file_sha256(model)
    output.mkdir(parents=True, exist_ok=False)
    plan = {'maps': args.maps, 'seeds': args.seeds, 'groups': args.groups,
            'steps_per_robot': args.steps, 'coverage_target_pct': args.target_coverage,
            'world_variant': 'fast',
            'use_camera': args.camera, 'frontier_assist': args.frontier_assist,
            'robot_starts': [[-1.7, -2.5], [-1.5, 3.3]],
            'coverage_resolution_m': .2,
            'code_sha256': code_hashes, 'world_sha256': world_hashes,
            'model_sha256': model_hash,
            'reward_only_difference': 'independent local novelty versus shared union novelty',
            'runs': len(combos)}
    (output / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
    failed = False
    for index, (map_name, seed, group) in enumerate(combos):
        if simulator_running():
            raise RuntimeError('Prior simulator process remains; refusing cross-run contamination')
        if (any(file_sha256(ROOT / name) != digest for name, digest in code_hashes.items()) or
                file_sha256(ROOT / 'worlds' / 'fast' / f'{map_name}.world') != world_hashes[map_name] or
                file_sha256(model) != model_hash):
            raise RuntimeError('Code or assets changed during batch; refusing incomparable runs')
        run_dir = output / map_name / f'seed_{seed:06d}' / group
        run_dir.mkdir(parents=True, exist_ok=False)
        source_world = ROOT / 'worlds' / 'fast' / f'{map_name}.world'
        world = run_dir / f'{map_name}.world'
        shutil.copy2(source_world, world)
        config = {'map': map_name, 'seed': seed, 'reward_mode': group,
                  'steps_per_robot': args.steps, 'coverage_target_pct': args.target_coverage,
                  'world_sha256': file_sha256(world),
                  'use_camera': args.camera, 'frontier_assist': args.frontier_assist,
                  'model_sha256': model_hash, 'code_sha256': code_hashes,
                  'ros_domain_id': 40 + index,
                  'gazebo_master_port': 11345 + index,
                  'run_dir': str(run_dir)}
        (run_dir / 'run_config.json').write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8')
        (run_dir / 'ros_logs').mkdir()
        (run_dir / 'gazebo_logs').mkdir()
        environment = os.environ.copy()
        environment.update({'ROS_DOMAIN_ID': str(40 + index),
                            'GAZEBO_MASTER_URI': f'http://127.0.0.1:{11345 + index}',
                            'ROS_LOG_DIR': str(run_dir / 'ros_logs'),
                            'GAZEBO_LOG_PATH': str(run_dir / 'gazebo_logs')})
        command = ['bash', '-c', 'source /opt/ros/humble/setup.bash && '
                   'source "$1" && exec ros2 launch dual_explore mapped_experiment.launch.py '
                   'world:="$2" run_dir:="$3" reward_mode:="$4" seed:="$5" '
                   'max_steps:="$6" gui:="$7" use_camera:="$8" coverage_target_pct:="$9" '
                   'frontier_assist:="${10}"',
                   'bash', str(install), str(world), str(run_dir), group,
                   str(seed), str(args.steps), str(args.gui).lower(), str(args.camera).lower(),
                   str(args.target_coverage), str(args.frontier_assist).lower()]
        print(f'RUN {index + 1}/{len(combos)} {map_name} seed={seed} {group}', flush=True)
        try:
            code = execute(command, environment, run_dir / 'launch.log', args.timeout)
            summary_path = run_dir / 'summary.json'
            summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}
            if (code != 0 or summary.get('status') != 'completed' or
                    (args.target_coverage and not summary.get('target_reached'))):
                raise RuntimeError(f'launch exit={code}, completed summary={summary_path.exists()}')
        except Exception as error:
            failed = True
            (run_dir / 'runner_error.txt').write_text(str(error) + '\n', encoding='utf-8')
            print(f'FAILED {run_dir}: {error}', file=sys.stderr, flush=True)
            break
        # Gazebo usually exits with launch. Do not start another group until it has.
        for _ in range(20):
            if not simulator_running():
                break
            time.sleep(.5)
    run_count, pair_count = export(output)
    print(f'Exported {run_count} runs and {pair_count} complete pairs to {output}')
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
