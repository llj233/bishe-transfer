"""Isolated two-robot mapping experiment with optional Gazebo GUI."""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, IncludeLaunchDescription, RegisterEventHandler, SetEnvironmentVariable, TimerAction
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    gazebo_share = get_package_share_directory('gazebo_ros')
    tb3_share = get_package_share_directory('turtlebot3_gazebo')
    own_share = get_package_share_directory('dual_explore')
    model = os.path.join(own_share, 'models', 'turtlebot3_waffle_pi_fast', 'model.sdf')
    if not os.path.isfile(model):
        raise FileNotFoundError(f'Run scripts/prepare_fast_assets.py and colcon build: {model}')
    world = LaunchConfiguration('world')
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(gazebo_share, 'launch', 'gazebo.launch.py')),
        launch_arguments={'world': world, 'gui': LaunchConfiguration('gui'),
                          'seed': LaunchConfiguration('seed'),
                          'verbose': 'false'}.items())

    def spawn(name, x, y):
        return Node(package='gazebo_ros', executable='spawn_entity.py', output='screen',
                    arguments=['-entity', name, '-robot_namespace', f'/{name}',
                               '-file', model, '-x', str(x), '-y', str(y), '-z', '0.01'])

    explorer = Node(
        package='dual_explore', executable='mapped_explorer', output='screen',
        parameters=[{'use_sim_time': True, 'robot_names': ['robot1', 'robot2'],
                     'spawn_offsets': [-1.7, -2.5, -1.5, 3.3],
                     'world_path': world, 'run_dir': LaunchConfiguration('run_dir'),
                     'reward_mode': LaunchConfiguration('reward_mode'),
                     'seed': LaunchConfiguration('seed'),
                     'max_steps': LaunchConfiguration('max_steps'),
                     'coverage_target_pct': LaunchConfiguration('coverage_target_pct'),
                     'frontier_assist': LaunchConfiguration('frontier_assist'),
                     'use_camera': LaunchConfiguration('use_camera')}])
    return LaunchDescription([
        DeclareLaunchArgument('world', description='Absolute prepared or fast SDF world path'),
        DeclareLaunchArgument('run_dir', description='Fresh, empty directory for this run'),
        DeclareLaunchArgument('reward_mode', default_value='shared',
                              description='independent or shared'),
        DeclareLaunchArgument('seed', default_value='7'),
        DeclareLaunchArgument('max_steps', default_value='600'),
        DeclareLaunchArgument('coverage_target_pct', default_value='0.0'),
        DeclareLaunchArgument('frontier_assist', default_value='false'),
        DeclareLaunchArgument('use_camera', default_value='false'),
        DeclareLaunchArgument('gui', default_value='false'),
        SetEnvironmentVariable('GAZEBO_MODEL_PATH',
                               os.path.join(tb3_share, 'models') + os.pathsep +
                               os.environ.get('GAZEBO_MODEL_PATH', '')),
        gazebo,
        TimerAction(period=5.0, actions=[spawn('robot1', -1.7, -2.5)]),
        TimerAction(period=8.0, actions=[spawn('robot2', -1.5, 3.3)]),
        explorer,
        RegisterEventHandler(OnProcessExit(target_action=explorer,
                                           on_exit=[EmitEvent(event=Shutdown())])),
    ])
