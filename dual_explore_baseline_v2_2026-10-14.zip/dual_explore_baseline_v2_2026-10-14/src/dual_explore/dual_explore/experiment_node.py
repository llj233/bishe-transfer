"""Two-robot mapping experiment with isolated rewards and ground-truth scoring."""

import csv
from collections import deque
import json
import math
import os
from pathlib import Path
import time

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import OccupancyGrid, Odometry
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy, qos_profile_sensor_data
from sensor_msgs.msg import Image, LaserScan

from .core import EscapeNavigator, SharedLearner, image_signature, safe_motion, scan_bins, state_from_sensors
from .frontier import FrontierNavigator
from .mapping import FusedLaserMap, GroundTruth, exploration_rewards


def quaternion_yaw(q):
    return math.atan2(2 * (q.w * q.z + q.x * q.y),
                      1 - 2 * (q.y * q.y + q.z * q.z))


class ExperimentComplete(Exception):
    """Leave the ROS executor after an experiment stop condition."""


class MappedExplorer(Node):
    """One controller, one shared Q table, two local maps and a fused map."""

    def __init__(self):
        super().__init__('mapped_explorer')
        for name, value in (
            ('robot_names', ['robot1', 'robot2']),
            ('spawn_offsets', [-1.7, -2.5, -1.5, 3.3]),
            ('world_path', ''), ('run_dir', ''), ('reward_mode', 'shared'),
            ('seed', 7), ('max_steps', 600), ('coverage_target_pct', 0.0),
            ('sensor_timeout', 3.0),
            ('map_resolution', 0.2), ('beam_stride', 4), ('train', True),
            ('use_camera', False), ('frontier_assist', False),
            ('stagnation_seconds', 30.0), ('stagnation_min_new_cells', 30),
        ):
            self.declare_parameter(name, value)
        self.names = tuple(self.get_parameter('robot_names').value)
        offsets = tuple(float(x) for x in self.get_parameter('spawn_offsets').value)
        if len(self.names) != 2 or len(offsets) != 4:
            raise ValueError('Mapped experiments require exactly two names and four spawn coordinates')
        self.starts = {name: (offsets[2 * i], offsets[2 * i + 1])
                       for i, name in enumerate(self.names)}
        self.world_path = Path(self.get_parameter('world_path').value).resolve()
        self.run_dir = Path(self.get_parameter('run_dir').value).resolve()
        if not self.world_path.is_file() or not self.run_dir.is_dir():
            raise ValueError('world_path must exist and run_dir must be pre-created by the runner')
        self.reward_mode = self.get_parameter('reward_mode').value
        if self.reward_mode not in ('independent', 'shared'):
            raise ValueError('reward_mode must be independent or shared')
        self.seed = int(self.get_parameter('seed').value)
        self.max_steps = int(self.get_parameter('max_steps').value)
        self.coverage_target_pct = float(self.get_parameter('coverage_target_pct').value)
        if self.max_steps < 0 or not 0 <= self.coverage_target_pct <= 100 or not (self.max_steps or self.coverage_target_pct):
            raise ValueError('Set a positive max_steps and/or coverage_target_pct in (0, 100]')
        self.training = bool(self.get_parameter('train').value)
        self.use_camera = bool(self.get_parameter('use_camera').value)
        self.frontier_assist = bool(self.get_parameter('frontier_assist').value)
        self.stagnation_seconds = float(self.get_parameter('stagnation_seconds').value)
        self.stagnation_min_new_cells = int(self.get_parameter('stagnation_min_new_cells').value)
        self.frontiers = {name: FrontierNavigator() for name in self.names}
        self.seen_window = deque()
        self.learner = SharedLearner(seed=self.seed)
        self.q_path = self.run_dir / 'q_table.json'
        if self.q_path.exists():
            raise FileExistsError(f'Run is not isolated: {self.q_path} already exists')
        self.truth = GroundTruth.from_sdf(self.world_path, self.starts.values(),
                                          resolution=float(self.get_parameter('map_resolution').value))
        self.mapping = FusedLaserMap(self.truth.grid, self.names,
                                     beam_stride=int(self.get_parameter('beam_stride').value))
        # Transient-local QoS lets RViz see the latest map after it starts.
        map_qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                             durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.map_publisher = self.create_publisher(OccupancyGrid, '/merged_map', map_qos)
        self.cmd_publishers = {}
        self.subscriptions_ = []
        self.robots = {}
        for i, name in enumerate(self.names):
            prefix = f'/{name}'
            self.robots[name] = {
                'scan': None, 'scan_msg': None,
                'image': None if self.use_camera else (0, 0, 0), 'odom': None,
                'odom_origin': None, 'scan_time': 0., 'image_time': 0., 'odom_time': 0.,
                'mapped_scan_time': -1., 'frames': 0, 'steps': 0, 'last': None,
                'avoid_turn': 0, 'local_cells': set(), 'last_new_cell': None,
                'escape': None, 'escape_started': 0., 'next_hand': -1 if i == 0 else 1,
                'total_reward': 0., 'near_collision_ticks': 0,
            }
            self.cmd_publishers[name] = self.create_publisher(Twist, f'{prefix}/cmd_vel', 10)
            self.subscriptions_.extend((
                self.create_subscription(LaserScan, f'{prefix}/scan',
                                         lambda msg, n=name: self.on_scan(n, msg), qos_profile_sensor_data),
                self.create_subscription(Odometry, f'{prefix}/odom',
                                         lambda msg, n=name: self.on_odom(n, msg), qos_profile_sensor_data),
            ))
            if self.use_camera:
                self.subscriptions_.append(self.create_subscription(
                    Image, f'{prefix}/camera/image_raw',
                    lambda msg, n=name: self.on_image(n, msg), qos_profile_sensor_data))
        self.log_file = (self.run_dir / 'metrics.csv').open('x', newline='', encoding='utf-8')
        self.writer = csv.writer(self.log_file)
        self.writer.writerow(('sim_time_s', 'exploration_elapsed_s', 'robot', 'step',
                              'reward_mode', 'reward', 'cumulative_reward',
                              'action', 'control_mode', 'x_world_m', 'y_world_m',
                              'yaw_world_rad', 'local_new_free', 'team_new_free',
                              'local_coverage_pct', 'fused_coverage_pct',
                              'fused_true_free', 'truth_reachable_free', 'image_frames'))
        self.start_wall = None
        self.start_sim = None
        self.last_map_publish = -1.
        self.closed = False
        self.wait_log_time = -10.
        self.timer = self.create_timer(.5, self.tick)  # With use_sim_time, equal simulation time.
        self.get_logger().info(f'world={self.world_path.name} mode={self.reward_mode} '
                               f'seed={self.seed} GT reachable cells={len(self.truth.reachable_free)}')

    def sim_now(self):
        return self.get_clock().now().nanoseconds / 1e9

    def on_scan(self, name, msg):
        robot = self.robots[name]
        robot['scan'] = scan_bins(msg.ranges, msg.range_min, msg.range_max)
        robot['scan_msg'] = msg
        robot['scan_time'] = self.sim_now()

    def on_odom(self, name, msg):
        p, q = msg.pose.pose.position, msg.pose.pose.orientation
        robot = self.robots[name]
        robot['odom'] = (p.x, p.y, quaternion_yaw(q))
        if robot['odom_origin'] is None:
            robot['odom_origin'] = robot['odom']
        robot['odom_time'] = self.sim_now()

    def on_image(self, name, msg):
        robot = self.robots[name]
        robot['image'] = image_signature(msg.data, msg.width, msg.height,
                                         msg.step, msg.encoding)
        robot['frames'] += 1
        robot['image_time'] = self.sim_now()

    def publish_velocity(self, name, command=(0., 0.)):
        message = Twist()
        message.linear.x, message.angular.z = command
        self.cmd_publishers[name].publish(message)

    def pose(self, name):
        robot = self.robots[name]
        ox, oy, oyaw = robot['odom_origin']
        x, y, yaw = robot['odom']
        sx, sy = self.starts[name]
        # Spawn yaw is zero; offsets put both odometry tracks in one map frame.
        return sx + x - ox, sy + y - oy, yaw - oyaw

    def publish_map(self):
        grid = self.truth.grid
        message = OccupancyGrid()
        message.header.stamp = self.get_clock().now().to_msg()
        message.header.frame_id = 'map'
        message.info.resolution = grid.resolution
        message.info.width, message.info.height = grid.width, grid.height
        message.info.origin.position.x = grid.x_min
        message.info.origin.position.y = grid.y_min
        message.info.origin.orientation.w = 1.
        message.data = self.mapping.occupancy_data()
        self.map_publisher.publish(message)

    def tick(self):
        now = self.sim_now()
        timeout = float(self.get_parameter('sensor_timeout').value)
        ready = all(
            robot['scan'] is not None and robot['odom'] is not None and
            (not self.use_camera or robot['image'] is not None) and
            all(0 <= now - robot[k] <= timeout for k in
                (('scan_time', 'image_time', 'odom_time') if self.use_camera
                 else ('scan_time', 'odom_time')))
            for robot in self.robots.values())
        if not ready:
            for name in self.names:
                self.publish_velocity(name)
            if now - self.wait_log_time >= 5.:
                self.get_logger().info('Waiting for fresh scan and odometry from both robots'
                                       + (' and image' if self.use_camera else ''))
                self.wait_log_time = now
            return
        if self.start_wall is None:
            self.start_wall, self.start_sim = time.monotonic(), now
        observations, local_gain = {}, {}
        team_gain = 0
        for name in self.names:
            robot = self.robots[name]
            x, y, yaw = self.pose(name)
            observations[name] = (x, y, yaw, robot['scan'], robot['image'])
            local_gain[name] = 0
            if robot['mapped_scan_time'] != robot['scan_time']:
                msg = robot['scan_msg']
                local_gain[name], added = self.mapping.update(
                    name, x, y, yaw, msg.ranges, msg.angle_min, msg.angle_increment,
                    msg.range_min, msg.range_max)
                team_gain += added
                robot['mapped_scan_time'] = robot['scan_time']
        fronts = {name: observations[name][3][4] for name in self.names}
        rewards = exploration_rewards(self.names, local_gain, team_gain,
                                      fronts, self.reward_mode)
        fused_n, truth_n, fused_pct = self.mapping.coverage(self.truth)
        seen_n = len(self.mapping.fused_seen_free)
        self.seen_window.append((now, seen_n))
        while len(self.seen_window) > 1 and self.seen_window[1][0] <= now - self.stagnation_seconds:
            self.seen_window.popleft()
        stagnant = (now - self.seen_window[0][0] >= self.stagnation_seconds - .51 and
                    seen_n - self.seen_window[0][1] < self.stagnation_min_new_cells)
        for name in self.names:
            robot = self.robots[name]
            x, y, yaw, scan, image = observations[name]
            state = state_from_sensors(scan, image)
            # Local visited cells only trigger doorway escape, not coverage scoring.
            cell = (math.floor(x / .5), math.floor(y / .5))
            if cell not in robot['local_cells']:
                robot['local_cells'].add(cell)
                robot['last_new_cell'] = now
            if robot['escape'] is not None and now - robot['escape_started'] > 120.:
                robot['escape'] = None
                robot['next_hand'] *= -1
                robot['last_new_cell'] = now
            if robot['escape'] is None and now - robot['last_new_cell'] > 12.:
                robot['escape'] = EscapeNavigator(robot['next_hand'])
                robot['escape_started'] = now
                robot['avoid_turn'] = 0
            if self.training and robot['last'] is not None:
                prev_state, prev_action = robot['last']
                self.learner.learn(prev_state, prev_action, rewards[name], state)
            action = self.learner.choose(state, self.training)
            other = next(n for n in self.names if n != name)
            frontier = self.frontiers[name]
            guided = None
            if self.frontier_assist and (frontier.goal is not None or stagnant):
                guided = frontier.step(self.mapping, (x, y, yaw), scan,
                                       robot['steps'], self.frontiers[other].goal)
            if guided is not None:
                command, control_mode = guided
                robot['escape'] = None
                robot['avoid_turn'] = 0
            elif robot['escape'] is None:
                command, robot['avoid_turn'], control_mode = safe_motion(
                    scan, action, robot['avoid_turn'])
            else:
                command, control_mode = robot['escape'].step(scan)
            self.publish_velocity(name, command)
            robot['last'] = (state, action) if control_mode == 'learn' else None
            robot['steps'] += 1
            robot['total_reward'] += rewards[name]
            robot['near_collision_ticks'] += int(fronts[name] < .25)
            _, _, local_pct = self.mapping.coverage(self.truth, name)
            self.writer.writerow((round(now, 3), round(now - self.start_sim, 3),
                                  name, robot['steps'], self.reward_mode,
                                  round(rewards[name], 4), round(robot['total_reward'], 4),
                                  action, control_mode,
                                  round(x, 3), round(y, 3), round(yaw, 3),
                                  local_gain[name], team_gain, round(local_pct * 100, 3),
                                  round(fused_pct * 100, 3), fused_n, truth_n, robot['frames']))
        if now - self.last_map_publish >= 2.:
            self.publish_map()
            self.last_map_publish = now
        if self.robots[self.names[0]]['steps'] % 20 == 0:
            self.log_file.flush()
            self.learner.save(self.q_path)
            self.get_logger().info(f'steps={self.robots[self.names[0]]["steps"]} '
                                   f'coverage={fused_pct * 100:.2f}% new={team_gain}')
        if self.coverage_target_pct and fused_pct * 100 >= self.coverage_target_pct:
            self.close(status='completed', stop_reason='coverage_target')
            raise ExperimentComplete
        if self.max_steps and all(self.robots[name]['steps'] >= self.max_steps for name in self.names):
            self.close(status='completed', stop_reason='step_limit')
            # Leave the executor callback; shutting rclpy down inside it can hang.
            raise ExperimentComplete

    def close(self, status='interrupted', stop_reason='interrupted'):
        if self.closed:
            return
        self.closed = True
        if rclpy.ok():
            for name in self.names:
                self.publish_velocity(name)
            self.publish_map()
        self.learner.save(self.q_path)
        self.log_file.close()
        self.write_map()
        numerator, denominator, fraction = self.mapping.coverage(self.truth)
        per_robot = {name: {'true_free_cells': self.mapping.coverage(self.truth, name)[0],
                            'coverage_pct': round(self.mapping.coverage(self.truth, name)[2] * 100, 4),
                            'steps': self.robots[name]['steps'],
                            'total_reward': round(self.robots[name]['total_reward'], 4),
                            'near_collision_ticks': self.robots[name]['near_collision_ticks']}
                     for name in self.names}
        overlap = len(set.intersection(*(self.mapping.local_seen_free[name] for name in self.names))
                      & self.truth.reachable_free)
        elapsed_wall = time.monotonic() - self.start_wall if self.start_wall else 0.
        elapsed_sim = self.sim_now() - self.start_sim if self.start_sim else 0.
        team_reward = (sum(self.robots[name]['total_reward'] for name in self.names) /
                       (len(self.names) if self.reward_mode == 'shared' else 1))
        summary = {'status': status, 'stop_reason': stop_reason,
                   'coverage_target_pct': self.coverage_target_pct,
                   'target_reached': bool(self.coverage_target_pct and fraction * 100 >= self.coverage_target_pct),
                   'team_cumulative_reward': round(team_reward, 4),
                   'world': str(self.world_path), 'map_name': self.world_path.stem,
                   'seed': self.seed, 'reward_mode': self.reward_mode,
                   'use_camera': self.use_camera,
                   'frontier_assist': self.frontier_assist,
                   'map_resolution_m': self.truth.grid.resolution,
                   'truth_reachable_free_cells': denominator,
                   'fused_true_free_cells': numerator,
                   'fused_coverage_pct': round(fraction * 100, 4),
                   'fused_seen_free_cells': len(self.mapping.fused_seen_free),
                   'overlap_true_free_cells': overlap, 'per_robot': per_robot,
                   'q_states': len(self.learner.q), 'sim_elapsed_s': round(elapsed_sim, 3),
                   'wall_elapsed_s': round(elapsed_wall, 3),
                   'real_time_factor': round(elapsed_sim / elapsed_wall, 4) if elapsed_wall else 0.}
        (self.run_dir / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n',
                                                   encoding='utf-8')
        self.get_logger().info(f'{status}: fused coverage={fraction * 100:.2f}% '
                               f'RTF={summary["real_time_factor"]:.2f}')

    def write_map(self):
        grid = self.truth.grid
        # PGM is flipped vertically for common image viewers; ROS map origin stays lower-left.
        values = self.mapping.occupancy_data()
        with (self.run_dir / 'fused_map.pgm').open('wb') as stream:
            stream.write(f'P5\n{grid.width} {grid.height}\n255\n'.encode('ascii'))
            for iy in reversed(range(grid.height)):
                stream.write(bytes(0 if v == 100 else 254 if v == 0 else 205
                                   for v in values[iy * grid.width:(iy + 1) * grid.width]))
        (self.run_dir / 'fused_map.yaml').write_text(
            f'image: fused_map.pgm\nresolution: {grid.resolution}\n'
            f'origin: [{grid.x_min}, {grid.y_min}, 0.0]\n'
            'negate: 0\noccupied_thresh: 0.65\nfree_thresh: 0.196\n', encoding='utf-8')


def main():
    rclpy.init()
    node = MappedExplorer()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExperimentComplete, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        node.close()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
