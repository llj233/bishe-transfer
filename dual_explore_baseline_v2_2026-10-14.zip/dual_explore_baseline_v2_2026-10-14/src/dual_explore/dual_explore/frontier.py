"""Navigate to frontiers using only the fused laser map, never SDF truth."""

from collections import deque
import math


def neighbors(cell, grid):
    x, y = cell
    for other in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
        if 0 <= other[0] < grid.width and 0 <= other[1] < grid.height:
            yield other


def choose_frontier(mapping, x, y, excluded=(), avoid=None):
    """Find a reachable observed-free boundary and a path through known free cells."""
    grid = mapping.grid
    free = mapping.fused_seen_free
    occupied = {cell for cell, score in mapping.fused_scores.items() if score >= .5}
    safe = free - occupied
    start = grid.cell(x, y)
    if not safe or start is None:
        return None
    if start not in safe:
        candidates = [cell for cell in safe if abs(cell[0] - start[0]) + abs(cell[1] - start[1]) <= 5]
        if not candidates:
            return None
        start = min(candidates, key=lambda cell: abs(cell[0] - start[0]) + abs(cell[1] - start[1]))
    excluded = set(excluded)
    previous = {start: None}
    distance = {start: 0}
    pending = deque([start])
    best = None
    best_score = -1.0
    while pending:
        cell = pending.popleft()
        steps = distance[cell]
        if cell not in excluded and steps >= 4 and (avoid is None or
                math.dist(cell, avoid) * grid.resolution >= 2.):
            unknown = sum((nx, ny) not in free and (nx, ny) not in occupied
                          for nx in range(max(0, cell[0] - 4), min(grid.width, cell[0] + 5))
                          for ny in range(max(0, cell[1] - 4), min(grid.height, cell[1] + 5)))
            if any(other not in free and other not in occupied
                   for other in neighbors(cell, grid)):
                score = unknown / (1. + .035 * steps)
                if score > best_score:
                    best, best_score = cell, score
        for other in neighbors(cell, grid):
            if other in safe and other not in previous:
                previous[other] = cell
                distance[other] = steps + 1
                pending.append(other)
    if best is None:
        return None
    path = []
    cell = best
    while cell is not None:
        path.append(cell)
        cell = previous[cell]
    path.reverse()
    return best, path


class FrontierNavigator:
    """Hold a frontier goal, retry elsewhere if progress stops."""

    def __init__(self):
        self.goal = None
        self.path = []
        self.excluded_until = {}
        self.best_distance = math.inf
        self.last_progress_step = 0

    def step(self, mapping, pose, scan, step, avoid=None):
        x, y, yaw = pose
        grid = mapping.grid
        self.excluded_until = {cell: until for cell, until in self.excluded_until.items()
                               if until > step}
        if self.goal is not None:
            gx, gy = grid.center(self.goal)
            goal_distance = math.hypot(gx - x, gy - y)
            if goal_distance < .45 or step - self.last_progress_step > 40:
                self.excluded_until[self.goal] = step + 240
                self.goal, self.path = None, []
            elif goal_distance < self.best_distance - .15:
                self.best_distance = goal_distance
                self.last_progress_step = step
        if self.goal is None:
            plan = choose_frontier(mapping, x, y, self.excluded_until, avoid)
            if plan is None:
                return None
            self.goal, self.path = plan
            gx, gy = grid.center(self.goal)
            self.best_distance = math.hypot(gx - x, gy - y)
            self.last_progress_step = step
        # Follow the first path cell at least 0.6 m ahead, then replan as needed.
        nearest = min(range(len(self.path)), key=lambda i:
                      math.dist(grid.center(self.path[i]), (x, y)))
        waypoint = grid.center(self.path[min(nearest + 3, len(self.path) - 1)])
        error = math.atan2(waypoint[1] - y, waypoint[0] - x) - yaw
        error = math.atan2(math.sin(error), math.cos(error))
        turn = max(-.9, min(.9, 1.5 * error))
        if scan[4] < .32:
            self.excluded_until[self.goal] = step + 120
            self.goal, self.path = None, []
            return (0., .9 if scan[1] >= scan[2] else -.9), 'frontier_avoid'
        if abs(error) > .35 or scan[4] < .5:
            return (0., turn if abs(turn) > .2 else (.6 if scan[1] >= scan[2] else -.6)), 'frontier_turn'
        return (.16, max(-.45, min(.45, turn))), 'frontier_drive'
