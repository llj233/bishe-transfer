# 双机器人地图融合与奖励对照实验

## 与 v1 基线的关系

`src/dual_explore/dual_explore/node.py` 和原来的 `dual_explore.launch.py` 是已归档的历史基线 v1。**当前基线 v2** 是 `mapped_explorer` 加 `--frontier-assist` 的固定版本，定义见 `BASELINE.md`：每台车从激光建立局部栅格，按已知出生坐标与里程计放进同一 `map` 坐标系，融合后发布 `/merged_map`，并保存 `fused_map.pgm`。这里**没有做 SLAM、回环检测或里程计漂移校正**。相机在对照实验中默认关闭；状态向量的后三个颜色分量固定为零。两组都使用相同观测设置。

## “真实地图覆盖率”的定义

`mapping.py` 从 Gazebo SDF 读取与机器人高度相交的固定 box 碰撞体，按 0.2 m 栅格栅格化，并按 0.22 m 机器人半径膨胀障碍。从两个出生位置向外做四邻域搜索，得到真值可达空闲格集合 `G`。上方门楣不阻挡地面机器人。地面 100×100 m 的无限式平面不算探索区域。

每台车把激光射线上的空闲格投影到共同坐标系，得到 `F1`、`F2`；融合图的已观测空闲集合是 `F = F1 ∪ F2`。表中的**融合覆盖率**为 `100 × |F ∩ G| / |G|`。分子必须是真值可达空闲格，不会因误把墙或地图外空间当成空闲而增加。另存的融合占据图将两车的空闲/障碍证据累加到一张图。由于位姿仍由出生位置加里程计估算，该指标会受里程计漂移影响；它是对 Gazebo 场景真值的覆盖评估，不是 SLAM 精度评估。

## 独立奖励与共享奖励

两组都由一个节点控制两台机器人，都**共用同一张 Q 表**，动作空间、学习率、折扣率、epsilon、避障/脱困规则、场景、出生位姿、种子和步数相同。唯一的实验自变量是奖励如何汇总：

- `independent`：各机器人得到自己局部地图新发现空闲格的奖励和自己的近障惩罚。
- `shared`：两车得到同一个团队奖励；新发现格按融合图去重，除以 2 保持与独立奖励相近的尺度，近障惩罚也取两车平均。

每车每周期奖励为 `-0.01 + 0.02 × min(新空闲格数, 50) - 近障惩罚`；正前方小于 0.25 m 触发惩罚。只有由 Q 表实际执行的动作才进入下一次 Q 更新，安全层和脱困层接管的动作不训练。这个设计比较的是**奖励共享**，不是“共享策略 vs 独立策略”。

## 速度设置

原模型每车相机为 640×480、30 Hz，原世界开启阴影并用 1000 Hz 物理步。`scripts/prepare_fast_assets.py` 生成独立的快速资产：相机 160×120、5 Hz 且默认不激活，阴影关闭，物理步为 0.005 s / 200 Hz，激光仍为 360 束、5 Hz。建图每 4 束取 1 束，控制每 0.5 **仿真秒**进行一次。正式批量实验默认 `gui=false`；查看窗口时加 `--gui`。`summary.json` 中的 `real_time_factor` 是仿真时间除以实际耗时，可用来量化加速结果；Gazebo 窗口的显示帧率还取决于虚拟机图形驱动。

## 运行

```bash
cd ~/single_ros2_prototype
source /opt/ros/humble/setup.bash
python3 scripts/prepare_fast_assets.py
colcon build --symlink-install
source install/setup.bash

# 先看计划，不创建文件或启动 Gazebo。
python3 scripts/run_experiments.py --dry-run

# 正式配对：6 个固定地图 × 3 个种子 × 2 组，每车 600 步。
python3 scripts/run_experiments.py --maps corner corridor loop loop_with_corridor room room_with_corner --seeds 7 17 27 --steps 600 --output experiments/formal_v1

# 用仿真窗口短试运行；正式大批量建议不加 --gui。
DISPLAY=:0 python3 scripts/run_experiments.py --maps room --seeds 7 --steps 40 --gui --output experiments/gui_check

# 窗口长试验：两车融合真值覆盖率达到 95% 才停止；0 表示不设步数和实际时间上限。
DISPLAY=:0 python3 scripts/run_experiments.py --maps room --seeds 7 --groups shared --steps 0 --target-coverage 95 --timeout 0 --gui --output experiments/long_gui_room_seed7_target95

# 若基线控制器长期重复已知路线，可在新目录开启基于融合激光地图的前沿导航辅助。
DISPLAY=:0 python3 scripts/run_experiments.py --maps room --seeds 7 --groups shared --steps 0 --target-coverage 95 --timeout 0 --gui --frontier-assist --output experiments/long_gui_room_seed7_target95_frontier_v4

# 任意时刻重新导出已有完成的运行记录。
python3 scripts/export_results.py experiments/formal_v1
```

完整批次会消耗较长时间。先用 `--maps room --seeds 7 --steps 40` 做烟雾试验；这类短试验的数据不可解释为正式效果。`--camera` 可尝试打开低分辨率相机，但会增加渲染成本，而且在某些无界面虚拟机上可能没有图像数据。

## 隔离和导出

运行器为每个 `地图/seed_XXXXXX/奖励组` 创建新目录，包含本次 SDF 副本、配置与哈希、单独 Q 表、逐步 CSV、融合地图、汇总 JSON、ROS/Gazebo 日志。它拒绝使用已存在的输出目录，也拒绝在有 Gazebo 进程时开始批次；每次运行使用不同的 `ROS_DOMAIN_ID` 和 `GAZEBO_MASTER_URI`。批次记录源码、模型和场景哈希，运行途中发现文件变动就停止。学习器在实验目录里只从空 Q 表开始，绝不读取 `~/.dual_explore_q.json`。Gazebo 与 Q 学习器使用相同的种子，独立/共享两组按同一地图与种子配对。

批次根目录生成：

- `runs.csv`：每次运行的覆盖率、两车各自覆盖、重复观测、奖励、近障次数、Q 状态数、实时因子；预定但尚未执行或失败的组也会列出状态。
- `reward_coverage.csv`：每步的融合真值覆盖率、探索仿真时长、两车单步与累计奖励、团队累计奖励。共享奖励模式下，两车得到同一个奖励，团队累计奖励只计一次；独立模式下把两车奖励相加。
- `comparison.csv`：同地图同种子的独立/共享覆盖率及差值（百分点）；缺少一组时标成 `incomplete`，不计算差值。
- `comparison.md`：可直接阅读的对照表。只有完整配对才计算平均差。

完整的正式比较应检查多种子配对差异，而不是根据一次短试验判定哪种奖励更好。
`runs.csv` 的 `sim_elapsed_s` 是探索阶段的仿真时间，`wall_elapsed_s` 是实际耗时；`target_reached` 和 `stop_reason` 用于核实是否真正因 95% 门槛结束。若地图或策略无法达到门槛，`--steps 0 --timeout 0` 会持续运行，须人工决定是否中断；中断后的结果不能写成已达标。
`--frontier-assist` 在过去 30 仿真秒内融合激光图新增空闲格少于 30 个时，使用**融合激光图的已观测空闲格**规划到未知边界；它改变了控制策略，因此带辅助与不带辅助的运行必须分开标注。触发、前沿目标和路径都不读取 SDF 真值。该辅助接管时的动作不写入 Q 学习更新，但覆盖奖励仍正常累计。

## 已完成的短试验

`experiments/pilot_2026-10-14_room_seed7_v6/` 是已完成的 `room`、种子 7、两组各 40 步的配对烟雾试验。`comparison.md` 和 `comparison.csv` 给出独立奖励 13.2147%、共享奖励 12.3979%，差值为 -0.8168 个百分点；这只验证数据链路和导出逻辑。另有 `experiments/gui_check_2026-10-14/` 的单组窗口试运行，仿真实时因子为 0.9986；该数值不能当作窗口画面 FPS。

`experiments/long_gui_room_seed7_target95_frontier_v4/` 是已完成的窗口长试验：`room`、种子 7、共享奖励、前沿导航辅助，融合真值覆盖率达到 95.0543% 后自动停止。最终结果见该目录的 `result_summary.zh-CN.md`、`runs.csv` 与 `reward_coverage.csv`。前面未达标或设计修正前的试运行分别保存在 `long_gui_room_seed7_target95/` 和 `long_gui_room_seed7_target95_frontier_v2/v3/`，不得计作达标结果。
