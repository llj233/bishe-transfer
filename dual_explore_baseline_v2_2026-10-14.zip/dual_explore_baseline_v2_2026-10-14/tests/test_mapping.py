"""Checks that truth, sensor fusion, reward arms and fast assets agree."""

import math
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src' / 'dual_explore'))
from dual_explore.mapping import Box, FusedLaserMap, GroundTruth, exploration_rewards
sys.path.insert(0, str(ROOT / 'scripts'))
from export_results import export


def test_ground_truth_for_all_six_worlds():
    for path in sorted((ROOT / 'worlds' / 'fast').glob('*.world')):
        truth = GroundTruth.from_sdf(path, [(-1.7, -2.5), (-1.5, 3.3)])
        assert len(truth.reachable_free) > 1000, path
        assert truth.grid.cell(-1.7, -2.5) in truth.reachable_free
        assert truth.grid.cell(-1.5, 3.3) in truth.reachable_free
        assert truth.obstacles  # A real SDF obstacle mask was constructed.


def test_laser_maps_fuse_in_one_grid_and_coverage_is_bounded():
    walls = [Box(0, 2, 0, 4, .2), Box(0, -2, 0, 4, .2),
             Box(2, 0, 0, .2, 4), Box(-2, 0, 0, .2, 4)]
    truth = GroundTruth(walls, [(-1, 0), (1, 0)], resolution=.2)
    mapping = FusedLaserMap(truth.grid, ('robot1', 'robot2'), beam_stride=1)
    scan = [1., 1., 1., 1.]
    first_local, first_team = mapping.update('robot1', -1, 0, 0, scan,
                                              0, math.pi / 2, .12, 3.5)
    second_local, second_team = mapping.update('robot2', 1, 0, 0, scan,
                                                0, math.pi / 2, .12, 3.5)
    assert first_local == first_team > 0
    assert 0 < second_team <= second_local
    observed, total, fraction = mapping.coverage(truth)
    assert 0 < observed <= total
    assert 0 < fraction <= 1
    assert observed >= mapping.coverage(truth, 'robot1')[0]
    assert observed >= mapping.coverage(truth, 'robot2')[0]
    assert len(mapping.occupancy_data()) == truth.grid.width * truth.grid.height


def test_room_doorway_is_free_but_outer_wall_is_occupied():
    truth = GroundTruth.from_sdf(ROOT / 'worlds/fast/room.world',
                                 [(-1.7, -2.5), (-1.5, 3.3)])
    assert truth.grid.cell(4, 7) in truth.reachable_free  # Door lintel is above robot.
    assert truth.grid.cell(10, 0) in truth.obstacles


def test_reward_arms_only_change_aggregation():
    names = ('robot1', 'robot2')
    local = {'robot1': 10, 'robot2': 2}
    fronts = {'robot1': 1., 'robot2': 1.}
    independent = exploration_rewards(names, local, 12, fronts, 'independent')
    shared = exploration_rewards(names, local, 12, fronts, 'shared')
    assert independent['robot1'] != independent['robot2']
    assert shared['robot1'] == shared['robot2']
    assert abs(sum(independent.values()) - sum(shared.values())) < 1e-9


def test_fast_assets_reduce_render_work_without_changing_original_world():
    source = ET.parse('/opt/ros/humble/share/turtlebot3_gazebo/models/turtlebot3_waffle_pi/model.sdf')
    fast = ET.parse(ROOT / 'models/turtlebot3_waffle_pi_fast/model.sdf')
    get = lambda tree, path: tree.getroot().findtext(path)
    assert get(source, './/sensor[@name="camera"]/camera/image/width') == '640'
    assert get(fast, './/sensor[@name="camera"]/camera/image/width') == '160'
    assert get(fast, './/sensor[@name="camera"]/update_rate') == '5'
    prepared = ET.parse(ROOT / 'worlds/prepared/room.world')
    fast_world = ET.parse(ROOT / 'worlds/fast/room.world')
    assert get(prepared, './world/scene/shadows') == '1'
    assert get(fast_world, './world/scene/shadows') == '0'


def test_export_pairs_only_complete_runs_and_runner_refuses_reuse(tmp_path):
    for mode, coverage in (('independent', 12.0), ('shared', 15.0)):
        run = tmp_path / 'room' / 'seed_000007' / mode
        run.mkdir(parents=True)
        (run / 'summary.json').write_text(json.dumps({
            'seed': 7, 'reward_mode': mode, 'status': 'completed',
            'fused_coverage_pct': coverage, 'real_time_factor': 1.0,
        }), encoding='utf-8')
    assert export(tmp_path) == (2, 1)
    comparison = (tmp_path / 'comparison.csv').read_text(encoding='utf-8-sig')
    assert '3.0' in comparison and 'complete' in comparison
    (tmp_path / 'plan.json').write_text(json.dumps({
        'maps': ['room', 'corridor'], 'seeds': [7],
        'groups': ['independent', 'shared']}), encoding='utf-8')
    assert export(tmp_path) == (4, 1)
    comparison = (tmp_path / 'comparison.csv').read_text(encoding='utf-8-sig')
    assert 'corridor,7,,,,' in comparison and 'incomplete' in comparison
    refusal = subprocess.run([sys.executable, str(ROOT / 'scripts/run_experiments.py'),
                              '--maps', 'room', '--seeds', '7', '--steps', '20',
                              '--output', str(tmp_path), '--dry-run'],
                             capture_output=True, text=True)
    assert refusal.returncode == 2
    assert 'already exists' in refusal.stderr
