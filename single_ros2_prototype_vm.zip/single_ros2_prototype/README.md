# ROS 2 Humble 单机探索最小闭环

适用：Ubuntu 22.04、ROS 2 Humble、Gazebo Classic。`worlds/original/` 保存 Explore-Bench 的六张原始 SDF 地图，固定到提交 `ce3b98a09bf593b0716b26555dc4cccbd9e83cd3`。`worlds/prepared/` 是删除原项目 ROS 1 专用 `libgazebo_2Dmap_plugin.so` 后的可加载版本。原 Explore-Bench 整套程序使用 ROS 1 Melodic，本工程只复用地图，不依赖它的 ROS 1 节点。

## 复制进 VM

将整个 `single_ros2_prototype` 文件夹通过 VMware/VirtualBox 共享文件夹、拖放或 U 盘复制到 VM 的 `~/single_ros2_prototype`。六张地图已包含在文件夹中；无需在 VM 重新下载。若以后想从上游重新获取，运行 `python3 scripts/download_worlds.py`。

## 安装与编译

以下命令在 VM 的 Ubuntu 终端执行。先确认 `echo $ROS_DISTRO` 显示 `humble`，或运行第一条 `source` 命令。

```bash
source /opt/ros/humble/setup.bash
sudo apt update
sudo apt install -y ros-humble-gazebo-ros-pkgs ros-humble-turtlebot3-gazebo python3-colcon-common-extensions
cd ~/single_ros2_prototype
python3 scripts/prepare_world.py room
colcon build --symlink-install
source install/setup.bash
```

如 `ros-humble-turtlebot3-gazebo` 在当前 apt 源不存在，请先确认 ROS 2 Humble 官方 apt 源已经配置，再执行 `apt-cache policy ros-humble-turtlebot3-gazebo`。不要把上游 ROS 1 `sim_env` 直接放进这个 colcon 工作区。

## 单机运行

```bash
cd ~/single_ros2_prototype
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch dual_explore single_explore.launch.py world:=$PWD/worlds/prepared/room.world
```

启动文件会打开 Gazebo Classic、在 `(-2.0, -2.5)` 放置 Waffle Pi，并启动 `q_explorer`。节点订阅 `/camera/image_raw`、`/scan`、`/odom`，发布 `/cmd_vel`。每秒执行一步离散 Q-learning：视觉颜色签名与三段激光距离组成观测；新访问的 0.5 m 网格奖励 +1，新视觉签名 +0.1，靠近障碍惩罚 -1，每步 -0.01。现在的“探索”用里程计近似计数，还不是 SLAM 地图覆盖率。预留的 `SharedLearner` 可供后续两台机器人共用。

## 验收

另开一个 VM 终端，执行：

```bash
source /opt/ros/humble/setup.bash
source ~/single_ros2_prototype/install/setup.bash
ros2 topic hz /camera/image_raw
ros2 topic hz /scan
ros2 topic hz /odom
ros2 topic echo /cmd_vel --once
tail -f ~/dual_explore.csv
```

正常时，终端每 10 步打印 `ready steps=... image_frames=... visited=...`，CSV 中 `step` 和 `image_frames` 持续增加，机器人会移动。按 Ctrl+C 后 Q 表保存在 `~/.dual_explore_q.json`；训练时每 10 步也会保存一次。若一直出现 `waiting for fresh scan/odom/rgb8 image`，先用 `ros2 topic list` 核对相机话题，必要时运行 `ros2 run dual_explore q_explorer --ros-args -p image_topic:=/实际话题` 单独诊断。若 Gazebo 图形窗口在 VM 内无法显示，先检查虚拟机 3D 加速和 OpenGL；仍可通过话题和 CSV 判断链路。

## 换地图

```bash
cd ~/single_ros2_prototype
python3 scripts/prepare_world.py corridor
ros2 launch dual_explore single_explore.launch.py world:=$PWD/worlds/prepared/corridor.world
```

其它地图名：`corner`、`loop`、`loop_with_corridor`、`room_with_corner`。每张图的安全出生点可能不同，换图时若机器人出现在墙内，请修改 `src/dual_explore/launch/single_explore.launch.py` 的 `-x`、`-y` 参数并重新 `colcon build --symlink-install`。

## 来源

- [Explore-Bench 地图目录](https://github.com/efc-robot/Explore-Bench/tree/master/sim_env/worlds)
- [Explore-Bench README](https://github.com/efc-robot/Explore-Bench)
- [TurtleBot3 Gazebo 模型](https://github.com/ROBOTIS-GIT/turtlebot3_simulations/tree/humble/turtlebot3_gazebo/models/turtlebot3_waffle_pi)
