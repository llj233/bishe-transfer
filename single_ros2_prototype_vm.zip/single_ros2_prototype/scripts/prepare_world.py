"""Remove Explore-Bench's unavailable ROS 1 Gazebo world plugin from an SDF world."""
from pathlib import Path
import argparse
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('name', choices=('corner', 'corridor', 'loop', 'loop_with_corridor', 'room', 'room_with_corner'))
args = parser.parse_args()

source = root / 'worlds' / 'original' / f'{args.name}.world'
if not source.is_file():
    raise SystemExit(f'Missing {source}; run scripts/download_worlds.py first')
tree = ET.parse(source)
world = tree.getroot().find('world')
if world is None:
    raise SystemExit('SDF has no world element')
removed = 0
for plugin in list(world.findall('plugin')):
    if plugin.get('filename') == 'libgazebo_2Dmap_plugin.so':
        world.remove(plugin)
        removed += 1
destination = root / 'worlds' / 'prepared' / source.name
destination.parent.mkdir(parents=True, exist_ok=True)
tree.write(destination, encoding='utf-8', xml_declaration=True)
print(f'{destination.resolve()} (removed {removed} ROS 1 occupancy plugin)')
