"""Download the six unmodified Explore-Bench SDF worlds at a pinned revision."""
from pathlib import Path
from urllib.request import urlopen
import hashlib

COMMIT = 'ce3b98a09bf593b0716b26555dc4cccbd9e83cd3'
NAMES = ('corner', 'corridor', 'loop', 'loop_with_corridor', 'room', 'room_with_corner')
ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'worlds' / 'original'
DEST.mkdir(parents=True, exist_ok=True)

for name in NAMES:
    url = f'https://raw.githubusercontent.com/efc-robot/Explore-Bench/{COMMIT}/sim_env/worlds/{name}.world'
    data = urlopen(url, timeout=30).read()
    if not data.lstrip().startswith(b'<sdf'):
        raise SystemExit(f'Unexpected response for {url}')
    path = DEST / f'{name}.world'
    path.write_bytes(data)
    print(f'{path}: {len(data)} bytes sha256={hashlib.sha256(data).hexdigest()}')
