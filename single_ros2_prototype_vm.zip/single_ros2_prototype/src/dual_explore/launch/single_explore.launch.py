"""Explore-Bench world + Gazebo Classic TurtleBot3 Waffle Pi + Q learner."""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    world = LaunchConfiguration('world')
    gazebo_share = get_package_share_directory('gazebo_ros')
    tb3_share = get_package_share_directory('turtlebot3_gazebo')
    robot = os.path.join(tb3_share, 'models', 'turtlebot3_waffle_pi', 'model.sdf')
    if not os.path.isfile(robot):
        raise FileNotFoundError(f'Install ros-humble-turtlebot3-gazebo: {robot}')

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(gazebo_share, 'launch', 'gazebo.launch.py')),
        launch_arguments={'world': world, 'verbose': 'true'}.items())
    spawn = Node(
        package='gazebo_ros', executable='spawn_entity.py', output='screen',
        arguments=['-entity', 'waffle_pi', '-file', robot,
                   '-x', '-2.0', '-y', '-2.5', '-z', '0.01'])
    learner = Node(
        package='dual_explore', executable='q_explorer', output='screen',
        parameters=[{'robot_names': ['robot'], 'train': True,
                     'image_topic': '/camera/image_raw'}])
    return LaunchDescription([
        DeclareLaunchArgument('world', description='Absolute path to a prepared Explore-Bench .world'),
        SetEnvironmentVariable('GAZEBO_MODEL_PATH',
                               os.path.join(tb3_share, 'models') + os.pathsep +
                               os.environ.get('GAZEBO_MODEL_PATH', '')),
        gazebo,
        TimerAction(period=5.0, actions=[spawn]),
        learner,
    ])
