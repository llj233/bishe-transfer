"""Pure Python state, reward and tabular Q-learning logic (no ROS dependency)."""
import json
import math
import random

ACTIONS = ((0.10, 0.0), (0.0, 0.55), (0.0, -0.55))


def image_signature(data, width, height, step, encoding):
    """Quantize a few RGB/BGR pixels; return None for an unsupported frame."""
    if encoding not in ('rgb8', 'bgr8') or width < 1 or height < 1 or step < width * 3:
        return None
    if len(data) < step * height:
        return None
    samples = []
    for y in (height // 4, height // 2, 3 * height // 4):
        for x in (width // 4, width // 2, 3 * width // 4):
            i = y * step + x * 3
            r, g, b = data[i:i + 3]
            if encoding == 'bgr8':
                r, b = b, r
            samples.append((int(r > g * 1.3 and r > b * 1.3),
                            int(g > r * 1.3 and g > b * 1.3),
                            int(b > r * 1.3 and b > g * 1.3)))
    return tuple(sum(s[k] for s in samples) // 3 for k in range(3))


def scan_bins(ranges, range_min, range_max):
    if not ranges or not math.isfinite(range_max) or range_max <= range_min:
        return None
    n = len(ranges)
    def sector(lo, hi):
        vals = [float(v) if math.isfinite(v) else range_max for v in ranges[lo:hi]
                if (math.isfinite(v) and range_min <= v <= range_max) or math.isinf(v) and v > 0]
        return min(vals) if vals else range_max
    front = min(sector(0, max(1, n // 8)), sector(7 * n // 8, n))
    left = sector(n // 8, 3 * n // 8)
    right = sector(5 * n // 8, 7 * n // 8)
    return front, left, right


def state_from_sensors(scan, image_sig):
    front, left, right = scan
    def q(v): return 0 if v < 0.35 else 1 if v < 0.8 else 2
    return (q(front), q(left), q(right), *(image_sig or (0, 0, 0)))


class SharedLearner:
    def __init__(self, alpha=0.2, gamma=0.9, epsilon=0.2, seed=7):
        self.alpha, self.gamma, self.epsilon = alpha, gamma, epsilon
        self.rng = random.Random(seed)
        self.q = {}
        self.visited = set()
        self.images = set()

    def choose(self, state, train=True):
        if train and self.rng.random() < self.epsilon:
            return self.rng.randrange(len(ACTIONS))
        values = self.q.get(tuple(state), [0.0] * len(ACTIONS))
        return max(range(len(ACTIONS)), key=lambda i: values[i])

    def learn(self, state, action, reward, next_state):
        old = self.q.setdefault(tuple(state), [0.0] * len(ACTIONS))
        future = max(self.q.get(tuple(next_state), [0.0] * len(ACTIONS)))
        old[action] += self.alpha * (reward + self.gamma * future - old[action])

    def reward(self, x, y, image_sig, front):
        cell = (math.floor(x / 0.5), math.floor(y / 0.5))
        reward = -0.01
        if cell not in self.visited:
            self.visited.add(cell)
            reward += 1.0
        if image_sig is not None and image_sig not in self.images:
            self.images.add(image_sig)
            reward += 0.1
        if front < 0.25:
            reward -= 1.0
        return reward

    def save(self, path):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'q': {','.join(map(str, k)): v for k, v in self.q.items()}}, f)

    def load(self, path):
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        self.q = {tuple(map(int, k.split(','))): v for k, v in data['q'].items()}
