from setuptools import setup
from glob import glob
import os

setup(
    name='dual_explore', version='0.1.0', packages=['dual_explore'],
    data_files=[('share/ament_index/resource_index/packages', ['resource/dual_explore']),
                ('share/dual_explore', ['package.xml']),
                (os.path.join('share', 'dual_explore', 'launch'), glob('launch/*.launch.py'))],
    install_requires=['setuptools'], zip_safe=True,
    maintainer='Graduation project', maintainer_email='student@example.com',
    description='Minimal ROS 2 visual and tabular RL exploration bridge',
    license='MIT',
    entry_points={'console_scripts': ['q_explorer = dual_explore.node:main']},
)
