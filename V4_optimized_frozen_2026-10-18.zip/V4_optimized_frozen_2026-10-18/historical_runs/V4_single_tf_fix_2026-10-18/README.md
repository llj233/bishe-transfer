# V4 单机主动探索：TF 死锁修复版

独立于所有旧版本。本版本保留六新增障碍的种子地图、SLAM Toolbox、frontier 安全观测点、Nav2 路径与导航，以及探索率 >95%、ROI 已知率 >90% 后返回出生点的任务判据。

关键修复是使用本目录的官方 Humble tf2/tf2_ros 0.25.24，解决本机 0.25.23 已复现的 ABBA 死锁。软件包仅在 `vendor/root` 解包，系统安装没有更改。原始线程栈、旧/新库回归结果和解释见 [ROOT_CAUSE.md](ROOT_CAUSE.md)。

## 编译与运行

当前 VM 是 Ubuntu 22.04 amd64、ROS2 Humble，需要 Gazebo Classic、SLAM Toolbox 与 Nav2。确切版本见 `ENVIRONMENT.json`、`vendor/PACKAGES.json`。供应库已包含在目录中，不需要在系统中升级 tf2。

```bash
cd /home/lemuel/Downloads/V4_single_tf_fix_2026-10-18
bash scripts/build_isolated.sh
bash scripts/run_gui.sh --map-seed 7 --policy-seed 11
```

两个脚本都以自己的进程设置环境。启动器为每组实验生成独立 ROS_DOMAIN_ID、Gazebo 端口、运行目录及 manifest，不依赖另一个 V4 的 install 文件。编译产生的绝对路径在迁移目录或换机器后需重新生成。

默认预算为 700 秒任务仿真时间，GUI 开启，结果和地图保存在 `experiments/single/room/map_seed_*/policy_seed_*/*/`。世界生成器和代码哈希写入 manifest，随机种子确定输入布局与候选排序；异步仿真执行仍可能使同种子轨迹不同。

## 输出

`fused_slam_map_preview.png` 使用统一配色和 8 倍显示，另有标准 PGM/YAML。`evaluation.csv` 是独立真值覆盖率评价，`navigation_health.csv` 是原始路径/足迹/代价地图时间戳，`mission_events.jsonl` 保存导航和任务状态。

```bash
python3 scripts/aggregate_runs.py
python3 scripts/export_validation_report.py
```

汇总器保留失败和未完成运行。最终验收表、曲线与说明在本目录生成；冻结记录以 `FROZEN_VERSION.json` 为准。
