# V4 单机 TF 死锁修复与验收

父目录：`V4_single_navigation_cyclone_2026-10-18`。独立源码、构建、运行及 vendor 库。之前版本不回写；系统 `/opt/ros/humble` 保持原安装。

在独立诊断版 `V4_single_tf_diagnosis_2026-10-18` 中，用 GDB 捕获到了同一控制器两次线程快照：激光回调卡在 `BufferCore::addTransformableRequest`，TF listener 卡在 `BufferCore::testTransformableRequests` 调用的 tf2_ros 回调，锁地址不同且连续快照未推进。这与本机 tf2 0.25.23 的加锁顺序以及上游 [Humble #995](https://github.com/ros2/geometry2/issues/995) 一致。

本版使用官方 tf2 与 tf2_ros **0.25.24** DEB 在本目录解包的动态库，核心修复为释放变换请求锁后再执行回调。对应 [Humble 修复 #990](https://github.com/ros2/geometry2/pull/990) 与 [0.25.24 更新记录](https://github.com/ros2/geometry2/blob/0.25.24/tf2/CHANGELOG.rst)。前沿评分、六障碍生成器、传感器、出生点、Nav2 有限恢复和覆盖率判据保持父版参数。

先以 `callback_reentry` 测试验证同一个程序在旧 libtf2 下超时、新 libtf2 下正常返回，再进行 Gazebo GUI 验收。

验收种子固定为 7/11、9/13（开发参照）和 101/501（新的验证组合），每组 700 秒任务预算。第一组完成后才继续下一组，不因成功失败临时替换种子。任务必须探索率 >95%、ROI 已知率 >90%，并返航；同时没有持续 TF/足迹冻结、没有循环 Spin、没有导航生命周期重置。若仍出现问题则保存证据，在新的隔离版本继续修复。

停止优化的条件：同一冻结版本三组均完整成功，且上述故障没有复现。该有限验收不能证明所有随机世界都成功，但比仅关闭旋转更完整。每组输出 PNG/PGM/YAML、覆盖率 CSV、导航健康 CSV、世界/源码/vendor 哈希与完整运行日志。
