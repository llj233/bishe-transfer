# V4 单机六障碍泛化试验（预注册）

## 版本边界

本目录从 `V4_single_generalization_tf_lead_2026-10-18` 的源码独立复制；旧版实验、构建目录和报告均未复制。基线单机主动 SLAM（slam_toolbox + frontier + Nav2）不含可训练权重，`policy_seed` 仅为候选目标的确定性近似平分排序。这里的“优化”是规划参数调整，不称强化学习训练。

本版仅作两处受控改变：房间种子地图的新增箱形障碍从 3 个增至 6 个，候选簇上限由 120 增至 160、Nav2 路径查询上限由 36 增至 40。原有两只可移动箱子与静态场景保留。生成器只依据碰撞几何和出生点可达栅格接受地图，不依据探索结果挑选。

## 固定实验

单机、GUI、每次仿真预算 700 秒，真值可达空闲格探索率 **>95%** 且 ROI 已知率 **>90%** 后返航至出生点才算任务成功。原世界、出生点、激光、SLAM/Nav2 参数及评价器固定。完整记录失败与超时。

| 顺序 | map_seed | policy_seed | 角色 |
|---|---:|---:|---|
| 1 | 7 | 11 | 旧成功组合，开发参考；六障碍地图是新几何 |
| 2 | 9 | 13 | 旧成功组合，开发参考；六障碍地图是新几何 |
| 3 | 101 | 501 | 未参与本轮调参的地图/策略组合 |

本轮只运行上述每组一次，不按结果临时替换种子，不反复调参。判断为有明显改善的最低条件：三组均完整达标返航，且无长时间导航卡住；否则停止继续优化，报告失败原因及后续建议，等待用户指定下一步。即使三组均成功，样本量仍不足以证明泛化成功率。

**提前停止记录（试验结束后补记）：** 第 1 组地图 7/策略 11 在 529.5 秒因 `navigation_failed` 停止，探索率 50.26%；已不可能满足三组全成功的最低条件。按用户“优化效果差就停止”的要求，第 2、3 组未启动，不能视为失败或成功。没有再调参。

## 复现与输出

`source /opt/ros/humble/setup.bash && source install/setup.bash`

`python3 scripts/run_test.py --mode single --world worlds/room.world --map-seed 7 --policy-seed 11 --max-sim-seconds 700 --gui true --wait`

每组运行保存在 `experiments/single/room/map_seed_*/policy_seed_*/*/`，包含 manifest（源码与世界 SHA256）、生成 SDF、配置、日志、覆盖率 CSV、建图文件和结果。最终运行 `python3 scripts/aggregate_runs.py` 导出包含所有尝试的 `GENERALIZATION_RESULTS.csv`。
