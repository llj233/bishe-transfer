"""Validated map alignment and fusion. No SDF or evaluation imports."""
from dataclasses import dataclass
from typing import Dict, Optional
from .model import Grid, Pose2, Transform2


@dataclass(frozen=True)
class FusionResult:
    grid: Optional[Grid]
    version: int
    healthy: bool
    reason: str
    overlap_cells: int
    conflict_cells: int
    conflict_ratio: float


class AlignmentFusion:
    def __init__(self, output_grid: Grid, max_age_s: float = 3.0,
                 min_overlap: int = 20, max_conflict_ratio: float = .15):
        self.output_grid = output_grid
        self.max_age_s = max_age_s
        self.min_overlap = min_overlap
        self.max_conflict_ratio = max_conflict_ratio
        self.version = 0

    def fuse(self, maps: Dict[str, Grid], transforms: Dict[str, Transform2],
             now_sim_s: float) -> FusionResult:
        names = sorted(maps)
        if len(names) != 2 or set(names) != set(transforms):
            return self._bad('missing_robot_map_or_transform')
        for name in names:
            grid, tf = maps[name], transforms[name]
            if (grid.stamp < 0 or tf.stamp < 0 or
                now_sim_s - grid.stamp > self.max_age_s or
                now_sim_s - tf.stamp > self.max_age_s or
                grid.stamp > now_sim_s + .2 or tf.stamp > now_sim_s + .2):
                return self._bad(name + '_stale_map_or_alignment')
        layers = []
        for name in names:
            layer = [-1] * len(self.output_grid.cells)
            grid, tf = maps[name], transforms[name]
            for y in range(grid.height):
                for x in range(grid.width):
                    value = grid.at(x, y)
                    if value < 0:
                        continue
                    dest = self.output_grid.cell_of(tf.apply(grid.center(x, y)))
                    if dest is None:
                        continue
                    idx = self.output_grid.index(*dest)
                    occupied = 100 if value >= 65 else 0 if value <= 25 else -1
                    if occupied < 0:
                        continue
                    # Conservatively keep occupied evidence within one local map.
                    layer[idx] = max(layer[idx], occupied)
            layers.append(layer)
        overlap = conflict = 0
        cells = []
        for a, b in zip(*layers):
            if a >= 0 and b >= 0:
                overlap += 1
                conflict += int(a != b)
            cells.append(100 if a == 100 or b == 100 else
                         0 if a == 0 or b == 0 else -1)
        ratio = conflict / overlap if overlap else 1.0
        if overlap < self.min_overlap:
            return self._bad('insufficient_overlap', overlap, conflict, ratio)
        if ratio > self.max_conflict_ratio:
            return self._bad('occupancy_conflict', overlap, conflict, ratio)
        self.version += 1
        o = self.output_grid
        return FusionResult(Grid(o.width, o.height, o.resolution, o.origin,
                                 tuple(cells), now_sim_s, o.frame),
                            self.version, True, 'ok', overlap, conflict, ratio)

    def _bad(self, reason, overlap=0, conflict=0, ratio=0.0):
        return FusionResult(None, self.version, False, reason,
                            overlap, conflict, ratio)
