"""Data contracts shared by the V4 online components.

All timestamps and deadlines here use ROS simulation seconds. Wall time belongs
only to the external runner/watchdog and must never change a planning decision.
"""
from dataclasses import dataclass
from enum import Enum
import math
from typing import Optional, Tuple


class Phase(str, Enum):
    STARTUP = 'STARTUP'
    EXPLORE = 'EXPLORE'
    RETURN = 'RETURN'
    COMPLETE = 'COMPLETE'
    FAILED = 'FAILED'


class GoalStatus(str, Enum):
    ASSIGNED = 'assigned'
    NAVIGATING = 'navigating'
    REACHED = 'reached'
    FAILED = 'failed'
    CANCELED = 'canceled'


class Failure(str, Enum):
    STARTUP = 'startup_failure'
    COVERAGE_TIMEOUT = 'coverage_timeout'
    NO_FRONTIER = 'no_reachable_frontier'
    NAVIGATION = 'navigation_failed'
    RETURN = 'return_failed'
    LOCALIZATION = 'localization_unhealthy'
    ALIGNMENT = 'alignment_unhealthy'
    RUNTIME = 'runtime_error'


@dataclass(frozen=True)
class Pose2:
    x: float
    y: float
    yaw: float = 0.0


@dataclass(frozen=True)
class Transform2:
    """T_global_map_i: maps coordinates from one robot's SLAM frame to global."""
    x: float
    y: float
    yaw: float
    stamp: float

    def apply(self, pose: Pose2) -> Pose2:
        c, s = math.cos(self.yaw), math.sin(self.yaw)
        return Pose2(self.x + c * pose.x - s * pose.y,
                     self.y + s * pose.x + c * pose.y,
                     pose.yaw + self.yaw)

    def inverse(self, pose: Pose2) -> Pose2:
        c, s = math.cos(self.yaw), math.sin(self.yaw)
        dx, dy = pose.x - self.x, pose.y - self.y
        return Pose2(c * dx + s * dy, -s * dx + c * dy,
                     pose.yaw - self.yaw)


@dataclass(frozen=True)
class Grid:
    width: int
    height: int
    resolution: float
    origin: Pose2
    cells: Tuple[int, ...]
    stamp: float
    frame: str

    def __post_init__(self):
        if self.width < 1 or self.height < 1 or self.resolution <= 0:
            raise ValueError('invalid grid geometry')
        if len(self.cells) != self.width * self.height:
            raise ValueError('grid data length mismatch')

    def index(self, x: int, y: int) -> int:
        return y * self.width + x

    def at(self, x: int, y: int) -> int:
        return self.cells[self.index(x, y)]

    def center(self, x: int, y: int) -> Pose2:
        u, v = (x + .5) * self.resolution, (y + .5) * self.resolution
        c, s = math.cos(self.origin.yaw), math.sin(self.origin.yaw)
        return Pose2(self.origin.x + c * u - s * v,
                     self.origin.y + s * u + c * v)

    def cell_of(self, pose: Pose2) -> Optional[Tuple[int, int]]:
        dx, dy = pose.x - self.origin.x, pose.y - self.origin.y
        c, s = math.cos(self.origin.yaw), math.sin(self.origin.yaw)
        x = math.floor((c * dx + s * dy) / self.resolution)
        y = math.floor((-s * dx + c * dy) / self.resolution)
        return (x, y) if 0 <= x < self.width and 0 <= y < self.height else None


@dataclass(frozen=True)
class Candidate:
    candidate_id: str
    robot: str
    region_id: str
    pose_local: Pose2
    pose_global: Pose2
    map_version: int
    predicted_new_cells: int
    path_m: float
    clearance_m: float
    score: float


@dataclass(frozen=True)
class Goal:
    goal_id: str
    robot: str
    region_id: str
    pose_local: Pose2
    map_version: int
    assigned_sim_s: float
    deadline_sim_s: float
    status: GoalStatus = GoalStatus.ASSIGNED


@dataclass(frozen=True)
class RunResult:
    phase: Phase
    failure: Optional[Failure]
    exploration_reached: bool
    returned: Tuple[bool, bool]
    sim_seconds: float

