"""Explicit startup and runtime gates for each robot stack."""
from dataclasses import dataclass
from typing import Dict, Tuple
import math
from .model import Pose2


@dataclass(frozen=True)
class RobotHeartbeat:
    scan_stamp: float
    odom_stamp: float
    map_stamp: float
    tf_stamp: float
    costmap_stamp: float
    nav2_active: bool
    path_service_ready: bool


def check_robot(heartbeat: RobotHeartbeat, now_sim_s: float,
                max_age_s: float = 3.0) -> Tuple[bool, Tuple[str, ...]]:
    reasons = []
    for name in ('scan', 'odom', 'map', 'tf', 'costmap'):
        stamp = getattr(heartbeat, name + '_stamp')
        if stamp < 0 or stamp > now_sim_s + .2 or now_sim_s - stamp > max_age_s:
            reasons.append(name + '_stale')
    if not heartbeat.nav2_active:
        reasons.append('nav2_inactive')
    if not heartbeat.path_service_ready:
        reasons.append('path_service_unready')
    return not reasons, tuple(reasons)


def startup_ready(robots: Dict[str, RobotHeartbeat], now_sim_s: float) -> bool:
    return len(robots) == 2 and all(check_robot(h, now_sim_s)[0]
                                    for h in robots.values())


def backtrack_options(safe_poses, current: Pose2, min_distance=.8):
    """Try recently reached positions outside the current stuck spot first."""
    if current is None:
        return ()
    return tuple(p for p in reversed(safe_poses)
                 if math.hypot(p.x-current.x, p.y-current.y) >= min_distance)


def translated_enough(current: Pose2, reference: Pose2, threshold=.12):
    """Turning in place does not reset the navigation stall watchdog."""
    return (current is not None and reference is not None and
            math.hypot(current.x-reference.x, current.y-reference.y) >= threshold)


def update_distance_progress(best_m, distance_m, step_m=.25):
    """Ignore Nav2's zero placeholder before a path has been computed."""
    if not math.isfinite(distance_m) or distance_m <= .05:
        return best_m, False
    if best_m is None or distance_m <= best_m - step_m:
        return distance_m, True
    return best_m, False

