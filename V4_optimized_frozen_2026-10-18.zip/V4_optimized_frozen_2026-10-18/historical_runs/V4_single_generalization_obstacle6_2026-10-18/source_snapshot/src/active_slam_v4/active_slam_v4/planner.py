"""Frontier observations validated in the robot's own SLAM/Nav2 frame."""
from collections import deque
import hashlib
import math
from typing import Callable, List, Optional, Tuple
from .model import Candidate, Grid, Pose2, Transform2


def neighbors(grid: Grid, cell: Tuple[int, int]):
    x, y = cell
    for u, v in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
        if 0 <= u < grid.width and 0 <= v < grid.height:
            yield u, v


def reachable_free(grid: Grid, start: Pose2):
    root = grid.cell_of(start)
    if root is None or grid.at(*root) > 25 or grid.at(*root) < 0:
        return set()
    visited = {root}
    queue = deque([root])
    while queue:
        for cell in neighbors(grid, queue.popleft()):
            if cell not in visited and 0 <= grid.at(*cell) <= 25:
                visited.add(cell)
                queue.append(cell)
    return visited


def frontier_clusters(grid: Grid, traversable):
    frontier = {cell for cell in traversable
                if any(grid.at(*n) < 0 for n in neighbors(grid, cell))}
    groups = []
    while frontier:
        seed = min(frontier)
        frontier.remove(seed)
        group, queue = {seed}, deque([seed])
        while queue:
            for cell in neighbors(grid, queue.popleft()):
                if cell in frontier:
                    frontier.remove(cell)
                    group.add(cell)
                    queue.append(cell)
        groups.append(group)
    return sorted(groups, key=lambda g: (-len(g), min(g)))


def obstacle_clearance(grid: Grid, include_unknown=False):
    distance = [math.inf] * len(grid.cells)
    queue = deque()
    for y in range(grid.height):
        for x in range(grid.width):
            idx = grid.index(x, y)
            if grid.cells[idx] >= 65 or (include_unknown and grid.cells[idx] < 0):
                distance[idx] = 0
                queue.append((x, y))
    while queue:
        cell = queue.popleft()
        d = distance[grid.index(*cell)] + grid.resolution
        for other in neighbors(grid, cell):
            idx = grid.index(*other)
            if d < distance[idx]:
                distance[idx] = d
                queue.append(other)
    return distance


def visible_unknown(grid: Grid, pose: Pose2, max_range_m=3.2, rays=48):
    seen = set()
    for ray in range(rays):
        angle = ray * 2 * math.pi / rays
        for step in range(1, int(max_range_m / grid.resolution) + 1):
            point = Pose2(pose.x + step * grid.resolution * math.cos(angle),
                          pose.y + step * grid.resolution * math.sin(angle))
            cell = grid.cell_of(point)
            if cell is None:
                break
            value = grid.at(*cell)
            if value >= 65:
                break
            if value < 0:
                seen.add(cell)
                break
    return len(seen)


def region_id(pose: Pose2, side_m=2.0):
    return f'{math.floor(pose.x / side_m)}:{math.floor(pose.y / side_m)}'


def seeded_score(score, policy_seed, robot, pose):
    """Stable one-percent preference among near-equal candidate scores."""
    key = f'{policy_seed}:{robot}:{pose.x:.2f}:{pose.y:.2f}'.encode()
    fraction = int.from_bytes(hashlib.blake2b(key, digest_size=8).digest(), 'big') / 2**64
    return score + abs(score) * .01 * (2 * fraction - 1)


class CandidatePlanner:
    def __init__(self, safe_radius_m=.50, robot_speed_mps=.22,
                 max_candidates=120, max_path_queries=36, policy_seed=0):
        self.safe_radius_m = safe_radius_m
        self.robot_speed_mps = robot_speed_mps
        self.max_candidates = max_candidates
        self.max_path_queries = max_path_queries
        self.policy_seed = int(policy_seed)

    def plan(self, robot: str, local_map: Grid, robot_pose_local: Pose2,
             to_global: Transform2, map_version: int,
             path_length: Callable[[Pose2], Optional[float]],
             failed_on_version=frozenset(),
             forbidden_targets=()) -> Tuple[List[Candidate], dict]:
        """Path callback MUST call this robot's Nav2 ComputePathToPose service.

        The callback returns path length in metres, or None for no path/timeout.
        No Euclidean shortcut is allowed to mark a candidate navigable.
        """
        free = reachable_free(local_map, robot_pose_local)
        clusters = frontier_clusters(local_map, free)
        clearance = obstacle_clearance(local_map)
        unknown_gap = obstacle_clearance(local_map, include_unknown=True)
        proposals = []
        used_cells = set()
        rejected = {'unreachable_local': 0, 'unsafe': 0,
                    'low_gain': 0, 'no_nav2_path': 0, 'recent_failure': 0,
                    'too_close': 0}
        for group in clusters[:self.max_candidates]:
            # Move observation poses back into mapped space. Boundary cells
            # themselves can lie in Nav2's inflated or unknown region.
            cx = sum(x for x, _ in group) / len(group)
            cy = sum(y for _, y in group) / len(group)
            chosen = sorted(group, key=lambda p: (p[0] - cx) ** 2 +
                            (p[1] - cy) ** 2)[:4]
            for frontier in chosen:
                max_offset = max(.9, 1.5 * local_map.resolution)
                min_offset = min(.25, .5 * local_map.resolution)
                radius = max(1, int(max_offset / local_map.resolution))
                nearby = [(x, y) for y in range(max(0, frontier[1]-radius),
                                                  min(local_map.height, frontier[1]+radius+1))
                          for x in range(max(0, frontier[0]-radius),
                                         min(local_map.width, frontier[0]+radius+1))
                          if (x, y) in free and (x, y) not in used_cells and
                          min_offset <= math.hypot(x-frontier[0], y-frontier[1]) *
                          local_map.resolution <= max_offset and
                          clearance[local_map.index(x, y)] >= self.safe_radius_m and
                          unknown_gap[local_map.index(x, y)] >=
                          min(.2, local_map.resolution)]
                if not nearby:
                    rejected['unsafe'] += 1
                    continue
                cell = min(nearby, key=lambda p: (
                    abs(math.hypot(p[0]-frontier[0], p[1]-frontier[1]) *
                        local_map.resolution - .45),
                    -clearance[local_map.index(*p)], p))
                used_cells.add(cell)
                gap = min(clearance[local_map.index(*cell)],
                          unknown_gap[local_map.index(*cell)])
                pose = local_map.center(*cell)
                if math.hypot(pose.x - robot_pose_local.x,
                              pose.y - robot_pose_local.y) < .60:
                    rejected['too_close'] += 1
                    continue
                gain = visible_unknown(local_map, pose)
                if gain < 2:
                    rejected['low_gain'] += 1
                    continue
                gx, gy = local_map.center(*frontier).x, local_map.center(*frontier).y
                pose = Pose2(pose.x, pose.y, math.atan2(gy - pose.y, gx - pose.x))
                if any(math.hypot(pose.x - bad.x, pose.y - bad.y) < .55
                       for bad in forbidden_targets):
                    rejected['recent_failure'] += 1
                    continue
                global_pose = to_global.apply(pose)
                ident = f'{robot}:{map_version}:{cell[0]}:{cell[1]}'
                if ident in failed_on_version:
                    continue
                distance = math.hypot(pose.x-robot_pose_local.x,
                                      pose.y-robot_pose_local.y)
                proposals.append((gain, gap, pose, global_pose, ident,
                                  gain / (distance + 1.0)))
        # Query one spatially distinct area at a time. Otherwise dozens of
        # high-gain cells beyond the same blocked doorway consume the budget.
        proposals.sort(key=lambda p: (-p[5], -p[0], -p[1], p[4]))
        buckets = {}
        for proposal in proposals:
            p = proposal[2]
            key = (math.floor(p.x / 2.0), math.floor(p.y / 2.0))
            buckets.setdefault(key, []).append(proposal)
        diverse = []
        for rank in range(2):
            diverse.extend(items[rank] for items in buckets.values()
                           if len(items) > rank)
        result = []
        for gain, gap, pose, global_pose, ident, _ in diverse[:self.max_path_queries]:
            length = path_length(pose)
            if length is None or not math.isfinite(length) or length < 0:
                rejected['no_nav2_path'] += 1
                continue
            travel = length / self.robot_speed_mps + 2.0
            score = gain / travel - .1 / max(gap, .1)
            score = seeded_score(score, self.policy_seed, robot, pose)
            result.append(Candidate(ident, robot, region_id(global_pose),
                                    pose, global_pose, map_version, gain,
                                    length, gap, score))
        result.sort(key=lambda c: (-c.score, c.candidate_id))
        return result, {'frontier_clusters': len(clusters),
                        'reachable_free_cells': len(free),
                        'spatial_regions': len(buckets),
                        'path_queries': min(len(diverse), self.max_path_queries),
                        'rejected': rejected}

