"""A final velocity gate based on fresh laser data.

Nav2 remains the navigation authority. This gate only slows or stops a
command that would move the circular robot into an immediate obstacle.
"""
import math


def sector_min(ranges, angle_min, angle_increment, center, half_width,
               range_min=0.0, range_max=math.inf):
    values = [r for i, r in enumerate(ranges)
              if math.isfinite(r) and range_min <= r <= range_max and
              abs(math.atan2(math.sin(angle_min + i * angle_increment - center),
                             math.cos(angle_min + i * angle_increment - center))) <= half_width]
    return min(values) if values else math.inf


def safe_velocity(linear, angular, front, rear, scan_fresh,
                  footprint_radius=.19, margin=.10, decel=.45):
    """Return bounded linear/angular velocity and an intervention reason."""
    if not scan_fresh:
        return 0.0, 0.0, 'stale_scan'
    clearance = front if linear > 0 else rear
    if abs(linear) < 1e-6:
        return 0.0, angular, None
    stop_distance = footprint_radius + margin + linear * linear / (2 * decel)
    if clearance <= stop_distance:
        return 0.0, angular, 'obstacle_stop'
    slow_zone = stop_distance + .35
    if clearance < slow_zone:
        limited = math.copysign(min(abs(linear), .08), linear)
        return limited, angular, 'obstacle_slow'
    return linear, angular, None


def select_command(nav_command, nav_age, recovery_command, recovery_age):
    """Nav2 recovery wins while it is actively publishing a fresh command."""
    if (recovery_age <= .25 and
            (abs(recovery_command[0]) > 1e-4 or abs(recovery_command[1]) > 1e-4)):
        return recovery_command, 'recovery'
    if nav_age <= .5:
        return nav_command, 'navigation'
    return (0.0, 0.0), 'idle'
