"""V4 deterministic active-SLAM components. Ground truth lives outside this package."""

