"""Sim-time region leases keep the two robots from chasing the same frontier."""
from dataclasses import dataclass
from typing import Dict, Iterable, List
from .model import Candidate


@dataclass(frozen=True)
class Lease:
    robot: str
    region_id: str
    candidate_id: str
    acquired_sim_s: float
    expires_sim_s: float
    map_version: int


class Allocator:
    def __init__(self, lease_seconds=45.0):
        self.lease_seconds = lease_seconds
        self.leases: Dict[str, Lease] = {}

    def release(self, robot: str):
        self.leases.pop(robot, None)

    def expire(self, now_sim_s: float, map_version: int):
        for robot, lease in list(self.leases.items()):
            if now_sim_s >= lease.expires_sim_s or lease.map_version != map_version:
                self.release(robot)

    def assign(self, candidates: Iterable[Candidate], now_sim_s: float,
               map_version: int) -> Dict[str, Candidate]:
        self.expire(now_sim_s, map_version)
        used = {lease.region_id for lease in self.leases.values()}
        assigned = {}
        for c in sorted(candidates, key=lambda item: (-item.score,
                                                       item.robot, item.candidate_id)):
            if c.map_version != map_version or c.robot in self.leases or c.robot in assigned:
                continue
            if c.region_id in used:
                continue
            assigned[c.robot] = c
            used.add(c.region_id)
            self.leases[c.robot] = Lease(c.robot, c.region_id, c.candidate_id,
                                         now_sim_s, now_sim_s + self.lease_seconds,
                                         map_version)
        return assigned
