"""Frozen V3 map preview colors and 8x nearest-neighbor display format."""
import struct
import zlib


def write_map_preview(path, occupancy, width, height, scale=8):
    if width < 1 or height < 1 or scale < 1 or len(occupancy) != width * height:
        raise ValueError('Invalid map preview dimensions')
    colors = {0: bytes((224, 244, 255)), 100: bytes((25, 32, 42)),
              -1: bytes((241, 190, 95))}
    raw = bytearray()
    for y in reversed(range(height)):
        row = b''.join(colors[-1 if value < 0 else 100 if value >= 65 else 0] * scale
                       for value in occupancy[y * width:(y + 1) * width])
        for _ in range(scale):
            raw.extend(b'\x00')
            raw.extend(row)

    def chunk(kind, data):
        payload = kind + data
        return struct.pack('>I', len(data)) + payload + struct.pack('>I', zlib.crc32(payload))

    png = (b'\x89PNG\r\n\x1a\n' +
           chunk(b'IHDR', struct.pack('>IIBBBBB', width * scale, height * scale,
                                      8, 2, 0, 0, 0)) +
           chunk(b'IDAT', zlib.compress(raw, level=6)) + chunk(b'IEND', b''))
    path.write_bytes(png)

