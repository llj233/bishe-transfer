"""Single robot final cmd_vel gate; only this node writes the robot cmd_vel."""
import json
import math

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String

from .safety import safe_velocity, sector_min, select_command


class SafetyNode(Node):
    def __init__(self):
        super().__init__('single_safety_gate')
        self.declare_parameter('robot', 'robot1')
        name = self.get_parameter('robot').value
        self.name = name
        self.scan = None
        self.scan_time = -1.0
        self.command = Twist()
        self.command_time = -1.0
        self.recovery_command = Twist()
        self.recovery_time = -1.0
        self.odom_xy = None
        self.escape = None
        self.last_notice = -1e9
        self.create_subscription(LaserScan, f'/{name}/scan', self.on_scan,
                                 qos_profile_sensor_data)
        self.create_subscription(Twist, f'/{name}/cmd_vel_unchecked',
                                 self.on_command, 10)
        self.create_subscription(Twist, f'/{name}/cmd_vel_recovery',
                                 self.on_recovery, 10)
        self.create_subscription(Odometry, f'/{name}/odom', self.on_odom,
                                 qos_profile_sensor_data)
        self.create_subscription(String, '/v4/escape_request', self.on_escape, 10)
        self.publisher = self.create_publisher(Twist, f'/{name}/cmd_vel', 10)
        self.status = self.create_publisher(String, '/v4/safety_status', 10)
        self.create_timer(.05, self.tick)

    def now(self):
        return self.get_clock().now().nanoseconds / 1e9

    def on_scan(self, msg):
        self.scan = msg
        self.scan_time = self.now()

    def on_command(self, msg):
        self.command = msg
        self.command_time = self.now()

    def on_recovery(self, msg):
        self.recovery_command = msg
        self.recovery_time = self.now()

    def on_odom(self, msg):
        p = msg.pose.pose.position
        self.odom_xy = (p.x, p.y)

    def publish_status(self, reason, **fields):
        self.status.publish(String(data=json.dumps({'robot': self.name,
            'reason': reason, 'sim_time': self.now(), **fields})))

    def on_escape(self, msg):
        try:
            data = json.loads(msg.data)
        except (ValueError, TypeError):
            return
        if data.get('robot') != self.name or self.escape is not None:
            return
        now = self.now()
        if self.odom_xy is None or self.scan is None or now-self.scan_time > .7:
            self.publish_status('escape_finished', success=False,
                                detail='missing_fresh_sensor')
            return
        rear = sector_min(self.scan.ranges, self.scan.angle_min,
                          self.scan.angle_increment, math.pi,
                          math.radians(35), self.scan.range_min,
                          self.scan.range_max)
        if not math.isfinite(rear) or rear < .48:
            self.publish_status('escape_finished', success=False,
                                detail='rear_blocked')
            return
        self.escape = (self.odom_xy, now)
        self.publish_status('escape_started', rear_m=rear)

    def tick(self):
        now = self.now()
        output = Twist()
        if self.escape is not None:
            start_xy, start_time = self.escape
            moved = (math.hypot(self.odom_xy[0]-start_xy[0],
                                self.odom_xy[1]-start_xy[1])
                     if self.odom_xy is not None else 0.0)
            if moved >= .32 or now-start_time >= 6.5:
                self.escape = None
                self.publish_status('escape_finished', success=moved >= .26,
                                    moved_m=moved)
            elif self.scan is None or now-self.scan_time > .7:
                self.escape = None
                self.publish_status('escape_finished', success=False,
                                    detail='stale_scan')
            else:
                scan = self.scan
                rear = sector_min(scan.ranges, scan.angle_min,
                                  scan.angle_increment, math.pi,
                                  math.radians(35), scan.range_min, scan.range_max)
                if not math.isfinite(rear) or rear < .38:
                    self.escape = None
                    self.publish_status('escape_finished', success=False,
                                        detail='rear_blocked')
                else:
                    output.linear.x, _, reason = safe_velocity(
                        -.06, 0.0, math.inf, rear, True)
                    if reason == 'obstacle_stop':
                        self.escape = None
                        self.publish_status('escape_finished', success=False,
                                            detail='laser_stop')
            self.publisher.publish(output)
            return
        command, source = select_command(
            (self.command.linear.x, self.command.angular.z),
            now-self.command_time,
            (self.recovery_command.linear.x, self.recovery_command.angular.z),
            now-self.recovery_time)
        if self.scan is None or now - self.scan_time > .7:
            reason = 'stale_scan' if source != 'idle' else None
        elif source == 'idle':
            reason = None
        else:
            scan = self.scan
            front = sector_min(scan.ranges, scan.angle_min, scan.angle_increment,
                               0.0, math.radians(35), scan.range_min, scan.range_max)
            rear = sector_min(scan.ranges, scan.angle_min, scan.angle_increment,
                              math.pi, math.radians(35), scan.range_min, scan.range_max)
            x, z, reason = safe_velocity(command[0], command[1], front, rear,
                                         True)
            output.linear.x = x
            output.angular.z = z
        self.publisher.publish(output)
        if reason and now - self.last_notice >= 1.0:
            self.status.publish(String(data=json.dumps({'robot': self.name,
                'reason': reason, 'sim_time': now})))
            self.last_notice = now


def main():
    rclpy.init()
    node = SafetyNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
