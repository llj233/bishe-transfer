from setuptools import setup

package_name = 'v4_evaluator'
setup(name=package_name, version='0.1.0', packages=[package_name],
      data_files=[('share/ament_index/resource_index/packages',
                   ['resource/' + package_name]),
                  ('share/' + package_name, ['package.xml'])],
      install_requires=['setuptools'], zip_safe=True,
      maintainer='llj233', maintainer_email='llj233@users.noreply.github.com',
      description='SDF truth and ROI metrics isolated from V4 online planner',
      license='MIT',
      entry_points={'console_scripts': [
          'evaluator = v4_evaluator.node:main',
      ]})

