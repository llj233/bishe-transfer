"""Only ROS process allowed to load SDF truth and decide coverage success."""
import csv
import json
import math
from pathlib import Path

import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import String

from .metrics import Evaluator, MapData


class EvaluatorNode(Node):
    def __init__(self):
        super().__init__('v4_evaluator')
        for name, value in [('world_sdf', ''), ('run_dir', ''),
                            ('starts_xy', [-1.7, -2.5, -.7, -2.5]),
                            ('resolution', .1), ('exploration_target', 95.0),
                            ('roi_target', 90.0)]:
            self.declare_parameter(name, value)
        world = Path(self.get_parameter('world_sdf').value)
        run_dir = Path(self.get_parameter('run_dir').value)
        if not world.is_file() or not run_dir.is_dir():
            raise ValueError('Evaluator requires an existing world SDF and exclusive run dir')
        points = list(self.get_parameter('starts_xy').value)
        if len(points) not in (2, 4):
            raise ValueError('starts_xy must contain one or two (x,y) pairs')
        self.evaluator = Evaluator(
            world, [(points[i], points[i+1]) for i in range(0, len(points), 2)],
            resolution=float(self.get_parameter('resolution').value),
            exploration_target=float(self.get_parameter('exploration_target').value),
            roi_target=float(self.get_parameter('roi_target').value))
        self.output = (run_dir / 'evaluation.csv').open('x', newline='', encoding='utf-8')
        self.writer = csv.DictWriter(self.output, fieldnames=[
            'sim_time', 'reachable_free_seen', 'reachable_free_total',
            'exploration_pct', 'roi_known_cells', 'roi_total_cells',
            'roi_known_pct', 'coverage_passed'])
        self.writer.writeheader()
        self.last_logged = -1e9
        qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                         durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.pub = self.create_publisher(String, '/v4/evaluation', 10)
        self.sub = self.create_subscription(OccupancyGrid, '/map', self.on_map, qos)

    def on_map(self, msg):
        now = self.get_clock().now().nanoseconds / 1e9
        if now - self.last_logged < 5.0:
            return
        q = msg.info.origin.orientation
        yaw = math.atan2(2 * (q.w * q.z + q.x * q.y),
                         1 - 2 * (q.y * q.y + q.z * q.z))
        fused = MapData(msg.info.width, msg.info.height, msg.info.resolution,
                        msg.info.origin.position.x, msg.info.origin.position.y,
                        yaw, tuple(msg.data))
        metrics = self.evaluator.evaluate(fused)
        metrics['sim_time'] = now
        self.writer.writerow(metrics)
        self.output.flush()
        self.pub.publish(String(data=json.dumps(metrics)))
        self.last_logged = now

    def destroy_node(self):
        self.output.close()
        return super().destroy_node()


def main():
    rclpy.init()
    node = EvaluatorNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

