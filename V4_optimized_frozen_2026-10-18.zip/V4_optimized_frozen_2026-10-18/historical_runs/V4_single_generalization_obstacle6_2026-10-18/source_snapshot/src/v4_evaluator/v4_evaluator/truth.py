"""Frozen V3 SDF geometry and reachable-cell logic, copied for V4 evaluation.

Source: V3/src/dual_explore/dual_explore/mapping.py, lines 1-149.
This module belongs only to the separate evaluator package.
"""

from collections import deque
from dataclasses import dataclass
import math
import xml.etree.ElementTree as ET


def _pose(element):
    values = [float(v) for v in (element.findtext('pose') or '0 0 0 0 0 0').split()]
    if len(values) != 6 or abs(values[3]) > 1e-5 or abs(values[4]) > 1e-5:
        raise ValueError('Only planar SDF box poses are supported')
    return values[0], values[1], values[2], values[5]


def _compose(a, b):
    c, s = math.cos(a[3]), math.sin(a[3])
    return (a[0] + c * b[0] - s * b[1],
            a[1] + s * b[0] + c * b[1], a[2] + b[2], a[3] + b[3])


@dataclass(frozen=True)
class Box:
    x: float
    y: float
    yaw: float
    width: float
    depth: float

    def contains(self, x, y, margin=0.0):
        dx, dy = x - self.x, y - self.y
        c, s = math.cos(self.yaw), math.sin(self.yaw)
        local_x, local_y = c * dx + s * dy, -s * dx + c * dy
        return (abs(local_x) <= self.width / 2 + margin and
                abs(local_y) <= self.depth / 2 + margin)

    def corners(self):
        c, s = math.cos(self.yaw), math.sin(self.yaw)
        for dx in (-self.width / 2, self.width / 2):
            for dy in (-self.depth / 2, self.depth / 2):
                yield self.x + c * dx - s * dy, self.y + s * dx + c * dy


def boxes_from_sdf(path, robot_height=0.35):
    """Read fixed box collisions intersecting the robot's vertical footprint."""
    world = ET.parse(path).getroot().find('world')
    if world is None:
        raise ValueError(f'No world element in {path}')
    boxes = []
    for model in world.findall('model'):
        model_pose = _pose(model)
        for link in model.findall('link'):
            link_pose = _compose(model_pose, _pose(link))
            for collision in link.findall('collision'):
                size = collision.findtext('./geometry/box/size')
                if not size:
                    continue  # The ground plane is not a wall.
                w, d, h = map(float, size.split())
                x, y, z, yaw = _compose(link_pose, _pose(collision))
                if z - h / 2 < robot_height and z + h / 2 > 0:
                    boxes.append(Box(x, y, yaw, w, d))
    if not boxes:
        raise ValueError(f'No ground-level box collisions in {path}')
    return boxes


class Grid:
    """Common grid geometry, with cell (0,0) at the lower-left."""

    def __init__(self, boxes, resolution=0.2):
        self.resolution = float(resolution)
        if self.resolution <= 0:
            raise ValueError('resolution must be positive')
        corners = [point for box in boxes for point in box.corners()]
        self.x_min = math.floor(min(x for x, _ in corners) / resolution) * resolution
        self.y_min = math.floor(min(y for _, y in corners) / resolution) * resolution
        x_max = math.ceil(max(x for x, _ in corners) / resolution) * resolution
        y_max = math.ceil(max(y for _, y in corners) / resolution) * resolution
        self.width = max(1, int(round((x_max - self.x_min) / resolution)))
        self.height = max(1, int(round((y_max - self.y_min) / resolution)))

    def cell(self, x, y):
        ix = math.floor((x - self.x_min) / self.resolution)
        iy = math.floor((y - self.y_min) / self.resolution)
        return (ix, iy) if 0 <= ix < self.width and 0 <= iy < self.height else None

    def center(self, cell):
        return (self.x_min + (cell[0] + .5) * self.resolution,
                self.y_min + (cell[1] + .5) * self.resolution)

    def line(self, start, end):
        """Integer Bresenham ray, clipped to the finite map."""
        x0, y0 = start
        x1, y1 = end
        dx, dy = abs(x1 - x0), abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        err = dx - dy
        while True:
            if 0 <= x0 < self.width and 0 <= y0 < self.height:
                yield (x0, y0)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy


class GroundTruth:
    """Reachable free cells from fixed SDF collisions; evaluation only."""

    def __init__(self, boxes, starts, resolution=0.2, robot_radius=0.22):
        self.grid = Grid(boxes, resolution)
        obstacles = set()
        for iy in range(self.grid.height):
            for ix in range(self.grid.width):
                cell = (ix, iy)
                x, y = self.grid.center(cell)
                if any(box.contains(x, y, robot_radius) for box in boxes):
                    obstacles.add(cell)
        self.obstacles = obstacles
        seeds = [self.grid.cell(x, y) for x, y in starts]
        if any(cell is None or cell in obstacles for cell in seeds):
            raise ValueError('A robot starts outside the map or inside inflated obstacles')
        reachable = set(seeds)
        pending = deque(seeds)
        while pending:
            x, y = pending.popleft()
            for cell in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
                ix, iy = cell
                if (0 <= ix < self.grid.width and 0 <= iy < self.grid.height and
                        cell not in obstacles and cell not in reachable):
                    reachable.add(cell)
                    pending.append(cell)
        self.reachable_free = reachable

    @classmethod
    def from_sdf(cls, path, starts, resolution=0.2, robot_radius=0.22):
        return cls(boxes_from_sdf(path), starts, resolution, robot_radius)

