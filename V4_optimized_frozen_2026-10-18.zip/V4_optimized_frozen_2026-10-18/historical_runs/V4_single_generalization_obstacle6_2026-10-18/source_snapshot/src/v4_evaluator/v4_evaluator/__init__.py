"""Isolated SDF-based metrics. Online V4 modules never import this package."""

