"""Contract tests for the new, ROS-free V4 component boundaries."""
import math

from active_slam_v4.allocator import Allocator
from active_slam_v4.fusion import AlignmentFusion
from active_slam_v4.health import (RobotHeartbeat, startup_ready,
                                   backtrack_options, translated_enough)
from active_slam_v4.mission import Mission
from active_slam_v4.model import Candidate, Failure, Grid, Phase, Pose2, Transform2
from active_slam_v4.planner import CandidatePlanner
from active_slam_v4.preview import write_map_preview
from active_slam_v4.safety import safe_velocity, sector_min, select_command


def grid(rows, stamp=10.0, frame='map'):
    return Grid(len(rows[0]), len(rows), 1.0, Pose2(0, 0),
                tuple(v for row in rows for v in row), stamp, frame)


def candidate(robot, region, ident, score=1.0, version=1):
    return Candidate(ident, robot, region, Pose2(1, 1), Pose2(1, 1),
                     version, 10, 2.0, .5, score)


def test_stale_tf_blocks_fusion_and_version_does_not_advance():
    base = grid([[0] * 5 for _ in range(5)])
    fuser = AlignmentFusion(base, min_overlap=4)
    maps = {'robot1': base, 'robot2': base}
    tfs = {name: Transform2(0, 0, 0, 10) for name in maps}
    accepted = fuser.fuse(maps, tfs, 10.5)
    assert accepted.healthy and accepted.overlap_cells == 25
    rejected = fuser.fuse(maps, {**tfs, 'robot2': Transform2(0, 0, 0, 1)}, 10.5)
    assert not rejected.healthy and rejected.grid is None
    assert rejected.version == accepted.version


def test_conflicting_maps_stop_cross_robot_fusion():
    base = grid([[0] * 5 for _ in range(5)])
    wall = grid([[100] * 5 for _ in range(5)])
    fuser = AlignmentFusion(base, min_overlap=4)
    result = fuser.fuse({'robot1': base, 'robot2': wall},
                        {n: Transform2(0, 0, 0, 10) for n in ('robot1', 'robot2')}, 10)
    assert not result.healthy and result.reason == 'occupancy_conflict'
    assert result.conflict_cells == 25


def test_planner_never_accepts_target_without_own_nav2_path():
    g = grid([[0, 0, 0, 0, -1],
              [0, 0, 0, 0, -1],
              [0, 0, 0, 0, -1],
              [0, 0, 0, 0, -1],
              [0, 0, 0, 0, -1]])
    queries = []
    planner = CandidatePlanner(max_path_queries=4)
    denied, log = planner.plan('robot1', g, Pose2(1.5, 2.5),
                               Transform2(0, 0, 0, 10), 1,
                               lambda pose: queries.append(pose) or None)
    assert queries and not denied
    assert log['rejected']['no_nav2_path'] > 0
    accepted, _ = planner.plan('robot1', g, Pose2(1.5, 2.5),
                                Transform2(0, 0, 0, 10), 1,
                                lambda pose: 2.0)
    assert accepted and all(c.robot == 'robot1' for c in accepted)
    assert all(g.at(*g.cell_of(c.pose_local)) == 0 for c in accepted)


def test_region_lease_is_unique_and_uses_sim_time():
    allocator = Allocator(lease_seconds=10)
    choices = [candidate('robot1', 'door', 'a', 2),
               candidate('robot2', 'door', 'b', 1.9),
               candidate('robot2', 'far', 'c', 1.5)]
    assigned = allocator.assign(choices, 5, 1)
    assert {r: c.region_id for r, c in assigned.items()} == {
        'robot1': 'door', 'robot2': 'far'}
    assert allocator.assign(choices, 14.9, 1) == {}
    assert len(allocator.assign(choices, 15, 1)) == 2


def test_startup_gate_and_return_terminal_are_distinct():
    h = RobotHeartbeat(2, 2, 2, 2, 2, True, True)
    assert startup_ready({'robot1': h, 'robot2': h}, 3)
    assert not startup_ready({'robot1': h, 'robot2': h}, 7)
    mission = Mission()
    mission.tick(1, False)
    assert mission.phase == Phase.STARTUP
    mission.tick(2, True)
    assert mission.phase == Phase.EXPLORE
    mission.coverage_update(95.1, 90.1, True, 20)
    assert mission.phase == Phase.RETURN
    for robot in mission.robots:
        assert mission.dispatch_return(robot, Pose2(0, 0), 1, 22, True)
        mission.on_navigation_result(robot, 'success', 30)
    assert mission.result(30).phase == Phase.COMPLETE
    assert mission.result(30).returned == (True, True)


def test_return_retries_are_bounded_with_unique_failure():
    mission = Mission(max_retries=1)
    mission.tick(0, True)
    mission.coverage_update(96, 91, True, 10)
    mission.dispatch_return('robot1', Pose2(0, 0), 1, 11, False)
    mission.dispatch_return('robot1', Pose2(0, 0), 1, 12, False)
    result = mission.result(12)
    assert result.phase == Phase.FAILED
    assert result.failure == Failure.RETURN
    assert result.exploration_reached


def test_startup_budget_is_relative_to_world_clock_origin():
    mission = Mission(startup_budget_s=90)
    mission.tick(256.5, False)
    assert mission.phase == Phase.STARTUP
    mission.tick(346.4, False)
    assert mission.phase == Phase.STARTUP
    mission.tick(346.5, False)
    assert mission.result(346.5).failure == Failure.STARTUP


def test_preview_keeps_frozen_eight_pixel_palette(tmp_path):
    path = tmp_path / 'map.png'
    write_map_preview(path, [-1, 0, 100], 3, 1)
    payload = path.read_bytes()
    assert payload[:8] == b'\x89PNG\r\n\x1a\n'
    assert int.from_bytes(payload[16:20], 'big') == 24
    assert int.from_bytes(payload[20:24], 'big') == 8


def test_laser_gate_stops_forward_motion_and_stale_scans():
    assert safe_velocity(.25, 0.0, .2, 2.0, True) == (0.0, 0.0, 'obstacle_stop')
    assert safe_velocity(.25, 0.0, 2.0, 2.0, False) == (0.0, 0.0, 'stale_scan')
    assert safe_velocity(.25, 0.0, 2.0, 2.0, True) == (.25, 0.0, None)
    assert safe_velocity(-.06, 0.0, 2.0, .2, True) == (0.0, 0.0, 'obstacle_stop')
    assert safe_velocity(-.06, 0.0, 2.0, .8, True) == (-.06, 0.0, None)
    assert sector_min([2.0, .15, 2.0], -1.0, 1.0, 0.0, .1) == .15
    assert select_command((.2, 0), .1, (0, .5), .1) == ((0, .5), 'recovery')
    assert select_command((.2, 0), .1, (0, .5), 1) == ((.2, 0), 'navigation')


def test_recent_failed_goal_is_spatially_excluded():
    g = grid([[0, 0, 0, 0, -1], [0, 0, 0, 0, -1],
              [0, 0, 0, 0, -1], [0, 0, 0, 0, -1]])
    planner = CandidatePlanner(max_path_queries=20)
    accepted, _ = planner.plan('robot1', g, Pose2(1.5, 1.5),
                               Transform2(0, 0, 0, 10), 1, lambda _: 2.0)
    assert accepted
    denied, stats = planner.plan('robot1', g, Pose2(1.5, 1.5),
                                 Transform2(0, 0, 0, 10), 1,
                                 lambda _: 2.0,
                                 forbidden_targets=tuple(c.pose_local for c in accepted))
    assert len(denied) < len(accepted)
    assert stats['rejected']['recent_failure'] > 0


def test_planner_does_not_dispatch_goal_inside_nav2_tolerance():
    g = grid([[0, 0, 0, 0, -1], [0, 0, 0, 0, -1],
              [0, 0, 0, 0, -1], [0, 0, 0, 0, -1]])
    candidates, stats = CandidatePlanner(max_path_queries=20).plan(
        'robot1', g, Pose2(2.5, 1.5), Transform2(0, 0, 0, 10), 1,
        lambda _: 2.0)
    assert all(math.hypot(c.pose_local.x-2.5, c.pose_local.y-1.5) >= .6
               for c in candidates)
    assert stats['rejected']['too_close'] > 0


def test_path_queries_spread_across_regions_when_one_area_is_blocked():
    rows = [[0] * 20 for _ in range(5)]
    for row in rows[1:4]:
        row[5] = -1
        row[15] = -1
    g = grid(rows)
    queries = []
    planner = CandidatePlanner(max_candidates=20, max_path_queries=12)
    accepted, stats = planner.plan('robot1', g, Pose2(1.5, 2.5),
                                   Transform2(0, 0, 0, 10), 1,
                                   lambda p: queries.append(p) or
                                   (None if p.x < 10 else 3.0))
    assert stats['spatial_regions'] >= 2
    assert any(p.x > 10 for p in queries)
    assert accepted and all(c.pose_local.x > 10 for c in accepted)


def test_backtrack_uses_reached_pose_outside_stuck_spot():
    history = [Pose2(0, 0), Pose2(1, 0), Pose2(2, 0)]
    assert backtrack_options(history, Pose2(2.1, 0)) == (
        Pose2(1, 0), Pose2(0, 0))


def test_goal_deadline_requires_adapter_to_handle_cancellation():
    mission = Mission(robots=('robot1',), goal_budget_s=5)
    mission.tick(0, True)
    mission.dispatch(candidate('robot1', 'room', 'goal'), 1)
    mission.tick(6, True)
    assert mission.expired_goals(6) == (('robot1', 'goal'),)
    assert 'robot1' in mission.active  # adapter still has a cancellable action
    mission.on_navigation_result('robot1', 'timeout', 6)
    assert mission.expired_goals(6) == ()


def test_stall_watchdog_requires_translation_not_rotation():
    assert not translated_enough(Pose2(0, 0, math.pi), Pose2(0, 0, 0))
    assert translated_enough(Pose2(.13, 0, 0), Pose2(0, 0, 0))
