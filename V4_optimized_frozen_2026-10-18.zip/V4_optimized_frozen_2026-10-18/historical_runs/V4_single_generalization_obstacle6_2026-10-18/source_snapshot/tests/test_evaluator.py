from pathlib import Path

from v4_evaluator.metrics import Evaluator, MapData


WORLD = Path('/home/lemuel/Downloads/V3/worlds/fast/room.world')


def test_coverage_gate_is_owned_by_evaluator():
    evaluator = Evaluator(WORLD, [(-1.7, -2.5), (-.7, -2.5)], resolution=.2)
    truth = evaluator.truth.grid
    unknown = MapData(truth.width, truth.height, truth.resolution,
                      truth.x_min, truth.y_min, 0,
                      tuple([-1] * (truth.width * truth.height)))
    assert not evaluator.evaluate(unknown)['coverage_passed']
    cells = [100] * (truth.width * truth.height)
    for x, y in evaluator.truth.reachable_free:
        cells[y * truth.width + x] = 0
    complete = MapData(truth.width, truth.height, truth.resolution,
                       truth.x_min, truth.y_min, 0, tuple(cells))
    result = evaluator.evaluate(complete)
    assert result['coverage_passed']
    assert result['exploration_pct'] == 100.0
    assert result['roi_known_pct'] == 100.0
