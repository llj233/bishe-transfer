#!/usr/bin/env python3
"""Stage A: summarize the frozen V3 r11 corridor plateau without changing V3."""
import argparse
from collections import Counter
import csv
import json
from pathlib import Path


def analyze(run_dir: Path):
    decisions = list(csv.DictReader((run_dir / 'decisions.csv').open(newline='')))
    metrics = list(csv.DictReader((run_dir / 'metrics.csv').open(newline='')))
    result = json.loads((run_dir / 'result.json').read_text())
    segments = {}
    for label, lower, upper in [('before_180', 0, 180), ('after_180', 180, float('inf'))]:
        rows = [r for r in decisions if lower <= float(r['sim_s']) < upper]
        failures = [r for r in rows if r['reason'] == 'path_failed']
        segments[label] = {
            'decisions': len(rows),
            'reasons': dict(Counter(r['reason'] for r in rows)),
            'path_failed_by_robot': dict(Counter(r['robot'] for r in failures)),
            'no_candidate_by_robot': dict(Counter(r['robot'] for r in rows
                                                  if r['reason'] == 'no_candidate')),
            'repeated_failed_targets': [
                {'xy_rounded_0_1_m': list(xy), 'count': count}
                for xy, count in Counter((round(float(r['candidate_x']), 1),
                                          round(float(r['candidate_y']), 1))
                                         for r in failures if r['candidate_x'])
                .most_common(10)],
        }
    sampled = [{'sim_s': float(r['sim_seconds']),
                'exploration_pct': float(r['exploration_pct']),
                'roi_known_pct': float(r['known_area_pct'])}
               for r in metrics if r['sim_seconds']]
    at_180 = min(sampled, key=lambda p: abs(p['sim_s'] - 180))
    return {'source': str(run_dir), 'result_status': result['status'],
            'final_exploration_pct': result['exploration_pct'],
            'final_roi_known_pct': result['known_area_pct'],
            'final_sim_s': result['total_time_sim_s'],
            'segments': segments, 'coverage_at_180': at_180,
            'coverage_curve': sampled,
            'snapshot_inventory': {
                'terminal_fused_map': (run_dir / 'fused_slam_map.pgm').is_file(),
                'failure_time_local_maps': False,
                'failure_time_costmaps': False,
                'failure_time_tf': False,
            }}


def report(data):
    after = data['segments']['after_180']
    reasons = after['reasons']
    at_180 = data['coverage_at_180']
    top = after['repeated_failed_targets'][:3]
    return f'''# V4 阶段 A：r11 走廊故障诊断起点

冻结 V3 数据：`{data['source']}`。本分析只读取旧文件，不修改旧实验。

| 指标 | 数值 |
|---|---:|
| 最终探索率 | {data['final_exploration_pct']:.2f}% |
| 最终 ROI 已知率 | {data['final_roi_known_pct']:.2f}% |
| 约 180 秒时探索率 | {at_180['exploration_pct']:.2f}%（采样于 {at_180['sim_s']:.1f} 秒） |
| 任务仿真时间 | {data['final_sim_s']:.1f} 秒 |
| 180 秒后路径失败 | {reasons.get('path_failed', 0)} 次 |
| 180 秒后无候选 | {reasons.get('no_candidate', 0)} 次 |

## 可证实的现象

180 秒后路径失败按机器人分布：`{after['path_failed_by_robot']}`；无候选按机器人分布：`{after['no_candidate_by_robot']}`。重复失败最多的目标坐标（0.1 m 分箱）为 `{top}`。终点融合图显示未知区仍在通道附近，且有零散占据格。

## 尚不能定论的上游原因

冻结包没有故障时刻的两张本地 SLAM 图、两车全局/局部代价地图、TF 快照。无法从终点融合图区分：SLAM 假障碍、TF 失准、代价地图膨胀堵门、候选虽在公共图安全但本车不可达，或 Nav2 生命周期/服务异常。因此阶段 A 验收门尚未通过，不得据此固定 B/C 的参数或声称 V4 已解决走廊问题。

## 下一次复现必须保存

启动 `active_slam_v4 failure_snapshotter`，在 `path_failed` 或 `no_candidate` 触发时保存 SDF、两张本地图、融合图、两车全局/局部代价地图、TF、目标位姿、路径服务结果和地图版本。将快照与 SDF 可达图按同一坐标叠合，核对通道的最窄可通行宽度、机器人足迹与膨胀半径，再选择修复参数。
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    data = analyze(args.run_dir)
    (args.output_dir / 'r11_diagnosis.json').write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
    (args.output_dir / 'r11_diagnosis.md').write_text(report(data), encoding='utf-8')
    print(args.output_dir / 'r11_diagnosis.md')


if __name__ == '__main__':
    main()
