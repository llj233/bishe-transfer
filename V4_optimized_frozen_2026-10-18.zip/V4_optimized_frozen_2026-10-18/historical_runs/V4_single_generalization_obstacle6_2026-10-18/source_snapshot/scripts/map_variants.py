"""Deterministic, geometry-checked variants of the isolated room world."""
import random
import xml.etree.ElementTree as ET

from v4_evaluator.truth import GroundTruth, boxes_from_sdf


GENERATOR_VERSION = 'room_accessible_obstacles_v3_six'
EXTRA_OBSTACLES = 6
START = (-1.7, -2.5)


def generate_room(source, destination, map_seed):
    """Move two existing boxes and add six; preserve connected free space.

    Rejection depends only on ground-truth geometry, never on the explorer's
    outcome. The same source bytes and seed always produce the same layout.
    """
    reference = GroundTruth.from_sdf(source, [START], resolution=.2)
    fixed_boxes = boxes_from_sdf(source)
    possible = [reference.grid.center(c) for c in sorted(reference.reachable_free)]
    rng = random.Random(int(map_seed))
    for attempt in range(1, 51):
        tree = ET.parse(source)
        world = tree.getroot().find('world')
        if world is None:
            raise ValueError('Missing SDF world')
        models = [world.find(f"model[@name='{name}']")
                  for name in ('unit_box', 'unit_box_0')]
        if any(model is None for model in models):
            raise ValueError('Seeded room generator requires the two room unit boxes')
        placements = []
        for model in models:
            values = [float(v) for v in model.findtext('pose').split()]
            values[0] += rng.uniform(-.55, .55)
            values[1] += rng.uniform(-.55, .55)
            values[5] += rng.uniform(-.25, .25)
            model.find('pose').text = ' '.join(f'{v:.6f}' for v in values)
            placements.append([values[0], values[1], values[5]])
        rng.shuffle(possible)
        added = []
        for x, y in possible:
            if (len(added) >= EXTRA_OBSTACLES or
                    any(box.contains(x, y, .9) for box in fixed_boxes) or
                    (x - START[0]) ** 2 + (y - START[1]) ** 2 < 4.0 or
                    any((x-a) ** 2 + (y-b) ** 2 < 2.56 for a, b, *_ in added)):
                continue
            width = rng.uniform(.45, .7)
            depth = rng.uniform(.45, .7)
            yaw = rng.uniform(-.35, .35)
            model = ET.SubElement(world, 'model', name=f'seeded_obstacle_{len(added)}')
            ET.SubElement(model, 'static').text = '1'
            ET.SubElement(model, 'pose').text = f'{x:.6f} {y:.6f} .30 0 0 {yaw:.6f}'
            link = ET.SubElement(model, 'link', name='link')
            for kind in ('collision', 'visual'):
                geometry = ET.SubElement(ET.SubElement(link, kind, name=kind), 'geometry')
                ET.SubElement(ET.SubElement(geometry, 'box'), 'size').text = (
                    f'{width:.6f} {depth:.6f} .60')
            added.append([x, y, width, depth, yaw])
        if len(added) != EXTRA_OBSTACLES:
            raise ValueError('Not enough safe reachable obstacle positions')
        tree.write(destination, encoding='utf-8', xml_declaration=True)
        try:
            truth = GroundTruth.from_sdf(destination, [START], resolution=.2)
        except ValueError:
            continue
        if len(truth.reachable_free) >= .95 * len(reference.reachable_free):
            return {'generator': GENERATOR_VERSION, 'map_seed': int(map_seed),
                    'attempt': attempt, 'placements_xyyaw': placements,
                    'accessible_obstacles_xy_size_yaw': added,
                    'reachable_cells_0p2m': len(truth.reachable_free)}
    raise ValueError('No connected seeded room layout found in 50 attempts')
