#!/usr/bin/env python3
"""Read isolated V4 single-robot runs; never alter an earlier version."""
import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT.parent
VERSIONS = (
    'V4_single_generalization_2026-10-18',
    'V4_single_generalization_safe_2026-10-18',
    'V4_single_generalization_progress_2026-10-18',
    'V4_single_generalization_retry_2026-10-18',
    'V4_single_generalization_feedback_fix_2026-10-18',
    'V4_single_generalization_nav_reset_2026-10-18',
    'V4_single_generalization_rpp_2026-10-18',
    'V4_single_generalization_tf_lead_2026-10-18',
)
FIELDS = ('version', 'run_dir', 'map_seed', 'policy_seed', 'world_sha256',
          'budget_sim_s', 'status', 'failure', 'exploration_pct', 'roi_known_pct',
          'returned', 'sim_seconds', 'nav_success', 'nav_failure')


def collect(folder):
    manifest = json.loads((folder / 'manifest.json').read_text())
    result_path = folder / 'result.json'
    result = json.loads(result_path.read_text()) if result_path.exists() else {}
    evaluation_path = folder / 'evaluation.csv'
    with evaluation_path.open(newline='') if evaluation_path.exists() else open('/dev/null') as stream:
        samples = list(csv.DictReader(stream))
    evaluation = result.get('evaluation') or (samples[-1] if samples else {})
    events_path = folder / 'mission_events.jsonl'
    events = ([json.loads(line) for line in events_path.read_text().splitlines()]
              if events_path.exists() else [])
    nav = [event for event in events if event.get('event') == 'goal_result']
    return {
        'version': manifest.get('version', ''),
        'run_dir': str(folder.relative_to(PARENT)),
        'map_seed': manifest.get('map_seed', ''),
        'policy_seed': manifest.get('policy_seed', ''),
        'world_sha256': manifest.get('world_sha256', ''),
        'budget_sim_s': manifest.get('max_sim_seconds', ''),
        'status': result.get('status', 'INCOMPLETE'),
        'failure': result.get('failure') or '',
        'exploration_pct': evaluation.get('exploration_pct', ''),
        'roi_known_pct': evaluation.get('roi_known_pct', ''),
        'returned': result.get('returned', {}).get('robot1', ''),
        'sim_seconds': result.get('sim_seconds', ''),
        'nav_success': sum(item.get('result') == 'success' for item in nav),
        'nav_failure': sum(item.get('result') != 'success' for item in nav),
    }


def main():
    folders = [manifest.parent for version in VERSIONS
               for manifest in sorted((PARENT / version / 'experiments').glob('**/manifest.json'))]
    rows = [collect(folder) for folder in folders]
    output = ROOT / 'V4_GENERALIZATION_COMPARISON.csv'
    with output.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    print(f'{len(rows)} runs -> {output}')


if __name__ == '__main__':
    main()
