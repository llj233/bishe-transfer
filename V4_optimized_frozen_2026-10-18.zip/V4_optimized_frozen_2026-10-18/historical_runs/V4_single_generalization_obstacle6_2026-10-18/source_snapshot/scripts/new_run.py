#!/usr/bin/env python3
"""Create an exclusive V4 run folder with frozen inputs and source hashes."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import uuid


ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            sha.update(block)
    return sha.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--world', type=Path, required=True)
    parser.add_argument('--map-name', required=True)
    parser.add_argument('--seed', type=int, required=True)
    parser.add_argument('--group', choices=('no_allocation', 'allocation',
                                             'q_plugin'), required=True)
    parser.add_argument('--stage', choices=('diagnostic', 'pilot', 'formal'),
                        default='diagnostic')
    args = parser.parse_args()
    if not args.world.is_file():
        parser.error('world file does not exist')
    source_files = sorted((ROOT / 'src').glob('**/*.py'))
    source_hashes = {str(p.relative_to(ROOT)): digest(p) for p in source_files}
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    run_dir = (ROOT / 'experiments' / args.stage / args.map_name /
               f'seed_{args.seed:06d}' / args.group /
               f'{stamp}_{uuid.uuid4().hex[:8]}')
    run_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(args.world, run_dir / 'world.sdf')
    manifest = {
        'version': 'v4_redesign_2026-10-17',
        'design_source': 'llj233/bishe-transfer:V4_双机主动SLAM架构重设计_2026-10-17.md',
        'design_git_blob_sha': 'd03f4b01f7510bf4c0d1dd965040bffb48d3dbd4',
        'frozen_v3_archive_sha256':
            'd1707b55b4e2e3f39a2e10daa37dabba2818140700ec4bf364f1295c6005d536',
        'stage': args.stage, 'map': args.map_name, 'seed': args.seed,
        'group': args.group, 'world_sha256': digest(run_dir / 'world.sdf'),
        'source_sha256': source_hashes,
        'roi_definition': 'reachable free cells plus adjacent first-layer obstacles',
        'exploration_target_pct_strict': 95.0,
        'roi_target_pct_strict': 90.0,
    }
    (run_dir / 'manifest.json').write_text(json.dumps(manifest, indent=2,
                                                      ensure_ascii=False), encoding='utf-8')
    print(run_dir)


if __name__ == '__main__':
    main()
