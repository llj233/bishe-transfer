#!/usr/bin/env python3
"""Export every started seed run, including failures and incomplete runs."""
import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'GENERALIZATION_RESULTS.csv'
FIELDS = ('run_dir', 'version', 'map_seed', 'policy_seed', 'world_sha256',
          'budget_sim_s', 'status', 'failure', 'exploration_pct', 'roi_known_pct',
          'returned', 'sim_seconds', 't80_sim_s', 't90_sim_s', 't95_sim_s',
          'nav_success', 'nav_failure')


def first_threshold(rows, threshold, start):
    for row in rows:
        if float(row['exploration_pct']) > threshold:
            return round(float(row['sim_time']) - start, 2)
    return ''


def collect(folder):
    manifest = json.loads((folder / 'manifest.json').read_text())
    result_file = folder / 'result.json'
    result = json.loads(result_file.read_text()) if result_file.exists() else {}
    evaluation_file = folder / 'evaluation.csv'
    with evaluation_file.open(newline='') if evaluation_file.exists() else open('/dev/null') as f:
        samples = list(csv.DictReader(f))
    events_file = folder / 'mission_events.jsonl'
    events = ([json.loads(line) for line in events_file.read_text().splitlines()]
              if events_file.exists() else [])
    terminal = result.get('evaluation') or (samples[-1] if samples else {})
    start = result.get('sim_start_s')
    if start is None:
        starts = [e['sim_time'] for e in events if e.get('event') == 'startup_ready']
        start = starts[0] if starts else (float(samples[0]['sim_time']) if samples else 0)
    nav = [e for e in events if e.get('event') == 'goal_result']
    return {
        'run_dir': str(folder.relative_to(ROOT)),
        'version': manifest.get('version', ''),
        'map_seed': manifest.get('map_seed', ''),
        'policy_seed': manifest.get('policy_seed', ''),
        'world_sha256': manifest.get('world_sha256', ''),
        'budget_sim_s': manifest.get('max_sim_seconds', ''),
        'status': result.get('status', 'INCOMPLETE'),
        'failure': result.get('failure') or '',
        'exploration_pct': terminal.get('exploration_pct', ''),
        'roi_known_pct': terminal.get('roi_known_pct', ''),
        'returned': result.get('returned', {}).get('robot1', ''),
        'sim_seconds': result.get('sim_seconds', ''),
        't80_sim_s': first_threshold(samples, 80, start),
        't90_sim_s': first_threshold(samples, 90, start),
        't95_sim_s': first_threshold(samples, 95, start),
        'nav_success': sum(e.get('result') == 'success' for e in nav),
        'nav_failure': sum(e.get('result') != 'success' for e in nav),
    }


def main():
    folders = sorted((ROOT / 'experiments').glob('**/manifest.json'))
    rows = [collect(path.parent) for path in folders]
    with OUT.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    print(f'{len(rows)} runs -> {OUT}')


if __name__ == '__main__':
    main()
