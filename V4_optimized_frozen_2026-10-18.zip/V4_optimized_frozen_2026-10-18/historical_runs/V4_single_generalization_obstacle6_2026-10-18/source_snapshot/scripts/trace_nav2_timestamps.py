#!/usr/bin/env python3
"""Record read-only TF/path/action ages for one isolated running trial."""
import argparse
import csv
import json
from pathlib import Path

import rclpy
from action_msgs.msg import GoalStatusArray
from nav_msgs.msg import Path as NavPath
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, qos_profile_sensor_data
from rosgraph_msgs.msg import Clock
from tf2_msgs.msg import TFMessage


FIELDS = ('sim_time', 'map_odom_tf_time', 'plan_time', 'received_plan_time',
          'transformed_plan_time', 'follow_path_executing',
          'follow_path_canceling', 'follow_path_aborted')


class Nav2Trace(Node):
    def __init__(self, output):
        super().__init__('v4_nav2_timestamp_trace')
        self.values = {}
        self.stream = output.open('x', newline='', encoding='utf-8')
        self.writer = csv.DictWriter(self.stream, fieldnames=FIELDS)
        self.writer.writeheader()
        self.create_subscription(Clock, '/clock', self.on_clock,
                                 qos_profile_sensor_data)
        self.create_subscription(TFMessage, '/tf', self.on_tf,
                                 qos_profile_sensor_data)
        for key, topic in (
            ('plan_time', '/robot1/plan'),
            ('received_plan_time', '/robot1/received_global_plan'),
            ('transformed_plan_time', '/robot1/transformed_global_plan'),
        ):
            self.create_subscription(
                NavPath, topic,
                lambda msg, k=key: self.on_plan(k, msg), qos_profile_sensor_data)
        self.create_subscription(
            GoalStatusArray, '/robot1/follow_path/_action/status',
            self.on_status, QoSProfile(depth=10,
                                        reliability=ReliabilityPolicy.RELIABLE))
        self.create_timer(1.0, self.write_row)

    def on_clock(self, message):
        self.values['sim_time'] = (message.clock.sec +
                                   message.clock.nanosec / 1e9)

    def on_tf(self, message):
        for transform in message.transforms:
            if (transform.header.frame_id == 'robot1/map' and
                    transform.child_frame_id == 'robot1/odom'):
                stamp = transform.header.stamp
                self.values['map_odom_tf_time'] = stamp.sec + stamp.nanosec / 1e9

    def on_plan(self, key, message):
        stamp = message.header.stamp
        self.values[key] = stamp.sec + stamp.nanosec / 1e9

    def on_status(self, message):
        states = [goal.status for goal in message.status_list]
        self.values['follow_path_executing'] = states.count(2)
        self.values['follow_path_canceling'] = states.count(3)
        self.values['follow_path_aborted'] = states.count(6)

    def write_row(self):
        if 'sim_time' in self.values:
            self.writer.writerow({field: self.values.get(field, '')
                                  for field in FIELDS})
            self.stream.flush()

    def close(self):
        self.stream.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', required=True, type=Path)
    args = parser.parse_args()
    run_dir = args.run_dir.resolve()
    if not (run_dir / 'manifest.json').is_file():
        parser.error('run directory must contain manifest.json')
    manifest = json.loads((run_dir / 'manifest.json').read_text())
    if manifest.get('mode') != 'single':
        parser.error('this trace only supports isolated single-robot runs')
    rclpy.init()
    node = Nav2Trace(run_dir / 'nav2_timestamps.csv')
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.close()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
