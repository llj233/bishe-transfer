# V4 单机导航恢复修正版（独立工作区）

父版本是 `V4_single_generalization_obstacle6_2026-10-18`，父源码哈希保存于 `PARENT_SOURCE_SHA256.json`。源码、构建、运行和报告全部在本目录独立保存。

此次保留六障碍生成器、地图种子 7、策略种子 11、出生点、激光、frontier 候选数和评分，以及探索率 >95%、ROI >90% 后返航的评价。变化集中在导航执行：

1. 使用适配本机 Fast DDS 2.6 的显式 UDP XML 与异步发布；文件和 SHA 随每次运行保存。此项是待验证的通信稳定性修复，不断言它已解决 TF 停滞。
2. Nav2 Humble 行为树拥有唯一的运动恢复入口，最多两次系统恢复（等待/碰撞检测后退），移除内外两套 Spin。控制器仍可正常转向路径和目标朝向。
3. 新目标必须等待上次 NavigateToPose 的最终结果及取消后的短暂停顿；迟到的目标接受会被取消，不抢占恢复。
4. 使用 Nav2 SimpleProgressChecker 12 秒/0.12 米，外层平移停滞保护为 35 秒。路径重规划会改变剩余距离，不再以历史最短反馈值强制判死。
5. 记录路径、局部代价地图和足迹原始时间戳到 `navigation_health.csv`。输入失效或取消长期无结果时，停住速度输出并最多重置一次 Nav2 导航生命周期；SLAM 继续运行。恢复失败后明确终止，避免无限转圈。

先做一次地图 7/策略 11、700 秒预算的窗口复测。若未解决重复停滞，保留失败并结束本轮，避免继续调种子。如果完整探索返航成功，再用未见组合 101/501 做一次同预算验证。两次都保留，不据此宣称泛化成功率。未启动的测试不计入分母。

启动：`source /opt/ros/humble/setup.bash && source install/setup.bash && python3 scripts/run_test.py --map-seed 7 --policy-seed 11 --max-sim-seconds 700 --gui true --wait`

依据：Nav2 Humble 本机默认 BT 与 upstream Humble 源码；[Fast DDS 2.6 UDP XML](https://fast-dds.docs.eprosima.com/en/v2.6.10/fastdds/transport/udp/udp.html) 与[异步发布配置](https://fast-dds.docs.eprosima.com/en/v2.6.10/fastdds/ros2/ros2_configure.html)。
