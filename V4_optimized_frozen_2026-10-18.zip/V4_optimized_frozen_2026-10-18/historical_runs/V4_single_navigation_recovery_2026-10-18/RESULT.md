# 本次测试结果

地图 7/策略 11，六新增障碍，GUI，700 秒预算。24 个测试和两个 ROS 包编译通过。任务在 140.5 秒因导航输入过期及一次 Nav2 重置失败而终止；末次探索率 47.02%，ROI 已知率 47.63%，未返航，恢复 Spin 请求 0 次。

本版父源码未改变。完整失败数据在本目录 `experiments/`；后续另建了 Cyclone DDS 独立对照目录，没有修改本版源码。

[本轮完整诊断与对照报告](../V4_single_navigation_cyclone_2026-10-18/NAVIGATION_TEST_REPORT.md)
