"""ROS adapter for isolated V4 single/dual functional tests.

The online loop reads SLAM maps, scan/odom/TF and Nav2 only. SDF truth is in
the separate evaluator process. This runner is deterministic and has no Q table.
"""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import csv
import json
import math
import os
from pathlib import Path
from threading import Event
import time
import traceback

import rclpy
from action_msgs.msg import GoalStatus as ActionStatus
from geometry_msgs.msg import PoseStamped, PolygonStamped
from nav2_msgs.action import ComputePathToPose, NavigateToPose
from nav2_msgs.msg import Costmap
from nav2_msgs.srv import ManageLifecycleNodes
from nav_msgs.msg import OccupancyGrid, Odometry, Path as NavPath
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy, qos_profile_sensor_data
from rclpy.time import Time
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
from tf2_ros import Buffer, TransformException, TransformListener

from .allocator import Allocator
from .fusion import AlignmentFusion
from .health import RobotHeartbeat, backtrack_options, translated_enough, update_distance_progress
from .mission import Mission
from .model import Candidate, Failure, Grid, Phase, Pose2, Transform2
from .planner import CandidatePlanner
from .navigation_health import navigation_fault
from .preview import write_map_preview


STARTS = {'robot1': Pose2(-1.7, -2.5), 'robot2': Pose2(-.7, -2.5)}


def yaw(q):
    return math.atan2(2 * (q.w * q.z + q.x * q.y),
                      1 - 2 * (q.y * q.y + q.z * q.z))


def to_grid(msg):
    return Grid(msg.info.width, msg.info.height, msg.info.resolution,
                Pose2(msg.info.origin.position.x, msg.info.origin.position.y,
                      yaw(msg.info.origin.orientation)), tuple(msg.data),
                msg.header.stamp.sec + msg.header.stamp.nanosec / 1e9,
                msg.header.frame_id)


def pose_stamped(pose, frame, stamp):
    msg = PoseStamped()
    msg.header.frame_id = frame
    msg.header.stamp = stamp
    msg.pose.position.x = pose.x
    msg.pose.position.y = pose.y
    msg.pose.orientation.z = math.sin(pose.yaw / 2)
    msg.pose.orientation.w = math.cos(pose.yaw / 2)
    return msg


def wait_future(future, timeout_s=5.0):
    done = Event()
    future.add_done_callback(lambda _: done.set())
    if not done.wait(timeout_s):
        return None
    try:
        return future.result()
    except Exception:
        return None


class TestExecutor(Node):
    def __init__(self):
        super().__init__('v4_test_executor')
        self.declare_parameter('mode', 'single')
        self.declare_parameter('run_dir', '')
        self.declare_parameter('max_sim_seconds', 180.0)
        self.declare_parameter('policy_seed', 0)
        mode = self.get_parameter('mode').value
        if mode != 'single':
            raise ValueError('This isolated workspace is single-robot only')
        self.names = ('robot1',)
        self.folder = Path(self.get_parameter('run_dir').value).resolve()
        if not self.folder.is_dir() or not (self.folder / 'manifest.json').is_file():
            raise ValueError('runner must supply an exclusive V4 run directory')
        self.start_wall = time.monotonic()
        self.mission = Mission(robots=self.names,
                               sim_budget_s=float(self.get_parameter('max_sim_seconds').value),
                               startup_budget_s=90.0, goal_budget_s=70.0,
                               max_retries=20)
        self.events = (self.folder / 'mission_events.jsonl').open('x', encoding='utf-8')
        self.written_events = 0
        self.latest = {n: {'map': None, 'scan': -1.0, 'odom': -1.0,
                           'map_rx': -1.0, 'costmap': -1.0,
                           'tf': -1.0, 'pose': None, 'global_tf': None}
                       for n in self.names}
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.qos_map = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                                  durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.map_pub = self.create_publisher(OccupancyGrid, '/map', self.qos_map)
        self.trigger_pub = self.create_publisher(String, '/v4/diagnostic_trigger', 10)
        self.escape_pub = self.create_publisher(String, '/v4/escape_request', 10)
        self.hold_pub = self.create_publisher(String, '/v4/navigation_hold', 10)
        self.eval_sub = self.create_subscription(String, '/v4/evaluation',
                                                 self.on_evaluation, 10)
        self._topic_subscriptions = []
        self.nav = {}
        self.paths = {}
        self.nav_handles = {}
        self.goal_regions = {}
        self.failed_ids = set()
        self.failed_targets = {n: [] for n in self.names}
        self.goal_progress = {}
        self.goal_nav_progress = {}
        self.goal_start_pose = {}
        self.recovery_clients = {}
        self.recovering = {}
        self.nav_sending = {}
        self.nav_results = {}
        self.cancel_since = {}
        self.cancel_hold_until = {n: -1e9 for n in self.names}
        self.navigation_stamps = {n: dict(local=-1.0, footprint=-1.0,
                                         received=-1.0, transformed=-1.0)
                                  for n in self.names}
        self.reset_clients = {}
        self.reset_requested = None
        self.reset_future = None
        self.reset_count = 0
        self.reset_worker = ThreadPoolExecutor(max_workers=1)
        self.health_stream = (self.folder / 'navigation_health.csv').open('x', newline='')
        self.health_writer = csv.writer(self.health_stream)
        self.health_writer.writerow(('sim_time', 'local_costmap_stamp', 'footprint_stamp',
                                    'received_plan_stamp', 'transformed_plan_stamp',
                                    'phase', 'goal_id', 'fault', 'reset_count'))
        self.safe_poses = {n: [STARTS[n]] for n in self.names}
        self.pending_backtrack = {}
        self.backtrack_future = None
        self.backtrack_exhausted = {n: False for n in self.names}
        self.safety_sub = self.create_subscription(String, '/v4/safety_status',
                                                   self.on_safety, 10)
        for name in self.names:
            self._topic_subscriptions.append(self.create_subscription(
                OccupancyGrid, f'/{name}/map',
                lambda msg, n=name: self.on_map(n, msg), self.qos_map))
            self._topic_subscriptions.append(self.create_subscription(
                LaserScan, f'/{name}/scan',
                lambda msg, n=name: self.on_seen(n, 'scan'), qos_profile_sensor_data))
            self._topic_subscriptions.append(self.create_subscription(
                Odometry, f'/{name}/odom',
                lambda msg, n=name: self.on_seen(n, 'odom'), qos_profile_sensor_data))
            self._topic_subscriptions.append(self.create_subscription(
                OccupancyGrid, f'/{name}/global_costmap/costmap',
                lambda msg, n=name: self.on_seen(n, 'costmap'), self.qos_map))
            self.nav[name] = ActionClient(self, NavigateToPose, f'/{name}/navigate_to_pose')
            self.paths[name] = ActionClient(self, ComputePathToPose,
                                            f'/{name}/compute_path_to_pose')
            self.reset_clients[name] = self.create_client(
                ManageLifecycleNodes, f'/{name}/lifecycle_manager_navigation/manage_nodes')
            for key, topic, message_type in (
                ('local', f'/{name}/local_costmap/costmap_raw', Costmap),
                ('footprint', f'/{name}/local_costmap/published_footprint', PolygonStamped),
                ('received', f'/{name}/received_global_plan', NavPath),
                ('transformed', f'/{name}/transformed_global_plan', NavPath),
            ):
                self._topic_subscriptions.append(self.create_subscription(
                    message_type, topic,
                    lambda msg, n=name, k=key: self.on_navigation_input(n, k, msg),
                    qos_profile_sensor_data))
        template = Grid(300, 300, .1, Pose2(-15.0, -15.0), tuple([-1] * 90000),
                        0.0, 'map')
        self.fuser = AlignmentFusion(template, max_age_s=6.0, min_overlap=20,
                                     max_conflict_ratio=.20)
        self.planner = CandidatePlanner(max_candidates=160, max_path_queries=40,
                                        policy_seed=self.get_parameter('policy_seed').value)
        self.allocator = Allocator(lease_seconds=50)
        self.worker = ThreadPoolExecutor(max_workers=1)
        self.plan_future = None
        self.return_future = None
        self.last_planning_sim = -1e9
        self.last_map_stamps = None
        self.fused = None
        self.map_version = 0
        self.last_export_sim = -1e9
        self.last_status_sim = -1e9
        self.last_evaluation = None
        self.unhealthy_since = None
        self.health_reasons = {}
        self.ended = False
        self.create_timer(1.0, self.tick)
        self.get_logger().info(f'V4 {mode} test executor started; run_dir={self.folder}')

    def now(self):
        return self.get_clock().now().nanoseconds / 1e9

    def on_map(self, name, msg):
        if msg.info.width * msg.info.height == len(msg.data) and msg.data:
            self.latest[name]['map'] = msg
            self.latest[name]['map_rx'] = self.now()

    def on_seen(self, name, key):
        self.latest[name][key] = self.now()

    def on_navigation_input(self, name, key, msg):
        stamp = msg.header.stamp
        self.navigation_stamps[name][key] = stamp.sec + stamp.nanosec / 1e9

    def navigation_busy(self, now):
        """Do not overlap cancellation, late goal acceptance or recovery."""
        return (self.reset_requested is not None or self.reset_future is not None or
                bool(self.nav_sending) or
                any(n not in self.mission.active for n in self.nav_results) or
                any(now < t for t in self.cancel_hold_until.values()))

    def reset_navigation(self, name):
        """One bounded reset of Nav2 only; SLAM and the evaluator keep running."""
        client = self.reset_clients[name]
        if not client.wait_for_service(timeout_sec=3.0):
            return False
        for command in (ManageLifecycleNodes.Request.RESET,
                        ManageLifecycleNodes.Request.STARTUP):
            request = ManageLifecycleNodes.Request()
            request.command = command
            response = wait_future(client.call_async(request), 15.0)
            if response is None or not response.success:
                return False
        return True

    def navigation_guard(self, now):
        """Diagnose before recovery and allow at most one Nav2-only reset."""
        name = self.names[0]
        stamps = self.navigation_stamps[name]
        goal = self.mission.active.get(name)
        fault = navigation_fault(
            now, now - goal.assigned_sim_s if goal else 0.0,
            stamps['local'], stamps['footprint'],
            stamps['received'], stamps['transformed']) if goal else None
        self.health_writer.writerow((now, stamps['local'], stamps['footprint'],
                                    stamps['received'], stamps['transformed'],
                                    self.mission.phase.value, goal.goal_id if goal else '',
                                    fault or '', self.reset_count))
        self.health_stream.flush()
        for robot, since in list(self.cancel_since.items()):
            if now - since > 8.0 and not self.reset_requested and self.reset_future is None:
                fault = 'navigation_cancel_timeout'
        if (fault and self.reset_requested is None and self.reset_future is None and
                self.mission.phase in (Phase.EXPLORE, Phase.RETURN)):
            self.mission._event(now, 'navigation_input_fault', robot=name, reason=fault,
                                stamps=dict(stamps))
            self.hold_pub.publish(String(data=json.dumps({'robot': name, 'hold': True})))
            if self.reset_count >= 1:
                self.mission.fail(Failure.NAVIGATION, now)
                return
            self.reset_requested = (name, fault, now)
            if goal:
                self.on_goal_result(name, goal.goal_id, 'tf_stale')
        if self.reset_requested is not None:
            robot, reason, since = self.reset_requested
            # Normally wait for terminal cancellation. The hold gate also
            # makes a bounded lifecycle reset safe if cancellation is stuck.
            if (not self.nav_results and not self.nav_sending) or now - since > 8.0:
                self.reset_requested = None
                self.reset_count += 1
                self.mission._event(now, 'navigation_reset_started', reason=reason,
                                    attempt=self.reset_count)
                self.plan_future = None
                self.return_future = None
                self.reset_future = self.reset_worker.submit(self.reset_navigation, robot)
        if self.reset_future is not None and self.reset_future.done():
            try:
                success = bool(self.reset_future.result())
            except Exception:
                success = False
            self.reset_future = None
            self.mission._event(now, 'navigation_reset_finished', success=success)
            self.unhealthy_since = None
            if not success:
                self.mission.fail(Failure.NAVIGATION, now)
            else:
                self.nav_sending.clear()
                self.nav_results.clear()
                self.nav_handles.clear()
                self.cancel_since.clear()
                self.navigation_stamps[name]['received'] = -1.0
                self.navigation_stamps[name]['transformed'] = -1.0
                self.cancel_hold_until[name] = now + 3.0
                self.last_planning_sim = -1e9
                self.hold_pub.publish(String(data=json.dumps({'robot': name, 'hold': False})))

    def on_evaluation(self, msg):
        try:
            data = json.loads(msg.data)
            self.last_evaluation = data
            old = self.mission.phase
            self.mission.coverage_update(float(data['exploration_pct']),
                                         float(data['roi_known_pct']),
                                         bool(data['coverage_passed']), self.now())
            if old != self.mission.phase and self.mission.phase == Phase.RETURN:
                for handle in self.nav_handles.values():
                    handle.cancel_goal_async()
                self.nav_handles.clear()
                self.goal_regions.clear()
        except (ValueError, KeyError, TypeError) as exc:
            self.get_logger().warning(f'Ignored malformed evaluation: {exc}')

    def on_safety(self, msg):
        try:
            event = json.loads(msg.data)
            if event.get('reason') in ('obstacle_stop', 'obstacle_slow',
                                       'stale_scan', 'escape_started',
                                       'escape_finished'):
                with (self.folder / 'safety_events.jsonl').open('a', encoding='utf-8') as out:
                    out.write(json.dumps(event, ensure_ascii=False) + '\n')
            if event.get('reason') == 'escape_finished':
                name = event.get('robot')
                self.recovering.pop(name, None)
                self.last_planning_sim = -1e9
                self.mission._event(self.now(), 'escape_result',
                                    robot=name,
                                    success=bool(event.get('success')),
                                    detail=event.get('detail'))
                if name in self.safe_poses and not self.backtrack_exhausted[name]:
                    options = backtrack_options(self.safe_poses[name],
                                                self.latest[name]['pose'])
                    if options:
                        self.pending_backtrack[name] = list(options)
                        self.mission._event(self.now(), 'backtrack_queued',
                                            robot=name, options=len(options))
        except (ValueError, TypeError):
            pass

    def refresh_tf(self, now):
        for name in self.names:
            try:
                pose_tf = self.tf_buffer.lookup_transform(
                    f'{name}/map', f'{name}/base_footprint', Time())
                p = pose_tf.transform.translation
                self.latest[name]['pose'] = Pose2(p.x, p.y,
                                                   yaw(pose_tf.transform.rotation))
                stamp = (pose_tf.header.stamp.sec +
                         pose_tf.header.stamp.nanosec / 1e9)
                self.latest[name]['tf'] = stamp if stamp > 0 else now
                alignment = self.tf_buffer.lookup_transform('map', f'{name}/map', Time())
                a = alignment.transform.translation
                self.latest[name]['global_tf'] = Transform2(
                    a.x, a.y, yaw(alignment.transform.rotation), now)
            except TransformException:
                self.latest[name]['pose'] = None
                self.latest[name]['global_tf'] = None

    def ready(self, now):
        heartbeats = {}
        for name in self.names:
            state = self.latest[name]
            nav_ready = self.nav[name].server_is_ready()
            path_ready = self.paths[name].server_is_ready()
            heartbeats[name] = RobotHeartbeat(
                state['scan'], state['odom'], state['map_rx'], state['tf'],
                state['costmap'], nav_ready, path_ready)
        # Single and dual use the same per-robot readiness rule.
        from .health import check_robot
        checks = {name: check_robot(h, now, max_age_s=6.0)
                  for name, h in heartbeats.items()}
        self.health_reasons = {name: reasons for name, (_, reasons) in checks.items()}
        return all(ok for ok, _ in checks.values())

    def publish_map(self, grid):
        msg = OccupancyGrid()
        msg.header.frame_id = 'map'
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.info.resolution = grid.resolution
        msg.info.width = grid.width
        msg.info.height = grid.height
        msg.info.origin.position.x = float(grid.origin.x)
        msg.info.origin.position.y = float(grid.origin.y)
        msg.info.origin.orientation.z = math.sin(grid.origin.yaw / 2)
        msg.info.origin.orientation.w = math.cos(grid.origin.yaw / 2)
        msg.data = list(grid.cells)
        self.map_pub.publish(msg)

    def update_fusion(self, now):
        if any(self.latest[n]['map'] is None or
               self.latest[n]['global_tf'] is None for n in self.names):
            return True
        stamps = tuple((self.latest[n]['map'].header.stamp.sec,
                        self.latest[n]['map'].header.stamp.nanosec) for n in self.names)
        if stamps == self.last_map_stamps:
            return True
        self.last_map_stamps = stamps
        if len(self.names) == 1:
            local = to_grid(self.latest[self.names[0]]['map'])
            self.fused = Grid(local.width, local.height, local.resolution,
                              local.origin, local.cells, now, 'map')
            self.map_version += 1
            self.publish_map(self.fused)
            return True
        maps = {n: to_grid(self.latest[n]['map']) for n in self.names}
        transforms = {n: self.latest[n]['global_tf'] for n in self.names}
        result = self.fuser.fuse(maps, transforms, now)
        if not result.healthy:
            self.get_logger().warning(f'Fusion held: {result.reason}; '
                                      f'overlap={result.overlap_cells} '
                                      f'conflict={result.conflict_cells}')
            return False
        self.fused = result.grid
        self.map_version = result.version
        self.publish_map(result.grid)
        return True

    def query_path(self, name, pose):
        client = self.paths[name]
        if not client.server_is_ready():
            return None
        request = ComputePathToPose.Goal()
        request.goal = pose_stamped(pose, f'{name}/map', self.get_clock().now().to_msg())
        response = wait_future(client.send_goal_async(request), 6.0)
        if response is None or not response.accepted:
            return None
        result = wait_future(response.get_result_async(), 8.0)
        if result is None or result.status != ActionStatus.STATUS_SUCCEEDED:
            return None
        points = [p.pose.position for p in result.result.path.poses]
        if not points:
            return None
        return sum(math.hypot(a.x - b.x, a.y - b.y)
                   for a, b in zip(points, points[1:]))

    def plan_candidates(self, snapshot):
        all_candidates = []
        stats = {}
        for name, grid, pose, alignment, version, forbidden in snapshot:
            items, info = self.planner.plan(
                name, grid, pose, alignment, version,
                lambda target, n=name: self.query_path(n, target),
                frozenset(self.failed_ids), forbidden_targets=forbidden)
            all_candidates.extend(items)
            stats[name] = info
        return all_candidates, stats

    def send_navigation(self, name, pose, goal_id, region_id):
        request = NavigateToPose.Goal()
        request.pose = pose_stamped(pose, f'{name}/map', self.get_clock().now().to_msg())
        self.goal_regions[name] = region_id
        current = self.latest[name]['pose']
        self.goal_progress[name] = (current, self.now())
        self.goal_nav_progress[name] = {'goal_id': goal_id, 'best_m': None,
                                        'improved_at': self.now(), 'last_m': None}
        self.goal_start_pose[name] = current
        self.nav_sending[name] = goal_id
        future = self.nav[name].send_goal_async(
            request, feedback_callback=lambda feedback, n=name, ident=goal_id:
            self.on_navigation_feedback(n, ident, feedback))
        future.add_done_callback(
            lambda f, n=name, ident=goal_id: self.on_goal_accepted(n, ident, f))

    def on_navigation_feedback(self, name, goal_id, message):
        progress = self.goal_nav_progress.get(name)
        if progress is None or progress['goal_id'] != goal_id:
            return
        distance = float(message.feedback.distance_remaining)
        best, improved = update_distance_progress(progress['best_m'], distance)
        if not math.isfinite(distance) or distance <= .05:
            return
        progress['last_m'] = distance
        # Nav2 can rotate or oscillate while making no progress along its path.
        # A quarter-metre reduction is larger than feedback jitter.
        if improved:
            progress['best_m'] = best
            progress['improved_at'] = self.now()

    def on_goal_accepted(self, name, goal_id, future):
        if self.nav_sending.get(name) == goal_id:
            self.nav_sending.pop(name, None)
        try:
            handle = future.result()
        except Exception:
            handle = None
        if handle is None or not handle.accepted:
            self.on_goal_result(name, goal_id, 'no_path')
            return
        self.nav_handles[name] = handle
        result = handle.get_result_async()
        self.nav_results[name] = result
        result.add_done_callback(
            lambda f, n=name, ident=goal_id: self.on_goal_done(n, ident, f))
        active = self.mission.active.get(name)
        if active is None or active.goal_id != goal_id:
            handle.cancel_goal_async()
            self.cancel_since[name] = self.now()

    def on_goal_done(self, name, goal_id, future):
        if self.nav_results.get(name) is future:
            self.nav_results.pop(name, None)
        if name in self.cancel_since:
            self.cancel_since.pop(name, None)
            self.cancel_hold_until[name] = self.now() + 1.0
            self.mission._event(self.now(), 'navigation_cancel_terminal',
                                robot=name, goal_id=goal_id)
        try:
            response = future.result()
            result = ('success' if response.status == ActionStatus.STATUS_SUCCEEDED else
                      'canceled' if response.status == ActionStatus.STATUS_CANCELED else
                      'controller_stall')
        except Exception:
            result = 'runtime_error'
        self.on_goal_result(name, goal_id, result)

    def on_goal_result(self, name, goal_id, result):
        active = self.mission.active.get(name)
        if active is None or active.goal_id != goal_id:
            return
        handle = self.nav_handles.pop(name, None)
        if result in ('timeout', 'blocked', 'tf_stale') and handle is not None:
            handle.cancel_goal_async()
            self.cancel_since[name] = self.now()
            self.mission._event(self.now(), 'goal_cancel_requested',
                                robot=name, goal_id=goal_id, reason=result)
        self.goal_regions.pop(name, None)
        self.goal_progress.pop(name, None)
        self.goal_nav_progress.pop(name, None)
        started_at = self.goal_start_pose.pop(name, None)
        self.allocator.release(name)
        self.mission.on_navigation_result(name, result, self.now())
        if result == 'success':
            self.backtrack_exhausted[name] = False
            pose = self.latest[name]['pose']
            history = self.safe_poses[name]
            if pose is not None and (not history or math.hypot(
                    pose.x-history[-1].x, pose.y-history[-1].y) >= .6):
                history.append(pose)
        elif goal_id.startswith('backtrack:'):
            # Try a different frontier until real progress rather than
            # repeatedly sending recovery goals from the same stuck pose.
            self.backtrack_exhausted[name] = True
            self.pending_backtrack.pop(name, None)
            self.mission._event(self.now(), 'backtrack_exhausted', robot=name,
                                goal_id=goal_id, result=result)
            self.safe_poses[name] = [p for p in self.safe_poses[name]
                                     if math.hypot(p.x-active.pose_local.x,
                                                   p.y-active.pose_local.y) >= .25]
        # Nav2's bounded BT owns movement recovery. This layer only waits for
        # the terminal result and chooses a new frontier after failure.
        if result != 'success':
            self.cancel_hold_until[name] = self.now() + 2.0
        if result != 'success' and not goal_id.startswith('return:'):
            self.failed_ids.add(goal_id)
            # Key the exclusion to physical position, not a map-versioned ID.
            # A failed location must stay excluded beyond one goal budget.
            self.failed_targets[name].append((active.pose_local, self.now() + 180.0))
            self.last_planning_sim = -1e9
            self.trigger_pub.publish(String(data=json.dumps({
                'robot': name, 'reason': result, 'goal_id': goal_id,
                'map_version': self.map_version})))
        elif result == 'success' and not goal_id.startswith('return:'):
            current = self.latest[name]['pose']
            if started_at is not None and current is not None and math.hypot(
                    current.x-started_at.x, current.y-started_at.y) < .35:
                # An immediately successful Nav2 goal gave no new viewpoint.
                self.failed_targets[name].append((active.pose_local,
                                                  self.now() + 60.0))
                self.last_planning_sim = -1e9

    def schedule_explore(self, now):
        if self.navigation_busy(now):
            return
        if self.pending_backtrack or self.backtrack_future is not None:
            if self.backtrack_future is not None:
                if not self.backtrack_future.done():
                    return
                try:
                    name, pose, length = self.backtrack_future.result()
                except Exception as exc:
                    self.get_logger().warning(f'Backtrack path query failed: {exc}')
                    self.backtrack_future = None
                    self.pending_backtrack.clear()
                    return
                self.backtrack_future = None
                if length is not None and name not in self.mission.active:
                    goal_id = f'backtrack:{name}:{self.map_version}:{int(now*1000)}'
                    candidate = Candidate(goal_id, name, 'backtrack', pose,
                                          pose, self.map_version, 0, length,
                                          1.0, 0.0)
                    goal = self.mission.dispatch(candidate, now)
                    if goal:
                        self.pending_backtrack.pop(name, None)
                        self.send_navigation(name, pose, goal.goal_id,
                                             goal.region_id)
                        self.mission._event(now, 'backtrack_assigned',
                                            robot=name, goal_id=goal.goal_id)
                        return
            for name, options in list(self.pending_backtrack.items()):
                if name in self.mission.active:
                    return
                if not options:
                    self.pending_backtrack.pop(name, None)
                    continue
                pose = options.pop(0)
                self.backtrack_future = self.worker.submit(
                    lambda n=name, p=pose: (n, p, self.query_path(n, p)))
                return
        if self.plan_future is not None:
            if not self.plan_future.done():
                return
            try:
                candidates, stats = self.plan_future.result()
            except Exception as exc:
                self.get_logger().error(f'Planning exception: {exc}')
                self.mission.fail(Failure.RUNTIME, now)
                self.plan_future = None
                return
            self.plan_future = None
            occupied = set(self.goal_regions.values())
            choices = []
            for c in candidates:
                if c.region_id in occupied or c.robot in self.mission.active:
                    continue
                latest_map = self.latest[c.robot]['map']
                if latest_map is None:
                    continue
                current = to_grid(latest_map)
                cell = current.cell_of(c.pose_local)
                if cell is None or not 0 <= current.at(*cell) <= 25:
                    continue
                # SLAM can update while Nav2 answers a path query. Recheck the
                # target in the new map and bind its lease to that version.
                choices.append(replace(c, map_version=self.map_version))
            selected = self.allocator.assign(choices, now, self.map_version)
            for name, c in selected.items():
                goal = self.mission.dispatch(c, now)
                if goal:
                    self.send_navigation(name, goal.pose_local,
                                         goal.goal_id, goal.region_id)
            if not selected and all(n not in self.mission.active for n in self.names):
                self.trigger_pub.publish(String(data=json.dumps({
                    'reason': 'no_candidate', 'map_version': self.map_version,
                    'planner_stats': stats})))
            return
        if (now - self.last_planning_sim < 7.0 or self.fused is None or
            all(name in self.mission.active for name in self.names)):
            return
        snapshot = []
        for name in self.names:
            if name in self.mission.active:
                continue
            state = self.latest[name]
            if state['map'] is None or state['pose'] is None:
                continue
            snapshot.append((name, to_grid(state['map']), state['pose'],
                             state['global_tf'], self.map_version,
                             tuple(p for p, expiry in self.failed_targets[name]
                                   if expiry > now)))
        if snapshot:
            self.plan_future = self.worker.submit(self.plan_candidates, snapshot)
            self.last_planning_sim = now

    def schedule_return(self, now):
        if self.navigation_busy(now):
            return
        if self.return_future is not None:
            if not self.return_future.done():
                return
            name, goal_pose, version, length = self.return_future.result()
            self.return_future = None
            goal = self.mission.dispatch_return(name, goal_pose, version,
                                                now, path_exists=length is not None,
                                                door_owner=name)
            if goal:
                self.send_navigation(name, goal.pose_local,
                                     goal.goal_id, goal.region_id)
            return
        if self.mission.active:
            return  # one robot at a time owns narrow-door passage
        for name in self.names:
            if self.mission.returned[name]:
                continue
            pose = self.latest[name]['pose']
            target = STARTS[name]
            if pose is None:
                return
            if math.hypot(pose.x - target.x, pose.y - target.y) <= .35:
                self.mission.returned[name] = True
                self.mission._event(now, 'already_home', robot=name)
                if all(self.mission.returned.values()):
                    self.mission.phase = Phase.COMPLETE
                    self.mission._event(now, 'terminal', result='completed')
                continue
            version = self.map_version
            self.return_future = self.worker.submit(
                lambda n=name, p=target, v=version:
                    (n, p, v, self.query_path(n, p)))
            return

    def export_map(self):
        if self.fused is None:
            return
        g = self.fused
        write_map_preview(self.folder / 'fused_slam_map_preview.png',
                          g.cells, g.width, g.height, scale=8)
        # Standard PGM: y=0 is the ROS lower-left row.
        with (self.folder / 'fused_slam_map.pgm').open('wb') as out:
            out.write(f'P5\n{g.width} {g.height}\n255\n'.encode())
            out.write(bytes(205 if value < 0 else 0 if value >= 65 else 254
                            for y in reversed(range(g.height))
                            for value in g.cells[y*g.width:(y+1)*g.width]))
        (self.folder / 'fused_slam_map.yaml').write_text(
            f'image: fused_slam_map.pgm\nresolution: {g.resolution}\n'
            f'origin: [{g.origin.x}, {g.origin.y}, {g.origin.yaw}]\n'
            'negate: 0\noccupied_thresh: 0.65\nfree_thresh: 0.196\n')

    def flush_events(self):
        for event in self.mission.events[self.written_events:]:
            self.events.write(json.dumps(event, ensure_ascii=False) + '\n')
        self.written_events = len(self.mission.events)
        self.events.flush()

    def finish(self, now):
        if self.ended:
            return
        self.ended = True
        self.export_map()
        self.flush_events()
        result = self.mission.result(now)
        (self.folder / 'result.json').write_text(json.dumps({
            'version': 'v4_single_navigation_cyclone_2026-10-18',
            'mode': 'single',
            'status': result.phase.value,
            'failure': result.failure.value if result.failure else None,
            'exploration_reached': result.exploration_reached,
            'returned': dict(zip(self.names, result.returned)),
            'sim_seconds': result.sim_seconds,
            'sim_start_s': self.mission.start_sim_s,
            'evaluation': self.last_evaluation,
            'map_preview': 'fused_slam_map_preview.png' if self.fused else None,
        }, indent=2, ensure_ascii=False), encoding='utf-8')
        self.get_logger().info(f'V4 run finished: {result.phase.value}; '
                               f'failure={result.failure}')
        self.events.close()
        self.health_stream.close()
        self.reset_worker.shutdown(wait=False, cancel_futures=True)
        self.worker.shutdown(wait=False, cancel_futures=True)
        # The Nav2 action worker may still be waiting for a canceled result.
        # The result, map and events are already durable; exiting this dedicated
        # process lets the launch event shut Gazebo down promptly.
        os._exit(0)

    def tick(self):
        now = self.now()
        if self.ended:
            return
        if time.monotonic() - self.start_wall > 120 and self.mission.phase == Phase.STARTUP:
            self.mission.fail(Failure.STARTUP, now)
        self.refresh_tf(now)
        aligned = self.update_fusion(now)
        ready = self.ready(now)
        self.navigation_guard(now)
        resetting = self.reset_requested is not None or self.reset_future is not None
        if ready:
            self.unhealthy_since = None
        elif self.unhealthy_since is None:
            self.unhealthy_since = now
        healthy_enough = (resetting or ready or self.unhealthy_since is None or
                          now - self.unhealthy_since < 10.0)
        self.mission.tick(now, ready, localization_healthy=healthy_enough or
                          self.mission.phase == Phase.STARTUP,
                          alignment_healthy=aligned or self.mission.phase == Phase.STARTUP)
        for name, goal_id in self.mission.expired_goals(now):
            self.on_goal_result(name, goal_id, 'timeout')
        for name, goal in list(self.mission.active.items()):
            pose = self.latest[name]['pose']
            last_pose, last_time = self.goal_progress.get(name, (pose, now))
            if translated_enough(pose, last_pose):
                self.goal_progress[name] = (pose, now)
            elif now - last_time >= 35.0 and now - goal.assigned_sim_s >= 35.0:
                self.on_goal_result(name, goal.goal_id, 'blocked')
        for name, handle in list(self.nav_handles.items()):
            if name not in self.mission.active:
                handle.cancel_goal_async()
                self.nav_handles.pop(name, None)
                self.goal_regions.pop(name, None)
        if self.mission.phase == Phase.EXPLORE and ready and aligned:
            self.schedule_explore(now)
        elif self.mission.phase == Phase.RETURN and ready:
            self.schedule_return(now)
        if self.fused and now - self.last_export_sim >= 30:
            self.export_map()
            self.last_export_sim = now
        if now - self.last_status_sim >= 10:
            self.get_logger().info(f'phase={self.mission.phase.value} sim={now:.1f} '
                                   f'ready={ready} aligned={aligned} map_v={self.map_version} '
                                   f'coverage={None if not self.last_evaluation else round(self.last_evaluation["exploration_pct"], 2)} '
                                   f'health={self.health_reasons}')
            self.last_status_sim = now
        self.flush_events()
        if self.mission.phase in (Phase.COMPLETE, Phase.FAILED):
            self.finish(now)


def main():
    rclpy.init()
    node = TestExecutor()
    try:
        rclpy.spin(node)
    except Exception:
        detail = traceback.format_exc()
        (node.folder / 'runtime_exception.txt').write_text(detail, encoding='utf-8')
        node.get_logger().error(detail)
    finally:
        if not node.ended:
            node.mission.fail(Failure.RUNTIME, node.now())
            node.finish(node.now())
        node.destroy_node()
