"""Detect stale navigation consumers, not just fresh producer topics.

All ages use original message headers and simulation time. A newly received
message containing an old path does not count as a fresh navigation input.
"""


def navigation_fault(now, goal_age, local_costmap_stamp, footprint_stamp,
                     received_plan_stamp, transformed_plan_stamp):
    # Give navigation time to receive its first map/path and initial rotation.
    if goal_age < 8.0:
        return None
    if local_costmap_stamp < 0 or now - local_costmap_stamp > 4.0:
        return 'local_costmap_stale'
    if footprint_stamp < 0 or now - footprint_stamp > 4.0:
        return 'footprint_stale'
    # This fault means the controller gets new plans but cannot transform them.
    # A BT waiting/recovering with no incoming plan is not this condition.
    if (received_plan_stamp >= 0 and now - received_plan_stamp < 2.5 and
            (transformed_plan_stamp < 0 or
             now - transformed_plan_stamp > 5.0)):
        return 'controller_path_stale'
    return None
