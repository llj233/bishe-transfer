#!/usr/bin/env python3
"""Read three isolated versions and export this diagnostic comparison only."""
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
VERSIONS = (
    ('Six-obstacle reference', 'V4_single_generalization_obstacle6_2026-10-18'),
    ('Bounded recovery / Fast DDS', 'V4_single_navigation_recovery_2026-10-18'),
    ('Bounded recovery / Cyclone DDS', 'V4_single_navigation_cyclone_2026-10-18'),
)


def main():
    rows = []
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5), sharex=True, sharey=True)
    for label, version in VERSIONS:
        paths = list((ROOT.parent / version / 'experiments').glob('**/result.json'))
        for result_path in paths:
            folder = result_path.parent
            result = json.loads(result_path.read_text())
            manifest = json.loads((folder / 'manifest.json').read_text())
            events = [json.loads(x) for x in (folder / 'mission_events.jsonl').read_text().splitlines()]
            log = (folder / 'launch.log').read_text(errors='replace')
            evaluation = result['evaluation']
            rows.append(dict(
                version=version, run_dir=str(folder),
                map_seed=manifest['map_seed'], policy_seed=manifest['policy_seed'],
                world_sha256=manifest['world_sha256'],
                sim_seconds=result['sim_seconds'], status=result['status'],
                failure=result['failure'], exploration_pct=evaluation['exploration_pct'],
                roi_known_pct=evaluation['roi_known_pct'], returned=result['returned']['robot1'],
                nav_success=sum(x.get('result') == 'success' for x in events if x['event'] == 'goal_result'),
                nav_failure=sum(x.get('result') != 'success' for x in events if x['event'] == 'goal_result'),
                spin_requests=log.count('for spin behavior.'),
                stale_tf_log_lines=log.count('Transform data too old'),
                input_faults=sum(x['event'] == 'navigation_input_fault' for x in events),
                nav_reset_attempts=sum(x['event'] == 'navigation_reset_started' for x in events),
                nav_reset_successes=sum(x['event'] == 'navigation_reset_finished' and x.get('success') for x in events),
            ))
            with (folder / 'evaluation.csv').open() as stream:
                samples = list(csv.DictReader(stream))
            times = [float(x['sim_time']) - result['sim_start_s'] for x in samples]
            for ax, field in zip(axes, ('exploration_pct', 'roi_known_pct')):
                ax.plot(times, [float(x[field]) for x in samples], label=label, linewidth=1.8)
    for ax, title, threshold in zip(axes, ('Reachable free-space exploration', 'Fixed ROI known area'), (95, 90)):
        ax.axhline(threshold, color='gray', linestyle='--', linewidth=1, label=f'{threshold}% threshold')
        ax.set(title=title, xlabel='Simulation task time (s)', ylim=(0, 100), xlim=(0, 700))
        ax.grid(alpha=.25)
        ax.legend(fontsize=8, loc='lower right')
    axes[0].set_ylabel('Coverage (%)')
    fig.suptitle('Same six-obstacle world / map seed 7 / policy seed 11; all attempts retained')
    fig.tight_layout()
    fig.savefig(ROOT / 'coverage_comparison.png', dpi=160)
    plt.close(fig)
    with (ROOT / 'NAVIGATION_COMPARISON.csv').open('w', newline='', encoding='utf-8-sig') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(rows, indent=2))


if __name__ == '__main__':
    main()
