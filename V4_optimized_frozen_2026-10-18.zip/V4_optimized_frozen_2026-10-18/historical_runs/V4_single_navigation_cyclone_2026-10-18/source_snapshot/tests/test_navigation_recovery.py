from pathlib import Path
import xml.etree.ElementTree as ET
import yaml

from active_slam_v4.navigation_health import navigation_fault
from run_test import make_configs


def test_fresh_navigation_and_startup_do_not_reset():
    assert navigation_fault(100, 20, 99, 99, 100, 99.8) is None
    assert navigation_fault(100, 2, -1, -1, -1, -1) is None


def test_new_global_path_does_not_hide_a_stale_controller_transform():
    assert navigation_fault(100, 20, 99, 99, 100, 80) == 'controller_path_stale'
    # A paused/recovering BT without a new plan is not a failed path transform.
    assert navigation_fault(100, 20, 99, 99, 90, 90) is None


def test_stale_collision_inputs_are_reported_before_motion_recovery():
    assert navigation_fault(100, 20, 90, 99, 100, 100) == 'local_costmap_stale'
    assert navigation_fault(100, 20, 99, 90, 100, 100) == 'footprint_stale'


def test_generated_config_uses_bounded_humble_recovery_tree(tmp_path):
    make_configs('robot1', tmp_path)
    nav = yaml.safe_load((tmp_path / 'robot1_nav2.yaml').read_text())
    tree_path = Path(nav['bt_navigator']['ros__parameters']['default_nav_to_pose_bt_xml'])
    assert tree_path.is_file() and tree_path.parent == tmp_path
    tree = ET.parse(tree_path)
    assert tree.find('.//ComputePathToPose') is not None
    assert tree.find('.//FollowPath') is not None
    assert tree.find('.//BackUp') is not None
    assert tree.find('.//Spin') is None
