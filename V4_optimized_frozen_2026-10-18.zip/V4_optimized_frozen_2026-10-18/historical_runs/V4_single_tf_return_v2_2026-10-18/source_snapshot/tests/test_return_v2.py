import math
import xml.etree.ElementTree as ET
import yaml

from active_slam_v4.model import Candidate, Pose2, Transform2, Phase
from active_slam_v4.mission import Mission
from active_slam_v4.navigation_health import deployment_error, travel_goal_budget
from run_test import make_configs


def test_physical_home_distance_stays_in_odom_when_slam_frame_moves():
    home = Pose2(1, 2)
    new_map_from_odom = Transform2(3, -1, math.pi/2, 100)
    goal_in_map = new_map_from_odom.apply(home)
    assert math.isclose(goal_in_map.x, 1) and math.isclose(goal_in_map.y, 0, abs_tol=1e-9)
    assert deployment_error(Pose2(1.1, 2), home) < .35
    assert deployment_error(Pose2(1, 0), home) > .35
    assert math.isinf(deployment_error(None, home))


def test_long_nav2_path_has_time_to_run_but_deadline_stays_bounded():
    assert travel_goal_budget(2) == 70
    assert travel_goal_budget(18) >= 18/.18
    assert travel_goal_budget(100) == 150
    mission = Mission(robots=('robot1',), sim_budget_s=700, goal_budget_s=70, adaptive_goal_budget=True)
    mission.tick(0, True)
    candidate = Candidate('far', 'robot1', 'room', Pose2(1,1), Pose2(1,1), 1, 20, 18, .6, 1)
    goal = mission.dispatch(candidate, 1)
    assert goal.deadline_sim_s > 100
    mission.tick(701, True)
    # The action extension never changes the overall mission budget.
    assert mission.phase == Phase.FAILED and mission.failure.value == 'coverage_timeout'


def test_nav2_success_without_home_verification_is_not_a_completed_return():
    mission = Mission(robots=('robot1',))
    mission.tick(0, True)
    mission.coverage_update(96, 95, True, 10)
    mission.dispatch_return('robot1', Pose2(1,1), 1, 11, True)
    mission.on_navigation_result('robot1', 'home_not_reached', 12)
    assert mission.phase == Phase.RETURN and not mission.returned['robot1']


def test_return_uses_rpp_collision_check_and_a_tighter_goal_checker(tmp_path):
    make_configs('robot1', tmp_path)
    nav = yaml.safe_load((tmp_path/'robot1_nav2.yaml').read_text())['controller_server']['ros__parameters']
    assert 'RegulatedPurePursuitController' in nav['FollowPath']['plugin']
    assert nav['FollowPath']['use_collision_detection']
    assert nav['deployment_goal_checker']['xy_goal_tolerance'] == .20
    assert ET.parse(tmp_path/'navigate_return.xml').find('.//FollowPath').get('goal_checker_id') == 'deployment_goal_checker'
    assert ET.parse(tmp_path/'navigate_bounded.xml').find('.//FollowPath').get('goal_checker_id') == 'general_goal_checker'
