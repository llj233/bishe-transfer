set pagination off
set confirm off
set print thread-events off
set debuginfod enabled off
set logging file /home/lemuel/Downloads/V4_single_tf_diagnosis_2026-10-18/experiments/single/room/map_seed_000007/policy_seed_000011/20261018T063046Z_2794ab09/controller_threads.log
set logging overwrite on
set logging enabled on
handle SIGUSR1 stop noprint nopass
catch signal SIGUSR1
commands
silent
printf "\nV4 THREAD SNAPSHOT\n"
thread apply all bt
continue
end
run
