#!/usr/bin/env python3
"""Signal this run's GDB-owned controller at input freeze and reset cleanup."""
import argparse
import csv
import json
import os
from pathlib import Path
import re
import signal
import time


def child_controller(run_dir):
    log = (run_dir / 'launch.log').read_text(errors='replace')
    match = re.search(r'\[(?:gdb|controller_server)-\d+\]: process started with pid \[(\d+)\]', log)
    if not match:
        return None
    gdb_pid = int(match.group(1))
    for path in Path('/proc').glob('[0-9]*/status'):
        try:
            text = path.read_text()
            ppid = int(re.search(r'^PPid:\s+(\d+)', text, re.M).group(1))
            if ppid != gdb_pid:
                continue
            cmd = (path.parent / 'cmdline').read_bytes()
            if b'/nav2_controller/controller_server' in cmd:
                return int(path.parent.name)
        except (OSError, AttributeError):
            continue
    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-dir', required=True, type=Path)
    args = parser.parse_args()
    run_dir = args.run_dir.resolve()
    sent = set()
    start = time.monotonic()
    output = run_dir / 'stack_triggers.jsonl'
    while time.monotonic() - start < 300:
        if (run_dir / 'result.json').exists():
            return
        health = run_dir / 'navigation_health.csv'
        try:
            with health.open() as stream:
                rows = list(csv.DictReader(stream))
            row = rows[-1]
            now = float(row['sim_time'])
            footprint = float(row['footprint_stamp'])
            reasons = []
            if row['goal_id'] and footprint > 0 and now - footprint >= 3:
                reasons.append('footprint_freeze')
            if int(row['reset_count']) and not row['goal_id']:
                reasons.append('reset_cleanup')
            for reason in reasons:
                if reason in sent:
                    continue
                pid = child_controller(run_dir)
                if pid is not None:
                    os.kill(pid, signal.SIGUSR1)
                    sent.add(reason)
                    with output.open('a') as stream:
                        stream.write(json.dumps({'sim_time': now, 'reason': reason,
                                                 'controller_pid': pid}) + '\n')
                    print(reason, now, pid, flush=True)
        except (OSError, IndexError, ValueError):
            pass
        time.sleep(.2)


if __name__ == '__main__':
    main()
