#!/usr/bin/env python3
"""Export every attempt, a frozen-version validation table, and coverage plots."""
import csv
import json
import math
import os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', '/tmp/v4_tf_fix_matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
REFERENCE_VERSIONS = (
    'V4_single_generalization_obstacle6_2026-10-18',
    'V4_single_navigation_recovery_2026-10-18',
    'V4_single_navigation_cyclone_2026-10-18',
    'V4_single_tf_diagnosis_2026-10-18',
    'V4_single_tf_fix_2026-10-18',
    'V4_single_tf_return_v2_2026-10-18',
)
RESOLUTION_M = .1  # Fixed independent evaluator resolution in this experiment.


def longest_stationary_goal_interval(health):
    """Longest same-goal interval without 0.12 m net displacement; not a contact count."""
    anchor = None
    longest = None
    for row in health:
        if not row.get('goal_id') or not row.get('odom_x') or not row.get('odom_y'):
            anchor = None
            continue
        now, x, y = float(row['sim_time']), float(row['odom_x']), float(row['odom_y'])
        if anchor is None or anchor[0] != row['goal_id'] or math.hypot(x-anchor[2], y-anchor[3]) >= .12:
            anchor = (row['goal_id'], now, x, y)
        longest = max(longest or 0.0, now-anchor[1])
    return round(longest,2) if longest is not None else None


def read_run(folder):
    manifest = json.loads((folder / 'manifest.json').read_text())
    result_path = folder / 'result.json'
    result = json.loads(result_path.read_text()) if result_path.exists() else {}
    events_path = folder / 'mission_events.jsonl'
    events = [json.loads(x) for x in events_path.read_text().splitlines()] if events_path.exists() else []
    log = (folder / 'launch.log').read_text(errors='replace')
    metric = result.get('evaluation') or {}
    start = result.get('sim_start_s', 0)
    gate = next((x['sim_time'] - start for x in events if x['event'] == 'return_gate'), None)
    seconds = result.get('sim_seconds')
    goal_results = [x.get('result') for x in events if x['event'] == 'goal_result']
    health_path = folder / 'navigation_health.csv'
    with health_path.open() if health_path.exists() else open('/dev/null') as stream:
        health = list(csv.DictReader(stream))
    footprint_ages = [float(x['sim_time']) - float(x['footprint_stamp']) for x in health
                      if x['goal_id'] and float(x['footprint_stamp']) >= 0]
    row = dict(
        version=manifest['version'], run_dir=str(folder),
        map_seed=manifest['map_seed'], policy_seed=manifest['policy_seed'],
        world_sha256=manifest['world_sha256'], budget_sim_s=manifest['max_sim_seconds'],
        status=result.get('status', 'INCOMPLETE'), failure=result.get('failure') or '',
        exploration_pct=metric.get('exploration_pct'), roi_known_pct=metric.get('roi_known_pct'),
        explored_free_area_m2=round(metric['reachable_free_seen'] * RESOLUTION_M**2, 2) if metric else None,
        total_reachable_free_area_m2=round(metric['reachable_free_total'] * RESOLUTION_M**2, 2) if metric else None,
        roi_known_area_m2=round(metric['roi_known_cells'] * RESOLUTION_M**2, 2) if metric else None,
        exploration_end_sim_s=round(gate, 2) if gate is not None else None,
        total_task_sim_s=round(seconds, 2) if seconds is not None else None,
        return_phase_sim_s=round(seconds-gate, 2) if seconds is not None and gate is not None else None,
        returned=result.get('returned', {}).get('robot1'),
        home_error_odom_m=result.get('home_error_odom_m', {}).get('robot1'),
        return_nav_failure=sum(x.get('result') != 'success' for x in events
                               if x['event']=='goal_result' and x.get('goal_id','').startswith('return:')),
        nav_success=goal_results.count('success'), nav_failure=len(goal_results)-goal_results.count('success'),
        goal_timeout=goal_results.count('timeout'), goal_blocked=goal_results.count('blocked'),
        input_faults=sum(x['event'] == 'navigation_input_fault' for x in events),
        nav_resets=sum(x['event'] == 'navigation_reset_started' for x in events),
        spin_requests=log.count('for spin behavior.'),
        stale_tf_log_lines=log.count('Transform data too old'),
        off_grid_log_lines=log.count('Pose Goes Off Grid.'),
        max_footprint_age_during_goal_s=round(max(footprint_ages), 3) if footprint_ages else None,
        max_stationary_same_goal_sim_s=longest_stationary_goal_interval(health),
    )
    row['validation_pass'] = bool(
        row['status'] == 'COMPLETE' and row['returned'] and
        row['home_error_odom_m'] is not None and row['home_error_odom_m'] <= .35 and
        row['exploration_pct'] > 95 and row['roi_known_pct'] > 90 and
        not any(row[k] for k in ('input_faults','nav_resets','spin_requests',
                                'stale_tf_log_lines','off_grid_log_lines')))
    return row, result


def export_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8-sig') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def plot_curves(runs, output, title):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), sharex=True, sharey=True)
    for label, folder, result in runs:
        with (folder / 'evaluation.csv').open() as stream:
            samples = list(csv.DictReader(stream))
        times = [float(x['sim_time']) - result['sim_start_s'] for x in samples]
        for ax, field in zip(axes, ('exploration_pct', 'roi_known_pct')):
            ax.plot(times, [float(x[field]) for x in samples], label=label, linewidth=1.7)
    for ax, name, target in zip(axes, ('Reachable free-space exploration', 'Fixed ROI known area'), (95, 90)):
        ax.axhline(target, linestyle='--', color='gray', linewidth=1)
        ax.set(title=name, xlabel='Simulation task time (s)', xlim=(0,700), ylim=(0,100))
        ax.grid(alpha=.25)
        ax.legend(fontsize=8, loc='lower right')
    axes[0].set_ylabel('Coverage (%)')
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(output, dpi=160)
    plt.close(fig)


def main():
    references = [p.parent for name in REFERENCE_VERSIONS
                  for p in sorted((ROOT.parent/name/'experiments').glob('**/manifest.json'))]
    current = [p.parent for p in sorted((ROOT/'experiments').glob('**/manifest.json'))]
    all_rows, validation, curves, before_after = [], [], [], []
    for folder in references + current:
        row, result = read_run(folder)
        all_rows.append(row)
        if folder in current:
            validation.append(row)
            if result:
                curves.append((f"Map {row['map_seed']} / policy {row['policy_seed']}", folder, result))
        if row['map_seed'] == 7 and row['policy_seed'] == 11 and result:
            names = {
                'v4_single_generalization_obstacle6_2026-10-18': 'Earlier six-obstacle version',
                'v4_single_navigation_cyclone_2026-10-18': 'Bounded recovery, old tf2',
                'v4_single_tf_fix_2026-10-18': 'Same recovery, tf2 0.25.24',
                'v4_single_tf_return_v3_2026-10-18': 'TF fix + RPP + verified return',
            }
            if row['version'] in names:
                before_after.append((names[row['version']], folder, result))
    export_csv(ROOT/'ALL_ATTEMPTS.csv', all_rows)
    export_csv(ROOT/'VALIDATION_RESULTS.csv', validation)
    plot_curves(curves, ROOT/'validation_coverage_curves.png', 'Frozen verified-return version: six added obstacles, predefined map/policy pairs')
    plot_curves(before_after, ROOT/'seed7_before_after.png', 'Map 7 / policy 11: same world; all outcomes retained')
    print(json.dumps(validation, indent=2))


if __name__ == '__main__':
    main()
