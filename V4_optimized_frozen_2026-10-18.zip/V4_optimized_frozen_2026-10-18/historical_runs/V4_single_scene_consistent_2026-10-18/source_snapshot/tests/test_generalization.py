from pathlib import Path
import yaml
import xml.etree.ElementTree as ET

from map_variants import generate_room
from run_test import make_configs
from active_slam_v4.model import Pose2
from active_slam_v4.planner import seeded_score
from active_slam_v4.health import update_distance_progress
from v4_evaluator.truth import GroundTruth


ROOM = Path(__file__).resolve().parents[1] / 'worlds/room.world'


def test_map_seed_changes_accessible_geometry_and_replays_exactly(tmp_path):
    a, b, c = (tmp_path / name for name in ('a.world', 'b.world', 'c.world'))
    first = generate_room(ROOM, a, 7)
    replay = generate_room(ROOM, b, 7)
    other = generate_room(ROOM, c, 8)
    assert a.read_bytes() == b.read_bytes()
    assert a.read_bytes() != c.read_bytes()
    assert first == replay
    assert first['generator'] == 'room_static_obstacles_v4_consistent_state'
    assert len(first['accessible_obstacles_xy_size_yaw']) == 6
    assert len(other['accessible_obstacles_xy_size_yaw']) == 6
    assert first['accessible_obstacles_xy_size_yaw'] != other['accessible_obstacles_xy_size_yaw']
    for path in (a, c):
        world = ET.parse(path).getroot().find('world')
        assert world.find('state') is None
        for name in ('unit_box', 'unit_box_0'):
            assert world.find(f"model[@name='{name}']/static").text == '1'
        truth = GroundTruth.from_sdf(path, [(-1.7, -2.5)], resolution=.2)
        assert len(truth.reachable_free) > 8000


def test_policy_seed_is_stable_and_affects_near_tie_preference():
    pose = Pose2(1.25, 2.75)
    one = seeded_score(10.0, 11, 'robot1', pose)
    assert one == seeded_score(10.0, 11, 'robot1', pose)
    assert one != seeded_score(10.0, 12, 'robot1', pose)
    assert 9.9 <= one <= 10.1


def test_navigation_feedback_zero_is_not_a_real_best_distance():
    best, improved = update_distance_progress(None, 0.0)
    assert best is None and not improved
    best, improved = update_distance_progress(best, 5.0)
    assert best == 5.0 and improved
    assert update_distance_progress(best, 4.9) == (5.0, False)
    assert update_distance_progress(best, 4.7) == (4.7, True)


def test_slam_tf_lead_is_written_to_run_config(tmp_path):
    make_configs('robot1', tmp_path)
    slam = yaml.safe_load((tmp_path / 'robot1_slam.yaml').read_text())
    assert slam['/robot1/slam_toolbox']['ros__parameters']['transform_timeout'] == .6
