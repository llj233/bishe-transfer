#include <chrono>
#include <iostream>
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "tf2/buffer_core.hpp"

int main()
{
  tf2::BufferCore buffer;
  geometry_msgs::msg::TransformStamped transform;
  transform.header.frame_id = "map";
  transform.child_frame_id = "odom";
  transform.transform.rotation.w = 1.0;
  transform.header.stamp.sec = 1;
  buffer.setTransform(transform, "regression");
  bool called = false;
  buffer.addTransformableRequest(
    [&](auto, const auto &, const auto &, auto, auto) {
      // The old implementation invokes this under transformable_requests_mutex_.
      // Registering another request deterministically deadlocks that version.
      called = true;
      buffer.addTransformableRequest(
        [](auto, const auto &, const auto &, auto, auto) {},
        "map", "odom", tf2::TimePoint(std::chrono::seconds(3)));
    },
    "map", "odom", tf2::TimePoint(std::chrono::seconds(2)));
  transform.header.stamp.sec = 2;
  buffer.setTransform(transform, "regression");
  if (!called) {return 1;}
  std::cout << "PASS: callback can register a transform request without deadlock\n";
  return 0;
}
