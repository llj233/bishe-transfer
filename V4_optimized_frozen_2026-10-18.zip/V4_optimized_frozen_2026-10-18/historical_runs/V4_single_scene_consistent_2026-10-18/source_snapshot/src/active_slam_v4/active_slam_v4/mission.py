"""Deterministic, replayable mission state and bounded goal lifecycle."""
from typing import Dict, Optional
from .model import Candidate, Failure, Goal, GoalStatus, Phase, RunResult
from .navigation_health import travel_goal_budget


class Mission:
    def __init__(self, robots=('robot1', 'robot2'), sim_budget_s=900.0,
                 startup_budget_s=90.0, goal_budget_s=75.0, max_retries=2,
                 adaptive_goal_budget=False):
        self.robots = tuple(robots)
        self.sim_budget_s = sim_budget_s
        self.startup_budget_s = startup_budget_s
        self.goal_budget_s = goal_budget_s
        self.max_retries = max_retries
        self.adaptive_goal_budget = adaptive_goal_budget
        self.phase = Phase.STARTUP
        self.start_sim_s: Optional[float] = None
        self.failure: Optional[Failure] = None
        self.exploration_reached = False
        self.returned = {robot: False for robot in robots}
        self.active: Dict[str, Goal] = {}
        self.retries = {robot: 0 for robot in robots}
        self.last_replan_sim_s = {robot: -1e9 for robot in robots}
        self.events = []

    def _event(self, sim_s, kind, **fields):
        self.events.append({'sim_time': sim_s, 'phase': self.phase.value,
                            'event': kind, **fields})

    def fail(self, code: Failure, sim_s: float):
        if self.phase in (Phase.COMPLETE, Phase.FAILED):
            return
        self.failure = code
        self.phase = Phase.FAILED
        self._event(sim_s, 'terminal', failure=code.value)

    def tick(self, sim_s: float, all_ready: bool, localization_healthy=True,
             alignment_healthy=True):
        if self.start_sim_s is None:
            self.start_sim_s = sim_s
        elapsed = sim_s - self.start_sim_s
        if self.phase in (Phase.COMPLETE, Phase.FAILED):
            return
        if self.phase == Phase.STARTUP:
            if all_ready:
                self.phase = Phase.EXPLORE
                self._event(sim_s, 'startup_ready')
            elif elapsed >= self.startup_budget_s:
                self.fail(Failure.STARTUP, sim_s)
            return
        if not localization_healthy:
            self.fail(Failure.LOCALIZATION, sim_s)
        elif not alignment_healthy:
            # Cross-robot assignments are unsafe; stop rather than trust bad fusion.
            self.fail(Failure.ALIGNMENT, sim_s)
        elif elapsed >= self.sim_budget_s:
            self.fail(Failure.RETURN if self.phase == Phase.RETURN
                      else Failure.COVERAGE_TIMEOUT, sim_s)

    def expired_goals(self, sim_s: float):
        """Report deadlines; the ROS adapter must cancel and record each goal."""
        if self.phase not in (Phase.EXPLORE, Phase.RETURN):
            return ()
        return tuple((robot, goal.goal_id) for robot, goal in self.active.items()
                     if sim_s >= goal.deadline_sim_s)

    def coverage_update(self, exploration_pct: float, roi_known_pct: float,
                        passed: bool, sim_s: float):
        """Only the separate evaluator may decide whether coverage passed."""
        if self.phase == Phase.EXPLORE and passed:
            self.exploration_reached = True
            self.active.clear()
            self.phase = Phase.RETURN
            self._event(sim_s, 'return_gate', exploration_pct=exploration_pct,
                        roi_known_pct=roi_known_pct)

    def dispatch(self, candidate: Candidate, sim_s: float,
                 current_score: Optional[float] = None, min_replan_s=7.0,
                 switch_margin=.2) -> Optional[Goal]:
        if self.phase != Phase.EXPLORE:
            return None
        old = self.active.get(candidate.robot)
        if old is not None:
            if sim_s - self.last_replan_sim_s[candidate.robot] < min_replan_s:
                return None
            if current_score is not None and candidate.score <= current_score * (1 + switch_margin):
                return None
            self._event(sim_s, 'goal_canceled', robot=candidate.robot,
                        goal_id=old.goal_id, reason='better_target')
        budget = (travel_goal_budget(candidate.path_m, self.goal_budget_s)
                  if self.adaptive_goal_budget else self.goal_budget_s)
        goal = Goal(candidate.candidate_id, candidate.robot, candidate.region_id,
                    candidate.pose_local, candidate.map_version, sim_s,
                    sim_s + budget)
        self.active[candidate.robot] = goal
        self.last_replan_sim_s[candidate.robot] = sim_s
        self._event(sim_s, 'goal_assigned', robot=candidate.robot,
                    goal_id=goal.goal_id, map_version=goal.map_version,
                    path_m=candidate.path_m, budget_s=budget,
                    target_xy=[candidate.pose_local.x, candidate.pose_local.y])
        return goal

    def on_navigation_result(self, robot: str, result: str, sim_s: float):
        goal = self.active.pop(robot, None)
        if goal is None or self.phase not in (Phase.EXPLORE, Phase.RETURN):
            return
        classification = {
            'no_path': 'no_path', 'controller_stall': 'controller_stall',
            'tf_stale': 'tf_stale', 'blocked': 'blocked',
            'canceled': 'canceled', 'timeout': 'timeout',
            'success': 'success', 'home_not_reached': 'home_not_reached'}.get(result, 'runtime_error')
        self._event(sim_s, 'goal_result', robot=robot, goal_id=goal.goal_id,
                    result=classification)
        if classification == 'success':
            self.retries[robot] = 0
            if self.phase == Phase.RETURN:
                self.returned[robot] = True
                if all(self.returned.values()):
                    self.phase = Phase.COMPLETE
                    self._event(sim_s, 'terminal', result='completed')
        else:
            self.retries[robot] += 1
            if self.retries[robot] > self.max_retries:
                self.fail(Failure.RETURN if self.phase == Phase.RETURN
                          else Failure.NAVIGATION, sim_s)

    def dispatch_return(self, robot: str, pose_local, map_version: int,
                        sim_s: float, path_exists: bool,
                        door_owner: Optional[str] = None, path_m=None) -> Optional[Goal]:
        """Caller re-queries Nav2 from current pose before each return segment."""
        if self.phase != Phase.RETURN or self.returned[robot] or robot in self.active:
            return None
        if door_owner not in (None, robot):
            self._event(sim_s, 'return_wait_door', robot=robot, owner=door_owner)
            return None
        if not path_exists:
            self.retries[robot] += 1
            self._event(sim_s, 'return_no_path', robot=robot,
                        retry=self.retries[robot], map_version=map_version)
            if self.retries[robot] > self.max_retries:
                self.fail(Failure.RETURN, sim_s)
            return None
        budget = (travel_goal_budget(path_m, self.goal_budget_s)
                  if self.adaptive_goal_budget else self.goal_budget_s)
        goal = Goal(f'return:{robot}:{map_version}:{int(sim_s*1000)}',
                    robot, 'deployment', pose_local, map_version,
                    sim_s, sim_s + budget)
        self.active[robot] = goal
        self._event(sim_s, 'return_assigned', robot=robot, goal_id=goal.goal_id)
        return goal

    def result(self, sim_s: float) -> RunResult:
        return RunResult(self.phase, self.failure, self.exploration_reached,
                         tuple(self.returned[r] for r in self.robots),
                         sim_s - (self.start_sim_s if self.start_sim_s is not None else sim_s))
