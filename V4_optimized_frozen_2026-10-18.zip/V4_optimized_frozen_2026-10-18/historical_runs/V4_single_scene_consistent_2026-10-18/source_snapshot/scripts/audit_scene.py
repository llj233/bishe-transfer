#!/usr/bin/env python3
"""Read-only Gazebo pose audit; never publishes poses or navigation targets."""
import argparse
import json
import math
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run-dir', type=Path, required=True)
    args = parser.parse_args()
    run = args.run_dir.resolve()
    manifest = json.loads((run/'manifest.json').read_text())
    env = os.environ.copy()
    env['GAZEBO_MASTER_URI'] = manifest['gazebo_master_uri']
    world = ET.parse(run/'world.sdf').getroot().find('world')
    names = ['unit_box', 'unit_box_0'] + [f'seeded_obstacle_{i}' for i in range(6)]
    models = {name: world.find(f"model[@name='{name}']") for name in names}
    rows = []
    deadline = time.monotonic()+60
    for name, model in models.items():
        expected = list(map(float, model.findtext('pose').split()))
        actual = None
        while time.monotonic()<deadline:
            try:
                output = subprocess.check_output(['gz','model','-m',name,'-p'], env=env,
                    text=True, stderr=subprocess.DEVNULL, timeout=4)
                values = list(map(float,output.split()))
                if len(values)==6:
                    actual = values
                    break
            except (subprocess.SubprocessError, ValueError):
                pass
            time.sleep(.5)
        xy = math.hypot(actual[0]-expected[0],actual[1]-expected[1]) if actual else None
        angle = abs(math.atan2(math.sin(actual[5]-expected[5]),
                              math.cos(actual[5]-expected[5]))) if actual else None
        rows.append({'name':name,'expected_pose':expected,'actual_pose':actual,
                     'xy_error_m':xy,'yaw_error_rad':angle,
                     'passed':actual is not None and xy<=.005 and angle<=.01})
    result = {'passed':all(row['passed'] for row in rows),
              'saved_state_absent':world.find('state') is None,'models':rows}
    result['passed'] = result['passed'] and result['saved_state_absent']
    (run/'scene_audit.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result),flush=True)
    return 0 if result['passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
