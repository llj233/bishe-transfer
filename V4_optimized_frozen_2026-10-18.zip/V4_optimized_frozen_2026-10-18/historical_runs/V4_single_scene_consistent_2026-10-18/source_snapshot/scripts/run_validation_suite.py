#!/usr/bin/env python3
"""Run predefined GUI regressions sequentially; stop the suite on any failure."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import uuid

ROOT = Path(__file__).resolve().parents[1]
PAIRS = ((101, 501), (7, 11), (9, 13), (202, 602))


def main():
    uid = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8]
    folder = ROOT/'validation_suites'/uid
    folder.mkdir(parents=True, exist_ok=False)
    state = {'version': ROOT.name, 'status': 'RUNNING', 'runs': [
        {'map_seed': m, 'policy_seed': p, 'status': 'NOT_RUN'} for m,p in PAIRS]}
    output = folder/'suite.json'
    for row in state['runs']:
        before = set((ROOT/'experiments').glob('**/manifest.json'))
        row['status'] = 'RUNNING'
        output.write_text(json.dumps(state, indent=2))
        print(f"Starting map={row['map_seed']} policy={row['policy_seed']}", flush=True)
        code = subprocess.call(['bash',str(ROOT/'scripts/run_gui.sh'),
                                '--map-seed',str(row['map_seed']),
                                '--policy-seed',str(row['policy_seed'])], cwd=ROOT)
        created = set((ROOT/'experiments').glob('**/manifest.json'))-before
        if len(created) != 1:
            row['status'] = 'LAUNCH_ERROR'
        else:
            run = created.pop().parent
            row['run_dir'] = str(run.relative_to(ROOT))
            result_path = run/'result.json'
            result = json.loads(result_path.read_text()) if result_path.exists() else {}
            events_path = run/'mission_events.jsonl'
            events = [json.loads(x) for x in events_path.read_text().splitlines()] if events_path.exists() else []
            error = result.get('home_error_odom_m',{}).get('robot1')
            evaluation = result.get('evaluation') or {}
            audit_path = run/'scene_audit.json'
            audit = json.loads(audit_path.read_text()) if audit_path.exists() else {}
            row.update(status=result.get('status','INCOMPLETE'), home_error_odom_m=error)
            row['scene_audit_passed'] = bool(audit.get('passed'))
            row['passed'] = bool(code == 0 and row['status']=='COMPLETE' and
                result.get('returned',{}).get('robot1') and error is not None and error<=.35 and
                evaluation.get('exploration_pct',0)>95 and evaluation.get('roi_known_pct',0)>90 and
                row['scene_audit_passed'] and
                not any(x['event'] in ('navigation_input_fault','navigation_reset_started') for x in events))
        if not row.get('passed'):
            state['status'] = 'STOPPED_ON_FAILURE'
            output.write_text(json.dumps(state, indent=2))
            print(json.dumps(row), flush=True)
            return 1
        output.write_text(json.dumps(state, indent=2))
        print(json.dumps(row), flush=True)
    state['status'] = 'COMPLETE'
    output.write_text(json.dumps(state, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
