#!/usr/bin/env python3
"""Create an isolated V4 single or dual GUI test and start ROS/Gazebo."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET

import yaml
from map_variants import generate_room


ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / 'assets/robot.sdf'
NAV2 = Path('/opt/ros/humble/share/nav2_bringup/params/nav2_params.yaml')
SLAM = Path('/opt/ros/humble/share/slam_toolbox/config/mapper_params_online_async.yaml')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_rpp_config(controller):
    follow = controller['FollowPath']
    tolerance = max(controller[name]['xy_goal_tolerance']
                    for name in controller['goal_checker_plugins'])
    if follow['use_rotate_to_heading'] and follow['min_lookahead_dist'] <= tolerance:
        raise ValueError('RPP minimum lookahead must exceed every XY goal tolerance')


def make_model(name, path):
    root = ET.parse(MODEL).getroot()
    root.find('.//plugin[@name="turtlebot3_laserscan"]/frame_name').text = f'{name}/base_scan'
    laser = root.find('.//sensor[@name="hls_lfcd_lds"]')
    laser.find('./ray/range/max').text = '10.0'
    laser.find('./ray/scan/horizontal/samples').text = '180'
    laser.find('./update_rate').text = '3'
    drive = root.find('.//plugin[@name="turtlebot3_diff_drive"]')
    drive.find('odometry_frame').text = f'{name}/odom'
    drive.find('robot_base_frame').text = f'{name}/base_footprint'
    camera = root.find('.//sensor[@name="camera"]')
    if camera is not None:
        for link in root.findall('.//link'):
            if camera in list(link):
                link.remove(camera)
                break
    for visual in root.findall('.//sensor/visualize'):
        visual.text = 'false'
    ET.ElementTree(root).write(path, encoding='unicode', xml_declaration=False)


def make_configs(name, folder):
    slam = yaml.safe_load(SLAM.read_text())['slam_toolbox']['ros__parameters']
    slam.update({'odom_frame': f'{name}/odom', 'map_frame': f'{name}/map',
                 'base_frame': f'{name}/base_footprint', 'scan_topic': f'/{name}/scan',
                 'resolution': .1, 'map_update_interval': 2.0,
                 'minimum_travel_distance': .25, 'minimum_travel_heading': .25,
                 'max_laser_range': 10.0, 'do_loop_closing': False,
                 'transform_publish_period': .05, 'transform_timeout': .6,
                 'use_sim_time': True})
    (folder / f'{name}_slam.yaml').write_text(yaml.safe_dump(
        {f'/{name}/slam_toolbox': {'ros__parameters': slam}}, sort_keys=False))
    nav = yaml.safe_load(NAV2.read_text())
    bt = nav['bt_navigator']['ros__parameters']
    bt['global_frame'] = f'{name}/map'
    bt['robot_base_frame'] = f'{name}/base_footprint'
    bt['odom_topic'] = f'/{name}/odom'
    shutil.copy2(ROOT / 'assets/navigate_bounded.xml', folder / 'navigate_bounded.xml')
    (folder / 'navigate_return.xml').write_text(
        (ROOT / 'assets/navigate_bounded.xml').read_text().replace(
            'general_goal_checker', 'deployment_goal_checker'))
    bt['default_nav_to_pose_bt_xml'] = str(folder / 'navigate_bounded.xml')
    controller = nav['controller_server']['ros__parameters']
    controller['controller_frequency'] = 8.0
    controller['progress_checker']['required_movement_radius'] = .12
    controller['progress_checker']['movement_time_allowance'] = 12.0
    controller['general_goal_checker']['xy_goal_tolerance'] = .35
    controller['general_goal_checker']['yaw_goal_tolerance'] = .8
    controller['goal_checker_plugins'] = ['general_goal_checker', 'deployment_goal_checker']
    controller['deployment_goal_checker'] = dict(controller['general_goal_checker'])
    controller['deployment_goal_checker']['xy_goal_tolerance'] = .20
    controller['FollowPath'] = {
        'plugin': 'nav2_regulated_pure_pursuit_controller::RegulatedPurePursuitController',
        'desired_linear_vel': .28, 'lookahead_dist': .40,
        'min_lookahead_dist': .45, 'max_lookahead_dist': .70,
        'lookahead_time': 1.5, 'use_velocity_scaled_lookahead_dist': True,
        'rotate_to_heading_angular_vel': .6, 'transform_tolerance': .3,
        'min_approach_linear_velocity': .05, 'approach_velocity_scaling_dist': .6,
        'use_collision_detection': True, 'max_allowed_time_to_collision_up_to_carrot': 1.2,
        'use_regulated_linear_velocity_scaling': True,
        'use_cost_regulated_linear_velocity_scaling': False,
        'regulated_linear_scaling_min_radius': .9,
        'regulated_linear_scaling_min_speed': .08,
        'use_rotate_to_heading': True, 'rotate_to_heading_min_angle': .7,
        'max_angular_accel': 3.2, 'max_robot_pose_search_dist': 10.0,
        'use_interpolation': True,
    }
    validate_rpp_config(controller)
    for layer, frame in (('local_costmap', f'{name}/odom'),
                         ('global_costmap', f'{name}/map')):
        costmap = nav[layer][layer]['ros__parameters']
        costmap['global_frame'] = frame
        costmap['robot_base_frame'] = f'{name}/base_footprint'
        costmap['update_frequency'] = 2.0 if layer == 'local_costmap' else 1.0
        costmap['publish_frequency'] = 1.0
        for key in ('obstacle_layer', 'voxel_layer'):
            if key in costmap:
                costmap[key]['scan']['topic'] = f'/{name}/scan'
        if layer == 'local_costmap':
            costmap['plugins'] = ['obstacle_layer', 'inflation_layer']
            costmap['obstacle_layer'] = {
                'plugin': 'nav2_costmap_2d::ObstacleLayer', 'observation_sources': 'scan',
                'scan': {'topic': f'/{name}/scan', 'data_type': 'LaserScan',
                         'clearing': True, 'marking': True, 'obstacle_max_range': 3.0,
                         'raytrace_max_range': 3.5}}
            costmap['width'] = 4
            costmap['height'] = 4
            costmap['inflation_layer']['inflation_radius'] = .65
        else:
            costmap['plugins'] = ['static_layer', 'inflation_layer']
            costmap['static_layer']['map_topic'] = f'/{name}/map'
            costmap['static_layer']['map_subscribe_transient_local'] = True
            costmap['inflation_layer']['inflation_radius'] = .70
    nav['planner_server']['ros__parameters']['GridBased']['allow_unknown'] = False
    nav['behavior_server']['ros__parameters']['global_frame'] = f'{name}/odom'
    nav['behavior_server']['ros__parameters']['robot_base_frame'] = f'{name}/base_footprint'
    nav['velocity_smoother']['ros__parameters']['odom_topic'] = f'/{name}/odom'
    (folder / f'{name}_nav2.yaml').write_text(yaml.safe_dump(nav, sort_keys=False))
    make_model(name, folder / f'{name}.sdf')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('single',), default='single')
    parser.add_argument('--world', type=Path, default=ROOT / 'worlds/room.world')
    parser.add_argument('--map-seed', type=int, required=True)
    parser.add_argument('--policy-seed', type=int, required=True)
    parser.add_argument('--max-sim-seconds', type=float, default=180.0)
    parser.add_argument('--gui', choices=('true', 'false'), default='true')
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--wait', action='store_true',
                        help='Keep this launcher alive until the ROS test exits')
    args = parser.parse_args()
    if not all(p.is_file() for p in (args.world, MODEL, NAV2, SLAM)):
        parser.error('world/model/Nav2/SLAM inputs missing')
    if args.world.name != 'room.world':
        parser.error('This seeded evaluator supports room.world only; ROBOTIS models need mesh/include truth support')
    if not 0 <= args.map_seed < 2**32 or args.policy_seed < 0:
        parser.error('map seed must be uint32 and policy seed nonnegative')
    if args.max_sim_seconds <= 0:
        parser.error('max-sim-seconds must be positive')
    uid = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8]
    folder = (ROOT / 'experiments' / args.mode / args.world.stem /
              f'map_seed_{args.map_seed:06d}' / f'policy_seed_{args.policy_seed:06d}' / uid)
    folder.mkdir(parents=True, exist_ok=False)
    map_generation = generate_room(args.world, folder / 'world.sdf', args.map_seed)
    names = ['robot1']
    for name in names:
        make_configs(name, folder)
    domain = 20 + int(uuid.uuid4().hex[:4], 16) % 180
    port = 12000 + int(uuid.uuid4().hex[:4], 16) % 16000
    env = os.environ.copy()
    env['ROS_DOMAIN_ID'] = str(domain)
    env['GAZEBO_MASTER_URI'] = f'http://127.0.0.1:{port}'
    # Installed Fast DDS is 2.6: configure transport with its documented XML,
    # rather than depending on a newer built-in transport environment flag.
    shutil.copy2(ROOT / 'assets/fastdds_udp.xml', folder / 'fastdds_udp.xml')
    env.pop('FASTDDS_BUILTIN_TRANSPORTS', None)
    env['FASTRTPS_DEFAULT_PROFILES_FILE'] = str(folder / 'fastdds_udp.xml')
    env['RMW_FASTRTPS_PUBLICATION_MODE'] = 'ASYNCHRONOUS'
    # This separate version changes only the middleware from its parent trial.
    # Vendor packages are extracted locally, leaving /opt/ros unchanged.
    vendor_prefix = ROOT / 'vendor/root/opt/ros/humble'
    if not (vendor_prefix / 'lib/librmw_cyclonedds_cpp.so').is_file():
        parser.error('isolated Cyclone DDS vendor libraries are missing')
    tf_version = ET.parse(vendor_prefix / 'share/tf2/package.xml').getroot().findtext('version')
    if tf_version != '0.25.24':
        parser.error('this version requires the isolated tf2 0.25.24 deadlock fix')
    env['RMW_IMPLEMENTATION'] = 'rmw_cyclonedds_cpp'
    env['AMENT_PREFIX_PATH'] = str(vendor_prefix) + ':' + env.get('AMENT_PREFIX_PATH', '')
    env['LD_LIBRARY_PATH'] = (str(vendor_prefix / 'lib') + ':' +
                              str(vendor_prefix / 'lib/x86_64-linux-gnu') + ':' +
                              env.get('LD_LIBRARY_PATH', ''))
    env.pop('FASTRTPS_DEFAULT_PROFILES_FILE', None)
    env.pop('RMW_FASTRTPS_PUBLICATION_MODE', None)
    env['DISPLAY'] = env.get('DISPLAY') or ':0'
    if not env.get('XAUTHORITY') or not Path(env['XAUTHORITY']).is_file():
        authorities = sorted(Path(f'/run/user/{os.getuid()}').glob('.mutter-Xwaylandauth.*'),
                             key=lambda path: path.stat().st_mtime)
        if authorities:
            env['XAUTHORITY'] = str(authorities[-1])
    env['QT_X11_NO_MITSHM'] = '1'
    env['ROS_LOG_DIR'] = str(folder / 'ros_logs')
    manifest = {'version': 'v4_single_scene_consistent_2026-10-18', 'mode': args.mode,
                'world_source_sha256': sha(args.world),
                'world_sha256': sha(folder / 'world.sdf'),
                'map_seed': args.map_seed, 'policy_seed': args.policy_seed,
                'gazebo_seed': args.map_seed, 'map_generation': map_generation,
                'max_sim_seconds': args.max_sim_seconds, 'gui': args.gui,
                'ros_domain_id': domain, 'gazebo_master_uri': env['GAZEBO_MASTER_URI'],
                'rmw_implementation': env['RMW_IMPLEMENTATION'],
                'tf2_vendor_version': tf_version,
                'vendor_libraries_sha256': {str(p.relative_to(vendor_prefix)): sha(p) for p in
                                          sorted((vendor_prefix / 'lib').rglob('*.so*'))
                                          if p.is_file()},
                'behavior_tree_sha256': sha(folder / 'navigate_bounded.xml'),
                'return_behavior_tree_sha256': sha(folder / 'navigate_return.xml'),
                'robots': names, 'map_alignment': 'simulator_start_relation_validated_by_overlap',
                'runner_sha256': sha(Path(__file__)),
                'map_generator_sha256': sha(ROOT / 'scripts/map_variants.py'),
                'source_sha256': {str(p.relative_to(ROOT)): sha(p)
                                  for p in sorted((ROOT / 'src').rglob('*'))
                                  if p.is_file() and (p.suffix in ('.py', '.cpp', '.hpp', '.xml')
                                                     or p.name == 'CMakeLists.txt')}}
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    cmd = ['ros2', 'launch', 'active_slam_v4', 'v4_test.launch.py',
           f'run_dir:={folder}', f'world:={folder / "world.sdf"}',
           f'mode:={args.mode}', f'gui:={args.gui}',
           f'map_seed:={args.map_seed}', f'policy_seed:={args.policy_seed}',
           f'max_sim_seconds:={args.max_sim_seconds}']
    print(f'run_dir={folder}', flush=True)
    print(' '.join(cmd), flush=True)
    if args.dry_run:
        return
    log = (folder / 'launch.log').open('w', encoding='utf-8')
    proc = subprocess.Popen(cmd, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                            stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    (folder / 'launch.pid').write_text(str(proc.pid))
    audit_log = (folder / 'scene_audit.log').open('w', encoding='utf-8')
    audit_proc = subprocess.Popen([sys.executable, str(ROOT/'scripts/audit_scene.py'),
                                  '--run-dir', str(folder)], cwd=ROOT, env=env,
                                 stdout=audit_log, stderr=subprocess.STDOUT)
    (folder/'scene_audit.pid').write_text(str(audit_proc.pid))
    print(f'launch_pid={proc.pid} domain={domain} display={env["DISPLAY"]}', flush=True)
    if args.wait:
        raise SystemExit(proc.wait())


if __name__ == '__main__':
    main()
