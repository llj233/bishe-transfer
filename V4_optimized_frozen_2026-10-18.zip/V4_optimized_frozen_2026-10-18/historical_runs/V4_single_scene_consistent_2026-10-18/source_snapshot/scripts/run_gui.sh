#!/usr/bin/env bash
set -e
task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
source /opt/ros/humble/setup.bash
source "$task_root/install/local_setup.bash"
cd "$task_root"
exec python3 scripts/run_test.py --gui true --max-sim-seconds 700 --wait "$@"
