# V4 优化完成冻结版：单机主动 SLAM 探索

**发布标识：`V4_optimized_frozen_2026-10-18`。本包是当前已经验收的单机版本。**

核心运行代码、参数生成器、世界模板及本地运行库与已测试版本一致；新增内容为复现文档、环境检查、归档和校验工具。没有重新训练或修改探索算法。旧 V2/V3 与原 V4 工作目录保持隔离。

## 实验结果

| 类型 | 地图种子 | 策略种子 | 探索率 | ROI 已知率 | 总任务仿真时间 | 返航位置误差 |
|---|---:|---:|---:|---:|---:|---:|
| 预先固定验收 | 7 | 11 | 95.73% | 96.46% | 583 秒 | 0.198 米 |
| 预先固定验收 | 9 | 13 | 95.22% | 95.39% | 618 秒 | 0.195 米 |
| 预先固定验收 | 101 | 501 | 98.26% | 98.54% | 689 秒 | 0.204 米 |
| 预先固定验收 | 202 | 602 | 95.59% | 95.73% | 536 秒 | 0.141 米 |
| 独立随机补充测试 | 375954 | 868225 | 95.22% | 95.34% | 587 秒 | 0.170 米 |

原四组共记录 132 次导航结果，全部成功，目标超时为 0。补充测试独立保存，没有追加到原四组验收表中。五次均完成探索和返航，但这些是同一房间模板的不同障碍布局，不能解释为任意地图的必然成功或统计泛化优势。

- [原四组完整报告](VALIDATION_REPORT.md)、[原四组结果表](VALIDATION_RESULTS.csv)、[覆盖率曲线](validation_coverage_curves.png)
- [随机补充测试报告](SUPPLEMENTARY_RANDOM_TEST.md)、[补充结果表](SUPPLEMENTARY_RESULTS.csv)
- [全部历史尝试](ALL_ATTEMPTS.csv)：原 17 次记录，含 13 次历史调试和四次最终验收；历史原始数据位于 `historical_runs/`
- [复现指南](REPRODUCIBILITY.md)、[发布说明](RELEASE_NOTES.md)、[上传说明](UPLOAD_TO_GITHUB.md)

## 快速复现

环境为 Ubuntu 22.04 x86_64、ROS 2 Humble、Gazebo Classic 11。依赖安装及准确版本见 [复现指南](REPRODUCIBILITY.md)。在解压后的本目录中执行：

```bash
python3 scripts/verify_release.py
python3 scripts/check_environment.py
bash scripts/build_isolated.sh
bash scripts/run_gui.sh --map-seed 7 --policy-seed 11
```

打开 Gazebo 窗口运行单机任务。地图种子和策略种子必须同时提供。探索率 >95% 且 ROI 已知率 >90% 后返航，实际部署位置误差 ≤0.35 米才成功；总任务预算为 700 秒仿真时间。

原四组重新运行：

```bash
python3 scripts/run_validation_suite.py
python3 scripts/export_reproduction_report.py
```

每次仿真使用独立 ROS domain、Gazebo master 和唯一输出目录；复现汇总写入 `reproduction_reports/`，保留发布时的原四组结果表。请一次运行一个仿真。新的运行结果会出现在 `experiments/single/room/map_seed_*/policy_seed_*/*/`。

本包保留了原作者的报告生成脚本；发布后的复现汇总请用 `export_reproduction_report.py`，不要用旧的 `write_final_report.py` 覆盖发布报告。

## 算法与文件

激光/里程计 → slam_toolbox 和动态 TF → 可达 frontier 聚类 → 安全观测位姿 → 可见未知格代理收益与 Nav2 路径代价 → Nav2 全局规划与 RPP 路径跟随 → 地图更新。独立真值评估器只统计覆盖率与任务门槛，不给前沿选择提供未知真值。

这是启发式主动 SLAM 探索导航系统；本版本没有新增强化学习训练或更新 Q 表，没有可供加载的神经网络策略权重。地图种子控制随机障碍物布局；策略种子仅控制近似同分候选的确定性微小偏好。

- `src/`：探索、独立评估、一次性只读场景位姿审计插件和 tf2 回归程序。
- `scripts/`：构建、参数生成、GUI 启动、实验与复现工具。
- `assets/`、`worlds/`：机器人模型、行为树和原始世界模板。
- `vendor/`：本地隔离 tf2/tf2_ros 0.25.24、Cyclone DDS 运行库与官方 DEB，版本/哈希见 `vendor/PACKAGES.json`；不替换系统 ROS。
- `environment/`：作者包版本清单、关键依赖和实际使用的系统参数模板快照。
- `experiments/`：四组原始验收记录。`supplementary_runs/`：独立随机测试。
- `historical_runs/`、`evidence/`：历史失败/调试记录与线程栈；旧版覆盖率真值不一致样本有明确标注。
- `packaging_verification/`：发布副本干净构建、29 项 Python 测试、tf2 回归与地图生成校验记录。

各次输出含 `result.json`、`manifest.json`、`scene_audit.json`、`navigation_health.csv`、`evaluation.csv`、`mission_events.jsonl`，以及 PGM/YAML 建图文件和统一配色、8 倍放大的 PNG。

归档日志与原始 manifest 保留作者机器路径作为来源证据；`REFERENCE_PATH_INDEX.json` 将这些路径映射到本包中的实际位置。运行代码通过自身目录定位，不依赖作者的 `/home/lemuel/Downloads` 路径。
