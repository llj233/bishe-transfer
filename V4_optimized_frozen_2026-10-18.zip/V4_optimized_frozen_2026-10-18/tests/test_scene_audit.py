import json
import xml.etree.ElementTree as ET
from pathlib import Path
from audit_scene import compare_scene
from map_variants import generate_room
ROOM=Path(__file__).resolve().parents[1]/'worlds/room.world'

def test_scene_audit_rejects_real_pose_disagreement_and_dynamic_box(tmp_path):
    generate_room(ROOM,tmp_path/'world.sdf',7)
    world=ET.parse(tmp_path/'world.sdf').getroot().find('world')
    names=['unit_box','unit_box_0']+[f'seeded_obstacle_{i}' for i in range(6)]
    doc={'source':'gazebo_server_WorldPose','sim_time':.001,'models':[
      {'name':n,'static':True,'pose':list(map(float,world.find(f"model[@name='{n}']/pose").text.split()))} for n in names]}
    p=tmp_path/'scene_actual_poses.json'
    p.write_text(json.dumps(doc)); assert compare_scene(tmp_path)['passed']
    doc['models'][0]['pose'][0]+=.2
    p.write_text(json.dumps(doc)); assert not compare_scene(tmp_path)['passed']
    doc['models'][0]['pose'][0]-=.2;doc['models'][0]['static']=False
    p.write_text(json.dumps(doc)); assert not compare_scene(tmp_path)['passed']
