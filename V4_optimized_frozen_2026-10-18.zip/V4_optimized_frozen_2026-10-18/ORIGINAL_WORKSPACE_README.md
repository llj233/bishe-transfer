# V4 单机：TF 死锁、返航与场景真值一致性修复

这是独立单机版本，父版为 `V4_single_scene_consistent_2026-10-18`。旧 V2/V3/V4 目录及系统 `/opt/ros` 不受本版本修改。当前算法为启发式主动 SLAM 探索与 Nav2 导航，没有在本次测试中训练 Q 表或神经网络。

## 本轮结果

四组预先固定的种子均完成探索和返航验收；132 次记录的导航结果全部成功，无目标超时或导航输入故障。本轮优化已停止，代码已冻结。

[完整验收报告](VALIDATION_REPORT.md) · [结果 CSV](VALIDATION_RESULTS.csv) · [覆盖率曲线](validation_coverage_curves.png) · [全部历史尝试](ALL_ATTEMPTS.csv)

## 构建与运行

在本目录的 Ubuntu 22.04 / ROS 2 Humble 环境执行：

```bash
bash scripts/build_isolated.sh
bash scripts/run_gui.sh --map-seed 101 --policy-seed 501
```

单次运行将打开 Gazebo；预算为 700 秒仿真任务时间。输出位于 `experiments/single/room/map_seed_XXXXXX/policy_seed_XXXXXX/唯一运行编号/`，每次创建新目录。不要同时运行多组 GUI 仿真影响负载。

预先固定的四组验收：

```bash
python3 scripts/run_validation_suite.py
```

每次都由服务器内一次性只读插件记录实际障碍物位姿，再核对场景坐标。单组失败会停止本批后续运行，保留原始记录供诊断。地图探索率 >95% 且固定 ROI 已知率 >90% 才进入返航，实际部署位置误差 ≤0.35 米才记为成功。

## 架构

```mermaid
flowchart LR
  A[激光与里程计] --> B[slam_toolbox 与动态 TF]
  B --> C[SLAM 栅格地图]
  C --> D[可达 frontier 聚类]
  D --> E[安全观测位姿与射线收益代理]
  E --> F[Nav2 路径代价与区域选择]
  F --> G[Nav2 全局规划与 RPP 跟随]
  G --> A
  C --> H[独立 SDF 真值评估]
  H --> I{探索大于95%且ROI大于90%}
  I --> J[动态坐标转换后的部署点返航]
  J --> K[部署位置误差核验]
```

收益使用 SLAM 地图中射线可见未知格数的代理量；真实 SDF 几何只供评估器使用，不给 frontier 选择提供未知真值。地图种子决定障碍物布置，策略种子只是近似同分候选的可复现微小偏好，不是成功训练权重。

## 诊断与复现记录

- `ROOT_CAUSE.md`：原始 GDB 双锁死锁证据及官方 tf2 修复。
- `RETURN_FIX.md`：控制器旋转问题、配置中止记录、动态返航位姿与验收误差。
- `SCENE_FIX.md`：旧保存状态覆盖随机坐标的问题与实际场景审计。
- `VALIDATION_PROTOCOL.json`：预先固定种子、预算与验收标准。
- `TF_DEADLOCK_REGRESSION.json`：同一 C++ 回归程序加载旧/新 tf2 的结果。
- `vendor/PACKAGES.json`：本地隔离运行库的准确包版本与 SHA256。
- 每次 `manifest.json`：世界文件、源码、行为树与运行库哈希。
- 每次 `navigation_health.csv`、`mission_events.jsonl`、`evaluation.csv`：轨迹、导航事件与覆盖率曲线原始数据。
- 每次 `fused_slam_map.pgm` / `.yaml`：建图文件；`fused_slam_map_preview.png` 为统一配色、8 倍预览。

四组验收是有限回归验证，不能保证任意地图永不失败。本轮仅使用同一房间模板的不同障碍物布局，不代表所有地图类型。物理碰撞次数未单独装传感器计数，因此不能将“无永久卡住”写成“零碰撞”。Gazebo 默认 WORLD 里程计没有编码器漂移，本轮返航精度只适用于该仿真设置。
