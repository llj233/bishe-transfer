// Read model poses once, inside the server that owns them. No transport, no
// forces, no pose setters, no ROS publishers, and no navigation access.
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/Events.hh>
#include <gazebo/common/UpdateInfo.hh>
#include <cstdlib>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>

namespace gazebo {
class ScenePoseAudit final : public SystemPlugin {
 public:
  void Load(int, char **) override {
    const char *path = std::getenv("V4_SCENE_AUDIT_OUTPUT");
    if (!path || !*path) return;
    output_ = path;
    update_ = event::Events::ConnectWorldUpdateBegin(
        [this](const common::UpdateInfo &info) { this->Record(info); });
  }
 private:
  void Record(const common::UpdateInfo &info) {
    if (recorded_) return;
    auto world = physics::get_world(info.worldName);
    if (!world) return;
    std::vector<std::string> names{"unit_box", "unit_box_0"};
    for (int i=0; i<6; ++i) names.push_back("seeded_obstacle_"+std::to_string(i));
    // Wait until every expected static model has actually been instantiated.
    for (const auto &name : names) if (!world->ModelByName(name)) return;
    std::ofstream out(output_+".tmp",std::ios::trunc);
    out << std::setprecision(17) << "{\"source\":\"gazebo_server_WorldPose\",\"sim_time\":"
        << info.simTime.Double() << ",\"models\":[";
    bool first=true;
    for (const auto &name : names) {
      auto model=world->ModelByName(name);
      const auto pose=model->WorldPose();
      if (!first) out << ',';
      first=false;
      out << "{\"name\":\"" << name << "\",\"static\":"
          << (model->IsStatic()?"true":"false") << ",\"pose\":["
          << pose.Pos().X() << ',' << pose.Pos().Y() << ',' << pose.Pos().Z()
          << ',' << pose.Rot().Roll() << ',' << pose.Rot().Pitch() << ','
          << pose.Rot().Yaw() << "]}";
    }
    out << "]}\n";
    out.close();
    if (out.good() && std::rename((output_+".tmp").c_str(),output_.c_str())==0) {
      recorded_=true;
      update_.reset();
    }
  }
  bool recorded_=false;
  std::string output_;
  event::ConnectionPtr update_;
};
GZ_REGISTER_SYSTEM_PLUGIN(ScenePoseAudit)
}  // namespace gazebo
