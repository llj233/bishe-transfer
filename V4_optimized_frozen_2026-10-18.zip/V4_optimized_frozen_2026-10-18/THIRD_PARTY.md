# 依赖与来源说明

`vendor/debs/` 是本次固定使用的官方 ROS Debian 包；版本及 SHA256 见 `vendor/PACKAGES.json`。解包后的库与原有版权/许可证文件保留在 `vendor/root/usr/share/doc/` 和 `vendor/root/opt/ros/humble/share/doc/`。

工作区各包保留其 `package.xml` 声明的许可证。机器人模型使用 TurtleBot3 Waffle Pi 的模型资源，运行依赖 `ros-humble-turtlebot3-gazebo` 提供的模型；ROS、Nav2、slam_toolbox、Gazebo 和 TurtleBot3 的外部安装包沿用各自许可证。

根因修复采用的官方 tf2 上游依据见 `ROOT_CAUSE.md`，本包没有把第三方运行库宣称为原创算法。
