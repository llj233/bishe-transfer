# 上传 GitHub

本次提供完整 ZIP、同名 `.sha256` 校验文件及一份可直接放在仓库首页的 V4 说明。当前没有自动推送或修改远端仓库。

建议上传到 `llj233/bishe-transfer`：

- `V4_optimized_frozen_2026-10-18.zip`
- `V4_optimized_frozen_2026-10-18.zip.sha256`
- `V4_RELEASE_README.md`

可以沿用此前“Add file → Upload files”的手动上传方式。GitHub 浏览器上传每个文件上限为 25 MiB，见[官方文件上传说明](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)。压缩包实际大小和哈希见 ZIP 旁的发布索引。

若使用 Git 管理解压后的源码，保留 `.gitignore`，提交源码、环境、报告、参考数据和校验清单；不要提交在自己机器生成的 build/install/log 或新实验输出。冻结包内的原始参考记录仍应保留。可用标签 `v4-single-optimized-2026-10-18` 标注这次提交；该标签需要上传后由仓库所有者实际创建，本地打包不会自动创建远端标签。

下载者先校验 ZIP，再解压并按 `REPRODUCIBILITY.md` 构建。改变种子、依赖或参数应建立新实验目录，保留该冻结发布作为参考。
