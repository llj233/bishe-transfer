#!/usr/bin/env python3
"""Summarize completed acceptance and preserve all failed historical attempts."""
import csv,json,hashlib
from pathlib import Path
from datetime import datetime,timezone
from export_validation_report import main as export_tables
ROOT=Path(__file__).resolve().parents[1]

def main():
    export_tables()
    with (ROOT/'VALIDATION_RESULTS.csv').open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
    with (ROOT/'ALL_ATTEMPTS.csv').open(encoding='utf-8-sig') as f: history=list(csv.DictReader(f))
    complete=len(rows)==4 and all(x['validation_pass']=='True' for x in rows)
    lines=['# V4 单机持续优化与验收报告','',f"生成时间：{datetime.now(timezone.utc).isoformat()}",'',
           '## 当前结论','',
           ('四组预先固定的地图/策略种子全部通过验收，本轮停止优化并冻结版本。' if complete else '验收尚未全部通过；当前报告不能作为最终通过结论。'),'',
           '验收条件：探索率 >95%，固定 ROI 已知率 >90%，随后返回实际部署位置，位置误差 ≤0.35 米；总任务预算 700 秒仿真时间。每组实际障碍物坐标审计通过，且无导航输入故障、导航重置、Spin 恢复、陈旧 TF 或 SLAM 越界错误。','',
           '## 修复内容与依据','',
           '1. **永久停更根因**：GDB 两次快照证明旧 tf2 的请求锁与定时器锁相互等待。采用官方 tf2/tf2_ros 0.25.24 修复，在本目录 vendor 中加载。同一 C++ 回归程序加载旧库会超时、加载新库通过；系统 ROS 安装保持原版本。详见 [根因证据](ROOT_CAUSE.md)。',
           '2. **持续转向与返航失败**：旧 DWB 故障样本中 TF 已新鲜，但导航长期只有角速度。更换为 RPP 路径跟随、保留碰撞预测及有限恢复；修正 RPP 最小前视必须大于目标位置容差的配置约束。错误前视配置的一次调试运行明确保留为 ABORTED，没有计为成功。详见 [返航修复](RETURN_FIX.md)。',
           '3. **返航完成判定**：记录实际出生 odom 位姿，按当前动态 TF 转换返航目标；返航用独立 0.20 米 Nav2 容差，动作成功后再核验部署点位置误差 ≤0.35 米。未通过不能记录成功。',
           '4. **时间预算与停滞保护**：单目标预算按实际 Nav2 路径长度在 70–150 秒内计算，总任务仍限 700 秒；保留无平移看门狗、失败目标抑制和取消确认，避免原地转向无限占用任务。',
           '5. **场景真值修正**：原保存 state 覆盖了两个箱子的随机坐标。新生成器删除 state，将这两个箱子固定为静态，每次由服务器内一次性只读插件记录并独立核对 8 个随机箱子的实际坐标；父版 CLI 查询超时样本没有补判成功。旧覆盖率标为未验证，不用于最终真值验收。详见 [场景修复](SCENE_FIX.md)。','',
           '## 最终四组验收','',
           '| 地图/策略种子 | 状态 | 探索率 | ROI 已知率 | 探索面积 m² | 达标时间 s | 总任务 s | 部署点误差 m | 通过 |',
           '|---|---|---:|---:|---:|---:|---:|---:|---|']
    for r in rows:
        def fmt(k,n=2):
            return f"{float(r[k]):.{n}f}" if r.get(k) not in ('',None) else '—'
        lines.append(f"| {r['map_seed']}/{r['policy_seed']} | {r['status']} | {fmt('exploration_pct')}% | {fmt('roi_known_pct')}% | {fmt('explored_free_area_m2')} | {fmt('exploration_end_sim_s',1)} | {fmt('total_task_sim_s',1)} | {fmt('home_error_odom_m',3)} | {'是' if r['validation_pass']=='True' else '否'} |")
    lines += ['', '时间均为仿真任务时间；达标时间是进入返航的时间，总任务时间包括返航与完成确认。CSV 另列启动到结果写入的墙上时间、任务仿真时间/墙上时间比，以及约 1 Hz 里程计采样累计路径；这些不是独立物理接触计数或精确 Gazebo RTF。最终探索率来自最后一次评估采样，不将返航过程从记录中删除。面积为被 SLAM 判为空闲的真值可达栅格数 ×0.01 m²。ROI 包含预先固定的可达自由区及其邻接边界，不是整个地图矩形中的所有墙体内部面积。','',
        '[完整结果表](VALIDATION_RESULTS.csv) · [覆盖率曲线](validation_coverage_curves.png) · [全部尝试，包括失败与中止](ALL_ATTEMPTS.csv)','',
        '## 导航与场景审计','',
        '| 种子 | 导航成功/非成功 | 输入故障/重置 | Spin 请求 | 最长同目标无0.12m净位移 s | 场景审计 | 建图预览 |','|---|---:|---:|---:|---:|---|---|']
    for r in rows:
        folder=Path(r['run_dir']); rel=folder.relative_to(ROOT)
        lines.append(f"| {r['map_seed']}/{r['policy_seed']} | {r['nav_success']}/{r['nav_failure']} | {r['input_faults']}/{r['nav_resets']} | {r['spin_requests']} | {r['max_stationary_same_goal_sim_s']} | [原始坐标]({rel}/scene_audit.json) | [8倍PNG]({rel}/fused_slam_map_preview.png) |")
    lines += ['', '短暂对准路径的转向属于导航动作；最长静止区间由约 1 Hz 的 odom 记录估计，只是诊断量，不是碰撞计数。候选路径不可达与单目标失败被保留，不能与整场任务失败混为一谈。','',
      '## 架构与复现','',
      '激光/里程计 → slam_toolbox 地图和动态 TF → 可达 frontier 聚类 → 安全观测位姿 → 可见未知格代理收益与 Nav2 路径成本 → 区域/候选选择 → Nav2 全局规划与 RPP 跟随 → 新激光观测。独立评估器只负责统计达标条件，不向目标选择提供未知真值。当前是启发式主动 SLAM 导航系统，没有新增强化学习训练或更新 Q 表。', '',
      '地图种子改变障碍物布局；策略种子只对近似同分候选增加可复现的微小偏好，并非训练得到的策略权重。固定源世界、生成器版本、两个种子、参数、运行库版本和哈希即可重建输入；异步 ROS/Gazebo 调度仍可能导致轨迹和耗时差异，不能承诺逐位相同输出。','',
      '运行和构建方法见 [README](README.md)，预先固定规则见 [VALIDATION_PROTOCOL.json](VALIDATION_PROTOCOL.json)。各组 `manifest.json` 锁定输入哈希，`evaluation.csv` 保存曲线，`navigation_health.csv` 保存轨迹/指令/输入年龄，`mission_events.jsonl` 保存目标与阶段结果，`result.json` 保存任务结束状态。地图包含 PGM、YAML 和统一配色的 8 倍 PNG。','',
      '## 历史数据与结论边界','',
      f'本表合计保留 {len(history)} 次尝试，其中本版 {len(rows)} 次；历史 FAILED、ABORTED 和旧场景不一致样本没有从数据中删除。旧世界包含保存状态，本版世界已经修正，因此不将同名种子直接当作同一实际场景做配对速度提升结论。','',
      '四组仅覆盖同一房间模板内不同障碍物布置，是有限回归验收；不代表任意地图与任意种子必然成功，也不能据此作统计泛化优势结论。没有独立接触传感器计数，所以不能声称零物理碰撞。当前 Gazebo 使用 WORLD 来源里程计，没有编码器漂移；真实机器人需另验动态定位、噪声与返航精度。双机协同不在本次单机验收范围。','',
      '完整一次运行可能仍有正常转向、避障或局部目标失败；本轮修复针对的是长期转圈不前进、输入永久停更、任务超时和返航位置误判。只有最终四组全部达标才结束本轮优化。','']
    (ROOT/'VALIDATION_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    runtime_files=[p for d in ('src','assets','worlds','vendor') for p in (ROOT/d).rglob('*') if p.is_file() and '__pycache__' not in str(p)]
    runtime_files += [ROOT/'scripts'/x for x in ('run_test.py','run_gui.sh','run_validation_suite.py','map_variants.py','audit_scene.py','build_isolated.sh')]
    checks={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(runtime_files)}
    (ROOT/'FROZEN_RUNTIME_SHA256.json').write_text(json.dumps({'acceptance_complete':complete,'files':checks},indent=2))
    print('Report written; acceptance_complete=',complete)
if __name__=='__main__': main()
