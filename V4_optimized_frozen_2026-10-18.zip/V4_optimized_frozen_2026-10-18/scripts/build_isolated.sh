#!/usr/bin/env bash
set -e
task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
source /opt/ros/humble/setup.bash
task_vendor="$task_root/vendor/root/opt/ros/humble"
export AMENT_PREFIX_PATH="$task_vendor:$AMENT_PREFIX_PATH"
export CMAKE_PREFIX_PATH="$task_vendor:$CMAKE_PREFIX_PATH"
export LD_LIBRARY_PATH="$task_vendor/lib:$task_vendor/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
cd "$task_root"
colcon build --symlink-install --packages-select active_slam_v4 v4_evaluator tf_deadlock_regression gazebo_scene_audit
