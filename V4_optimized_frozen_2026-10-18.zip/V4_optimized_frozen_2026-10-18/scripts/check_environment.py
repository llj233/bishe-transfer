#!/usr/bin/env python3
"""Check the dependencies and system YAML inputs used by the frozen experiment."""
import argparse,hashlib,json,platform,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser();p.add_argument('--allow-version-drift',action='store_true');p.add_argument('--output',type=Path);a=p.parse_args()
    mismatches=[]
    if platform.machine()!='x86_64':mismatches.append('Vendor libraries require x86_64 Linux')
    osinfo=dict(line.split('=',1) for line in Path('/etc/os-release').read_text().splitlines() if '=' in line)
    if osinfo.get('ID','').strip('"')!='ubuntu' or osinfo.get('VERSION_ID','').strip('"')!='22.04':mismatches.append('Reference system is Ubuntu 22.04')
    if sys.version_info[:2]!=(3,10):mismatches.append('Reference Python major/minor is 3.10')
    expected=json.loads((ROOT/'environment/critical_packages.json').read_text())
    actual={}
    for name,version in expected.items():
        r=subprocess.run(['dpkg-query','-W','-f=${Version}',name],capture_output=True,text=True)
        actual[name]=r.stdout if r.returncode==0 else None
        if actual[name]!=version:mismatches.append(f'{name}: expected {version}; found {actual[name]}')
    for name,entry in json.loads((ROOT/'environment/system_templates.json').read_text()).items():
        path=Path(name)
        if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:mismatches.append(f'System parameter template differs: {name}')
    for path in ('vendor/root/opt/ros/humble/lib/libtf2.so','vendor/root/opt/ros/humble/lib/libtf2_ros.so','vendor/root/opt/ros/humble/lib/librmw_cyclonedds_cpp.so'):
        if not (ROOT/path).is_file():mismatches.append(f'Missing isolated library: {path}')
    result={'strict_match':not mismatches,'allow_version_drift':a.allow_version_drift,'mismatches':mismatches,'actual_critical_packages':actual}
    if a.output:a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
    return 0 if not mismatches or a.allow_version_drift else 1
if __name__=='__main__':raise SystemExit(main())
