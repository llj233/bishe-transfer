#!/usr/bin/env python3
"""Compare server-recorded actual model poses with independent SDF definitions."""
import argparse,json,math,time
from pathlib import Path
import xml.etree.ElementTree as ET

def compare_scene(run):
    world=ET.parse(run/'world.sdf').getroot().find('world')
    actual_doc=json.loads((run/'scene_actual_poses.json').read_text())
    actual={r['name']:r for r in actual_doc['models']}
    names=['unit_box','unit_box_0']+[f'seeded_obstacle_{i}' for i in range(6)]
    rows=[]
    for name in names:
        model=world.find(f"model[@name='{name}']")
        expected=list(map(float,model.findtext('pose').split()))
        record=actual.get(name,{})
        pose=record.get('pose')
        xy=math.hypot(pose[0]-expected[0],pose[1]-expected[1]) if pose else None
        angle=abs(math.atan2(math.sin(pose[5]-expected[5]),math.cos(pose[5]-expected[5]))) if pose else None
        passed=pose is not None and record.get('static') is True and xy<=.005 and angle<=.01
        rows.append({'name':name,'expected_pose':expected,'actual_pose':pose,'static':record.get('static'),'xy_error_m':xy,'yaw_error_rad':angle,'passed':passed})
    return {'passed':all(r['passed'] for r in rows) and world.find('state') is None,
            'source':actual_doc['source'],'sample_sim_time':actual_doc['sim_time'],
            'saved_state_absent':world.find('state') is None,'models':rows}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run-dir',type=Path,required=True)
    args=parser.parse_args();run=args.run_dir.resolve();deadline=time.monotonic()+60
    while not (run/'scene_actual_poses.json').exists() and time.monotonic()<deadline:time.sleep(.2)
    try: result=compare_scene(run)
    except (OSError,ValueError,KeyError) as error: result={'passed':False,'error':str(error)}
    (run/'scene_audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
    return 0 if result['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
