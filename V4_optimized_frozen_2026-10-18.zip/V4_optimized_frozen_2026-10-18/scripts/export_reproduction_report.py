#!/usr/bin/env python3
"""Export the selected rerun suite without replacing the published reference tables."""
import argparse,csv,json
from pathlib import Path
from datetime import datetime,timezone
from export_validation_report import read_run,export_csv,plot_curves
ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser();p.add_argument('--suite-dir',type=Path);a=p.parse_args()
    suites=sorted((ROOT/'validation_suites').glob('*/suite.json'))
    if not a.suite_dir and not suites:p.error('No suite found: run scripts/run_validation_suite.py first')
    source=a.suite_dir/'suite.json' if a.suite_dir else suites[-1]
    suite=json.loads(source.read_text());rows=[];curves=[]
    output=ROOT/'reproduction_reports'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    output.mkdir(parents=True,exist_ok=False)
    for record in suite['runs']:
        if not record.get('run_dir'):continue
        folder=ROOT/record['run_dir'];row,result=read_run(folder);rows.append(row)
        if result:curves.append((f"Map {row['map_seed']} / policy {row['policy_seed']}",folder,result))
    if rows:export_csv(output/'results.csv',rows)
    if curves:plot_curves(curves,output/'coverage.png','Reproduction suite; published reference data unchanged')
    (output/'suite_snapshot.json').write_text(json.dumps(suite,indent=2))
    print(output)
    return 0
if __name__=='__main__':raise SystemExit(main())
