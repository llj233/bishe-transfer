#!/usr/bin/env python3
"""Verify all immutable files shipped in this release; new rerun outputs are allowed."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    manifest=json.loads((ROOT/'RELEASE_MANIFEST.json').read_text());bad=[]
    for name,expected in manifest['files_sha256'].items():
        p=ROOT/name
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:bad.append(name)
    print(json.dumps({'passed':not bad,'checked_files':len(manifest['files_sha256']),'changed_or_missing':bad},indent=2))
    return 1 if bad else 0
if __name__=='__main__':raise SystemExit(main())
