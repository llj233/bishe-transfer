#!/usr/bin/env python3
"""Read saved files only; never interacts with a live ROS graph."""
import csv
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for manifest in sorted((ROOT/'experiments').glob('**/manifest.json')):
    run=manifest.parent
    m=json.loads(manifest.read_text())
    result=json.loads((run/'result.json').read_text()) if (run/'result.json').exists() else {}
    def last_csv(name):
        p=run/name
        if not p.exists(): return {}
        with p.open() as f: rows=list(csv.DictReader(f))
        return rows[-1] if rows else {}
    e=last_csv('evaluation.csv'); h=last_csv('navigation_health.csv')
    p=run/'mission_events.jsonl'
    events=[json.loads(x) for x in p.read_text().splitlines() if x.strip()] if p.exists() else []
    if result:
        print(json.dumps({'map_seed':m['map_seed'],'policy_seed':m['policy_seed'],'status':result.get('status'),'task_sim_s':result.get('sim_seconds'),'coverage':result.get('evaluation'),'home_error_m':result.get('home_error_odom_m')}))
        continue
    print(json.dumps({'map_seed':m['map_seed'],'policy_seed':m['policy_seed'],
        'status':result.get('status',h.get('phase','STARTUP')),'sim_time':h.get('sim_time'),
        'exploration_pct':e.get('exploration_pct'),'roi_known_pct':e.get('roi_known_pct'),
        'home_error_m':result.get('home_error_odom_m',h.get('home_error_odom_m')),
        'fault':h.get('fault'),'reset_count':h.get('reset_count'),
        'recent_events':events[-2:]},ensure_ascii=False))
