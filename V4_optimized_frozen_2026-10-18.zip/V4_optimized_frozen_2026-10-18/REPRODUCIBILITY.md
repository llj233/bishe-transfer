# V4 复现指南

## 1. 随机种子会不会影响结果？

**会。** 地图种子改变两个原有箱子的静态位置/角度和六个新增障碍物的布局，决定遮挡与可导航路径。策略种子改变近似同分前沿候选的微小偏好，可能改变后续行驶顺序。策略种子不是训练得到的权重，也不是“成功策略模型”。

固定源世界、地图生成器、两个种子、机器人模型、传感器、SLAM/Nav2 参数、ROI、700 秒预算和依赖版本，可以重建相同的实验输入。相同地图种子换了生成器版本，也不能当作同一场景。

ROS/Gazebo 的消息到达和线程调度是异步的。相同种子仍可能产生不同地图更新时机、候选选择、轨迹、耗时和最终覆盖率；种子无法固定整个异步系统。硬件/VM 负载及图形环境也会影响运行，不能承诺逐次或逐位相同结果。复现时应报告各次达标/超时结果、重复运行分布，而不是要求恰好等于参考的 583 秒等数字。

原四组均成功和一组随机补充成功，是功能回归结果，不是任意地图都成功的保证。改变地图布局、障碍数量、传感器或算法参数属于新实验，应独立编号。

## 2. 环境与依赖

参考环境：Ubuntu 22.04、x86_64、Python 3.10、ROS 2 Humble、Gazebo Classic 11.10.2。Nav2 为 1.1.20，slam_toolbox 为 2.6.10。准确的 Debian 构建版本见 `environment/critical_packages.json`；完整作者软件包清单见 `environment/dpkg-installed.tsv`。Python 工具版本见 `environment/python-packages.json`。

先配置 ROS 2 Humble 的官方软件源，再安装相应依赖，例如：

```bash
sudo apt update
sudo apt install -y build-essential cmake pkg-config libgazebo-dev \
  python3-colcon-common-extensions python3-pytest python3-yaml python3-matplotlib \
  ros-humble-ros-base ros-humble-gazebo-ros-pkgs \
  ros-humble-navigation2 ros-humble-nav2-bringup ros-humble-slam-toolbox \
  ros-humble-turtlebot3-gazebo
```

这是依赖类别安装命令，不保证软件源当前版本等于作者版本。准确复现需根据版本清单对齐实际可用的包；本包提供 tf2/Cyclone 的本地库，并非完整 Ubuntu/ROS 离线镜像。其他历史 Debian 包是否仍在软件源中，需要在复现机器核对。

`run_test.py` 从系统安装位置读取 Nav2 和 slam_toolbox 默认 YAML，再写入冻结的覆盖参数。因此本包保存了两份原始 YAML 快照及哈希。`check_environment.py` 检查关键软件版本和模板内容，存在差异会退出并列出差异。

```bash
python3 scripts/check_environment.py --output my_environment.json
```

如有意测试其他依赖版本，可用 `--allow-version-drift` 查看差异，但应将其标为环境变化实验，不能宣称严格匹配作者环境。`run_gui.sh` 本身不强制预检查，所以请按指南先执行检查。

本地 `vendor/` 是 Ubuntu 22.04 x86_64 的库；不能直接用于 ARM、Windows、其他 ROS 发行版或 Gazebo Sim。务必保留其中 tf2/tf2_ros 0.25.24 修复和 Cyclone DDS，不要改成系统旧 tf2 或其他 DDS 后仍当作本版本。

## 3. 解压、校验、重新编译

ZIP 旁边的 `.sha256` 用于校验压缩包，解压后用内部清单校验发布内容：

```bash
sha256sum -c V4_optimized_frozen_2026-10-18.zip.sha256
unzip V4_optimized_frozen_2026-10-18.zip
cd V4_optimized_frozen_2026-10-18
python3 scripts/verify_release.py
python3 scripts/check_environment.py
bash scripts/build_isolated.sh
```

四个包应构建成功：`active_slam_v4`、`v4_evaluator`、`tf_deadlock_regression`、`gazebo_scene_audit`。发布包不携带作者机器的 `build/`、`install/` 和构建日志目录，必须在新机器构建。包内 vendor 是固定依赖，不是上述工作区构建缓存。

确认虚拟机已有图形桌面，运行：

```bash
bash scripts/run_gui.sh --map-seed 7 --policy-seed 11
```

启动脚本会设置本运行的 ROS domain、Gazebo master 和隔离库路径，并创建唯一实验目录。GUI 需要有效的 DISPLAY/XAUTHORITY；远程 SSH 无图形会话时需先连接虚拟机桌面。

## 4. 原四组验收与汇总

```bash
python3 scripts/run_validation_suite.py
python3 scripts/export_reproduction_report.py
```

固定顺序为 101/501、7/11、9/13、202/602。单组失败时批次停止，未运行项保留为 NOT_RUN；不要只挑成功组重新计算成功率。指定其他批次汇总可用：

```bash
python3 scripts/export_reproduction_report.py --suite-dir validation_suites/你的批次编号
```

汇总输出到新的 `reproduction_reports/`，不替换发布参考表。原作者脚本 `write_final_report.py` 是开发归档用脚本，会覆盖原表且按作者目录搜历史记录；发布后不要用它做复现汇总。

复现独立随机补充测试：

```bash
bash scripts/run_gui.sh --map-seed 375954 --policy-seed 868225
```

可以更换两种种子做新实验，但必须报告两者。新 UUID、ROS domain、Gazebo 端口是进程隔离编号，不是控制地图/策略的随机种子。

## 5. 评价口径

- 探索率：真值可达空闲格中，被 SLAM 判为空闲的比例。
- ROI：预先固定的可达自由区及其邻接障碍边界，其中被判定为空闲或障碍的比例；不是整个地图矩形内所有墙体内部面积。
- 探索率严格 >95% 且 ROI 严格 >90% 才返航，显示四舍五入到 95% 不代表已通过。
- 总任务预算 700 秒仿真时间；分别报告探索达标时间和包含返航的总时间。
- 返航以首次有效 odom 部署点为准，使用动态 TF 换算目标；动作成功后还需实际部署位置误差 ≤0.35 米。
- 当前 Gazebo odom 来源为 WORLD，没有编码器漂移，返航误差不能直接代表真实机器人精度。
- `scene_audit.json` 必须通过：服务器内只读插件记录八个静态障碍的 WorldPose，再与独立 SDF 定义比较；不修改机器人或障碍物状态。

时间主指标使用仿真时间，墙上时间用于计算运行效率。每个新实验组/地图种子/策略种子独立保存，超时和失败也必须保留。物理碰撞未独立计数，不能以“没有卡死”推导“零接触”。
