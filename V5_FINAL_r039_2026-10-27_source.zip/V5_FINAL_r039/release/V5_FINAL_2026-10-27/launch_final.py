#!/usr/bin/env python3
"""Start only the user-selected V5/r039 policy, without changing its source."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
RELEASE=Path(__file__).resolve().parent


def verify():
    frozen=json.loads((ROOT/'protocol/HEADLESS_SEARCH_FREEZE.json').read_text())
    if frozen['source_snapshot_id']!='564c0e22aed4bfd1':
        raise RuntimeError('Not the frozen V5 final r039 snapshot')
    for rel,digest in frozen['sha256'].items():
        if hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('Frozen source changed: '+rel)
    assets=json.loads((ROOT/'protocol/ASSET_LOCK.json').read_text())
    for rel,digest in assets.items():
        if hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('Frozen map changed: '+rel)
    resource=json.loads((ROOT/'protocol/RESOURCE_LOCK.json').read_text())
    for rel,digest in resource['sha256'].items():
        if hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('Frozen resource changed: '+rel)
    external=json.loads((RELEASE/'EXTERNAL_CONFIG_HASHES.json').read_text())
    for name,digest in external.items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=digest:
            raise RuntimeError('ROS reference configuration differs: '+name)


def main():
    parser=argparse.ArgumentParser(description='V5 final r039: single robot, event_fast, headless')
    parser.add_argument('--world-id',choices=['N01','N02','N03','N04','N05','N06'],default='N03')
    parser.add_argument('--spawn-id',choices=['S01','S02'],default='S01')
    parser.add_argument('--run-seed',type=int,default=29)
    parser.add_argument('--max-sim-seconds',type=float,default=1800.)
    parser.add_argument('--verify-only',action='store_true')
    args=parser.parse_args()
    verify()
    if args.verify_only:
        print('V5 final r039 source, maps and ROS reference configurations verified.')
        return 0
    command=[sys.executable,str(ROOT/'scripts/run_v5.py'),'--world-id',args.world_id,
        '--spawn-id',args.spawn_id,'--run-seed',str(args.run_seed),
        '--max-sim-seconds',str(args.max_sim_seconds),'--execution-policy','event_fast',
        '--method','B2','--gui','false','--split','smoke','--contact-sensors','--wait']
    return subprocess.call(command,cwd=ROOT)


if __name__=='__main__':raise SystemExit(main())
