#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
source /opt/ros/humble/setup.bash
source install/setup.bash
exec python3 release/V5_FINAL_2026-10-27/launch_final.py "$@"
