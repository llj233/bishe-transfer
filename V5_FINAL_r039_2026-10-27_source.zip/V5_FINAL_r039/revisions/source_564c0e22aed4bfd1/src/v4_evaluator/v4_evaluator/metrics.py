"""Frozen ROI and two coverage measures, accessible only to the evaluator."""
from dataclasses import dataclass
import math
from .truth import GroundTruth


@dataclass(frozen=True)
class MapData:
    width: int
    height: int
    resolution: float
    origin_x: float
    origin_y: float
    origin_yaw: float
    cells: tuple

    def at_world(self, x, y):
        dx, dy = x - self.origin_x, y - self.origin_y
        c, s = math.cos(self.origin_yaw), math.sin(self.origin_yaw)
        ix = math.floor((c * dx + s * dy) / self.resolution)
        iy = math.floor((-s * dx + c * dy) / self.resolution)
        if 0 <= ix < self.width and 0 <= iy < self.height:
            return self.cells[iy * self.width + ix]
        return -1


def observable_roi(truth: GroundTruth):
    reachable = set(truth.reachable_free)
    boundary = set()
    for x, y in reachable:
        for cell in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
            if cell in truth.obstacles:
                boundary.add(cell)
    return reachable | boundary


class Evaluator:
    def __init__(self, world_sdf, starts, resolution=.1,
                 exploration_target=95.0, roi_target=90.0, truth_npz=''):
        self.npz = None
        if truth_npz:
            import numpy as np
            self.npz = np.load(truth_npz)
            self.exploration_target = exploration_target
            self.roi_target = roi_target
            self.sample_xy = {}
            for key in ('reachable','roi'):
                yy,xx=np.where(self.npz[key])
                origin=self.npz['origin'];r=float(self.npz['resolution'])
                self.sample_xy[key]=(origin[0]+(xx+.5)*r,origin[1]+(yy+.5)*r)
            return
        self.truth = GroundTruth.from_sdf(world_sdf, starts, resolution=resolution)
        self.roi = observable_roi(self.truth)
        self.exploration_target = exploration_target
        self.roi_target = roi_target

    def evaluate(self, fused: MapData):
        if self.npz is not None:
            import numpy as np
            values=np.asarray(fused.cells)
            samples={}
            c,s=math.cos(fused.origin_yaw),math.sin(fused.origin_yaw)
            for key,(x,y) in self.sample_xy.items():
                dx,dy=x-fused.origin_x,y-fused.origin_y
                ix=np.floor((c*dx+s*dy)/fused.resolution).astype(int)
                iy=np.floor((-s*dx+c*dy)/fused.resolution).astype(int)
                valid=(ix>=0)&(iy>=0)&(ix<fused.width)&(iy<fused.height)
                v=np.full(len(x),-1,dtype=int)
                v[valid]=values[iy[valid]*fused.width+ix[valid]]
                samples[key]=v
            f=samples['reachable'];r=samples['roi']
            seen=int(np.sum((f>=0)&(f<=25)));known=int(np.sum(r>=0))
            fp=100*seen/len(f);rp=100*known/len(r)
            return {'reachable_free_seen':seen,'reachable_free_total':len(f),
                'exploration_pct':fp,'roi_known_cells':known,'roi_total_cells':len(r),
                'roi_known_pct':rp,'coverage_passed':fp>self.exploration_target and rp>self.roi_target}
        truth = self.truth
        free_seen = sum(0 <= fused.at_world(*truth.grid.center(p)) <= 25
                        for p in truth.reachable_free)
        roi_known = sum(fused.at_world(*truth.grid.center(p)) >= 0
                        for p in self.roi)
        exploration_pct = 100 * free_seen / len(truth.reachable_free)
        roi_pct = 100 * roi_known / len(self.roi)
        return {
            'reachable_free_seen': free_seen,
            'reachable_free_total': len(truth.reachable_free),
            'exploration_pct': exploration_pct,
            'roi_known_cells': roi_known,
            'roi_total_cells': len(self.roi),
            'roi_known_pct': roi_pct,
            'coverage_passed': (exploration_pct > self.exploration_target and
                                roi_pct > self.roi_target),
        }

