"""Only ROS process allowed to load SDF truth and decide coverage success."""
import csv
import gzip
import json
import math
from pathlib import Path

import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import String
from gazebo_msgs.msg import ContactsState

from .metrics import Evaluator, MapData
from .contact_metrics import classify_contact, raw_contact


class EvaluatorNode(Node):
    def __init__(self):
        super().__init__('v4_evaluator')
        for name, value in [('world_sdf', ''), ('run_dir', ''),
                            ('starts_xy', [-1.7, -2.5, -.7, -2.5]),
                            ('resolution', .1), ('exploration_target', 95.0),
                            ('roi_target', 90.0), ('truth_npz', '')]:
            self.declare_parameter(name, value)
        world = Path(self.get_parameter('world_sdf').value)
        run_dir = Path(self.get_parameter('run_dir').value)
        if not world.is_file() or not run_dir.is_dir():
            raise ValueError('Evaluator requires an existing world SDF and exclusive run dir')
        points = list(self.get_parameter('starts_xy').value)
        if len(points) not in (2, 4):
            raise ValueError('starts_xy must contain one or two (x,y) pairs')
        self.evaluator = Evaluator(
            world, [(points[i], points[i+1]) for i in range(0, len(points), 2)],
            resolution=float(self.get_parameter('resolution').value),
            exploration_target=float(self.get_parameter('exploration_target').value),
            roi_target=float(self.get_parameter('roi_target').value),
            truth_npz=self.get_parameter('truth_npz').value)
        self.output = (run_dir / 'evaluation.csv').open('x', newline='', encoding='utf-8')
        self.writer = csv.DictWriter(self.output, fieldnames=[
            'sim_time', 'reachable_free_seen', 'reachable_free_total',
            'exploration_pct', 'roi_known_cells', 'roi_total_cells',
            'roi_known_pct', 'coverage_passed'])
        self.writer.writeheader()
        self.last_logged = -1e9
        self.contact_stream=(run_dir/'body_contacts.jsonl').open('x')
        self.raw_contact_stream=gzip.open(run_dir/'raw_contacts.jsonl.gz','xt',compresslevel=1)
        self.last_floor_geometry={}
        self.contact_sub=self.create_subscription(ContactsState,'/v5/body_contacts',self.on_contacts,10)
        self.contact_slots={};self.environment_slots={};self.support_slots={}
        self.last_contact_heartbeat=-1e9;self.any_contact=False;self.any_environment=False;self.any_support=False
        self.support_names=set(json.loads((run_dir/'manifest.json').read_text()).get('support_collision_names',[]))
        self.contact_subs=[self.create_subscription(ContactsState,'/v5/contacts/'+name,
            lambda msg,n=name:self.on_contacts(msg,n),10) for name in
            ('base_link','wheel_left_link','wheel_right_link','caster_back_left_link','caster_back_right_link')]
        qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                         durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.pub = self.create_publisher(String, '/v4/evaluation', 10)
        self.sub = self.create_subscription(OccupancyGrid, '/map', self.on_map, qos)

    def on_contacts(self,msg,sensor='legacy_body'):
        now=self.get_clock().now().nanoseconds/1e9
        # Never filter a wall contact solely because its normal is vertical.
        # Every message retains contact presence. All obstacle and lateral
        # floor-contact geometry is lossless at the sensor rate. Only ordinary
        # expected floor-support geometry/forces are sampled at 2Hz per link.
        # This avoids ~1GiB/hour of redundant resting-floor telemetry.
        sample_floor=now-self.last_floor_geometry.get(sensor,-1e9)>=.5
        floor=[s for s in msg.states if classify_contact(s,self.support_names)=='floor_support']
        selected=[s for s in msg.states if sample_floor or classify_contact(s,self.support_names)!='floor_support']
        raw={'sim_time':now,'sensor':sensor,
             'stamp':msg.header.stamp.sec+msg.header.stamp.nanosec/1e9,
             'state_count':len(msg.states),'expected_floor_support_count':len(floor),
             'expected_floor_pairs':sorted({(s.collision1_name,s.collision2_name) for s in floor}),
             'expected_floor_geometry_sampled':sample_floor,
             'storage_policy':'all_presence_and_nonfloor_geometry; ordinary_floor_geometry_2Hz',
             'states':[raw_contact(s,self.support_names) for s in selected]}
        self.raw_contact_stream.write(json.dumps(raw,separators=(',',':'))+'\n')
        if sample_floor:self.last_floor_geometry[sensor]=now
        support=[s for s in msg.states if classify_contact(s,self.support_names)=='floor_lateral']
        environment=[s for s in msg.states if classify_contact(s,self.support_names).startswith('obstacle_')]
        hits=support+environment
        self.environment_slots[sensor]=(bool(environment),now)
        self.support_slots[sensor]=(bool(support),now)
        self.contact_slots[sensor]=(bool(hits),now)
        active=any(flag for flag,stamp in self.contact_slots.values() if now-stamp<.5)
        env_active=any(flag for flag,stamp in self.environment_slots.values() if now-stamp<.5)
        support_active=any(flag for flag,stamp in self.support_slots.values() if now-stamp<.5)
        if (active==self.any_contact and env_active==self.any_environment and support_active==self.any_support
                and now-self.last_contact_heartbeat<5):return
        self.contact_stream.write(json.dumps({'sim_time':now,'sensor':sensor,
            'contact':active,'environment_contact':env_active,'support_mesh_lateral_contact':support_active,
            'contact_measurement_version':'r025_object_aware_all_nonfloor_contacts','pairs':[[s.collision1_name,s.collision2_name] for s in hits],
            'sensors_seen':sorted(self.contact_slots),
            'normal_z':[[n.z for n in s.contact_normals] for s in hits]})+'\n')
        self.contact_stream.flush()
        self.any_contact=active;self.any_environment=env_active;self.any_support=support_active;self.last_contact_heartbeat=now

    def on_map(self, msg):
        now = self.get_clock().now().nanoseconds / 1e9
        if now - self.last_logged < 5.0:
            return
        q = msg.info.origin.orientation
        yaw = math.atan2(2 * (q.w * q.z + q.x * q.y),
                         1 - 2 * (q.y * q.y + q.z * q.z))
        fused = MapData(msg.info.width, msg.info.height, msg.info.resolution,
                        msg.info.origin.position.x, msg.info.origin.position.y,
                        yaw, tuple(msg.data))
        metrics = self.evaluator.evaluate(fused)
        metrics['sim_time'] = now
        self.writer.writerow(metrics)
        self.output.flush()
        self.pub.publish(String(data=json.dumps(metrics)))
        self.last_logged = now

    def destroy_node(self):
        self.output.close()
        self.contact_stream.close()
        self.raw_contact_stream.close()
        return super().destroy_node()


def main():
    rclpy.init()
    node = EvaluatorNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        if rclpy.ok():rclpy.shutdown()

