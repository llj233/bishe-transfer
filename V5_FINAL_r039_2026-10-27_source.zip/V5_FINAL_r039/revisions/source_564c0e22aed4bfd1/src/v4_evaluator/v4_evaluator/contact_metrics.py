"""Object-aware contact classification, independent of ROS and ground truth."""
import math

def vector(v):
    return [float(v.x), float(v.y), float(v.z)]

def classify_contact(state, support_names):
    # Only exact declared floor identities may count as expected support.
    floor = state.collision1_name in support_names or state.collision2_name in support_names
    normals = [vector(v) for v in state.contact_normals]
    lateral = any(abs(v[2]) < .8 for v in normals)
    return ('floor_lateral' if lateral else 'floor_support') if floor else ('obstacle_side' if lateral else 'obstacle_support_or_unresolved')

def raw_contact(state, support_names):
    record = {'pair':[state.collision1_name,state.collision2_name],
              'category':classify_contact(state,support_names),
              'normals':[vector(v) for v in state.contact_normals],
              'positions':[vector(v) for v in state.contact_positions],
              'depths':[float(v) for v in state.depths]}
    wrench = getattr(state,'total_wrench',None)
    if wrench is not None:
        record['force']=vector(wrench.force)
        record['torque']=vector(wrench.torque)
    return record
