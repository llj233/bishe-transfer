// Offline collision projection and online physical pose/contact audit.
// The explorer never reads these files. All geometry comes from loaded Gazebo.
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/Events.hh>
#include <gazebo/common/UpdateInfo.hh>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <set>
#include <chrono>
#include <sstream>
#include <algorithm>
#include <gazebo/transport/transport.hh>

namespace gazebo {
class V5Audit final : public SystemPlugin {
  std::string truth_, telemetry_, floor_probes_;
  double floor_z_=0;
  event::ConnectionPtr update_;
  bool projected_=false, contact_=false;
  bool volume_recorded_=false;
  double last_=-1;
  double probe_last_=-100;
  std::ofstream log_;
  transport::NodePtr contact_node_;
  transport::SubscriberPtr contact_sub_;
 public:
  void Load(int, char**) override {
    if (auto p=std::getenv("V5_TRUTH_OUTPUT")) truth_=p;
    if (auto p=std::getenv("V5_FLOOR_PROBES")) floor_probes_=p;
    if (auto p=std::getenv("V5_FLOOR_Z")) floor_z_=std::stod(p);
    if (auto p=std::getenv("V5_PHYSICS_AUDIT")) telemetry_=p;
    if (truth_.empty() && telemetry_.empty()) return;
    if (!telemetry_.empty()) log_.open(telemetry_);
    update_=event::Events::ConnectWorldUpdateBegin(
      [this](const common::UpdateInfo& info){ Record(info); });
  }
 private:
  void Record(const common::UpdateInfo& info) {
    auto w=physics::get_world(info.worldName);
    if (!w || w->Models().empty()) return;
    if (!truth_.empty() && !projected_) {
      if(floor_probes_.empty())Project(w);else ProbeFloor(w); projected_=true;
      // Extraction is run without any robot and terminated by its supervisor.
    }
    if (!log_.is_open()) return;
    auto robot=w->ModelByName("robot1");
    if (!robot) return;
    if(!volume_recorded_ && info.simTime.Double()>=5.0){
      double lo=1e9,hi=-1e9;
      for(auto link:robot->GetLinks())for(auto collision:link->GetCollisions()){
        auto b=collision->BoundingBox();lo=std::min(lo,b.Min().Z());hi=std::max(hi,b.Max().Z());
      }
      std::ofstream volume(telemetry_+".volume.json");
      volume<<std::setprecision(17)<<"{\"source\":\"loaded robot collision bounding boxes\",\"sim_time\":"<<info.simTime.Double()
        <<",\"world_z_min\":"<<lo<<",\"world_z_max\":"<<hi<<",\"model_z\":"<<robot->WorldPose().Pos().Z()
        <<",\"floor_z\":"<<floor_z_<<",\"projection_upper_z\":"<<(floor_z_+.16)<<",\"inside_audited_envelope\":"<<((lo>=floor_z_-.02 && hi<=floor_z_+.1601)?"true":"false")<<"}\n";
      volume.close();volume_recorded_=true;
    }
    if(std::getenv("V5_RAY_DIAGNOSTIC") && info.simTime.Double()-probe_last_>10) {
      probe_last_=info.simTime.Double();
      auto link=robot->GetLink("base_scan");
      if(!link){for(auto l:robot->GetLinks())std::cerr<<"V5_RAY_PROBE link="<<l->GetName()<<" pose="<<l->WorldPose()<<std::endl;}
      if(link){
        auto pose=link->WorldPose()*ignition::math::Pose3d(-.064,0,.121,0,0,0);
        auto ray=boost::dynamic_pointer_cast<physics::RayShape>(w->Physics()->CreateShape("ray",physics::CollisionPtr()));
        std::cerr<<"V5_RAY_PROBE time="<<probe_last_<<" sensor_world="<<pose<<std::endl;
        if(auto body=robot->GetLink("base_link"))for(auto c:body->GetCollisions())
          std::cerr<<"V5_RAY_PROBE body="<<c->GetScopedName()<<" pose="<<c->WorldPose()<<" bounds="<<c->BoundingBox()<<std::endl;
        for(int degrees:{0,30,45,60,90,180,270,300,315,330}){
          double a=degrees*M_PI/180.;auto d=pose.Rot().RotateVector({cos(a),sin(a),0});
          ray->SetPoints(pose.Pos()+d*.12,pose.Pos()+d*10);
          double dist;std::string name;ray->GetIntersection(dist,name);
          std::cerr<<"V5_RAY_PROBE degree="<<degrees<<" range="<<dist+.12<<" hit="<<name<<"\n";
        }
      }
    }
    bool hit=false;
    // Contact recording is handled by standard Gazebo contact sensors. Keep
    // this server observer strictly read-only: no physics manager mutations.
    if (std::getenv("V5_LEGACY_CONTACT_DIAG")) {
    auto cm=w->Physics()->GetContactManager();
    // Never enable global NeverDropContacts: the diagnostic A/B run showed
    // min-range scan artifacts with that global physics setting enabled.
    // A scoped contact subscription records only this robot's collisions.
    if (!contact_sub_) {
      std::vector<std::string> names;
      // The lidar housing encloses the origin of the ray sensor. Subscribing
      // to that collision activates self-ray contacts in Classic ODE; do not
      // instrument the housing. Body, wheels and casters remain monitored.
      for(auto l:robot->GetLinks())for(auto c:l->GetCollisions())
        if(c->GetName()!="lidar_sensor_collision")names.push_back(c->GetScopedName());
      auto topic=cm->CreateFilter("v5_robot_contacts",names);
      contact_node_.reset(new transport::Node());contact_node_->Init(w->Name());
      contact_sub_=contact_node_->Subscribe(topic,&V5Audit::Contacts,this);
    }
    for (unsigned i=0;i<cm->GetContactCount();++i) {
      auto c=cm->GetContacts()[i];
      std::string a=c->collision1->GetScopedName(), b=c->collision2->GetScopedName();
      bool ar=a.find("robot1::")==0, br=b.find("robot1::")==0;
      if (ar==br) continue;
      auto other=ar?c->collision2:c->collision1;
      // Robot wheel-to-floor contacts are expected and are not collisions.
      auto shape=other->GetShape();
      if (shape && shape->HasType(physics::Base::PLANE_SHAPE)) continue;
      auto bb=other->BoundingBox();
      if (bb.Max().Z()<=.025) continue;
      hit=true;
    }
    }
    double t=info.simTime.Double();
    if (hit!=contact_ || t-last_>=.1) {
      auto p=robot->WorldPose();
      double wall=std::chrono::duration<double>(std::chrono::system_clock::now().time_since_epoch()).count();
      log_ << std::setprecision(17) << "{\"sim_time\":"<<t<<",\"wall_epoch_s\":"<<wall
        <<",\"x\":"<<p.Pos().X()<<",\"y\":"<<p.Pos().Y()
        <<",\"yaw\":"<<p.Rot().Yaw()<<",\"contact_source\":\"separate_standard_sensors\",\"contact\":"<<(hit?"true":"false")
        <<",\"contact_begin\":"<<((hit&&!contact_)?"true":"false")<<"}\n";
      log_.flush();last_=t;
    }
    contact_=hit;
  }
  void Contacts(ConstContactsPtr &) { /* subscription retains scoped contacts */ }
  void ProbeFloor(physics::WorldPtr w) {
    auto ray=boost::dynamic_pointer_cast<physics::RayShape>(w->Physics()->CreateShape("ray",physics::CollisionPtr()));
    std::stringstream input(floor_probes_);std::string point;std::vector<double> heights;
    std::ostringstream samples;bool first=true;
    while(std::getline(input,point,';')){
      std::istringstream xy(point);double x,y;if(!(xy>>x>>y))continue;
      for(double dx:{-.12,0.,.12})for(double dy:{-.12,0.,.12}){
        ray->SetPoints({x+dx,y+dy,.20},{x+dx,y+dy,-.20});double dist;std::string name;ray->GetIntersection(dist,name);
        if(!first)samples<<',';first=false;
        const double z=.20-dist;
        samples<<std::setprecision(17)<<"{\"x\":"<<x+dx<<",\"y\":"<<y+dy<<",\"collision\":\""<<name<<"\",\"z\":"<<z<<"}";
        if(!name.empty())heights.push_back(z);
      }
    }
    std::sort(heights.begin(),heights.end());
    const bool flat=!heights.empty()&&heights.back()-heights.front()<.01;
    const double floor=heights.empty()?0:heights[heights.size()/2];
    std::ofstream out(truth_+".floor.json");out<<std::setprecision(17)
      <<"{\"source\":\"native downward collision rays at both preregistered clear spawns\",\"passed\":"
      <<((flat&&heights.size()==18)?"true":"false")<<",\"floor_z\":"<<floor
      <<",\"valid_samples\":"<<heights.size()<<",\"samples\":["<<samples.str()<<"]}\n";
  }
  void Project(physics::WorldPtr w) {
    double xmin=1e9,ymin=1e9,xmax=-1e9,ymax=-1e9;
    unsigned collisions=0;
    std::function<void(physics::ModelPtr)> bounds=[&](physics::ModelPtr m){
      for(auto l:m->GetLinks()) for(auto c:l->GetCollisions()) {
        auto shape=c->GetShape();
        if(shape && shape->HasType(physics::Base::PLANE_SHAPE))continue;
        auto b=c->BoundingBox();
        if(!b.Min().IsFinite()||!b.Max().IsFinite()||b.Max().Z()<=floor_z_+.001||b.Min().Z()>floor_z_+.16)continue;
        xmin=std::min(xmin,b.Min().X());ymin=std::min(ymin,b.Min().Y());
        xmax=std::max(xmax,b.Max().X());ymax=std::max(ymax,b.Max().Y());++collisions;
      }
      for(auto n:m->NestedModels())bounds(n);
    };
    for(auto m:w->Models())bounds(m);
    if(!collisions){gzerr<<"V5 no body-height collision geometry\n";return;}
    // Restrict only when four real physical scope walls are actually loaded.
    // M06 contains remote mesh outliers; the robot cannot cross these walls.
    auto west=w->ModelByName("v5_scope_west"),east=w->ModelByName("v5_scope_east"),
         south=w->ModelByName("v5_scope_south"),north=w->ModelByName("v5_scope_north");
    bool bounded=west&&east&&south&&north;
    if(bounded){
      xmin=std::max(xmin,west->WorldPose().Pos().X()-.15);
      xmax=std::min(xmax,east->WorldPose().Pos().X()+.15);
      ymin=std::max(ymin,south->WorldPose().Pos().Y()-.15);
      ymax=std::min(ymax,north->WorldPose().Pos().Y()+.15);
    }
    constexpr double res=.1;
    xmin=std::floor(xmin/res)*res-.2; ymin=std::floor(ymin/res)*res-.2;
    xmax=std::ceil(xmax/res)*res+.2; ymax=std::ceil(ymax/res)*res+.2;
    int nx=std::ceil((xmax-xmin)/res),ny=std::ceil((ymax-ymin)/res);
    gzmsg<<"V5 loaded bounds "<<xmin<<","<<ymin<<" to "<<xmax<<","<<ymax<<"; cells "<<nx<<"x"<<ny<<"\n";
    if(nx<=0||ny<=0||static_cast<long>(nx)*ny>12000000){gzerr<<"V5 invalid/oversize bounds\n";return;}
    auto engine=w->Physics();engine->InitForThread();
    auto ray=boost::dynamic_pointer_cast<physics::RayShape>(engine->CreateShape("ray",physics::CollisionPtr()));
    std::vector<unsigned char> cells(nx*ny,0);
    // Ten heights span the actual robot plus a small vertical margin. Thin intermediate geometry
    // remains a documented sampling limitation, checked in the truth audit.
    const double zs[]={.01,.02,.04,.06,.08,.10,.12,.13,.14,.16};
    for(int y=0;y<ny;++y)for(int x=0;x<nx;++x){
      double cx=xmin+(x+.5)*res,cy=ymin+(y+.5)*res;
      bool hit=false;
      for(double relative_z:zs){
        const double z=floor_z_+relative_z;
        // Ten concentric square perimeters, as in the audited upstream
        // gazebo_ros2_2Dmap_plugin approach. Two diagonals alone can miss a
        // thin leg lying between them. Sampling spacing here is 0.005m.
        for(int ring=1;ring<=10&&!hit;++ring)for(int i:{-1,1})for(int j:{-1,1}){
          double a=res*ring/20.;
          ray->SetPoints({cx+i*a,cy-i*a,z},{cx+j*a,cy+j*a,z});
          double dist;std::string name;ray->GetIntersection(dist,name);
          if(!name.empty()){hit=true;break;}
        }
        if(hit)break;
      }
      cells[y*nx+x]=hit?100:0;
    }
    std::ofstream raw(truth_+".bin",std::ios::binary);
    raw.write(reinterpret_cast<const char*>(cells.data()),cells.size());raw.close();
    std::ofstream out(truth_+".json.tmp");
    out<<std::setprecision(17)<<"{\"source\":\"Gazebo loaded collision RayShape\",\"resolution\":0.1,\"origin\":["
       <<xmin<<","<<ymin<<"],\"width\":"<<nx<<",\"height\":"<<ny
       <<",\"floor_z\":"<<floor_z_<<",\"body_collision_count\":"<<collisions<<",\"cell_sampling\":\"10 concentric square perimeters\",\"physically_bounded_scope\":"<<(bounded?"true":"false")<<",\"heights\":[0.01,0.02,0.04,0.06,0.08,0.10,0.12,0.13,0.14,0.16],\"robot_present\":"
       <<(w->ModelByName("robot1")?"true":"false")<<",\"models\":[";
    bool first=true;
    for(auto m:w->Models()){
      if(!first)out<<',';first=false;auto p=m->WorldPose();
      out<<"{\"name\":\""<<m->GetName()<<"\",\"static\":"<<(m->IsStatic()?"true":"false")
         <<",\"pose\":["<<p.Pos().X()<<','<<p.Pos().Y()<<','<<p.Pos().Z()<<','<<p.Rot().Roll()<<','<<p.Rot().Pitch()<<','<<p.Rot().Yaw()<<"]}";
    }
    out<<"]}\n";out.close();std::rename((truth_+".json.tmp").c_str(),(truth_+".json").c_str());
    gzmsg<<"V5 truth extraction complete: "<<nx<<"x"<<ny<<"\n";
  }
};
GZ_REGISTER_SYSTEM_PLUGIN(V5Audit)
}
