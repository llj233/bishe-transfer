// Offline diagnostic only. This plugin is never loaded by an online explorer.
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/Events.hh>
#include <gazebo/common/UpdateInfo.hh>
#include <fstream>
#include <iomanip>
#include <cstdlib>
namespace gazebo {
class LocalRayProbe:public SystemPlugin {
 event::ConnectionPtr connection_;std::string output_;bool done_=false;
 public:void Load(int,char**) override {
  if(auto x=std::getenv("V5_LOCAL_PROBE_OUTPUT"))output_=x;
  if(output_.empty())return;
  connection_=event::Events::ConnectWorldUpdateBegin([this](const common::UpdateInfo&info){
   if(done_)return;auto w=physics::get_world(info.worldName);if(!w||w->Models().empty())return;
   auto e=w->Physics();e->InitForThread();auto ray=boost::dynamic_pointer_cast<physics::RayShape>(e->CreateShape("ray",physics::CollisionPtr()));
   std::ofstream out(output_+".tmp");out<<std::setprecision(17);out<<"{\"mode\":\"offline no robot body-height wall visibility\",\"rays\":[";bool first=true;
   for(double x:{-12.68,-12.8,-13.0})for(double z:{.01,.04,.08,.10,.12,.129,.14,.16,.18,.22,.3,.5,.8})for(int sign:{-1,1}){
    double y0=sign>0?-20.8:-19.,y1=sign>0?-19.:-20.8;
    ray->SetPoints({x,y0,z},{x,y1,z});double d;std::string name;ray->GetIntersection(d,name);
    if(!first)out<<',';first=false;out<<"{\"x\":"<<x<<",\"z\":"<<z<<",\"direction_y\":"<<sign<<",\"hit\":\""<<name<<"\",\"distance\":"<<d<<"}";
   }
   out<<"]}\n";out.close();std::rename((output_+".tmp").c_str(),output_.c_str());done_=true;
  });
 }
};GZ_REGISTER_SYSTEM_PLUGIN(LocalRayProbe)
}
