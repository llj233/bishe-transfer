// Single-robot simulation correction: exclude only GZ_SENSOR_COLLIDE from the
// robot's collision mask. Physical wall/ground contacts remain enabled.
// Not appropriate for multi-robot lidar: other robots must stay observable.
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
namespace gazebo {
class SelfRayMask final : public ModelPlugin {
 public:
  void Load(physics::ModelPtr model,sdf::ElementPtr) override {
    unsigned count=0;
    for(auto link:model->GetLinks())for(auto collision:link->GetCollisions()){
      // ODE broadphase accepts a pair if either category/mask direction
      // matches. Both directions must be zero for body-vs-lidar rejection.
      collision->SetCategoryBits(GZ_SENSOR_COLLIDE);
      collision->SetCollideBits(GZ_ALL_COLLIDE & ~GZ_SENSOR_COLLIDE);++count;
    }
    std::cerr<<"V5_SELF_RAY_MASK robot="<<model->GetName()<<" physical_collisions="<<count
             <<" excluded_bits="<<GZ_SENSOR_COLLIDE<<" physical_fixed_bit="
             <<((GZ_ALL_COLLIDE & ~GZ_SENSOR_COLLIDE)&GZ_FIXED_COLLIDE)<<std::endl;
  }
};
GZ_REGISTER_MODEL_PLUGIN(SelfRayMask)
}
