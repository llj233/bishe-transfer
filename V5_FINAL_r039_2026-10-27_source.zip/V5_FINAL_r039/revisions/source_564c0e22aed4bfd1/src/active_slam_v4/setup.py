from setuptools import setup
from glob import glob
import os

package_name = 'active_slam_v4'
setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[('share/ament_index/resource_index/packages',
                 ['resource/' + package_name]),
                ('share/' + package_name, ['package.xml']),
                (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py'))],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='llj233',
    maintainer_email='llj233@users.noreply.github.com',
    description='Isolated V4 active-SLAM architecture and failure snapshot tools',
    license='MIT',
    entry_points={'console_scripts': [
        'failure_snapshotter = active_slam_v4.snapshotter:main',
        'test_executor = active_slam_v4.ros_runtime:main',
        'single_safety_gate = active_slam_v4.safety_node:main',
        'project_near_ground = active_slam_v4.near_ground_node:main',
    ]},
)

