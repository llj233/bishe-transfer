"""Project measured shallow 3D lidar returns into the robot-height 2D scan.

No world model, truth occupancy or evaluator is imported. Ground rejection uses
known physical sensor mounting height above base_footprint, not a truth map.
"""
import numpy as np

def estimate_ground_plane(xyz, sensor_height=.131):
 """Robust local measured floor z=ax+by+c, never world/truth geometry.

    Only points near the calibrated floor height and within 2.5m can fit.
    Reject ill-conditioned, poorly supported or excessive-tilt estimates.
    If there is insufficient floor visibility, retain the calibrated prior.
 """
 points=np.asarray(xyz,dtype=float).reshape(-1,3)
 radius=np.hypot(points[:,0],points[:,1])
 keep=np.isfinite(points).all(axis=1)&(radius>.35)&(radius<2.5)&(np.abs(points[:,2]+sensor_height)<.06)
 floor=points[keep]
 if len(floor)<30:return None
 matrix=np.column_stack((floor[:,:2],np.ones(len(floor))))
 coef,_,rank,_=np.linalg.lstsq(matrix,floor[:,2],rcond=None)
 if rank<3:return None
 for _ in range(5):
  residual=floor[:,2]-matrix@coef
  inliers=np.abs(residual-np.median(residual))<.01
  if inliers.sum()<max(30,.55*len(floor)):return None
  coef,_,rank,_=np.linalg.lstsq(matrix[inliers],floor[inliers,2],rcond=None)
  if rank<3:return None
 if np.linalg.norm(coef[:2])>.15 or abs(coef[2]+sensor_height)>.04:return None
 if np.median(np.abs(floor[:,2]-matrix@coef))>.008:return None
 return coef


def dropoff_points(xyz, plane, minimum_drop=.03, max_radius=1.5, lip_uncertainty=.15):
 """Conservative missing-support points inferred from measured downward rays.

 A hit below a well-supported floor means the ray crossed that floor height
 without finding support. Mark that crossing, rather than the distant bottom
 hit, as unsafe. Never use truth occupancy or invent hazards on missing data.
 A positive obstacle is still handled separately by the ordinary projection.
 """
 if plane is None:return np.empty((0,2))
 points=np.asarray(xyz,dtype=float).reshape(-1,3)
 radius=np.hypot(points[:,0],points[:,1])
 height=points[:,2]-(points[:,:2]@plane[:2]+plane[2])
 keep=np.isfinite(points).all(axis=1)&(height < -minimum_drop)&(radius>=.12)&(radius<max_radius)
 points=points[keep]
 if not len(points):return np.empty((0,2))
 denominator=points[:,2]-points[:,:2]@plane[:2]
 fraction=plane[2]/denominator
 valid=(fraction>0)&(fraction<1)
 crossings=points[valid,:2]*fraction[valid,None]
 # Sparse vertical beams do not measure the lip itself. Bracket each unsafe
 # ray by the nearest preceding observed floor return at the same azimuth.
 # Use that near edge of the unresolved interval; projecting only the deep
 # hit/floor crossing allows a wheel to enter the gap before the body stops.
 all_points=np.asarray(xyz,dtype=float).reshape(-1,3)
 all_height=all_points[:,2]-(all_points[:,:2]@plane[:2]+plane[2])
 supported=all_points[np.isfinite(all_points).all(axis=1)&(np.abs(all_height)<.008),:2]
 sr=np.hypot(supported[:,0],supported[:,1]);sa=np.arctan2(supported[:,1],supported[:,0])
 for i,point in enumerate(crossings):
  radius=np.linalg.norm(point);angle=np.arctan2(point[1],point[0])
  difference=np.abs(np.arctan2(np.sin(sa-angle),np.cos(sa-angle)))
  before=sr[(difference<.01)&(sr<radius)]
  if len(before):
   boundary=max(.12,float(before.max())-.02)
   crossings[i]=point*(min(radius,boundary)/radius)
 # A thin gap can lie between successive vertical beams. Keep an explicit
 # 15cm unresolved-lip margin, separately from the ordinary 5cm body pad.
 # This is a conservative sensor-profile parameter, not a measured lip.
 radii=np.linalg.norm(crossings,axis=1)
 if len(radii):crossings*=np.maximum(.12,radii-lip_uncertainty)[:,None]/radii[:,None]
 return crossings


def fuse_ranges(ranges,angle_min,angle_increment,range_min,range_max,xyz,sensor_height=.131):
 out=np.asarray(ranges,dtype=float).copy()
 points=np.asarray(xyz,dtype=float).reshape(-1,3)
 plane=estimate_ground_plane(points,sensor_height)
 height=(points[:,2]+sensor_height if plane is None else
         points[:,2]-(points[:,:2]@plane[:2]+plane[2]))
 radius=np.hypot(points[:,0],points[:,1])
 keep=np.isfinite(points).all(axis=1)&(height>=.015)&(height<=.16)&(radius>=range_min)&(radius<=range_max)
 # Include measured negative obstacles. Their projected floor crossing is
 # a traversability constraint, not a measured vertical wall or entropy gain.
 xy=np.vstack((points[keep,:2],dropoff_points(points,plane)))
 if not len(xy):return out.tolist(),0
 radius=np.hypot(xy[:,0],xy[:,1]);angle=np.arctan2(xy[:,1],xy[:,0])
 angle=angle_min+np.mod(angle-angle_min,2*np.pi)
 index=np.rint((angle-angle_min)/angle_increment).astype(int)
 full_circle=angle_increment*(len(out)-1)>6.
 if full_circle:index%=len(out)
 valid=(index>=0)&(index<len(out))&(radius>=range_min)&(radius<=range_max)
 index=index[valid];radius=radius[valid]
 update=np.full(len(out),np.inf);np.minimum.at(update,index,radius)
 out=np.fmin(out,update)
 return out.tolist(),int(valid.sum())
