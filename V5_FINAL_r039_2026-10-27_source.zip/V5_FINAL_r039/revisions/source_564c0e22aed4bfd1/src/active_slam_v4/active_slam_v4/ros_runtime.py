"""ROS adapter for isolated V4 single/dual functional tests.

The online loop reads SLAM maps, scan/odom/TF and Nav2 only. SDF truth is in
the separate evaluator process. This runner is deterministic and has no Q table.
"""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import csv
import json
import math
import os
from pathlib import Path
from threading import Event
import time
import traceback

import rclpy
from action_msgs.msg import GoalStatus as ActionStatus
from geometry_msgs.msg import PoseStamped, PolygonStamped, Twist
from nav2_msgs.action import ComputePathToPose, NavigateToPose
from nav2_msgs.msg import Costmap
from nav2_msgs.srv import ManageLifecycleNodes
from nav_msgs.msg import OccupancyGrid, Odometry, Path as NavPath
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy, qos_profile_sensor_data
from rclpy.time import Time
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
from tf2_ros import Buffer, TransformException, TransformListener

from .allocator import Allocator
from .fusion import AlignmentFusion
from .travel_cost import estimate_path
from .execution_context import ExecutionMemory, physical_context, path_signature
from .health import failed_destination, unused_backtracks, RobotHeartbeat, backtrack_options, translated_enough, update_distance_progress, TranslationWindow, RecoveryEpisode, LegacyRecoveryEpisode
from .mission import Mission
from .model import Candidate, Failure, Grid, Phase, Pose2, Transform2
from .planner import CandidatePlanner, footprint_fits
from .navigation_health import navigation_fault, deployment_error
from .safety import sector_min
from .preview import write_map_preview
from .v5_progress import ProgressMemory


STARTS = {'robot1': Pose2(-1.7, -2.5), 'robot2': Pose2(-.7, -2.5)}


def yaw(q):
    return math.atan2(2 * (q.w * q.z + q.x * q.y),
                      1 - 2 * (q.y * q.y + q.z * q.z))


def to_grid(msg):
    return Grid(msg.info.width, msg.info.height, msg.info.resolution,
                Pose2(msg.info.origin.position.x, msg.info.origin.position.y,
                      yaw(msg.info.origin.orientation)), tuple(msg.data),
                msg.header.stamp.sec + msg.header.stamp.nanosec / 1e9,
                msg.header.frame_id)


def pose_stamped(pose, frame, stamp):
    msg = PoseStamped()
    msg.header.frame_id = frame
    msg.header.stamp = stamp
    msg.pose.position.x = pose.x
    msg.pose.position.y = pose.y
    msg.pose.orientation.z = math.sin(pose.yaw / 2)
    msg.pose.orientation.w = math.cos(pose.yaw / 2)
    return msg


def wait_future(future, timeout_s=5.0):
    done = Event()
    future.add_done_callback(lambda _: done.set())
    if not done.wait(timeout_s):
        return None
    try:
        return future.result()
    except Exception:
        return None


class TestExecutor(Node):
    def __init__(self):
        super().__init__('v4_test_executor')
        self.declare_parameter('mode', 'single')
        self.declare_parameter('run_dir', '')
        self.declare_parameter('max_sim_seconds', 180.0)
        self.declare_parameter('policy_seed', 0)
        mode = self.get_parameter('mode').value
        if mode != 'single':
            raise ValueError('This isolated workspace is single-robot only')
        self.names = ('robot1',)
        self.folder = Path(self.get_parameter('run_dir').value).resolve()
        if not self.folder.is_dir() or not (self.folder / 'manifest.json').is_file():
            raise ValueError('runner must supply an exclusive V4 run directory')
        self.manifest = json.loads((self.folder/'manifest.json').read_text())
        self.method = self.manifest.get('method', 'B1')
        self.execution_policy = self.manifest.get('execution_policy','context')
        self.execution_memory = {n:ExecutionMemory() for n in self.names}
        self.goal_execution_context = {}
        self.progress_memory = ProgressMemory()
        self.localization_anchor={}
        self.localization_bad_since={}
        self.no_candidate_since={}
        self.last_plan_trigger = 'startup'
        self.decisions = (self.folder/'decisions.jsonl').open('x')
        self.progress_log = (self.folder/'online_progress.jsonl').open('x')
        self.query_stream=(self.folder/'path_queries.csv').open('x',newline='')
        self.query_writer=csv.writer(self.query_stream)
        self.query_writer.writerow(['sim_time','phase','robot','goal_x','goal_y','wall_s','outcome','path_m'])
        self.map_update_stream=(self.folder/'slam_map_updates.csv').open('x',newline='')
        self.map_update_writer=csv.writer(self.map_update_stream)
        self.map_update_writer.writerow(['sim_time','robot','map_header_stamp','map_header_age_s','cells'])
        for name, values in self.manifest.get('deployment', {}).items():
            STARTS[name] = Pose2(*values)
        self.start_wall = time.monotonic()
        self.mission = Mission(robots=self.names,
                               sim_budget_s=float(self.get_parameter('max_sim_seconds').value),
                               startup_budget_s=90.0, goal_budget_s=70.0,
                               max_retries=20, adaptive_goal_budget=True,
                               goal_maximum_s=float(self.get_parameter('max_sim_seconds').value))
        # Public-map budgets include startup from the world's simulation t=0.
        self.mission.start_sim_s = 0.0
        self.events = (self.folder / 'mission_events.jsonl').open('x', encoding='utf-8')
        self.written_events = 0
        self.latest = {n: {'map': None, 'scan': -1.0, 'odom': -1.0,
                           'map_rx': -1.0, 'costmap': -1.0,
                           'tf': -1.0, 'pose': None, 'global_tf': None}
                       for n in self.names}
        for state in self.latest.values():
            state.update(odom_pose=None, map_from_odom=None,
                         nav_command=(0.0, 0.0), output_command=(0.0, 0.0),
                         front_m=math.inf, rear_m=math.inf)
        self.deployment_odom = {}
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        self.qos_map = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                                  durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.map_pub = self.create_publisher(OccupancyGrid, '/map', self.qos_map)
        self.trigger_pub = self.create_publisher(String, '/v4/diagnostic_trigger', 10)
        self.escape_pub = self.create_publisher(String, '/v4/escape_request', 10)
        self.hold_pub = self.create_publisher(String, '/v4/navigation_hold', 10)
        self.eval_sub = self.create_subscription(String, '/v4/evaluation',
                                                 self.on_evaluation, 10)
        self._topic_subscriptions = []
        self.nav = {}
        self.paths = {}
        self.nav_handles = {}
        self.goal_regions = {}
        self.failed_ids = set()
        self.failed_targets = {n: [] for n in self.names}
        self.goal_progress = {}
        self.goal_nav_progress = {}
        self.goal_start_pose = {}
        self.recovery_clients = {}
        self.recovering = {}
        self.pending_escape = {}
        self.return_detours = {}
        self.return_path_failures = {n:0 for n in self.names}
        self.query_failure_count = {n:0 for n in self.names}
        self.planning_idle_since = {n:None for n in self.names}
        self.return_recovery_count = {n:0 for n in self.names}
        self.total_escape_count = {n:0 for n in self.names}
        self.recovery_episodes = {n:(RecoveryEpisode() if self.execution_policy in ('context','fast','event_fast') else LegacyRecoveryEpisode()) for n in self.names}
        self.goal_start_odom = {}
        self.nav_sending = {}
        self.nav_results = {}
        self.cancel_since = {}
        self.cancel_hold_until = {n: -1e9 for n in self.names}
        self.navigation_stamps = {n: dict(local=-1.0, footprint=-1.0,
                                         received=-1.0, transformed=-1.0)
                                  for n in self.names}
        self.reset_clients = {}
        self.reset_requested = None
        self.reset_future = None
        self.reset_count = 0
        self.reset_worker = ThreadPoolExecutor(max_workers=1)
        self.health_stream = (self.folder / 'navigation_health.csv').open('x', newline='')
        self.health_writer = csv.writer(self.health_stream)
        self.health_writer.writerow(('sim_time', 'local_costmap_stamp', 'footprint_stamp',
                                    'received_plan_stamp', 'transformed_plan_stamp',
                                    'phase', 'goal_id', 'fault', 'reset_count',
                                    'map_x', 'map_y', 'odom_x', 'odom_y',
                                    'goal_x', 'goal_y', 'home_error_odom_m',
                                    'nav_v', 'nav_w', 'output_v', 'output_w',
                                    'front_m', 'rear_m'))
        self.safe_poses = {n: [STARTS[n]] for n in self.names}
        self.used_backtracks = {n: [] for n in self.names}
        self.pending_backtrack = {}
        self.backtrack_future = None
        self.backtrack_exhausted = {n: False for n in self.names}
        self.safety_sub = self.create_subscription(String, '/v4/safety_status',
                                                   self.on_safety, 10)
        for name in self.names:
            self._topic_subscriptions.append(self.create_subscription(
                OccupancyGrid, f'/{name}/map',
                lambda msg, n=name: self.on_map(n, msg), self.qos_map))
            self._topic_subscriptions.append(self.create_subscription(
                LaserScan, f'/{name}/scan',
                lambda msg, n=name: self.on_scan(n, msg), qos_profile_sensor_data))
            self._topic_subscriptions.append(self.create_subscription(
                Odometry, f'/{name}/odom',
                lambda msg, n=name: self.on_odometry(n, msg), qos_profile_sensor_data))
            for key, topic in (('nav_command', 'cmd_vel_nav'), ('output_command', 'cmd_vel')):
                self._topic_subscriptions.append(self.create_subscription(
                    Twist, f'/{name}/{topic}', lambda msg, n=name, k=key:
                    self.latest[n].__setitem__(k, (msg.linear.x, msg.angular.z)), 10))
            self._topic_subscriptions.append(self.create_subscription(
                OccupancyGrid, f'/{name}/global_costmap/costmap',
                lambda msg, n=name: self.on_seen(n, 'costmap'), self.qos_map))
            self.nav[name] = ActionClient(self, NavigateToPose, f'/{name}/navigate_to_pose')
            self.paths[name] = ActionClient(self, ComputePathToPose,
                                            f'/{name}/compute_path_to_pose')
            self.reset_clients[name] = self.create_client(
                ManageLifecycleNodes, f'/{name}/lifecycle_manager_navigation/manage_nodes')
            for key, topic, message_type in (
                ('local', f'/{name}/local_costmap/costmap_raw', Costmap),
                ('footprint', f'/{name}/local_costmap/published_footprint', PolygonStamped),
                # Humble RPP publishes its transformed base-frame path on
                # received_global_plan; plan is the planner's map-frame path.
                ('received', f'/{name}/plan', NavPath),
                ('transformed', f'/{name}/received_global_plan', NavPath),
                # MPPI publishes a consumed costmap-frame path on this topic.
                ('transformed', f'/{name}/transformed_global_plan', NavPath),
            ):
                self._topic_subscriptions.append(self.create_subscription(
                    message_type, topic,
                    lambda msg, n=name, k=key: self.on_navigation_input(n, k, msg),
                    qos_profile_sensor_data))
        template = Grid(300, 300, .1, Pose2(-15.0, -15.0), tuple([-1] * 90000),
                        0.0, 'map')
        self.fuser = AlignmentFusion(template, max_age_s=6.0, min_overlap=20,
                                     max_conflict_ratio=.20)
        self.planner = CandidatePlanner(max_candidates=160, max_path_queries=12,
                                        method=self.method, fast_mode=self.execution_policy in ('fast','event_fast'),
                                        policy_seed=self.get_parameter('policy_seed').value)
        self.allocator = Allocator(lease_seconds=50)
        self.worker = ThreadPoolExecutor(max_workers=1)
        self.plan_future = None
        self.return_future = None
        self.last_planning_sim = -1e9
        self.last_map_stamps = None
        self.fused = None
        self.map_version = 0
        self.last_export_sim = -1e9
        self.last_status_sim = -1e9
        self.last_evaluation = None
        self.unhealthy_since = None
        self.health_reasons = {}
        self.ended = False
        # A guard condition schedules tick on the same serialized ROS executor.
        # Worker threads only signal readiness; they never run mission logic.
        self.decision_wakeup=(self.create_guard_condition(self.tick)
                              if self.execution_policy=='event_fast' else None)
        self.plan_ready_sim=None
        self.create_timer(1.0, self.tick)
        self.get_logger().info(f'V4 {mode} test executor started; run_dir={self.folder}')

    def now(self):
        return self.get_clock().now().nanoseconds / 1e9

    def on_map(self, name, msg):
        if msg.info.width * msg.info.height == len(msg.data) and msg.data:
            self.latest[name]['map'] = msg
            self.latest[name]['map_rx'] = self.now()
            stamp=msg.header.stamp.sec+msg.header.stamp.nanosec/1e9
            self.map_update_writer.writerow([self.now(),name,stamp,self.now()-stamp,len(msg.data)])
            self.map_update_stream.flush()

    def on_seen(self, name, key):
        self.latest[name][key] = self.now()

    def on_odometry(self, name, msg):
        self.on_seen(name, 'odom')
        p = msg.pose.pose.position
        pose = Pose2(p.x, p.y, yaw(msg.pose.pose.orientation))
        self.latest[name]['odom_pose'] = pose
        if self.recovery_episodes[name].observe(pose, self.now()):
            self.mission._event(self.now(),'recovery_episode_cleared',robot=name,
                                reason=('sustained_10s_net_departure_over_1m' if self.execution_policy in ('context','fast','event_fast') else 'legacy_departure_1m'))
        if name not in self.deployment_odom:
            self.deployment_odom[name] = pose
            (self.folder / 'deployment_odom.json').write_text(json.dumps({
                robot: vars(home) for robot, home in self.deployment_odom.items()
            }, indent=2))

    def on_scan(self, name, msg):
        self.on_seen(name, 'scan')
        for key, center in (('front_m', 0.0), ('rear_m', math.pi)):
            self.latest[name][key] = sector_min(msg.ranges, msg.angle_min,
                msg.angle_increment, center, math.radians(35), msg.range_min, msg.range_max)

    def home_error(self, name):
        return deployment_error(self.latest[name]['odom_pose'], self.deployment_odom.get(name))

    def on_navigation_input(self, name, key, msg):
        stamp = msg.header.stamp
        self.navigation_stamps[name][key] = stamp.sec + stamp.nanosec / 1e9

    def navigation_busy(self, now):
        """Do not overlap cancellation, late goal acceptance or recovery."""
        return (self.reset_requested is not None or self.reset_future is not None or
                bool(self.nav_sending) or bool(self.recovering) or
                any(n not in self.mission.active for n in self.nav_results) or
                any(now < t for t in self.cancel_hold_until.values()))

    def reset_navigation(self, name):
        """One bounded reset of Nav2 only; SLAM and the evaluator keep running."""
        client = self.reset_clients[name]
        if not client.wait_for_service(timeout_sec=3.0):
            return False
        for command in (ManageLifecycleNodes.Request.RESET,
                        ManageLifecycleNodes.Request.STARTUP):
            request = ManageLifecycleNodes.Request()
            request.command = command
            response = wait_future(client.call_async(request), 15.0)
            if response is None or not response.success:
                return False
        return True

    def localization_guard(self,now):
        # This simulator declares ideal WORLD odometry. Bound unexplained
        # SLAM correction relative to its first alignment, not a truth map.
        for name in self.names:
            state=self.latest[name];relation=state['map_from_odom']
            odom=state['odom_pose'];pose=state['pose']
            if relation is None or odom is None or pose is None:continue
            if name not in self.localization_anchor:self.localization_anchor[name]=relation
            expected=self.localization_anchor[name].apply(odom)
            distance=math.hypot(expected.x-pose.x,expected.y-pose.y)
            heading=abs(math.atan2(math.sin(expected.yaw-pose.yaw),math.cos(expected.yaw-pose.yaw)))
            if distance>1. or heading>.25:
                since=self.localization_bad_since.setdefault(name,now)
                if now-since>=3.:
                    self.hold_pub.publish(String(data=json.dumps({'robot':name,'hold':True})))
                    self.mission._event(now,'localization_correction_exceeded',robot=name,distance_m=distance,yaw_rad=heading,odometry_profile='ideal_WORLD')
                    self.mission.fail(Failure.LOCALIZATION,now)
            else:self.localization_bad_since.pop(name,None)

    def navigation_guard(self, now):
        """Diagnose before recovery and allow at most one Nav2-only reset."""
        name = self.names[0]
        stamps = self.navigation_stamps[name]
        goal = self.mission.active.get(name)
        fault = navigation_fault(
            now, now - goal.assigned_sim_s if goal else 0.0,
            stamps['local'], stamps['footprint'],
            stamps['received'], stamps['transformed']) if goal else None
        self.health_writer.writerow((now, stamps['local'], stamps['footprint'],
                                    stamps['received'], stamps['transformed'],
                                    self.mission.phase.value, goal.goal_id if goal else '',
                                    fault or '', self.reset_count,
                                    self.latest[name]['pose'].x if self.latest[name]['pose'] else '',
                                    self.latest[name]['pose'].y if self.latest[name]['pose'] else '',
                                    self.latest[name]['odom_pose'].x if self.latest[name]['odom_pose'] else '',
                                    self.latest[name]['odom_pose'].y if self.latest[name]['odom_pose'] else '',
                                    goal.pose_local.x if goal else '', goal.pose_local.y if goal else '',
                                    self.home_error(name), *self.latest[name]['nav_command'],
                                    *self.latest[name]['output_command'],
                                    self.latest[name]['front_m'], self.latest[name]['rear_m']))
        self.health_stream.flush()
        for robot, since in list(self.cancel_since.items()):
            if now - since > 8.0 and not self.reset_requested and self.reset_future is None:
                fault = 'navigation_cancel_timeout'
        if (fault and self.reset_requested is None and self.reset_future is None and
                self.mission.phase in (Phase.EXPLORE, Phase.RETURN)):
            self.mission._event(now, 'navigation_input_fault', robot=name, reason=fault,
                                stamps=dict(stamps))
            self.hold_pub.publish(String(data=json.dumps({'robot': name, 'hold': True})))
            if self.reset_count >= 1:
                self.mission.fail(Failure.NAVIGATION, now)
                return
            self.reset_requested = (name, fault, now)
            if goal:
                self.on_goal_result(name, goal.goal_id, 'tf_stale')
        if self.reset_requested is not None:
            robot, reason, since = self.reset_requested
            # Normally wait for terminal cancellation. The hold gate also
            # makes a bounded lifecycle reset safe if cancellation is stuck.
            if (not self.nav_results and not self.nav_sending) or now - since > 8.0:
                self.reset_requested = None
                self.reset_count += 1
                self.mission._event(now, 'navigation_reset_started', reason=reason,
                                    attempt=self.reset_count)
                self.plan_future = None
                self.return_future = None
                self.reset_future = self.reset_worker.submit(self.reset_navigation, robot)
        if self.reset_future is not None and self.reset_future.done():
            try:
                success = bool(self.reset_future.result())
            except Exception:
                success = False
            self.reset_future = None
            self.mission._event(now, 'navigation_reset_finished', success=success)
            self.unhealthy_since = None
            if not success:
                self.mission.fail(Failure.NAVIGATION, now)
            else:
                self.nav_sending.clear()
                self.nav_results.clear()
                self.nav_handles.clear()
                self.cancel_since.clear()
                self.navigation_stamps[name]['received'] = -1.0
                self.navigation_stamps[name]['transformed'] = -1.0
                self.cancel_hold_until[name] = now + 3.0
                self.last_planning_sim = -1e9
                self.hold_pub.publish(String(data=json.dumps({'robot': name, 'hold': False})))

    def on_evaluation(self, msg):
        try:
            data = json.loads(msg.data)
            self.last_evaluation = data
            old = self.mission.phase
            self.mission.coverage_update(float(data['exploration_pct']),
                                         float(data['roi_known_pct']),
                                         bool(data['coverage_passed']), self.now())
            if old != self.mission.phase and self.mission.phase == Phase.RETURN:
                for handle in self.nav_handles.values():
                    handle.cancel_goal_async()
                self.nav_handles.clear()
                self.goal_regions.clear()
        except (ValueError, KeyError, TypeError) as exc:
            self.get_logger().warning(f'Ignored malformed evaluation: {exc}')

    def on_safety(self, msg):
        try:
            event = json.loads(msg.data)
            if event.get('reason') in ('obstacle_stop', 'obstacle_slow',
                                       'stale_scan', 'footprint_sweep_stop','insufficient_scan', 'escape_started',
                                       'escape_finished'):
                with (self.folder / 'safety_events.jsonl').open('a', encoding='utf-8') as out:
                    out.write(json.dumps(event, ensure_ascii=False) + '\n')
            if event.get('reason') == 'escape_finished':
                name = event.get('robot')
                self.recovering.pop(name, None)
                self.last_planning_sim = -1e9
                self.mission._event(self.now(), 'escape_result',
                                    robot=name,
                                    success=bool(event.get('success')),
                                    detail=event.get('detail'))
                if event.get('success') and self.execution_policy=='legacy':
                    self.recovery_episodes[name].failures=0
                if event.get('success'):
                    self.mission._event(self.now(), 'recovery_verification_pending', robot=name,
                                        reason='escape_action_finished_not_verified')
                if (not event.get('success') and self.mission.phase == Phase.EXPLORE and name in self.safe_poses
                        and not self.backtrack_exhausted[name]):
                    options = unused_backtracks(self.safe_poses[name], self.latest[name]['pose'],
                                                self.used_backtracks[name], self.now())
                    if options:
                        self.pending_backtrack[name] = list(options)
                        self.mission._event(self.now(), 'backtrack_queued',
                                            robot=name, options=len(options))
        except (ValueError, TypeError):
            pass

    def refresh_tf(self, now):
        for name in self.names:
            try:
                pose_tf = self.tf_buffer.lookup_transform(
                    f'{name}/map', f'{name}/base_footprint', Time())
                p = pose_tf.transform.translation
                self.latest[name]['pose'] = Pose2(p.x, p.y,
                                                   yaw(pose_tf.transform.rotation))
                stamp = (pose_tf.header.stamp.sec +
                         pose_tf.header.stamp.nanosec / 1e9)
                self.latest[name]['tf'] = stamp if stamp > 0 else now
                alignment = self.tf_buffer.lookup_transform('map', f'{name}/map', Time())
                a = alignment.transform.translation
                self.latest[name]['global_tf'] = Transform2(
                    a.x, a.y, yaw(alignment.transform.rotation), now)
                relation = self.tf_buffer.lookup_transform(f'{name}/map', f'{name}/odom', Time())
                offset = relation.transform.translation
                self.latest[name]['map_from_odom'] = Transform2(
                    offset.x, offset.y, yaw(relation.transform.rotation), now)
            except TransformException:
                self.latest[name]['pose'] = None
                self.latest[name]['global_tf'] = None
                self.latest[name]['map_from_odom'] = None

    def ready(self, now):
        heartbeats = {}
        for name in self.names:
            state = self.latest[name]
            nav_ready = self.nav[name].server_is_ready()
            path_ready = self.paths[name].server_is_ready()
            heartbeats[name] = RobotHeartbeat(
                state['scan'], state['odom'], state['map_rx'], state['tf'],
                state['costmap'], nav_ready, path_ready)
        # Single and dual use the same per-robot readiness rule.
        from .health import check_robot
        checks = {name: check_robot(h, now, max_age_s=6.0)
                  for name, h in heartbeats.items()}
        self.health_reasons = {name: reasons for name, (_, reasons) in checks.items()}
        return all(ok for ok, _ in checks.values())

    def publish_map(self, grid):
        msg = OccupancyGrid()
        msg.header.frame_id = 'map'
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.info.resolution = grid.resolution
        msg.info.width = grid.width
        msg.info.height = grid.height
        msg.info.origin.position.x = float(grid.origin.x)
        msg.info.origin.position.y = float(grid.origin.y)
        msg.info.origin.orientation.z = math.sin(grid.origin.yaw / 2)
        msg.info.origin.orientation.w = math.cos(grid.origin.yaw / 2)
        msg.data = list(grid.cells)
        self.map_pub.publish(msg)

    def update_fusion(self, now):
        if any(self.latest[n]['map'] is None or
               self.latest[n]['global_tf'] is None for n in self.names):
            return True
        stamps = tuple((self.latest[n]['map'].header.stamp.sec,
                        self.latest[n]['map'].header.stamp.nanosec) for n in self.names)
        if stamps == self.last_map_stamps:
            return True
        self.last_map_stamps = stamps
        if len(self.names) == 1:
            local = to_grid(self.latest[self.names[0]]['map'])
            self.fused = Grid(local.width, local.height, local.resolution,
                              local.origin, local.cells, now, 'map')
            self.map_version += 1
            self.publish_map(self.fused)
            return True
        maps = {n: to_grid(self.latest[n]['map']) for n in self.names}
        transforms = {n: self.latest[n]['global_tf'] for n in self.names}
        result = self.fuser.fuse(maps, transforms, now)
        if not result.healthy:
            self.get_logger().warning(f'Fusion held: {result.reason}; '
                                      f'overlap={result.overlap_cells} '
                                      f'conflict={result.conflict_cells}')
            return False
        self.fused = result.grid
        self.map_version = result.version
        self.publish_map(result.grid)
        return True

    def query_path(self, name, pose):
        started=time.monotonic()
        def record(outcome,length=None):
            self.query_failure_count[name] = (0 if outcome=='success' else self.query_failure_count[name]+1)
            self.query_writer.writerow([self.now(),self.mission.phase.value,name,pose.x,pose.y,
                time.monotonic()-started,outcome,length]);self.query_stream.flush()
            return length
        client = self.paths[name]
        if not client.server_is_ready():
            return record('server_unavailable')
        request = ComputePathToPose.Goal()
        request.planner_id = 'ReturnGrid' if self.mission.phase==Phase.RETURN else 'GridBased'
        request.goal = pose_stamped(pose, f'{name}/map', self.get_clock().now().to_msg())
        response = wait_future(client.send_goal_async(request), 6.0)
        if response is None or not response.accepted:
            return record('request_timeout' if response is None else 'rejected')
        result = wait_future(response.get_result_async(), 8.0)
        if result is None or result.status != ActionStatus.STATUS_SUCCEEDED:
            return record('result_timeout' if result is None else f'action_status_{result.status}')
        points = [p.pose.position for p in result.result.path.poses]
        if not points:
            return record('empty_path')
        poses=[Pose2(p.pose.position.x,p.pose.position.y,yaw(p.pose.orientation))
               for p in result.result.path.poses]
        with (self.folder/'path_contexts.jsonl').open('a') as out:
            out.write(json.dumps({'sim_time':self.now(),'robot':name,
                'map_version':self.map_version,'phase':self.mission.phase.value,
                'target':vars(pose),'signature':path_signature(poses)})+'\n')
        if self.mission.phase==Phase.RETURN:
            with (self.folder/'return_paths.jsonl').open('a') as out:
                out.write(json.dumps({'sim_time':self.now(),'frame':f'{name}/map',
                    'target':[pose.x,pose.y,pose.yaw],
                    'points':[[p.x,p.y] for p in points]})+'\n')
        length=sum(math.hypot(a.x-b.x,a.y-b.y) for a,b in zip(points,points[1:]))
        if self.execution_policy in ('fast','event_fast') and self.mission.phase==Phase.EXPLORE:
            cost=estimate_path(poses)
            with (self.folder/'travel_costs.jsonl').open('a') as out:
                out.write(json.dumps({'sim_time':self.now(),'robot':name,'target':vars(pose),
                    'path_m':float(cost),'travel_time_s':cost.travel_time_s,
                    'forward_m':cost.forward_m,'reverse_m':cost.reverse_m,'cusps':cost.cusps})+'\n')
            return record('success',cost)
        return record('success',length)

    def plan_candidates(self, snapshot):
        planning_wall_start = time.monotonic()
        planning_start_sim = self.now()
        replan_reason = self.last_plan_trigger
        all_candidates = []
        stats = {}
        for name, grid, pose, alignment, version, forbidden in snapshot:
            items, info = self.planner.plan(
                name, grid, pose, alignment, version,
                lambda target, n=name: self.query_path(n, target),
                frozenset(self.failed_ids), forbidden_targets=forbidden)
            kept=[]
            for candidate in items:
                context=physical_context(pose,self.latest[name]['odom_pose'],candidate.pose_local)
                if self.execution_policy in ('context','fast','event_fast') and self.execution_memory[name].blocked(context,self.now()):
                    info['execution_context_cooldown_filtered']=info.get('execution_context_cooldown_filtered',0)+1
                else:kept.append(candidate)
            all_candidates.extend(kept)
            stats[name] = info
        if self.method in ('B2', 'B2_FEEDBACK'):
            all_candidates = self.progress_memory.adjust(all_candidates, self.now())
        self.decisions.write(json.dumps({'sim_time':self.now(), 'method':self.method,
            'replan_reason':replan_reason,
            'robots':{name:{'pose':vars(pose),'map_version':version} for name,grid,pose,alignment,version,forbidden in snapshot},
            'planning_start_sim_s':planning_start_sim,
            'snapshot_map_stamps':{n:g.stamp for n,g,p,a,v,f in snapshot},
            'planning_wall_s':time.monotonic()-planning_wall_start,'stats':stats,
            'candidates':[vars(c) | {'pose_local':vars(c.pose_local),
                'pose_global':vars(c.pose_global)} for c in all_candidates]})+'\n')
        self.decisions.flush()
        return all_candidates, stats

    def send_navigation(self, name, pose, goal_id, region_id):
        request = NavigateToPose.Goal()
        request.behavior_tree = str(self.folder / (
            'navigate_return_transit.xml' if region_id == 'return_transit' else
            'navigate_return.xml' if goal_id.startswith('return:') else 'navigate_bounded.xml'))
        request.pose = pose_stamped(pose, f'{name}/map', self.get_clock().now().to_msg())
        self.goal_regions[name] = region_id
        self.goal_execution_context[goal_id] = physical_context(
            self.latest[name]['pose'], self.latest[name]['odom_pose'], pose)
        self.mission._event(self.now(), 'execution_context_started', robot=name,
            goal_id=goal_id, map_version=self.map_version,
            context=repr(self.goal_execution_context[goal_id]))
        current = self.latest[name]['pose']
        current_map = self.latest[name]['map']
        if current is not None and current_map is not None and not goal_id.startswith('return:'):
            self.progress_memory.begin(goal_id,pose,current,to_grid(current_map),self.now())
        self.goal_progress[name] = (self.latest[name]['odom_pose'], self.now())
        self.goal_start_odom[name] = self.latest[name]['odom_pose']
        self.goal_nav_progress[name] = {'goal_id': goal_id, 'best_m': None,
                                        'improved_at': self.now(), 'last_m': None,
                                        'translation_window': TranslationWindow()}
        self.goal_start_pose[name] = current
        self.nav_sending[name] = goal_id
        future = self.nav[name].send_goal_async(
            request, feedback_callback=lambda feedback, n=name, ident=goal_id:
            self.on_navigation_feedback(n, ident, feedback))
        future.add_done_callback(
            lambda f, n=name, ident=goal_id: self.on_goal_accepted(n, ident, f))

    def on_navigation_feedback(self, name, goal_id, message):
        progress = self.goal_nav_progress.get(name)
        if progress is None or progress['goal_id'] != goal_id:
            return
        distance = float(message.feedback.distance_remaining)
        best, improved = update_distance_progress(progress['best_m'], distance)
        if not math.isfinite(distance) or distance <= .05:
            return
        progress['last_m'] = distance
        # Nav2 can rotate or oscillate while making no progress along its path.
        # A quarter-metre reduction is larger than feedback jitter.
        if improved:
            progress['best_m'] = best
            progress['improved_at'] = self.now()

    def on_goal_accepted(self, name, goal_id, future):
        if self.nav_sending.get(name) == goal_id:
            self.nav_sending.pop(name, None)
        try:
            handle = future.result()
        except Exception:
            handle = None
        if handle is None or not handle.accepted:
            self.on_goal_result(name, goal_id, 'no_path')
            return
        self.nav_handles[name] = handle
        result = handle.get_result_async()
        self.nav_results[name] = result
        result.add_done_callback(
            lambda f, n=name, ident=goal_id: self.on_goal_done(n, ident, f))
        active = self.mission.active.get(name)
        if active is None or active.goal_id != goal_id:
            handle.cancel_goal_async()
            self.cancel_since[name] = self.now()

    def on_goal_done(self, name, goal_id, future):
        if self.nav_results.get(name) is future:
            self.nav_results.pop(name, None)
        if name in self.cancel_since:
            self.cancel_since.pop(name, None)
            self.cancel_hold_until[name] = self.now() + 1.0
            self.mission._event(self.now(), 'navigation_cancel_terminal',
                                robot=name, goal_id=goal_id)
        try:
            response = future.result()
            result = ('success' if response.status == ActionStatus.STATUS_SUCCEEDED else
                      'canceled' if response.status == ActionStatus.STATUS_CANCELED else
                      'controller_stall')
        except Exception:
            result = 'runtime_error'
        if (result == 'success' and goal_id.startswith('return:')
                and self.mission.active.get(name) is not None
                and self.mission.active[name].region_id == 'deployment'
                and self.home_error(name) > .35):
            self.mission._event(self.now(), 'home_verification_failed', robot=name,
                                home_error_odom_m=self.home_error(name))
            result = 'home_not_reached'
        self.on_goal_result(name, goal_id, result)

    def on_goal_result(self, name, goal_id, result):
        active = self.mission.active.get(name)
        if active is None or active.goal_id != goal_id:
            return
        self.last_plan_trigger = 'navigation_result:'+result
        if self.execution_policy in ('fast','event_fast') and result=='success':
            self.last_planning_sim=-1e9  # terminal event: no fixed 7s wait for a finished goal
        grid = self.latest[name]['map']
        feedback = self.progress_memory.finish(goal_id,self.latest[name]['pose'],
                    to_grid(grid) if grid else None,self.now(),result)
        if feedback:
            self.progress_log.write(json.dumps(feedback)+'\n');self.progress_log.flush()
        handle = self.nav_handles.pop(name, None)
        if result in ('timeout', 'blocked', 'tf_stale') and handle is not None:
            handle.cancel_goal_async()
            self.cancel_since[name] = self.now()
            self.mission._event(self.now(), 'goal_cancel_requested',
                                robot=name, goal_id=goal_id, reason=result)
        self.goal_regions.pop(name, None)
        self.goal_progress.pop(name, None)
        self.goal_nav_progress.pop(name, None)
        started_at = self.goal_start_pose.pop(name, None)
        self.allocator.release(name)
        self.mission.on_navigation_result(name, result, self.now())
        odom_start=self.goal_start_odom.pop(name,None)
        odom_now=self.latest[name]['odom_pose']
        moved=(math.hypot(odom_now.x-odom_start.x,odom_now.y-odom_start.y)
               if odom_start is not None and odom_now is not None else 0.)
        context=self.goal_execution_context.pop(goal_id,None)
        if self.execution_policy in ('context','fast','event_fast') and self.execution_memory[name].failure(context,self.now(),result):
            self.mission._event(self.now(),'execution_context_cooldown',robot=name,
                goal_id=goal_id,result=result,until=self.execution_memory[name].expiry(self.now()),
                map_version=self.map_version,context=repr(context))
        episode=self.recovery_episodes[name]
        if episode.navigation_result(odom_now,result,moved):
            self.mission._event(self.now(),'recovery_episode_cleared',robot=name,
                                reason='left_initial_stuck_neighborhood_1m')
        if (result in ('blocked','controller_stall','timeout') and episode.failures>=2
                and self.mission.phase in (Phase.EXPLORE,Phase.RETURN)):
            self.pending_escape[name]=self.now()
            self.mission._event(self.now(),'escape_queued',robot=name,
                                stationary_failures=episode.failures,
                                episode_escapes=episode.escapes,
                                episode_backtracks=episode.backtracks)
        if result == 'success':
            self.backtrack_exhausted[name] = False
            pose = self.latest[name]['pose']
            history = self.safe_poses[name]
            if pose is not None and (not history or math.hypot(
                    pose.x-history[-1].x, pose.y-history[-1].y) >= .6):
                history.append(pose)
        elif goal_id.startswith('backtrack:'):
            # Try a different frontier until real progress rather than
            # repeatedly sending recovery goals from the same stuck pose.
            self.backtrack_exhausted[name] = True
            self.pending_backtrack.pop(name, None)
            self.mission._event(self.now(), 'backtrack_exhausted', robot=name,
                                goal_id=goal_id, result=result)
            self.safe_poses[name] = [p for p in self.safe_poses[name]
                                     if math.hypot(p.x-active.pose_local.x,
                                                   p.y-active.pose_local.y) >= .25]
        # Nav2's bounded BT owns movement recovery. This layer only waits for
        # the terminal result and chooses a new frontier after failure.
        if result != 'success':
            self.cancel_hold_until[name] = self.now() + 2.0
        if result != 'success' and not goal_id.startswith('return:'):
            self.failed_ids.add(goal_id)
            # Key the exclusion to physical position, not a map-versioned ID.
            # A failed location must stay excluded beyond one goal budget.
            if failed_destination(self.latest[name]['pose'],active.pose_local,result):
                self.failed_targets[name].append((active.pose_local,self.now()+180.))
            else:
                self.mission._event(self.now(),'local_execution_failure',robot=name,
                                    target_excluded=False,goal_id=goal_id)
            self.last_planning_sim = -1e9
            self.trigger_pub.publish(String(data=json.dumps({
                'robot': name, 'reason': result, 'goal_id': goal_id,
                'map_version': self.map_version})))
        elif result != 'success':
            self.trigger_pub.publish(String(data=json.dumps({
                'robot': name, 'reason': result, 'goal_id': goal_id,
                'phase': 'RETURN', 'home_error_odom_m': self.home_error(name),
                'target_xy': [active.pose_local.x, active.pose_local.y]})))
        elif result == 'success' and not goal_id.startswith('return:'):
            current = self.latest[name]['pose']
            if started_at is not None and current is not None and math.hypot(
                    current.x-started_at.x, current.y-started_at.y) < .35:
                # An immediately successful Nav2 goal gave no new viewpoint.
                self.failed_targets[name].append((active.pose_local,
                                                  self.now() + 60.0))
                self.last_planning_sim = -1e9

        if self.decision_wakeup is not None:
            self.decision_wakeup.trigger()

    def run_pending_escape(self, now):
        # A low-level escape starts only after Nav2's terminal cancellation;
        # no second velocity owner runs concurrently with an active action.
        for name,stamp in list(self.recovering.items()):
            if now-stamp>10.:
                self.recovering.pop(name,None)
                self.mission._event(now,'escape_status_timeout',robot=name)
        for name in list(self.pending_escape):
            if self.navigation_busy(now) or self.mission.active:
                return
            episode=self.recovery_episodes[name]
            if episode.escapes>=3:
                options=tuple(p for p in unused_backtracks(
                    self.safe_poses[name],self.latest[name]['pose'],
                    self.used_backtracks[name],now)
                    if translated_enough(p,self.latest[name]['pose'],threshold=1.5))
                if self.mission.phase==Phase.EXPLORE and episode.backtracks<2 and options:
                    self.pending_escape.pop(name,None)
                    episode.backtracks+=1
                    self.pending_backtrack[name]=list(options)
                    self.plan_future=None
                    self.mission._event(now,'repeated_escape_backtrack',robot=name,
                        attempt=episode.backtracks,options=len(options),
                        episode_origin_odom=vars(episode.origin) if episode.origin else None)
                    return
                if self.mission.phase==Phase.RETURN and self.return_recovery_count[name]<2:
                    from .planner import footprint_fits
                    grid=self.latest[name]['map']
                    candidates=[p for p in options if grid is not None and footprint_fits(to_grid(grid),p)]
                    if candidates:
                        selected=candidates[0]
                        self.used_backtracks[name].append((selected,now+600.))
                        self.return_detours[name]=selected
                        self.return_recovery_count[name]+=1
                        self.pending_escape.pop(name,None)
                        episode.failures=0;episode.escapes=0
                        self.mission._event(now,'return_detour_queued',robot=name,
                            attempt=self.return_recovery_count[name],target_xy=[selected.x,selected.y])
                        return
                self.mission._event(now,'bounded_recovery_exhausted',robot=name,
                                    episode_escapes=episode.escapes,
                                    episode_backtracks=episode.backtracks)
                self.mission.fail(Failure.RETURN if self.mission.phase==Phase.RETURN else Failure.NAVIGATION,now)
                self.pending_escape.clear();return
            if self.total_escape_count[name]>=12:
                self.mission._event(now,'task_escape_budget_exhausted',robot=name)
                self.mission.fail(Failure.RETURN if self.mission.phase==Phase.RETURN else Failure.NAVIGATION,now)
                self.pending_escape.clear();return
            self.total_escape_count[name]+=1
            self.pending_escape.pop(name,None);episode.escapes+=1
            self.recovering[name]=now;self.plan_future=None
            self.mission._event(now,'escape_requested',robot=name,attempt=episode.escapes)
            self.escape_pub.publish(String(data=json.dumps({'robot':name})))
            return

    def monitor_planning_idle(self, now, ready):
        """A planner failure without an action has no navigation-result callback."""
        for name in self.names:
            if (self.mission.phase!=Phase.EXPLORE or not ready
                    or name in self.mission.active or self.navigation_busy(now)):
                self.planning_idle_since[name]=None
                continue
            if self.planning_idle_since[name] is None:
                self.planning_idle_since[name]=now
            waiting=now-self.planning_idle_since[name]
            if waiting<25. or self.query_failure_count[name]<2:
                continue
            # Discard plan-only results before any movement recovery. They
            # never command velocity and must not dispatch an old waypoint.
            for attr in ('plan_future','backtrack_future'):
                future=getattr(self,attr)
                if future is not None:future.cancel()
                setattr(self,attr,None)
            self.pending_backtrack.pop(name,None)
            episode=self.recovery_episodes[name]
            if episode.origin is None:episode.origin=self.latest[name]['odom_pose']
            episode.failures=max(2,episode.failures)
            self.pending_escape[name]=now
            self.mission._event(now,'no_goal_planning_recovery_queued',robot=name,
                idle_s=waiting,failed_queries=self.query_failure_count[name])
            self.trigger_pub.publish(String(data=json.dumps({
                'reason':'no_goal_planning_stall','robot':name,'idle_s':waiting})))
            self.planning_idle_since[name]=now

    def schedule_explore(self, now):
        if self.navigation_busy(now):
            return
        if self.pending_backtrack or self.backtrack_future is not None:
            if self.backtrack_future is not None:
                if not self.backtrack_future.done():
                    return
                try:
                    name, pose, length = self.backtrack_future.result()
                except Exception as exc:
                    self.get_logger().warning(f'Backtrack path query failed: {exc}')
                    self.backtrack_future = None
                    self.pending_backtrack.clear()
                    return
                self.backtrack_future = None
                if length is not None and name not in self.mission.active:
                    goal_id = f'backtrack:{name}:{self.map_version}:{int(now*1000)}'
                    candidate = Candidate(goal_id, name, 'backtrack', pose,
                                          pose, self.map_version, 0, length,
                                          1.0, 0.0)
                    goal = self.mission.dispatch(candidate, now)
                    if goal:
                        self.pending_backtrack.pop(name, None)
                        self.used_backtracks[name].append((pose,now+180.))
                        self.send_navigation(name, pose, goal.goal_id,
                                             goal.region_id)
                        self.mission._event(now, 'backtrack_assigned',
                                            robot=name, goal_id=goal.goal_id)
                        return
            for name, options in list(self.pending_backtrack.items()):
                if name in self.mission.active:
                    return
                if not options:
                    self.pending_backtrack.pop(name, None)
                    continue
                pose = options.pop(0)
                self.backtrack_future = self.worker.submit(
                    lambda n=name, p=pose: (n, p, self.query_path(n, p)))
                return
        if self.plan_future is not None:
            if not self.plan_future.done():
                return
            try:
                candidates, stats = self.plan_future.result()
            except Exception as exc:
                self.get_logger().error(f'Planning exception: {exc}')
                self.mission.fail(Failure.RUNTIME, now)
                self.plan_future = None
                return
            self.plan_future = None
            self.mission._event(now,'planning_result_consumed',
                ready_sim_s=self.plan_ready_sim,
                result_wait_sim_s=None if self.plan_ready_sim is None else max(0.,now-self.plan_ready_sim))
            occupied = set(self.goal_regions.values())
            choices = []
            for c in candidates:
                if c.region_id in occupied or c.robot in self.mission.active:
                    continue
                context=physical_context(self.latest[c.robot]['pose'],
                    self.latest[c.robot]['odom_pose'],c.pose_local)
                if self.execution_policy in ('context','fast','event_fast') and self.execution_memory[c.robot].blocked(context,now):continue
                latest_map = self.latest[c.robot]['map']
                if latest_map is None:
                    continue
                current = to_grid(latest_map)
                cell = current.cell_of(c.pose_local)
                if cell is None or not 0 <= current.at(*cell) <= 25:
                    continue
                if self.execution_policy=='event_fast' and not footprint_fits(current,c.pose_local):
                    self.mission._event(now,'dispatch_footprint_rejected',robot=c.robot,goal_id=c.candidate_id)
                    continue
                # SLAM can update while Nav2 answers a path query. Recheck the
                # target in the new map and bind its lease to that version.
                choices.append(replace(c, map_version=self.map_version))
            selected = self.allocator.assign(choices, now, self.map_version)
            if selected:self.no_candidate_since.clear()
            for name, c in selected.items():
                goal = self.mission.dispatch(c, now)
                if goal:
                    self.send_navigation(name, goal.pose_local,
                                         goal.goal_id, goal.region_id)
            if not selected and all(n not in self.mission.active for n in self.names):
                for name in self.names:
                    since=self.no_candidate_since.setdefault(name,now)
                    if now-since>=14. and name not in self.pending_backtrack:
                        options=unused_backtracks(self.safe_poses[name],self.latest[name]['pose'],self.used_backtracks[name],now)
                        if options:
                            self.pending_backtrack[name]=list(options)
                            self.mission._event(now,'no_candidate_backtrack',robot=name,options=len(options))
                        else:self.pending_escape[name]=now
                        self.no_candidate_since[name]=now
                self.last_plan_trigger = 'no_candidate_retry'
                self.trigger_pub.publish(String(data=json.dumps({
                    'reason': 'no_candidate', 'map_version': self.map_version,
                    'planner_stats': stats})))
            return
        if (now - self.last_planning_sim < 7.0 or self.fused is None or
            all(name in self.mission.active for name in self.names)):
            return
        snapshot = []
        for name in self.names:
            if name in self.mission.active:
                continue
            state = self.latest[name]
            if state['map'] is None or state['pose'] is None:
                continue
            snapshot.append((name, to_grid(state['map']), state['pose'],
                             state['global_tf'], self.map_version,
                             tuple(p for p, expiry in self.failed_targets[name]
                                   if expiry > now)))
        if snapshot:
            self.plan_ready_sim=None
            self.mission._event(now,'planning_snapshot_submitted',
                map_version=self.map_version,
                map_stamps={n:g.stamp for n,g,p,a,v,f in snapshot})
            self.plan_future = self.worker.submit(self.plan_candidates, snapshot)
            self.plan_future.add_done_callback(self.on_plan_ready)
            self.last_planning_sim = now

    def on_plan_ready(self, future):
        self.plan_ready_sim=self.now()
        if self.decision_wakeup is not None:
            self.decision_wakeup.trigger()

    def schedule_return(self, now):
        if self.navigation_busy(now):
            return
        if self.return_future is not None:
            if not self.return_future.done():
                return
            name, goal_pose, version, length, final = self.return_future.result()
            self.return_future = None
            if length is None:
                self.return_path_failures[name]+=1
                self.trigger_pub.publish(String(data=json.dumps({
                    'reason':'return_path_missing','robot':name,
                    'target_xy':[goal_pose.x,goal_pose.y],
                    'map_version':version,'consecutive':self.return_path_failures[name]})))
            else:
                self.return_path_failures[name]=0
            goal = self.mission.dispatch_return(name, goal_pose, version,
                                                now, path_exists=length is not None,
                                                door_owner=name, path_m=length, final=final)
            if goal:
                self.send_navigation(name, goal.pose_local,
                                     goal.goal_id, goal.region_id)
            elif (length is None and self.return_path_failures[name]>=2
                  and self.mission.phase==Phase.RETURN):
                # No action exists, so its normal stall callback cannot recover.
                # Reuse the measured full-footprint escape, with the same caps.
                self.return_path_failures[name]=0
                episode=self.recovery_episodes[name]
                if episode.origin is None:episode.origin=self.latest[name]['odom_pose']
                episode.failures+=1
                self.pending_escape[name]=now
                self.mission._event(now,'return_no_path_escape_queued',robot=name)
            return
        if self.mission.active:
            return  # one robot at a time owns narrow-door passage
        for name in self.names:
            if self.mission.returned[name]:
                continue
            pose = self.latest[name]['pose']
            home = self.deployment_odom.get(name)
            relation = self.latest[name]['map_from_odom']
            if pose is None or home is None or relation is None:
                return
            if self.home_error(name) <= .35:
                self.mission.returned[name] = True
                self.mission._event(now, 'already_home', robot=name)
                if all(self.mission.returned.values()):
                    self.mission.phase = Phase.COMPLETE
                    self.mission._event(now, 'terminal', result='completed')
                continue
            final = name not in self.return_detours
            target = self.return_detours.pop(name,None) if not final else relation.apply(home)
            version = self.map_version
            self.return_future = self.worker.submit(
                lambda n=name, p=target, v=version, f=final:
                    (n, p, v, self.query_path(n, p), f))
            return

    def export_map(self):
        if self.fused is None:
            return
        g = self.fused
        write_map_preview(self.folder / 'fused_slam_map_preview.png',
                          g.cells, g.width, g.height, scale=8)
        # Standard PGM: y=0 is the ROS lower-left row.
        temporary = self.folder / 'fused_slam_map.pgm.tmp'
        with temporary.open('wb') as out:
            out.write(f'P5\n{g.width} {g.height}\n255\n'.encode())
            out.write(bytes(205 if value < 0 else 0 if value >= 65 else 254
                            for y in reversed(range(g.height))
                            for value in g.cells[y*g.width:(y+1)*g.width]))
        temporary.replace(self.folder / 'fused_slam_map.pgm')
        (self.folder / 'fused_slam_map.yaml').write_text(
            f'image: fused_slam_map.pgm\nresolution: {g.resolution}\n'
            f'origin: [{g.origin.x}, {g.origin.y}, {g.origin.yaw}]\n'
            'negate: 0\noccupied_thresh: 0.65\nfree_thresh: 0.196\n')

    def flush_events(self):
        for event in self.mission.events[self.written_events:]:
            self.events.write(json.dumps(event, ensure_ascii=False) + '\n')
        self.written_events = len(self.mission.events)
        self.events.flush()

    def finish(self, now):
        if self.ended:
            return
        self.ended = True
        self.export_map()
        self.flush_events()
        result = self.mission.result(now)
        (self.folder / 'result.json').write_text(json.dumps({
            'version': self.manifest.get('version','V5_single_r027_formal_2026-10-22'), 'method': self.method,
            'mode': 'single',
            'status': result.phase.value,
            'failure': result.failure.value if result.failure else None,
            'exploration_reached': result.exploration_reached,
            'returned': dict(zip(self.names, result.returned)),
            'deployment_odom': {n: vars(p) for n, p in self.deployment_odom.items()},
            'final_odom': {n: vars(self.latest[n]['odom_pose'])
                           if self.latest[n]['odom_pose'] else None for n in self.names},
            'home_error_odom_m': {n: self.home_error(n) if math.isfinite(self.home_error(n))
                                else None for n in self.names},
            'sim_seconds': result.sim_seconds,
            'sim_start_s': self.mission.start_sim_s,
            'evaluation': self.last_evaluation,
            'map_preview': 'fused_slam_map_preview.png' if self.fused else None,
        }, indent=2, ensure_ascii=False), encoding='utf-8')
        self.get_logger().info(f'V4 run finished: {result.phase.value}; '
                               f'failure={result.failure}')
        self.events.close()
        self.health_stream.close()
        self.reset_worker.shutdown(wait=False, cancel_futures=True)
        self.worker.shutdown(wait=False, cancel_futures=True)
        # The Nav2 action worker may still be waiting for a canceled result.
        # The result, map and events are already durable; exiting this dedicated
        # process lets the launch event shut Gazebo down promptly.
        os._exit(0)

    def record_trajectory(self, now):
        # Only fresh, actively traversed SLAM poses become recovery waypoints.
        # Unknown space and obstacle cells under the full body remain forbidden.
        from .planner import record_safe_breadcrumb
        for name in self.mission.active:
            state = self.latest[name]
            if state['map'] is not None and state['scan'] is not None and now-state['scan']<1.:
                record_safe_breadcrumb(self.safe_poses[name], to_grid(state['map']), state['pose'])

    def tick(self):
        now = self.now()
        if self.ended:
            return
        if time.monotonic() - self.start_wall > 120 and self.mission.phase == Phase.STARTUP:
            self.mission.fail(Failure.STARTUP, now)
        self.refresh_tf(now)
        aligned = self.update_fusion(now)
        ready = self.ready(now)
        self.localization_guard(now)
        self.navigation_guard(now)
        self.record_trajectory(now)
        resetting = self.reset_requested is not None or self.reset_future is not None
        if ready:
            self.unhealthy_since = None
        elif self.unhealthy_since is None:
            self.unhealthy_since = now
        healthy_enough = (resetting or ready or self.unhealthy_since is None or
                          now - self.unhealthy_since < 10.0)
        self.mission.tick(now, ready, localization_healthy=healthy_enough or
                          self.mission.phase == Phase.STARTUP,
                          alignment_healthy=aligned or self.mission.phase == Phase.STARTUP)
        for name, goal_id in self.mission.expired_goals(now):
            self.on_goal_result(name, goal_id, 'timeout')
        for name, goal in list(self.mission.active.items()):
            pose = self.latest[name]['odom_pose']
            last_pose, last_time = self.goal_progress.get(name, (pose, now))
            if translated_enough(pose, last_pose):
                self.goal_progress[name] = (pose, now)
                last_time = now
            path_progress=self.goal_nav_progress.get(name,{})
            window=path_progress.get('translation_window')
            recent_net=window.update(now,pose) if window is not None else None
            no_route_gain=(path_progress.get('best_m') is not None and
                           now-path_progress.get('improved_at',now)>=20.)
            # Replanning can lengthen a valid route. Do not cancel a robot
            # that is actually translating through that detour.
            route_stalled=(no_route_gain and recent_net is not None and recent_net<.5)
            if (now-last_time>=20. or route_stalled) and now-goal.assigned_sim_s>=20.:
                self.mission._event(now,'navigation_progress_guard',robot=name,
                    goal_id=goal.goal_id,no_translation_s=now-last_time,
                    no_route_gain_s=now-path_progress.get('improved_at',now),
                    last20s_net_m=recent_net,
                    reason='no_translation' if now-last_time>=20. else 'no_route_gain_and_low_net_motion')
                self.on_goal_result(name,goal.goal_id,'blocked')
        for name, handle in list(self.nav_handles.items()):
            if name not in self.mission.active:
                handle.cancel_goal_async()
                self.nav_handles.pop(name, None)
                self.goal_regions.pop(name, None)
        self.monitor_planning_idle(now,ready)
        if self.mission.phase in (Phase.EXPLORE,Phase.RETURN):
            self.run_pending_escape(now)
        if self.mission.phase == Phase.EXPLORE and ready and aligned:
            self.schedule_explore(now)
        elif self.mission.phase == Phase.RETURN and ready:
            self.schedule_return(now)
        if self.fused and now - self.last_export_sim >= 30:
            self.export_map()
            self.last_export_sim = now
        if now - self.last_status_sim >= 10:
            self.get_logger().info(f'phase={self.mission.phase.value} sim={now:.1f} '
                                   f'ready={ready} aligned={aligned} map_v={self.map_version} '
                                   f'coverage={None if not self.last_evaluation else round(self.last_evaluation["exploration_pct"], 2)} '
                                   f'health={self.health_reasons}')
            self.last_status_sim = now
        self.flush_events()
        if self.mission.phase in (Phase.COMPLETE, Phase.FAILED):
            self.finish(now)


def main():
    rclpy.init()
    node = TestExecutor()
    try:
        rclpy.spin(node)
    except Exception:
        detail = traceback.format_exc()
        (node.folder / 'runtime_exception.txt').write_text(detail, encoding='utf-8')
        node.get_logger().error(detail)
    finally:
        if not node.ended:
            node.mission.fail(Failure.RUNTIME, node.now())
            node.finish(node.now())
        node.destroy_node()
