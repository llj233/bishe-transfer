"""Read-only process sampling, restricted to one experiment's descendants."""
import csv,time
from pathlib import Path
import psutil

class ProcessProfiler:
 def __init__(self,pid,folder):
  self.pid=pid;self.started=time.monotonic();self.previous={};self.last=-1e9
  self.output=(folder/'process_profile.csv').open('x',newline='')
  self.writer=csv.writer(self.output)
  self.writer.writerow(['wall_elapsed_s','pid','role','cpu_percent_one_core','rss_mib','threads','user_cpu_s','system_cpu_s'])
 def sample(self):
  now=time.monotonic()
  if now-self.last<5:return
  try:processes=[psutil.Process(self.pid)]+psutil.Process(self.pid).children(recursive=True)
  except psutil.Error:return
  for proc in processes:
   try:
    with proc.oneshot():
     cpu=proc.cpu_times();total=cpu.user+cpu.system;rss=proc.memory_info().rss/2**20;role=proc.name();args=proc.cmdline()
     if role.startswith('python') and len(args)>1:role=Path(args[1]).name
     old=self.previous.get(proc.pid);percent=100*(total-old[1])/(now-old[0]) if old else None
     self.writer.writerow([now-self.started,proc.pid,role,percent,rss,proc.num_threads(),cpu.user,cpu.system]);self.previous[proc.pid]=(now,total)
   except psutil.Error:continue
  self.output.flush();self.last=now
 def close(self):self.output.close()
