"""Save failure-time SLAM, costmaps, TF and target for V4 stage A.

Start alongside a reproduction run; publish a JSON String to
/v4/diagnostic_trigger when path planning fails or no candidate remains.
The output is a new timestamped directory per trigger.
"""
import json
from pathlib import Path
import gzip
from collections import deque
import shutil
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from nav_msgs.msg import OccupancyGrid
from nav_msgs.msg import Odometry, Path as NavPath
from nav2_msgs.msg import Costmap
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import PolygonStamped
from std_msgs.msg import String
from tf2_msgs.msg import TFMessage
from rosidl_runtime_py.convert import message_to_ordereddict
from .preview import write_map_preview


TOPICS = {
    'robot1_footprint': ('/robot1/local_costmap/published_footprint', PolygonStamped),
    'robot1_global_plan': ('/robot1/plan', NavPath),
    'robot1_consumed_plan': ('/robot1/transformed_global_plan', NavPath),
    'robot1_map': ('/robot1/map', OccupancyGrid),
    'robot2_map': ('/robot2/map', OccupancyGrid),
    'fused_map': ('/map', OccupancyGrid),
    'robot1_global_costmap': ('/robot1/global_costmap/costmap_raw', Costmap),
    'robot2_global_costmap': ('/robot2/global_costmap/costmap_raw', Costmap),
    'robot1_local_costmap': ('/robot1/local_costmap/costmap_raw', Costmap),
    'robot2_local_costmap': ('/robot2/local_costmap/costmap_raw', Costmap),
    'robot1_local_costmap_display': ('/robot1/local_costmap/costmap', OccupancyGrid),
    'robot1_global_costmap_display': ('/robot1/global_costmap/costmap', OccupancyGrid),
    'robot1_scan': ('/robot1/scan', LaserScan),
    'robot1_odom': ('/robot1/odom', Odometry),
    'tf': ('/tf', TFMessage),
    'tf_static': ('/tf_static', TFMessage),
}


class Snapshotter(Node):
    def __init__(self):
        super().__init__('v4_failure_snapshotter')
        self.declare_parameter('output_dir', '/tmp/v4_diagnostics')
        self.declare_parameter('world_sdf', '')
        self.output_dir = Path(self.get_parameter('output_dir').value).resolve()
        self.world_sdf = Path(self.get_parameter('world_sdf').value)
        self.latest = {}
        self.ring = deque(maxlen=6)
        self.pending_windows = []
        self.last_window = -1e9
        self.ring_timer = self.create_timer(2., self.sample_ring)
        self.last_capture_by_reason = {}
        self.tf_tree = {}
        volatile = QoSProfile(depth=5, reliability=ReliabilityPolicy.BEST_EFFORT)
        latched = QoSProfile(depth=1, reliability=ReliabilityPolicy.RELIABLE,
                             durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self._topic_subscriptions = []
        for key, (topic, msg_type) in TOPICS.items():
            qos = latched if key == 'tf_static' else volatile
            self._topic_subscriptions.append(self.create_subscription(
                msg_type, topic, lambda msg, k=key: self.remember(k, msg), qos))
        self.trigger_sub = self.create_subscription(
            String, '/v4/diagnostic_trigger', self.capture, 10)

    def sample_ring(self):
        now=self.get_clock().now().nanoseconds/1e9
        # Keep references to immutable received messages; do not serialize at
        # sensor rate or repeatedly rasterize a full map during normal motion.
        frame=(now,dict(self.latest))
        self.ring.append(frame)
        for end,folder in list(self.pending_windows):
            self.write_ring_frame(folder,frame)
            if now>=end:self.pending_windows.remove((end,folder))

    def write_ring_frame(self, folder, frame):
        stamp,cached=frame
        payload={'sim_time':stamp,'topics':{k:{'received_sim_s':rx,
            'message':message_to_ordereddict(msg)} for k,(rx,msg) in cached.items()
            if not k.startswith('robot2')}}
        with gzip.open(folder/f'{stamp:012.3f}.json.gz','wt',encoding='utf-8') as out:
            json.dump(payload,out,ensure_ascii=False)

    def remember(self, key, msg):
        self.latest[key] = (self.get_clock().now().nanoseconds / 1e9, msg)
        if key in ('tf', 'tf_static'):
            for transform in msg.transforms:
                parent = transform.header.frame_id
                child = transform.child_frame_id
                self.tf_tree[f'{parent}->{child}'] = message_to_ordereddict(transform)

    def capture(self, request: String):
        now = self.get_clock().now().nanoseconds / 1e9
        try:
            trigger = json.loads(request.data)
            if not isinstance(trigger, dict):
                raise ValueError('trigger must be a JSON object')
        except (json.JSONDecodeError, ValueError) as exc:
            self.get_logger().error(f'Invalid diagnostic trigger: {exc}')
            return
        key=str(trigger.get('reason','unknown'))
        # Repeated no-candidate snapshots can fill the VM disk on large maps.
        # Decisions and health remain continuous; retain first + one/minute.
        if key=='no_candidate' and now-self.last_capture_by_reason.get(key,-1e9)<60:
            return
        self.last_capture_by_reason[key]=now
        stamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
        folder = self.output_dir / f'{stamp}_{time.time_ns() % 1000000000:09d}'
        folder.mkdir(parents=True, exist_ok=False)
        if now-self.last_window>=30.:
            self.last_window=now
            window=folder/'synchronized_window';window.mkdir()
            for frame in self.ring:self.write_ring_frame(window,frame)
            self.pending_windows.append((now+10.,window))
            (window/'WINDOW.json').write_text(json.dumps({
                'trigger_sim_s':now,'before_s':10,'after_s':10,
                'sample_interval_s':2,'source':'per-topic latest messages, each stamped; not simultaneous sensor hardware capture',
                'trigger':trigger,'bounded_one_window_per_30s':True},indent=2))
        inventory = {}
        for key in TOPICS:
            cached = self.latest.get(key)
            if cached is None:
                inventory[key] = {'available': False}
                continue
            received_sim_s, msg = cached
            (folder / f'{key}.json').write_text(
                json.dumps(message_to_ordereddict(msg), ensure_ascii=False),
                encoding='utf-8')
            if isinstance(msg, OccupancyGrid):
                write_map_preview(folder / f'{key}_preview.png',
                                  msg.data, msg.info.width, msg.info.height)
            inventory[key] = {'available': True, 'received_sim_s': received_sim_s,
                              'age_sim_s': now - received_sim_s}
        if self.world_sdf.is_file():
            shutil.copy2(self.world_sdf, folder / 'world.sdf')
        (folder / 'tf_tree.json').write_text(
            json.dumps(self.tf_tree, ensure_ascii=False, indent=2), encoding='utf-8')
        (folder / 'trigger.json').write_text(json.dumps({
            'sim_time': now, 'wall_time_utc': stamp, 'trigger': trigger,
            'topics': inventory}, indent=2, ensure_ascii=False), encoding='utf-8')
        self.get_logger().info(f'Saved V4 failure snapshot: {folder}')


def main():
    rclpy.init()
    node = Snapshotter()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        if rclpy.ok():rclpy.shutdown()
