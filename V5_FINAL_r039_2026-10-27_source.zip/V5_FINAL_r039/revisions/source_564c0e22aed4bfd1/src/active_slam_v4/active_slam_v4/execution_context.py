"""Temporary execution-context memory, in odometry coordinates only.

This memory changes target selection, never collision clearances or velocities.
A refreshed SLAM map does not erase evidence about the same physical approach.
"""
from dataclasses import dataclass
from collections import deque
from threading import RLock
import math

@dataclass(frozen=True)
class Context:
    start: object
    target: object
    bearing: float

def angle(a, b):
    return abs(math.atan2(math.sin(a-b), math.cos(a-b)))

def physical_context(map_start, odom_start, target):
    if map_start is None or odom_start is None:
        return None
    dx, dy = target.x-map_start.x, target.y-map_start.y
    rotation = odom_start.yaw-map_start.yaw
    c, s = math.cos(rotation), math.sin(rotation)
    from .model import Pose2
    physical = Pose2(odom_start.x+c*dx-s*dy, odom_start.y+s*dx+c*dy)
    return Context(odom_start, physical, math.atan2(physical.y-odom_start.y,
                                                  physical.x-odom_start.x))

class ExecutionMemory:
    def __init__(self, window_s=60., cooldown_s=60.):
        self.window_s, self.cooldown_s = window_s, cooldown_s
        self.failures = deque(maxlen=256)
        self.leases = deque(maxlen=128)
        self.lock = RLock()

    @staticmethod
    def same(a,b):
        # Approach direction matters; a different entry remains eligible.
        return (math.hypot(a.start.x-b.start.x,a.start.y-b.start.y)<=.75
                and angle(a.start.yaw,b.start.yaw)<=1.1
                and angle(a.bearing,b.bearing)<=.55
                and math.hypot(a.target.x-b.target.x,a.target.y-b.target.y)<=1.5)

    def failure(self, context, now, result):
        if context is None or result not in ('blocked','controller_stall','timeout'):
            return False
        with self.lock:
            self.failures.append((now,context,result))
            count=sum(0<=now-t<=self.window_s and self.same(context,c)
                      for t,c,_ in self.failures)
            if count>=2:
                self.leases.append((now+self.cooldown_s,context,result))
                return True
        return False

    def blocked(self, context, now):
        if context is None:return False
        with self.lock:
            return any(expiry>now and self.same(context,c) for expiry,c,_ in self.leases)

    def expiry(self, now):
        with self.lock:
            return max((t for t,_,_ in self.leases if t>now),default=now)


def path_signature(points, resolution=.2, horizon=2.):
    """First two metres, relative to start; direction and cusp indices retained."""
    if not points:return {'cells':[],'cusps':[]}
    origin=points[0];distance=0.;next_sample=0.;cells=[];cusps=[];previous=None
    for i,point in enumerate(points):
        if i:
            dx,dy=point.x-points[i-1].x,point.y-points[i-1].y
            segment=math.hypot(dx,dy);distance+=segment
            direction=1 if dx*math.cos(points[i-1].yaw)+dy*math.sin(points[i-1].yaw)>=0 else -1
            if segment>.01 and previous is not None and direction!=previous:cusps.append(i)
            if segment>.01:previous=direction
        if distance>horizon:break
        if distance>=next_sample:
            cells.append([round((point.x-origin.x)/resolution),round((point.y-origin.y)/resolution)])
            next_sample=distance+resolution
    return {'cells':cells,'cusps':cusps}
