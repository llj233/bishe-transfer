"""Synchronized raw 2D and shallow multi-layer lidar projection."""
import copy,csv,math
from pathlib import Path
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan,PointCloud2
from message_filters import Subscriber,ApproximateTimeSynchronizer
from .near_ground import fuse_ranges, estimate_ground_plane, dropoff_points

def xyz_array(msg):
 offsets={f.name:f.offset for f in msg.fields}
 dtype=np.dtype({'names':['x','y','z'],'formats':[('>' if msg.is_bigendian else '<')+'f4']*3,'offsets':[offsets[n] for n in ['x','y','z']],'itemsize':msg.point_step})
 a=np.ndarray((msg.height,msg.width),dtype=dtype,buffer=msg.data,strides=(msg.row_step,msg.point_step)).reshape(-1)
 return np.column_stack([a[n] for n in ['x','y','z']])

class GroundProjection(Node):
 def __init__(self):
  super().__init__('near_ground_projection')
  self.declare_parameter('robot','robot1');self.declare_parameter('run_dir','')
  robot=self.get_parameter('robot').value;folder=self.get_parameter('run_dir').value
  self.stream=None
  if folder:
   self.stream=(Path(folder)/'sensor_projection.csv').open('x',newline='');self.writer=csv.writer(self.stream);self.writer.writerow(['sim_time','raw_stamp','cloud_stamp','stamp_gap_s','cloud_points','kept_obstacle_points','sensor_height_m','ground_fit_valid','ground_a','ground_b','ground_c','dropoff_crossings'])
  self.pub=self.create_publisher(LaserScan,f'/{robot}/scan',qos_profile_sensor_data)
  self.raw=Subscriber(self,LaserScan,f'/{robot}/scan_raw',qos_profile=qos_profile_sensor_data)
  self.cloud=Subscriber(self,PointCloud2,f'/{robot}/near_ground_points',qos_profile=qos_profile_sensor_data)
  self.sync=ApproximateTimeSynchronizer([self.raw,self.cloud],8,.08);self.sync.registerCallback(self.project)
 def project(self,raw,cloud):
  if raw.header.frame_id.lstrip('/')!=cloud.header.frame_id.lstrip('/'):
   self.get_logger().error('Refuse unaligned sensor frames');return
  points=xyz_array(cloud)
  # Empty/invalid auxiliary sensor data must not silently degrade into the
  # old blind scan. Positive-inf beams are normal clear-space measurements.
  if not np.isfinite(points).all(axis=1).any():return
  valid=sum(not math.isnan(x) and x>=raw.range_min for x in raw.ranges)
  if valid<.9*len(raw.ranges):return
  ranges,count=fuse_ranges(raw.ranges,raw.angle_min,raw.angle_increment,raw.range_min,raw.range_max,points)
  msg=copy.deepcopy(raw);msg.ranges=ranges;msg.intensities=[];self.pub.publish(msg)
  if self.stream:
   a=raw.header.stamp.sec+raw.header.stamp.nanosec/1e9;b=cloud.header.stamp.sec+cloud.header.stamp.nanosec/1e9
   plane=estimate_ground_plane(points)
   self.writer.writerow([self.get_clock().now().nanoseconds/1e9,a,b,abs(a-b),len(points),count,.131,plane is not None,*(plane.tolist() if plane is not None else [None,None,None]),len(dropoff_points(points,plane))]);self.stream.flush()
 def destroy_node(self):
  if self.stream:self.stream.close()
  return super().destroy_node()
def main():
 rclpy.init();node=GroundProjection()
 try:rclpy.spin(node)
 finally:
  node.destroy_node()
  if rclpy.ok():rclpy.shutdown()
