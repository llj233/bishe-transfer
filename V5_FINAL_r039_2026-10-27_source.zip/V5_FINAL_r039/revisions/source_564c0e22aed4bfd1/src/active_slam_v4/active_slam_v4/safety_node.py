"""Single robot final cmd_vel gate; only this node writes the robot cmd_vel."""
import json
import gzip
import math
from pathlib import Path

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan, PointCloud2, JointState
from sensor_msgs_py.point_cloud2 import create_cloud_xyz32
from std_msgs.msg import String, Header

from .safety import select_command
from .swept_safety import laser_points,swept_velocity,scaled_swept_velocity
from .laser_history import ObstacleHistory
from .pose_history import PoseHistory


class SafetyNode(Node):
    def __init__(self):
        super().__init__('single_safety_gate')
        self.declare_parameter('robot', 'robot1')
        self.declare_parameter('run_dir','')
        folder=self.get_parameter('run_dir').value
        self.trace=(Path(folder)/'laser_guard_trace.jsonl').open('x') if folder else None
        self.motion_trace=gzip.open(Path(folder)/'motion_diagnostics.jsonl.gz','xt',compresslevel=1) if folder else None
        self.last_motion_trace=-1e9
        self.joint_sample={}
        self.last_output=(0.,0.)
        self.obstacle_history=ObstacleHistory(near_hold_m=.6,confirmations=3)
        self.pose_history=PoseHistory()
        self.pending_scan=None
        self.odom_stamp_msg=None
        self.odom_pose=None
        self.odom_time=-1.
        name = self.get_parameter('robot').value
        self.name = name
        self.scan = None
        self.scan_time = -1.0
        self.scan_points = []
        self.command = Twist()
        self.command_time = -1.0
        self.recovery_command = Twist()
        self.recovery_time = -1.0
        self.odom_xy = None
        self.escape = None
        self.navigation_hold = False
        self.last_notice = -1e9
        self.create_subscription(LaserScan, f'/{name}/scan', self.on_scan,
                                 qos_profile_sensor_data)
        self.create_subscription(Twist, f'/{name}/cmd_vel_unchecked',
                                 self.on_command, 10)
        self.create_subscription(Twist, f'/{name}/cmd_vel_recovery',
                                 self.on_recovery, 10)
        self.create_subscription(Odometry, f'/{name}/odom', self.on_odom,
                                 qos_profile_sensor_data)
        self.create_subscription(JointState, f'/{name}/joint_states', self.on_joints, qos_profile_sensor_data)
        self.create_subscription(String, '/v4/escape_request', self.on_escape, 10)
        self.create_subscription(String, '/v4/navigation_hold', self.on_hold, 10)
        self.publisher = self.create_publisher(Twist, f'/{name}/cmd_vel', 10)
        self.obstacle_pub = self.create_publisher(PointCloud2, f'/{name}/retained_static_obstacles', 10)
        self.last_obstacle_publish = -1e9
        self.status = self.create_publisher(String, '/v4/safety_status', 10)
        self.create_timer(.05, self.tick)

    def now(self):
        return self.get_clock().now().nanoseconds / 1e9

    def on_scan(self, msg):
        if not self.accept_scan(msg):
            self.pending_scan=msg

    def accept_scan(self,msg):
        stamp=msg.header.stamp.sec+msg.header.stamp.nanosec/1e9
        if stamp<=self.scan_time or self.now()-stamp>.7:
            return True  # discard superseded/stale observations
        pose=self.pose_history.at(stamp)
        if pose is None:return False
        self.scan=msg;self.scan_time=stamp
        self.scan_points=laser_points(msg.ranges,msg.angle_min,msg.angle_increment,
                                      msg.range_min,msg.range_max)
        self.obstacle_history.observe(self.scan_points,pose,stamp)
        if self.trace:
            self.trace.write(json.dumps({'sim_time':self.now(),
                'measurement_stamp':stamp,'pose_stamp':stamp,'odom':pose,
                'latest_odom':self.odom_pose,'odom_latest_stamp':self.odom_time,
                'angle_min':msg.angle_min,'angle_increment':msg.angle_increment,
                'range_min':msg.range_min,'range_max':msg.range_max,
                'ranges':[r if math.isfinite(r) else 'inf' for r in msg.ranges]})+'\n')
            self.trace.flush()
        return True

    def on_command(self, msg):
        self.command = msg
        self.command_time = self.now()

    def on_recovery(self, msg):
        self.recovery_command = msg
        self.recovery_time = self.now()

    def on_joints(self, msg):
        self.joint_sample={'stamp':msg.header.stamp.sec+msg.header.stamp.nanosec/1e9,
                           'names':list(msg.name),'positions':list(msg.position),
                           'velocities':list(msg.velocity),'efforts':list(msg.effort)}

    def on_odom(self, msg):
        p=msg.pose.pose.position;q=msg.pose.pose.orientation
        stamp=msg.header.stamp.sec+msg.header.stamp.nanosec/1e9
        pose=(p.x,p.y,math.atan2(2*(q.w*q.z+q.x*q.y),
                               1-2*(q.y*q.y+q.z*q.z)))
        if self.motion_trace and stamp-self.last_motion_trace>=.2:
            roll=math.atan2(2*(q.w*q.x+q.y*q.z),1-2*(q.x*q.x+q.y*q.y))
            pitch=math.asin(max(-1.,min(1.,2*(q.w*q.y-q.z*q.x))))
            self.motion_trace.write(json.dumps({'sim_time':stamp,'position':[p.x,p.y,p.z],
                'roll_pitch_yaw':[roll,pitch,pose[2]],
                'measured_twist':[msg.twist.twist.linear.x,msg.twist.twist.angular.z],
                'nav_command':[self.command.linear.x,self.command.angular.z],
                'gate_output':self.last_output,'joints':self.joint_sample})+'\n')
            self.last_motion_trace=stamp
        if not self.pose_history.append(stamp,pose):return
        self.odom_xy=(p.x,p.y);self.odom_pose=pose
        self.odom_time=stamp;self.odom_stamp_msg=msg.header.stamp
        if self.pending_scan is not None and self.accept_scan(self.pending_scan):
            self.pending_scan=None

    def publish_status(self, reason, **fields):
        self.status.publish(String(data=json.dumps({'robot': self.name,
            'reason': reason, 'sim_time': self.now(), **fields})))

    def on_escape(self, msg):
        try:
            data = json.loads(msg.data)
        except (ValueError, TypeError):
            return
        if data.get('robot') != self.name or self.escape is not None:
            return
        now = self.now()
        if self.odom_xy is None or self.scan is None or now-self.scan_time > .7 or now-self.odom_time>.3:
            self.publish_status('escape_finished', success=False,
                                detail='missing_fresh_sensor')
            return
        points=self.guard_points(now)
        options=[]
        # Check both directions and several bounded displacements. Do not
        # reject 10cm of usable retreat merely because 32cm is unavailable.
        for sign in (-1,1):
            for distance in (.32,.24,.16,.10,.06):
                _,_,reason=swept_velocity(sign*.06,0.,points,padding=.05,horizon=distance/.06)
                if reason is None:
                    options.append((sign,distance));break
        if not options:
            self.publish_status('escape_finished',success=False,detail='no_safe_translation')
            return
        sign,distance=options[0]
        self.escape=(self.odom_xy,now,sign,distance)
        self.publish_status('escape_started',direction='reverse' if sign<0 else 'forward',target_distance_m=distance)

    def guard_points(self,now):
        if self.odom_pose is None or not self.scan_points:return []
        points=self.obstacle_history.project(self.odom_pose,now)
        return points if points else [(3.,3.)]  # valid clear-space scan

    def on_hold(self, msg):
        try:
            data = json.loads(msg.data)
            if data.get('robot') == self.name:
                self.navigation_hold = bool(data['hold'])
                self.command = Twist()
                self.recovery_command = Twist()
                self.escape = None
        except (ValueError, KeyError, TypeError):
            pass

    def tick(self):
        now = self.now()
        output = Twist()
        if now-self.last_obstacle_publish >= .3:
            # Give Nav2 the same static measured constraints as the final gate.
            # This is retained 2D obstacle memory, not a fresh 3D sensor claim.
            fresh=(self.scan is not None and now-self.scan_time<=.7 and
                   self.odom_pose is not None and now-self.odom_time<=.3)
            points=self.guard_points(now) if fresh else []
            header=Header();header.stamp=(self.odom_stamp_msg if self.odom_stamp_msg is not None
                                         else self.get_clock().now().to_msg())
            header.frame_id=f'{self.name}/base_footprint'
            cloud=create_cloud_xyz32(header,[(x,y,.08) for x,y in points
                                             if math.hypot(x,y)<1.2])
            self.obstacle_pub.publish(cloud)
            self.last_obstacle_publish=now
        if self.navigation_hold:
            self.last_output=(output.linear.x,output.angular.z)
            self.publisher.publish(output)
            return
        if self.escape is not None:
            start_xy, start_time, direction, target_distance = self.escape
            moved = (math.hypot(self.odom_xy[0]-start_xy[0],
                                self.odom_xy[1]-start_xy[1])
                     if self.odom_xy is not None else 0.0)
            if moved >= target_distance or now-start_time >= 6.5:
                self.escape = None
                self.publish_status('escape_finished', success=moved >= min(.12,.75*target_distance),
                                    moved_m=moved)
            elif self.scan is None or now-self.scan_time > .7 or now-self.odom_time>.3:
                self.escape = None
                self.publish_status('escape_finished', success=False,
                                    detail='stale_scan')
            else:
                x,z,reason=swept_velocity(direction*.06,0.,self.guard_points(now),padding=.05)
                if reason:
                    self.escape=None
                    self.publish_status('escape_finished',success=False,detail=reason,moved_m=moved)
                else:output.linear.x=x;output.angular.z=z
            self.last_output=(output.linear.x,output.angular.z)
            self.publisher.publish(output)
            return
        command, source = select_command(
            (self.command.linear.x, self.command.angular.z),
            now-self.command_time,
            (self.recovery_command.linear.x, self.recovery_command.angular.z),
            now-self.recovery_time)
        if self.scan is None or now-self.scan_time>.7 or self.odom_pose is None or now-self.odom_time>.3:
            reason = 'stale_scan' if source != 'idle' else None
        elif source == 'idle':
            reason = None
        else:
            # Match Nav2's non-circular footprint. The old sector circle
            # stopped valid narrow-space motions before the body sweep ran.
            x,z,reason=scaled_swept_velocity(command[0],command[1],
                                            self.guard_points(now),padding=.05)
            output.linear.x = x
            output.angular.z = z
        self.last_output=(output.linear.x,output.angular.z)
        self.publisher.publish(output)
        if reason and now - self.last_notice >= 1.0:
            self.status.publish(String(data=json.dumps({'robot': self.name,
                'reason': reason, 'sim_time': now})))
            self.last_notice = now


    def destroy_node(self):
        if self.trace:self.trace.close()
        if self.motion_trace:self.motion_trace.close()
        return super().destroy_node()


def main():
    rclpy.init()
    node = SafetyNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        if rclpy.ok():rclpy.shutdown()
