"""Explicit startup and runtime gates for each robot stack."""
from dataclasses import dataclass
from typing import Dict, Tuple
import math
from collections import deque
from .model import Pose2


@dataclass(frozen=True)
class RobotHeartbeat:
    scan_stamp: float
    odom_stamp: float
    map_stamp: float
    tf_stamp: float
    costmap_stamp: float
    nav2_active: bool
    path_service_ready: bool


def check_robot(heartbeat: RobotHeartbeat, now_sim_s: float,
                max_age_s: float = 3.0) -> Tuple[bool, Tuple[str, ...]]:
    reasons = []
    for name in ('scan', 'odom', 'map', 'tf', 'costmap'):
        stamp = getattr(heartbeat, name + '_stamp')
        if stamp < 0 or stamp > now_sim_s + .2 or now_sim_s - stamp > max_age_s:
            reasons.append(name + '_stale')
    if not heartbeat.nav2_active:
        reasons.append('nav2_inactive')
    if not heartbeat.path_service_ready:
        reasons.append('path_service_unready')
    return not reasons, tuple(reasons)


def startup_ready(robots: Dict[str, RobotHeartbeat], now_sim_s: float) -> bool:
    return len(robots) == 2 and all(check_robot(h, now_sim_s)[0]
                                    for h in robots.values())


def backtrack_options(safe_poses, current: Pose2, min_distance=.8):
    """Try recently reached positions outside the current stuck spot first."""
    if current is None:
        return ()
    return tuple(p for p in reversed(safe_poses)
                 if math.hypot(p.x-current.x, p.y-current.y) >= min_distance)


def translated_enough(current: Pose2, reference: Pose2, threshold=.12):
    """Turning in place does not reset the navigation stall watchdog."""
    return (current is not None and reference is not None and
            math.hypot(current.x-reference.x, current.y-reference.y) >= threshold)


def update_distance_progress(best_m, distance_m, step_m=.25):
    """Ignore Nav2's zero placeholder before a path has been computed."""
    if not math.isfinite(distance_m) or distance_m <= .05:
        return best_m, False
    if best_m is None or distance_m <= best_m - step_m:
        return distance_m, True
    return best_m, False



def failed_destination(current, target, result, radius=1.):
    """A local start/turn stall does not prove a far destination unreachable."""
    return result == 'no_path' or (current is not None and
        math.hypot(current.x-target.x, current.y-target.y) <= radius)


def unused_backtracks(history, current, used, now):
    return tuple(p for p in backtrack_options(history,current)
                 if not any(expiry>now and math.hypot(p.x-q.x,p.y-q.y)<.45
                            for q,expiry in used))


class TranslationWindow:
    """Measure net motion over a full window; distance feedback can replan upward.

    Net displacement, rather than summed path length, keeps small back-and-forth
    motions from looking like a productive detour. This never changes deadlines.
    """
    def __init__(self, seconds=20.):
        self.seconds=seconds
        self.samples=deque()

    def update(self, now, pose):
        if pose is None:
            return None
        if self.samples and now < self.samples[-1][0]:
            self.samples.clear()
        self.samples.append((now, pose))
        while len(self.samples)>1 and self.samples[1][0]<=now-self.seconds:
            self.samples.popleft()
        stamp, before=self.samples[0]
        if now-stamp < self.seconds:
            return None
        return math.hypot(pose.x-before.x, pose.y-before.y)


@dataclass
class RecoveryEpisode:
    """A retreat followed by returning to the same trap is one episode.

    All locations are odometry coordinates. Local escape success resets the
    immediate failure streak, never the episode's bounded movement budget.
    """
    origin: object = None
    failures: int = 0
    escapes: int = 0
    backtracks: int = 0

    verification_since: object = None
    verification_best_m: float = 0.

    def observe(self, current, now=None):
        """Require sustained departure; a brief retreat cannot reset the budget.

        Net displacement must exceed 1m for ten seconds without returning more
        than .3m toward the trap. Spin and out-and-back motion do not qualify.
        No-clock callers cannot claim a verified recovery.
        """
        if self.origin is None or current is None or now is None:
            return False
        distance=math.hypot(current.x-self.origin.x,current.y-self.origin.y)
        if distance<1. or distance<self.verification_best_m-.3:
            self.verification_since=None;self.verification_best_m=0.
            return False
        if self.verification_since is None:
            self.verification_since=now
        self.verification_best_m=max(self.verification_best_m,distance)
        if now-self.verification_since<10.:
            return False
        self.origin=None;self.failures=0;self.escapes=0;self.backtracks=0
        self.verification_since=None;self.verification_best_m=0.
        return True

    def navigation_result(self, current, result, moved):
        # Nav2 success or a safety retreat is an action result, not evidence
        # that the exploration route has recovered. observe() verifies that.
        failed=result in ('blocked','controller_stall','timeout')
        if failed:
            if self.origin is None:self.origin=current
            self.failures+=1
        return False


# Exact r029 distance-only episode logic, for the preregistered control arm.
@dataclass
class LegacyRecoveryEpisode:
    """A retreat followed by returning to the same trap is one episode.

    All locations are odometry coordinates. Local escape success resets the
    immediate failure streak, never the episode's bounded movement budget.
    """
    origin: object = None
    failures: int = 0
    escapes: int = 0
    backtracks: int = 0

    def observe(self, current, now=None):
        """Clear a local episode upon actual departure, including mid-action."""
        if self.origin is not None and translated_enough(current,self.origin,threshold=1.):
            self.origin=None;self.failures=0;self.escapes=0;self.backtracks=0
            return True
        return False

    def navigation_result(self, current, result, moved):
        cleared=(self.origin is not None and
                 translated_enough(current,self.origin,threshold=1.))
        if cleared:
            self.origin=None;self.failures=0;self.escapes=0;self.backtracks=0
        failed=result in ('blocked','controller_stall','timeout')
        if self.origin is None:
            if moved>=.25:
                self.failures=0
            elif failed:
                self.origin=current;self.failures+=1
        elif failed:
            self.failures+=1
        elif result=='success':
            self.failures=0
        return cleared
