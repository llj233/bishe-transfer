"""Laser-only footprint sweep in base_footprint, independent of truth.

Bounds enclose the supplied SDF body, wheels and casters. A small padding is
added; this is a sampled 2D guard, not a proof for invisible/3D obstacles.
"""
import math
# Actual base box: x=[-.1965,.0685], y=[-.1325,.1325].
# Wheels extend to approximately |y|=.162; include sensor/body tolerances.
FOOTPRINT=((-0.197,-.133),(-.034,-.163),(.034,-.163),(.069,-.133),(.069,.133),(.034,.163),(-.034,.163),(-.197,.133))
EDGES=[]
for a,b in zip(FOOTPRINT,FOOTPRINT[1:]+FOOTPRINT[:1]):
 dx,dy=b[0]-a[0],b[1]-a[1];length=math.hypot(dx,dy)
 EDGES.append((a[0],a[1],dy/length,-dx/length))
LASER_X=-.064

def laser_points(ranges,angle_min,angle_increment,range_min,range_max):
 points=[]
 for i,r in enumerate(ranges):
  if math.isnan(r) or r<range_min:continue
  # Positive infinity denotes clear space to the maximum measured range.
  if not math.isfinite(r):r=range_max
  if not math.isfinite(r) or r<=0:continue
  r=min(r,range_max);a=angle_min+i*angle_increment
  points.append((LASER_X+r*math.cos(a),r*math.sin(a)))
 return points

def clearance(point,x=0.,y=0.,yaw=0.):
 dx,dy=point[0]-x,point[1]-y;c,s=math.cos(yaw),math.sin(yaw)
 u,v=c*dx+s*dy,-s*dx+c*dy
 return max(nx*(u-ax)+ny*(v-ay) for ax,ay,nx,ny in EDGES)

def swept_velocity(linear,angular,points,padding=.025,horizon=.6):
 if not points:return 0.,0.,'insufficient_scan'
 if abs(linear)+abs(angular)<1e-6:return linear,angular,None
 # Include translational braking distance and one sensor interval. Angular
 # commands are also checked, unlike the old front/rear-only gate.
 horizon=max(horizon,abs(linear)/.45+.35)
 points=[p for p in points if math.hypot(*p)<1.2]
 if not points:return linear,angular,None
 initial=[clearance(p) for p in points]
 for step in range(1,13):
  t=step*horizon/12;angle=angular*t
  if abs(angular)<1e-6:x,y=linear*t,0.
  else:x,y=linear/angular*math.sin(angle),linear/angular*(1-math.cos(angle))
  for p,old in zip(points,initial):
   gap=clearance(p,x,y,angle)
   # Permit controlled translation away from an already tight spot. Rotation
   # at a tight corner is rejected unless the whole sampled sweep is clear.
   if gap<padding and (old>=padding or gap<old-.001 or abs(linear)<.005):
    return 0.,0.,'footprint_sweep_stop'
 return linear,angular,None


def scaled_swept_velocity(linear, angular, points, padding=.05):
 """Slow along the commanded arc; never invent a different direction.

 Every accepted command passes the existing full-body sweep with the same
 padding and braking horizon. A blocked fast command may have a valid slower
 command. Zero is retained when none of the bounded scales is admissible.
 """
 linear=max(-.26,min(.26,linear));angular=max(-.6,min(.6,angular))
 if not points:return 0.,0.,'insufficient_scan'
 for scale in (1.,.75,.5,.25,.125):
  v,w=linear*scale,angular*scale
  x,z,reason=swept_velocity(v,w,points,padding=padding)
  if reason is None:return x,z,None if scale==1 else 'footprint_sweep_slow'
 return 0.,0.,'footprint_sweep_stop'
