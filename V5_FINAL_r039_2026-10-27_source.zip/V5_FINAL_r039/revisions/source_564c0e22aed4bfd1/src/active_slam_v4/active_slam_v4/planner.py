"""Frontier observations validated in the robot's own SLAM/Nav2 frame."""
from collections import deque
import hashlib
import math
from typing import Callable, List, Optional, Tuple
from .model import Candidate, Grid, Pose2, Transform2


def footprint_fits(grid: Grid, pose: Pose2, margin=.05):
    """Conservative oriented body test against known-free SLAM cells only.

    A cell half-diagonal expands every body half-plane, so blocked/unknown
    squares touching the padded footprint are rejected, including map edges.
    This is a pose filter; Nav2 must still validate the full route.
    """
    import numpy as np
    from .swept_safety import EDGES, FOOTPRINT
    cell = grid.cell_of(pose)
    if cell is None:
        return False
    padding = margin + grid.resolution * math.sqrt(2) / 2
    radius = math.ceil((max(math.hypot(*p) for p in FOOTPRINT) +
                        2 * padding) / grid.resolution)
    xs = np.arange(cell[0]-radius, cell[0]+radius+1)
    ys = np.arange(cell[1]-radius, cell[1]+radius+1)
    xx, yy = np.meshgrid(xs, ys)
    anchor = grid.center(*cell)
    dx = (xx-cell[0])*grid.resolution
    dy = (yy-cell[1])*grid.resolution
    c, sn = math.cos(grid.origin.yaw), math.sin(grid.origin.yaw)
    wx = anchor.x + c*dx-sn*dy-pose.x
    wy = anchor.y + sn*dx+c*dy-pose.y
    c, sn = math.cos(pose.yaw), math.sin(pose.yaw)
    u, v = c*wx+sn*wy, -sn*wx+c*wy
    intersects = np.ones(xx.shape, dtype=bool)
    for ax, ay, nx, ny in EDGES:
        intersects &= nx*(u-ax)+ny*(v-ay) <= padding
    inside = (xx>=0)&(yy>=0)&(xx<grid.width)&(yy<grid.height)
    if np.any(intersects & ~inside):
        return False
    selected = intersects & inside
    values = np.asarray(grid.cells).reshape(grid.height, grid.width)[yy[selected], xx[selected]]
    return bool(np.all((values>=0)&(values<=25)))


class CenterFootprintChecker:
    """Reuse the map array and conservative body masks during one decision.

    Candidates are grid centres. Quantising yaw expands the mask by the
    greatest possible corner displacement, so this cache cannot admit a pose
    rejected by the exact padded-body test. Unknown cells remain forbidden.
    """
    def __init__(self, grid, margin=.05, bins=64):
        import numpy as np
        from .swept_safety import FOOTPRINT
        self.grid, self.margin, self.bins = grid, margin, bins
        self.free = np.asarray(grid.cells).reshape(grid.height, grid.width)
        self.free = (self.free >= 0) & (self.free <= 25)
        self.masks = {}
        self.body_radius = max(math.hypot(*p) for p in FOOTPRINT)

    def fits(self, x, y, yaw):
        import numpy as np
        from .swept_safety import EDGES
        g = self.grid
        relative = (yaw-g.origin.yaw) % (2*math.pi)
        bucket = int(math.floor(relative*self.bins/(2*math.pi)+.5)) % self.bins
        if bucket not in self.masks:
            angle = bucket*2*math.pi/self.bins
            # Covers the half-bin yaw uncertainty and raster cell extent.
            pad = (self.margin + g.resolution*math.sqrt(2)/2 +
                   2*self.body_radius*math.sin(math.pi/(2*self.bins)) + 1e-10)
            radius = math.ceil((self.body_radius+2*pad)/g.resolution)
            xx, yy = np.meshgrid(np.arange(-radius,radius+1),
                                 np.arange(-radius,radius+1))
            u = g.resolution*(math.cos(angle)*xx+math.sin(angle)*yy)
            v = g.resolution*(-math.sin(angle)*xx+math.cos(angle)*yy)
            mask = np.ones(xx.shape,dtype=bool)
            for ax,ay,nx,ny in EDGES:
                mask &= nx*(u-ax)+ny*(v-ay) <= pad
            self.masks[bucket] = xx[mask],yy[mask]
        dx,dy = self.masks[bucket]
        xs,ys = x+dx,y+dy
        if xs.min()<0 or ys.min()<0 or xs.max()>=g.width or ys.max()>=g.height:
            return False
        return bool(np.all(self.free[ys,xs]))


def record_safe_breadcrumb(history, grid, pose, spacing=.6):
    """Keep measured, traversed poses for short Nav2-validated recoveries."""
    if pose is None or (history and math.hypot(pose.x-history[-1].x,
                                              pose.y-history[-1].y)<spacing):
        return False
    if not footprint_fits(grid, pose):
        return False
    history.append(pose)
    if len(history)>2000:
        del history[:-2000]
    return True


def neighbors(grid: Grid, cell: Tuple[int, int]):
    x, y = cell
    for u, v in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
        if 0 <= u < grid.width and 0 <= v < grid.height:
            yield u, v


def reachable_free(grid: Grid, start: Pose2):
    import numpy as np
    from scipy.ndimage import label
    root=grid.cell_of(start)
    if root is None or not 0<=grid.at(*root)<=25:return set()
    cells=np.asarray(grid.cells).reshape(grid.height,grid.width)
    labels,_=label((cells>=0)&(cells<=25))  # same four-neighbour topology
    component=labels[root[1],root[0]]
    return {(x,y) for y,x in np.argwhere(labels==component).tolist()}


def frontier_clusters(grid: Grid, traversable):
    import numpy as np
    from scipy.ndimage import label
    if not traversable:return []
    cells=np.asarray(grid.cells).reshape(grid.height,grid.width)
    unknown=cells<0;adjacent=np.zeros_like(unknown)
    adjacent[1:] |= unknown[:-1];adjacent[:-1] |= unknown[1:]
    adjacent[:,1:] |= unknown[:,:-1];adjacent[:,:-1] |= unknown[:,1:]
    reachable=np.zeros_like(unknown);xs,ys=zip(*traversable);reachable[ys,xs]=True
    labels,_=label(adjacent & reachable)
    groups={}
    for y,x in np.argwhere(labels>0).tolist():groups.setdefault(int(labels[y,x]),set()).add((x,y))
    return sorted(groups.values(),key=lambda g:(-len(g),min(g)))


def obstacle_clearance(grid: Grid, include_unknown=False, euclidean=False):
    if euclidean:
        import numpy as np
        from scipy.ndimage import distance_transform_edt
        cells = np.asarray(grid.cells).reshape(grid.height, grid.width)
        blocked = (cells >= 65) | ((cells < 0) if include_unknown else False)
        # Distance between cell centres minus half the obstacle-cell diagonal.
        # Unknown outside the map is treated as blocked for footprint checks.
        padded = np.pad(~blocked, 1, constant_values=False)
        distance = distance_transform_edt(padded)[1:-1, 1:-1] * grid.resolution
        return np.maximum(0, distance-grid.resolution*math.sqrt(2)/2).ravel().tolist()
    distance = [math.inf] * len(grid.cells)
    queue = deque()
    for y in range(grid.height):
        for x in range(grid.width):
            idx = grid.index(x, y)
            if grid.cells[idx] >= 65 or (include_unknown and grid.cells[idx] < 0):
                distance[idx] = 0
                queue.append((x, y))
    while queue:
        cell = queue.popleft()
        d = distance[grid.index(*cell)] + grid.resolution
        for other in neighbors(grid, cell):
            idx = grid.index(*other)
            if d < distance[idx]:
                distance[idx] = d
                queue.append(other)
    return distance


def visible_unknown(grid: Grid, pose: Pose2, max_range_m=3.2, rays=48,
                    cells_array=None):
    """Same first-unknown-per-ray proxy, evaluated as one small array.

    Occupied cells and map edges terminate a ray before unknown cells behind
    them can count. This is a visibility proxy, not entropy reduction.
    """
    import numpy as np
    cells = (np.asarray(grid.cells).reshape(grid.height,grid.width)
             if cells_array is None else cells_array)
    steps = np.arange(1,int(max_range_m/grid.resolution)+1)*grid.resolution
    if not len(steps):
        return 0
    angles = [ray*2*math.pi/rays for ray in range(rays)]
    wx = pose.x + np.array([math.cos(a) for a in angles])[:,None]*steps
    wy = pose.y + np.array([math.sin(a) for a in angles])[:,None]*steps
    dx,dy = wx-grid.origin.x,wy-grid.origin.y
    c,s = math.cos(grid.origin.yaw),math.sin(grid.origin.yaw)
    xs = np.floor((c*dx+s*dy)/grid.resolution).astype(int)
    ys = np.floor((-s*dx+c*dy)/grid.resolution).astype(int)
    inside = (xs>=0)&(ys>=0)&(xs<grid.width)&(ys<grid.height)
    values = cells[np.clip(ys,0,grid.height-1),np.clip(xs,0,grid.width-1)]
    stop = ~inside | (values>=65) | (values<0)
    hit = stop.argmax(axis=1)
    rr = np.arange(rays)
    unknown = stop.any(axis=1)&inside[rr,hit]&(values[rr,hit]<0)
    return len(set(zip(xs[rr[unknown],hit[unknown]].tolist(),
                       ys[rr[unknown],hit[unknown]].tolist())))


def region_id(pose: Pose2, side_m=2.0):
    return f'{math.floor(pose.x / side_m)}:{math.floor(pose.y / side_m)}'


def seeded_score(score, policy_seed, robot, pose):
    """Stable one-percent preference among near-equal candidate scores."""
    key = f'{policy_seed}:{robot}:{pose.x:.2f}:{pose.y:.2f}'.encode()
    fraction = int.from_bytes(hashlib.blake2b(key, digest_size=8).digest(), 'big') / 2**64
    return score + abs(score) * .01 * (2 * fraction - 1)


class CandidatePlanner:
    def __init__(self, safe_radius_m=.50, robot_speed_mps=.22,
                 max_candidates=120, max_path_queries=36, policy_seed=0,
                 method='B1', feasible_target_limit=6, fast_mode=False):
        self.fast_mode = fast_mode
        self.safe_radius_m = safe_radius_m
        self.robot_speed_mps = robot_speed_mps
        self.max_candidates = max_candidates
        self.max_path_queries = max_path_queries
        self.policy_seed = int(policy_seed)
        self.method = method
        self.last_candidates = []
        self.feasible_target_limit=feasible_target_limit
        self.empty_rounds=0

    def plan(self, robot: str, local_map: Grid, robot_pose_local: Pose2,
             to_global: Transform2, map_version: int,
             path_length: Callable[[Pose2], Optional[float]],
             failed_on_version=frozenset(),
             forbidden_targets=()) -> Tuple[List[Candidate], dict]:
        """Path callback MUST call this robot's Nav2 ComputePathToPose service.

        The callback returns path length in metres, or None for no path/timeout.
        No Euclidean shortcut is allowed to mark a candidate navigable.
        """
        free = reachable_free(local_map, robot_pose_local)
        clusters = frontier_clusters(local_map, free)
        footprint = self.method in ('B2', 'B2_FOOTPRINT')
        # Cheap centre prefilter; B2 then checks the full oriented padded body.
        required_clearance = .10 if footprint else self.safe_radius_m
        required_known_gap = .10 if footprint else min(.2,local_map.resolution)
        clearance = obstacle_clearance(local_map, euclidean=footprint)
        unknown_gap = obstacle_clearance(local_map, include_unknown=True,
                                        euclidean=footprint)
        import numpy as np
        cells_array = np.asarray(local_map.cells).reshape(local_map.height,local_map.width)
        checker = CenterFootprintChecker(local_map) if footprint else None
        # Keep normal separation; after two empty rounds, allow a short safe
        # observation move rather than translating blindly near deployment.
        min_goal_distance = .25 if self.empty_rounds >= 2 else .60
        proposals = []
        used_cells = set()
        rejected = {'unreachable_local': 0, 'unsafe': 0,
                    'low_gain': 0, 'no_nav2_path': 0, 'recent_failure': 0,
                    'too_close': 0}
        candidate_clusters = {}
        for cluster_index,group in enumerate(clusters[:self.max_candidates]):
            # Move observation poses back into mapped space. Boundary cells
            # themselves can lie in Nav2's inflated or unknown region.
            cx = sum(x for x, _ in group) / len(group)
            cy = sum(y for _, y in group) / len(group)
            chosen = sorted(group, key=lambda p: (p[0] - cx) ** 2 +
                            (p[1] - cy) ** 2)[:4]
            for frontier in chosen:
                max_offset = max(.9, 1.5 * local_map.resolution)
                min_offset = min(.25, .5 * local_map.resolution)
                radius = max(1, int(max_offset / local_map.resolution))
                nearby = [(x, y) for y in range(max(0, frontier[1]-radius),
                                                  min(local_map.height, frontier[1]+radius+1))
                          for x in range(max(0, frontier[0]-radius),
                                         min(local_map.width, frontier[0]+radius+1))
                          if (x, y) in free and (x, y) not in used_cells and
                          min_offset <= math.hypot(x-frontier[0], y-frontier[1]) *
                          local_map.resolution <= max_offset and
                          clearance[local_map.index(x, y)] >= required_clearance and
                          unknown_gap[local_map.index(x, y)] >=
                          required_known_gap]
                if not nearby:
                    rejected['unsafe'] += 1
                    continue
                nearby.sort(key=lambda p: (
                    abs(math.hypot(p[0]-frontier[0], p[1]-frontier[1]) *
                        local_map.resolution - .45),
                    -clearance[local_map.index(*p)], p))
                target = local_map.center(*frontier)
                cell = None
                for option in nearby:
                    point = local_map.center(*option)
                    # Check before choosing a cell: a near first option must
                    # not hide the remaining safe options in this cluster.
                    if math.hypot(point.x-robot_pose_local.x,
                                  point.y-robot_pose_local.y) < min_goal_distance:
                        rejected['too_close'] += 1
                        continue
                    observation = Pose2(point.x, point.y,
                                        math.atan2(point.y-robot_pose_local.y, point.x-robot_pose_local.x)
                                        if self.fast_mode else math.atan2(target.y-point.y, target.x-point.x))
                    if not footprint or checker.fits(option[0], option[1], observation.yaw):
                        cell = option
                        break
                if cell is None:
                    rejected['unsafe'] += 1
                    continue
                used_cells.add(cell)
                gap = min(clearance[local_map.index(*cell)],
                          unknown_gap[local_map.index(*cell)])
                pose = local_map.center(*cell)
                if math.hypot(pose.x - robot_pose_local.x,
                              pose.y - robot_pose_local.y) < min_goal_distance:
                    rejected['too_close'] += 1
                    continue
                gain = visible_unknown(local_map, pose, cells_array=cells_array)
                if gain < 2:
                    rejected['low_gain'] += 1
                    continue
                gx, gy = local_map.center(*frontier).x, local_map.center(*frontier).y
                pose = Pose2(pose.x, pose.y,
                             math.atan2(pose.y-robot_pose_local.y,pose.x-robot_pose_local.x)
                             if self.fast_mode else math.atan2(gy-pose.y,gx-pose.x))
                if any(math.hypot(pose.x - bad.x, pose.y - bad.y) < .55
                       for bad in forbidden_targets):
                    rejected['recent_failure'] += 1
                    continue
                global_pose = to_global.apply(pose)
                ident = f'{robot}:{map_version}:{cell[0]}:{cell[1]}'
                if ident in failed_on_version:
                    continue
                candidate_clusters[ident] = cluster_index
                distance = math.hypot(pose.x-robot_pose_local.x,
                                      pose.y-robot_pose_local.y)
                proposals.append((gain, gap, pose, global_pose, ident,
                                  gain / (distance + 1.0)))
        # Query one spatially distinct area at a time. Otherwise dozens of
        # high-gain cells beyond the same blocked doorway consume the budget.
        proposals.sort(key=lambda p: (-p[5], -p[0], -p[1], p[4]))
        buckets = {}
        for proposal in proposals:
            p = proposal[2]
            key = (math.floor(p.x / 2.0), math.floor(p.y / 2.0))
            buckets.setdefault(key, []).append(proposal)
        diverse = []
        for rank in range(2):
            diverse.extend(items[rank] for items in buckets.values()
                           if len(items) > rank)
        result = []
        query_cap=min(40,self.max_path_queries*(2 if self.empty_rounds>=2 else 1))
        query_count=0
        for gain, gap, pose, global_pose, ident, _ in diverse[:query_cap]:
            query_count+=1
            length = path_length(pose)
            if length is None or not math.isfinite(length) or length < 0:
                rejected['no_nav2_path'] += 1
                continue
            travel = getattr(length,'travel_time_s',length/self.robot_speed_mps+2.)
            score = gain / travel - .1 / max(gap, .1)
            score = seeded_score(score, self.policy_seed, robot, pose)
            if self.method == 'B0':
                score = -length
            result.append(Candidate(ident, robot, region_id(global_pose),
                                    pose, global_pose, map_version, gain,
                                    length, gap, score))
            if len(result)>=self.feasible_target_limit:break
        result.sort(key=lambda c: (-c.score, c.candidate_id))
        self.last_candidates = list(result)
        self.empty_rounds=0 if result else self.empty_rounds+1
        return result, {'frontier_clusters': len(clusters),
                        'frontier_cells': sum(len(g) for g in clusters),
                        'proposals': len(proposals),
                        'reachable_candidates': len(result),
                        'candidate_clusters':candidate_clusters,
                        'reachable_free_cells': len(free),
                        'spatial_regions': len(buckets),
                        'path_queries': query_count, 'path_query_cap':query_cap,
                        'rejected': rejected}

