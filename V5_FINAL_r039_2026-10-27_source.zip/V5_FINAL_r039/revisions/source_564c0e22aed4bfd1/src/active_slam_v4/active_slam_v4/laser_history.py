"""Measured obstacle memory in odometry; no truth/map dependency.

Optional near retention is for frozen static scenes: a low obstacle entering a
sensor blind zone must not become free space merely because a timer expired.
It is not a moving-object tracker. Fresh sensor/odometry gates remain mandatory.
"""
from collections import deque
import math

class ObstacleHistory:
 def __init__(self,age_s=1.2,near_hold_m=0.,confirmations=1):
  self.age=age_s;self.frames=deque();self.near_hold=near_hold_m;self.held={}
  self.confirmations=confirmations;self.pending_near={}
 def observe(self,points,pose,now):
  x,y,yaw=pose;c,s=math.cos(yaw),math.sin(yaw)
  world=[(x+c*u-s*v,y+s*u+c*v) for u,v in points if math.hypot(u,v)<1.5]
  self.frames.append((now,world));self.expire(now)
  if self.near_hold:
   self.prune_near(x,y)
   observed=set()
   for u,v in world:
    if math.hypot(u-x,v-y)<self.near_hold:
     # Quantise only the key; preserve the actual measured point coordinates.
     key=(math.floor(u/.02),math.floor(v/.02))
     if key in observed:continue
     observed.add(key)
     point,stamps=self.pending_near.get(key,((u,v),deque()))
     while stamps and now-stamps[0]>1.5:stamps.popleft()
     if not stamps or now-stamps[-1]>1e-6:stamps.append(now)
     self.pending_near[key]=((u,v),stamps)
     if key in self.held or (len(stamps)>=self.confirmations and
                            (self.confirmations==1 or now-stamps[0]>=.4)):
      self.held[key]=(u,v)
 def prune_near(self,x,y):
  self.held={k:p for k,p in self.held.items()
             if math.hypot(p[0]-x,p[1]-y)<self.near_hold+.1}
  self.pending_near={k:v for k,v in self.pending_near.items()
                     if math.hypot(v[0][0]-x,v[0][1]-y)<self.near_hold+.1}
 def expire(self,now):
  while self.frames and now-self.frames[0][0]>self.age:self.frames.popleft()
  self.pending_near={k:v for k,v in self.pending_near.items()
                     if v[1] and now-v[1][-1]<=1.5}
 def project(self,pose,now):
  self.expire(now);x,y,yaw=pose;c,s=math.cos(yaw),math.sin(yaw)
  self.prune_near(x,y)
  world=[p for stamp,points in self.frames for p in points]+list(self.held.values())
  return [(c*(u-x)+s*(v-y),-s*(u-x)+c*(v-y)) for u,v in world]
