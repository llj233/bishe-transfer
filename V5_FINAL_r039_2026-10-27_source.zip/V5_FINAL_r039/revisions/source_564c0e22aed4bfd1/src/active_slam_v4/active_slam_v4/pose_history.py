"""Interpolate sensor-time odometry without extrapolation or truth access."""
from bisect import bisect_left
import math

class PoseHistory:
    def __init__(self, age_s=5., max_gap_s=.15):
        self.age_s=age_s;self.max_gap_s=max_gap_s;self.samples=[]

    def append(self, stamp, pose):
        if self.samples and stamp<self.samples[-1][0]-1e-6:
            if stamp<self.samples[-1][0]-1.:
                self.samples.clear()
            else:
                return False
        if self.samples and abs(stamp-self.samples[-1][0])<1e-6:
            self.samples[-1]=(stamp,pose)
        else:
            self.samples.append((stamp,pose))
        while len(self.samples)>2 and stamp-self.samples[0][0]>self.age_s:
            self.samples.pop(0)
        return True

    def at(self, stamp):
        if not self.samples:return None
        i=bisect_left([s[0] for s in self.samples],stamp)
        if i<len(self.samples) and abs(self.samples[i][0]-stamp)<1e-6:
            return self.samples[i][1]
        if i==0 or i==len(self.samples):return None
        ta,a=self.samples[i-1];tb,b=self.samples[i]
        if tb-ta>self.max_gap_s:return None
        f=(stamp-ta)/(tb-ta)
        delta=math.atan2(math.sin(b[2]-a[2]),math.cos(b[2]-a[2]))
        angle=a[2]+f*delta
        return (a[0]+f*(b[0]-a[0]),a[1]+f*(b[1]-a[1]),
                math.atan2(math.sin(angle),math.cos(angle)))
