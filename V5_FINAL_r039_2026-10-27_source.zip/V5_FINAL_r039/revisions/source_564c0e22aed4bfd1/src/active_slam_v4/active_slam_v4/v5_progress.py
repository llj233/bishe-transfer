"""Decaying online experience; no SDF, truth mask or evaluator access."""
from dataclasses import replace
import math
from .planner import region_id

def known_near(grid, pose, radius=3.2):
    """Quantized world positions tolerate changes in SLAM grid origin."""
    seen=set()
    c,s=math.cos(grid.origin.yaw),math.sin(grid.origin.yaw)
    dx,dy=pose.x-grid.origin.x,pose.y-grid.origin.y
    cx=(c*dx+s*dy)/grid.resolution;cy=(-s*dx+c*dy)/grid.resolution
    reach=radius/grid.resolution+1
    for y in range(max(0,int(math.floor(cy-reach))),min(grid.height,int(math.ceil(cy+reach)))):
        for x in range(max(0,int(math.floor(cx-reach))),min(grid.width,int(math.ceil(cx+reach)))):
            if grid.at(x,y)<0:continue
            p=grid.center(x,y)
            if math.hypot(p.x-pose.x,p.y-pose.y)<=radius:
                seen.add((math.floor(p.x/.1+1e-6),math.floor(p.y/.1+1e-6)))
    return seen

class ProgressMemory:
    def __init__(self):
        self.starts={}
        self.history=[]

    def begin(self, goal_id, goal_pose, robot_pose, grid, now):
        self.starts[goal_id]=(goal_pose,robot_pose,now,known_near(grid,goal_pose))

    def finish(self, goal_id, robot_pose, grid, now, result):
        state=self.starts.pop(goal_id,None)
        if not state or not grid or robot_pose is None:return None
        target,start,stamp,before=state
        after=known_near(grid,target)
        gained=len(after-before)
        lost=len(before-after)
        movement=math.hypot(robot_pose.x-start.x,robot_pose.y-start.y)
        # Large loss of mapped cells suggests SLAM/frame changes; do not learn
        # a negative regional judgement from inconsistent maps.
        healthy=lost<=max(10,.2*len(before))
        eligible=healthy and now-stamp>=3 and movement>=.15
        failed=healthy and now-stamp>=5 and result in ('blocked','controller_stall','timeout','no_path')
        row={'goal_id':goal_id,'region':region_id(target),'sim_time':now,
             'duration_s':now-stamp,'online_new_known_cells':gained,
             'lost_known_cells':lost,'movement_m':movement,'feedback_eligible':eligible,
             'low_gain':eligible and gained<5,'navigation_failed':failed,'failure_region':region_id(robot_pose),'result':result}
        self.history.append(row)
        return row

    def adjust(self, candidates, now):
        if not candidates:return []
        # Rank before subtracting penalties: raw V4 scores may be negative.
        ordered=sorted(candidates,key=lambda c:(-c.score,c.candidate_id))
        scores={c.candidate_id:(len(ordered)-1-i)/max(1,len(ordered)-1)
                for i,c in enumerate(ordered)}
        output=[]
        for c in ordered:
            past=[r for r in self.history if (r['region']==c.region_id and r['feedback_eligible']) or (r.get('navigation_failed',False) and r.get('failure_region',r['region'])==c.region_id)]
            visits=sum(math.exp(-(now-r['sim_time'])/180) for r in past)
            low=sum(math.exp(-(now-r['sim_time'])/90) for r in past if r['low_gain'])
            # Repeated low gain can outweigh even the top rank when only two
            # candidates remain. Ordinary successful visits have a mild cost.
            failures=sum(math.exp(-(now-r['sim_time'])/90) for r in past if r.get('navigation_failed',False))
            penalty=.25*min(1,visits/3)+.85*min(1,low/2)+.9*min(1,failures/2)
            output.append(replace(c,score=scores[c.candidate_id]-penalty))
        return sorted(output,key=lambda c:(-c.score,c.candidate_id))
