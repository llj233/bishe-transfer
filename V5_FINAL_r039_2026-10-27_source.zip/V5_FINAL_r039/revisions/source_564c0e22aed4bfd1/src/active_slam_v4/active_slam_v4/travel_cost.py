"""Execution-time proxy from the actual Nav2 path, without ground truth."""
import math

class PathCost(float):
    def __new__(cls, length, travel_time_s, forward_m, reverse_m, cusps):
        obj=super().__new__(cls,length)
        obj.travel_time_s=travel_time_s
        obj.forward_m=forward_m;obj.reverse_m=reverse_m;obj.cusps=cusps
        return obj

def angle_delta(a,b):
    return abs(math.atan2(math.sin(a-b),math.cos(a-b)))

def estimate_path(poses, forward_speed=.22, reverse_speed=.08,
                  angular_speed=.6, cusp_seconds=1.):
    if min(forward_speed,reverse_speed,angular_speed)<=0:
        raise ValueError('Speeds must be positive')
    forward=reverse=length=travel=0.;cusps=0;previous=None
    for a,b in zip(poses,poses[1:]):
        dx,dy=b.x-a.x,b.y-a.y;distance=math.hypot(dx,dy)
        rotation=angle_delta(b.yaw,a.yaw)
        if distance<1e-6:
            travel+=rotation/angular_speed;continue
        direction=1 if dx*math.cos(a.yaw)+dy*math.sin(a.yaw)>=0 else -1
        if previous is not None and direction!=previous:cusps+=1
        previous=direction;length+=distance
        if direction>0:forward+=distance
        else:reverse+=distance
        travel+=max(distance/(forward_speed if direction>0 else reverse_speed),
                    rotation/angular_speed)
    return PathCost(length,travel+cusps*cusp_seconds+2.,forward,reverse,cusps)
