"""Isolated V4 single/dual Gazebo test. Readiness is checked by the executor."""
from pathlib import Path
import json
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, ExecuteProcess, OpaqueFunction, RegisterEventHandler
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.descriptions import ParameterFile
from nav2_common.launch import RewrittenYaml


POSITIONS = [('robot1', -1.7, -2.5), ('robot2', -.7, -2.5)]


def robot_nodes(name, x, y, folder, angle=0.0, spawn_z=.01):
    nav_file = str(Path(folder) / f'{name}_nav2.yaml')
    slam_file = str(Path(folder) / f'{name}_slam.yaml')
    model_file = str(Path(folder) / f'{name}.sdf')
    params = ParameterFile(RewrittenYaml(source_file=nav_file, root_key=name,
                                         param_rewrites={'use_sim_time': 'true'},
                                         convert_types=True), allow_substs=True)

    def static(parent, child, sx=0.0, sy=0.0, sz=0.0):
        return Node(package='tf2_ros', executable='static_transform_publisher',
                    arguments=['--x', str(sx), '--y', str(sy), '--z', str(sz),
                               '--frame-id', parent, '--child-frame-id', child],
                    output='log')

    nodes = [
        # Simulator odometry starts in the world frame. This explicit initial
        # alignment is validated by V4 map overlap; it is not a real-robot TF.
        static('map', f'{name}/map'),
        static(f'{name}/base_footprint', f'{name}/base_link', 0, 0, .01),
        static(f'{name}/base_link', f'{name}/base_scan', -.064, 0, .121),
        Node(package='gazebo_ros', executable='spawn_entity.py',
             arguments=['-entity', name, '-robot_namespace', f'/{name}',
                        '-file', model_file, '-x', str(x), '-y', str(y), '-z', str(spawn_z), '-Y', str(angle)],
             output='screen'),
        Node(package='slam_toolbox', executable='async_slam_toolbox_node',
             name='slam_toolbox', namespace=name, output='screen',
             parameters=[slam_file, {'use_sim_time': True}],
             remappings=[('/map', f'/{name}/map'),
                         ('/map_metadata', f'/{name}/map_metadata')]),
    ]
    nav = [
        ('nav2_controller', 'controller_server', 'controller_server', [('cmd_vel', 'cmd_vel_nav')]),
        ('nav2_smoother', 'smoother_server', 'smoother_server', []),
        ('nav2_planner', 'planner_server', 'planner_server', []),
        ('nav2_behaviors', 'behavior_server', 'behavior_server',
         [('cmd_vel', 'cmd_vel_recovery')]),
        ('nav2_bt_navigator', 'bt_navigator', 'bt_navigator', []),
        ('nav2_waypoint_follower', 'waypoint_follower', 'waypoint_follower', []),
        ('nav2_velocity_smoother', 'velocity_smoother', 'velocity_smoother',
         [('cmd_vel', 'cmd_vel_nav'), ('cmd_vel_smoothed', 'cmd_vel_unchecked')]),
    ]
    for package, executable, node_name, remaps in nav:
        nodes.append(Node(package=package, executable=executable, name=node_name,
                          namespace=name, output='log', parameters=[params],
                          remappings=remaps))
    nodes.append(Node(package='nav2_lifecycle_manager', executable='lifecycle_manager',
                      name='lifecycle_manager_navigation', namespace=name,
                      output='screen', parameters=[{'use_sim_time': True,
                          'autostart': True, 'node_names': [item[2] for item in nav]}]))
    nodes.append(Node(package='active_slam_v4', executable='project_near_ground',
                      namespace=name, output='screen',
                      parameters=[{'use_sim_time': True, 'robot': name, 'run_dir': str(folder)}]))
    nodes.append(Node(package='active_slam_v4', executable='single_safety_gate',
                      namespace=name, output='screen',
                      parameters=[{'use_sim_time': True, 'robot': name, 'run_dir': str(folder)}]))
    return nodes


def generate_launch_description():
    def build(context):
        folder = LaunchConfiguration('run_dir').perform(context)
        mode = LaunchConfiguration('mode').perform(context)
        if mode != 'single':
            raise ValueError('This isolated workspace is single-robot only')
        names = ['robot1']
        manifest = json.loads((Path(folder)/'manifest.json').read_text())
        deployment = manifest.get('deployment', {'robot1':[-1.7,-2.5,0.0]})
        world = LaunchConfiguration('world').perform(context)
        # gazebo_ros.launch prepends installed TurtleBot models ahead of the
        # locked V5 resources. Launch directly to preserve pinned path order.
        # Also load the server audit only in gzserver, never in the GUI client.
        plugin_path='/opt/ros/humble/lib:/usr/lib/x86_64-linux-gnu/gazebo-11/plugins:'+os.environ.get('GAZEBO_PLUGIN_PATH','')
        gazebo=ExecuteProcess(cmd=['gzserver',world,'--seed',LaunchConfiguration('map_seed'),
            '-s','libgazebo_ros_init.so','-s','libgazebo_ros_factory.so',
            '-s','libgazebo_ros_force_system.so','-s',str(Path(get_package_share_directory('gazebo_scene_audit')).parents[1]/'lib/libv5_audit.so')],
            additional_env={'GAZEBO_PLUGIN_PATH':plugin_path},output='screen')
        client=ExecuteProcess(cmd=['gzclient','--gui-client-plugin=libgazebo_ros_eol_gui.so'],
            additional_env={'GAZEBO_PLUGIN_PATH':plugin_path},condition=IfCondition(LaunchConfiguration('gui')),output='log')
        actions = [gazebo,client,
                   RegisterEventHandler(OnProcessExit(target_action=gazebo,
                       on_exit=[EmitEvent(event=Shutdown(reason='Gazebo server exited'))]))]
        for name in names:
            x,y,angle = deployment[name]
            actions.extend(robot_nodes(name, x, y, folder, angle, spawn_z=float(manifest.get('deployment_z_m',.01))))
        coordinator = Node(package='active_slam_v4', executable='test_executor',
                           output='screen', parameters=[{'use_sim_time': True,
                               'mode': mode, 'run_dir': folder,
                               'policy_seed': LaunchConfiguration('policy_seed'),
                               'max_sim_seconds': LaunchConfiguration('max_sim_seconds')}])
        evaluator = Node(package='v4_evaluator', executable='evaluator',
                         output='screen', parameters=[{'use_sim_time': True,
                             'world_sdf': world, 'run_dir': folder,
                             'truth_npz': manifest.get('truth_npz',''),
                             'starts_xy': deployment['robot1'][:2]}])
        snapshotter = Node(package='active_slam_v4', executable='failure_snapshotter',
                           output='log', parameters=[{'use_sim_time': True,
                               'world_sdf': world,
                               'output_dir': str(Path(folder) / 'diagnostics')}])
        actions.extend([coordinator, evaluator, snapshotter,
                        RegisterEventHandler(OnProcessExit(
                            target_action=coordinator,
                            on_exit=[EmitEvent(event=Shutdown())]))])
        return actions

    return LaunchDescription([
        DeclareLaunchArgument('run_dir'),
        DeclareLaunchArgument('world'),
        DeclareLaunchArgument('mode', default_value='single'),
        DeclareLaunchArgument('gui', default_value='true'),
        DeclareLaunchArgument('max_sim_seconds', default_value='180'),
        DeclareLaunchArgument('map_seed', default_value='0'),
        DeclareLaunchArgument('policy_seed', default_value='0'),
        OpaqueFunction(function=build),
    ])
