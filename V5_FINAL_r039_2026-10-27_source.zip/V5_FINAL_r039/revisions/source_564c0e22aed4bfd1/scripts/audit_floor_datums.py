#!/usr/bin/env python3
"""Audit scene-only support datum at both fixed legal deployments."""
import json,os,signal,subprocess,time
from pathlib import Path
from world_adapter import ROOT,WORLDS,environment

def main():
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--maps',nargs='+',required=True);args=parser.parse_args()
 for index,wid in enumerate(args.maps):
  adapter=WORLDS[wid]
  folder=adapter.directory;audit=json.loads((folder/'truth_audit.json').read_text())
  evidence=folder/('floor_probe_'+str(time.time_ns()));evidence.mkdir()
  env=environment();env['V5_TRUTH_OUTPUT']=str(evidence/'collision');env['V5_FLOOR_PROBES']=';'.join(f'{p[0]} {p[1]}' for p in audit['spawns'].values())
  env.pop('V5_PHYSICS_AUDIT',None);env.pop('V5_FLOOR_Z',None);env['GAZEBO_MASTER_URI']=f'http://127.0.0.1:{24500+index}'
  output=evidence/'collision.floor.json'
  with (evidence/'gazebo.log').open('w') as log:
   p=subprocess.Popen(['gzserver','--verbose','-s',str(ROOT/'install/gazebo_scene_audit/lib/libv5_audit.so'),str(folder/'world.sdf')],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:
    start=time.monotonic()
    while not output.exists():
     if p.poll() is not None:raise RuntimeError('Floor probe server exited '+wid)
     if time.monotonic()-start>120:raise TimeoutError('Floor probe watchdog '+wid)
     time.sleep(.2)
    data=json.loads(output.read_text());data['evidence_dir']=str(evidence)
    if not data['passed']:raise ValueError('No consistent single floor datum: '+str(output))
    (folder/'floor_audit.json').write_text(json.dumps(data,indent=2));print(wid,data['floor_z'],data['valid_samples'],flush=True)
   finally:
    if p.poll() is None:os.killpg(p.pid,signal.SIGINT)
    try:p.wait(10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
if __name__=='__main__':main()
