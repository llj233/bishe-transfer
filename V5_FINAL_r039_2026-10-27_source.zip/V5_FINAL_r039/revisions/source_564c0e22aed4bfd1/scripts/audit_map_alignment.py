#!/usr/bin/env python3
"""Check measured occupied landmarks against independent collision surfaces."""
import json,math,sys
from pathlib import Path
import numpy as np,yaml
from scipy import ndimage
from PIL import Image
from world_adapter import ROOT

def audit(folder):
 m=json.loads((folder/'manifest.json').read_text());adapter=ROOT/'world_adapters'/m['world_id']
 if not (folder/'fused_slam_map.yaml').exists() or not (folder/'fused_slam_map.pgm').exists():
  result={'passed':False,'reason':'SLAM map absent after startup/infrastructure failure','world_id':m['world_id'],'run_dir':str(folder)}
  (folder/'alignment_audit.json').write_text(json.dumps(result,indent=2));return result
 truth=json.loads((adapter/'collision.json').read_text())
 raw=np.fromfile(adapter/'collision.bin',np.uint8).reshape(truth['height'],truth['width'])>0
 distance=ndimage.distance_transform_edt(~raw)*truth['resolution']
 config=yaml.safe_load((folder/'fused_slam_map.yaml').read_text())
 grid=np.flipud(np.asarray(Image.open(folder/'fused_slam_map.pgm')))
 yy,xx=np.where(grid==0);ox,oy,angle=config['origin'];r=config['resolution']
 x=(xx+.5)*r;y=(yy+.5)*r
 wx=ox+np.cos(angle)*x-np.sin(angle)*y;wy=oy+np.sin(angle)*x+np.cos(angle)*y
 ix=np.floor((wx-truth['origin'][0])/truth['resolution']).astype(int)
 iy=np.floor((wy-truth['origin'][1])/truth['resolution']).astype(int)
 valid=(ix>=0)&(iy>=0)&(ix<truth['width'])&(iy<truth['height'])
 distances=np.full(len(xx),np.inf);distances[valid]=distance[iy[valid],ix[valid]]
 agreement=float(np.mean(distances<=.25)) if len(xx) else 0
 # This is a registration smoke gate, not a complete map accuracy metric.
 result={'passed':len(xx)>=20 and agreement>=.8,'occupied_samples':len(xx),
  'within_0p25m_fraction':agreement,'median_surface_error_m':float(np.median(distances)) if len(xx) else None,
  'scope':'observed occupied surface agreement only; not full SLAM accuracy proof',
  'world_id':m['world_id'],'run_dir':str(folder),'truth_version':json.loads((adapter/'truth_audit.json').read_text())['truth_sha256']}
 (folder/'alignment_audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
 return result

if __name__=='__main__':raise SystemExit(0 if audit(Path(sys.argv[1]))['passed'] else 1)
