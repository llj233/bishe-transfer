#!/usr/bin/env python3
"""Derive five-second task telemetry and per-candidate decisions from raw logs."""
import csv,json,math,sys
from pathlib import Path
from summarize_run import lines,load

def export(folder):
 physics=lines(folder/'physical_audit.jsonl')
 ev=list(csv.DictReader((folder/'evaluation.csv').open())) if (folder/'evaluation.csv').exists() else []
 decisions=lines(folder/'decisions.jsonl');events=lines(folder/'mission_events.jsonl')
 progress={r['goal_id']:r for r in lines(folder/'online_progress.jsonl')}
 updates=list(csv.DictReader((folder/'slam_map_updates.csv').open())) if (folder/'slam_map_updates.csv').exists() else []
 selected={e['goal_id']:e for e in events if e.get('event')=='goal_assigned'}
 results={e['goal_id']:e for e in events if e.get('event')=='goal_result'}
 with (folder/'decision_candidates.csv').open('w',newline='') as f:
  keys=['sim_time','replan_reason','robot','current_x','current_y','frontier_cells','frontier_clusters','proposals','reachable_candidates','candidate_cluster','candidate_id','region','predicted_new_cells','path_m','clearance_m','target_clearance_risk_proxy','final_score','selected','navigation_result','goal_duration_s','online_new_known_cells','planning_wall_s']
  writer=csv.DictWriter(f,fieldnames=keys);writer.writeheader()
  for decision in decisions:
   for c in decision['candidates']:
    stat=decision['stats'].get(c['robot'],{});robot=decision.get('robots',{}).get(c['robot'],{}).get('pose',{})
    goal=selected.get(c['candidate_id']);result=results.get(c['candidate_id']);feedback=progress.get(c['candidate_id'],{})
    row={'sim_time':decision['sim_time'],'replan_reason':decision.get('replan_reason','not_recorded_in_earlier_revision'),'robot':c['robot'],'current_x':robot.get('x'),'current_y':robot.get('y'),
     'frontier_cells':stat.get('frontier_cells'),'frontier_clusters':stat.get('frontier_clusters'),'proposals':stat.get('proposals'),
     'reachable_candidates':stat.get('reachable_candidates'),'candidate_cluster':stat.get('candidate_clusters',{}).get(c['candidate_id']),
     'candidate_id':c['candidate_id'],'region':c['region_id'],'predicted_new_cells':c['predicted_new_cells'],
     'path_m':c['path_m'],'clearance_m':c['clearance_m'],'target_clearance_risk_proxy':.1/max(c['clearance_m'],.1),'final_score':c['score'],
     'selected':bool(goal),'navigation_result':result.get('result') if result else None,
     'goal_duration_s':feedback.get('duration_s'),'online_new_known_cells':feedback.get('online_new_known_cells'),
     'planning_wall_s':decision['planning_wall_s']}
    writer.writerow(row)
 with (folder/'telemetry_5s.csv').open('w',newline='') as f:
  keys=['sim_time','coverage_pct','roi_known_pct','roi_known_m2','physical_path_m','reentered_cell_path_m_0p25','stopped_translation_s','rtf_since_first_physics_sample','last_planning_wall_s','slam_map_header_age_s']
  writer=csv.DictWriter(f,fieldnames=keys);writer.writeheader()
  distance=repeat=stopped=0.;previous=None;visited=set();last_cell=None;repeated=False;last_t=-1e9
  ei=di=ui=0
  for r in physics:
   cell=(math.floor(r['x']/.25),math.floor(r['y']/.25))
   if cell!=last_cell:repeated=cell in visited;visited.add(cell);last_cell=cell
   if previous:
    d=math.hypot(r['x']-previous['x'],r['y']-previous['y']);dt=r['sim_time']-previous['sim_time']
    distance+=d;repeat+=d if repeated else 0
    if dt>0 and d/dt<.01:stopped+=dt
   previous=r
   t=r['sim_time']
   if t-last_t<5:continue
   while ei+1<len(ev) and float(ev[ei+1]['sim_time'])<=t:ei+=1
   while di+1<len(decisions) and decisions[di+1]['sim_time']<=t:di+=1
   while ui+1<len(updates) and float(updates[ui+1]['sim_time'])<=t:ui+=1
   e=ev[ei] if ev and float(ev[ei]['sim_time'])<=t else {}
   wall=r.get('wall_epoch_s');start_wall=physics[0].get('wall_epoch_s')
   rtf=(t-physics[0]['sim_time'])/(wall-start_wall) if wall and start_wall and wall>start_wall else None
   writer.writerow({'sim_time':t,'coverage_pct':e.get('exploration_pct'),'roi_known_pct':e.get('roi_known_pct'),
    'roi_known_m2':int(e['roi_known_cells'])*.01 if e else None,'physical_path_m':distance,
    'reentered_cell_path_m_0p25':repeat,'stopped_translation_s':stopped,'rtf_since_first_physics_sample':rtf,
    'last_planning_wall_s':decisions[di]['planning_wall_s'] if decisions and decisions[di]['sim_time']<=t else None,
    'slam_map_header_age_s':t-float(updates[ui]['map_header_stamp']) if updates and float(updates[ui]['sim_time'])<=t else None})
   last_t=t
 return folder/'telemetry_5s.csv'

if __name__=='__main__':print(export(Path(sys.argv[1])))
