#!/usr/bin/env python3
"""Read-only raw/cloud/fused input monitor; never publishes sensor/control data."""
import os,sys,json,time,argparse,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--campaign',type=Path);p.add_argument('--index',type=int);p.add_argument('--run-dir',type=Path);p.add_argument('--child',action='store_true');a=p.parse_args();folder=a.run_dir
 if not a.child:
  deadline=time.monotonic()+90
  while folder is None and time.monotonic()<deadline:
   log=a.campaign/f'job_{a.index:03d}.log'
   if log.exists():folder=next((Path(s[8:]) for s in log.read_text().splitlines() if s.startswith('run_dir=')),None)
   if folder is None:time.sleep(.3)
  if folder is None:raise RuntimeError('Observer: no run directory')
  while not (folder/'environment.json').exists() and time.monotonic()<deadline:time.sleep(.3)
  env=os.environ.copy();env.update(json.loads((folder/'environment.json').read_text()));vendor=ROOT/'vendor/root/opt/ros/humble'
  env['AMENT_PREFIX_PATH']=str(vendor)+':'+env.get('AMENT_PREFIX_PATH','');env['LD_LIBRARY_PATH']=str(vendor/'lib')+':'+str(vendor/'lib/x86_64-linux-gnu')+':'+env.get('LD_LIBRARY_PATH','')
  return subprocess.call([sys.executable,__file__,'--run-dir',str(folder),'--child'],env=env)
 import rclpy,numpy as np
 from rclpy.node import Node
 from rclpy.parameter import Parameter
 from rclpy.qos import qos_profile_sensor_data
 from sensor_msgs.msg import LaserScan,PointCloud2
 from collections import deque
 from active_slam_v4.near_ground_node import xyz_array
 rclpy.init();node=Node('boot_input_observer',parameter_overrides=[Parameter('use_sim_time',value=True)])
 counts={'raw':0,'cloud':0,'fused':0};stamps={k:deque(maxlen=8) for k in counts};frames={};details={}
 def remember(key,msg):
  counts[key]+=1;stamps[key].append(msg.header.stamp.sec+msg.header.stamp.nanosec/1e9);frames[key]=msg.header.frame_id
  if key=='raw':details['raw_valid_fraction']=sum(not np.isnan(v) and v>=msg.range_min for v in msg.ranges)/max(1,len(msg.ranges))
  if key=='cloud':
   try:details['cloud_finite_points']=int(np.isfinite(xyz_array(msg)).all(axis=1).sum())
   except Exception as exc:details['cloud_parse_error']=str(exc)
 subs=[node.create_subscription(LaserScan,'/robot1/scan_raw',lambda m:remember('raw',m),qos_profile_sensor_data),node.create_subscription(PointCloud2,'/robot1/near_ground_points',lambda m:remember('cloud',m),qos_profile_sensor_data),node.create_subscription(LaserScan,'/robot1/scan',lambda m:remember('fused',m),qos_profile_sensor_data)]
 stream=(folder/'boot_input_observer.jsonl').open('x');last_wall=-1e9
 try:
  while not (folder/'process_exit.json').exists():
   rclpy.spin_once(node,timeout_sec=.2)
   if time.monotonic()-last_wall>=2.:
    last_wall=time.monotonic();gap=min((abs(a-b) for a in stamps['raw'] for b in stamps['cloud']),default=None)
    stream.write(json.dumps({'sim_time':node.get_clock().now().nanoseconds/1e9,'counts':counts,'frames':frames,'latest_stamps':{k:v[-1] if v else None for k,v in stamps.items()},'nearest_recent_raw_cloud_gap_s':gap,'configured_sync_slop_s':.08,'details':details,'observer_only_not_proof_of_projection_node_reception':True})+'\n');stream.flush()
 finally:stream.close();node.destroy_node();rclpy.shutdown()
 return 0
if __name__=='__main__':raise SystemExit(main())
