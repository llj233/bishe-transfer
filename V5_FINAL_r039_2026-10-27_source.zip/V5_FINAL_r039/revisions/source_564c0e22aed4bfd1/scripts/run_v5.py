#!/usr/bin/env python3
"""One isolated, supervised V5 run; each attempt is immutable."""
import sys
import argparse,datetime,hashlib,json,os,shutil,subprocess,time,uuid,signal
import xml.etree.ElementTree as ET
from pathlib import Path
from world_adapter import ROOT,WORLDS,environment
from run_test import make_configs
from source_freeze import snapshot,hashes
from experiment_scope import require_allowed
from active_slam_v4.process_profile import ProcessProfiler

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def add_contact_sensors(tree):
 for name,collision in [('base_link','base_collision'),('wheel_left_link','wheel_left_collision'),
                        ('wheel_right_link','wheel_right_collision'),
                        ('caster_back_left_link','collision'),('caster_back_right_link','collision')]:
  link=tree.find(f'.//link[@name="{name}"]')
  sensor=ET.SubElement(link,'sensor',{'name':'v5_contact_'+name,'type':'contact'})
  ET.SubElement(sensor,'always_on').text='true';ET.SubElement(sensor,'update_rate').text='20'
  ET.SubElement(ET.SubElement(sensor,'contact'),'collision').text=collision
  plug=ET.SubElement(sensor,'plugin',{'name':'v5_contact_ros_'+name,'filename':'libgazebo_ros_bumper.so'})
  ros=ET.SubElement(plug,'ros');ET.SubElement(ros,'namespace').text='/v5_audit'
  ET.SubElement(ros,'remapping').text='bumper_states:=/v5/contacts/'+name
  ET.SubElement(plug,'frame_name').text='world'

def main():
 p=argparse.ArgumentParser()
 p.add_argument('--world-id',choices=['N01','N02','N03','N04','N05','N06'],required=True)
 p.add_argument('--spawn-id',choices=['S01','S02'],default='S01')
 p.add_argument('--run-seed',type=int,default=11)
 p.add_argument('--method',choices=['B0','B1','B2','B2_FOOTPRINT','B2_FEEDBACK'],default='B2')
 p.add_argument('--execution-policy',choices=['legacy','context','fast','event_fast'],default='context')
 p.add_argument('--split',choices=['smoke','development','validation','formal'],default='smoke')
 p.add_argument('--gui',choices=['false'],default='false')
 p.add_argument('--max-sim-seconds',type=float)
 p.add_argument('--wait',action='store_true')
 p.add_argument('--no-physics-audit',action='store_true',help='Infrastructure diagnosis only; not a formal run')
 p.add_argument('--contact-sensors',action='store_true')
 p.add_argument('--disable-self-ray-mask',action='store_true',help='Diagnostic control only')
 args=p.parse_args()
 try:require_allowed([args.world_id])
 except ValueError as error:p.error(str(error))
 w=WORLDS[args.world_id];a=w.directory
 audit=json.loads((a/'truth_audit.json').read_text())
 if args.split=='formal' and not audit['formal_eligible']:p.error('Map not approved by truth/geometry audit')
 if args.split=='formal' and args.no_physics_audit:p.error('Formal runs require physical audit')
 if args.split=='formal' and not args.contact_sensors:p.error('Formal runs require validated contact sensors')
 if args.split=='formal':
  if args.disable_self_ray_mask:p.error('Formal groups require the common verified simulation correction')
  frozen=json.loads((ROOT/'protocol/FORMAL_FREEZE.json').read_text())
  if frozen['source_sha256']!=hashes():p.error('Algorithm source changed after formal freeze')
  contact_gate=json.loads((ROOT/'regressions/PHYSICAL_CONTACT_GATE.json').read_text())
  if not contact_gate['passed'] or contact_gate['mask_binary_sha256']!=sha(ROOT/'install/gazebo_scene_audit/lib/libv5_self_ray_mask.so'):p.error('Physical collision regression gate missing or binary changed')
 budget=float(args.max_sim_seconds or audit['budget_sim_s'])
 if args.split=='formal' and budget!=audit['budget_sim_s']:p.error('Formal budget must match preregistration')
 uid=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8]
 folder=ROOT/'experiments'/'event_pipeline_2026-10-26'/args.split/args.execution_policy/args.world_id/args.spawn_id/f'seed_{args.run_seed}'/args.method/uid
 folder.mkdir(parents=True,exist_ok=False)
 for src,name in [(a/'world.sdf','world.sdf'),(a/'truth.npz','truth.npz'),(a/'truth_audit.json','truth_audit.json'),(a/'manifest.json','world_manifest.json')]:shutil.copy2(src,folder/name)
 make_configs('robot1',folder,extended_return_search=args.execution_policy=='event_fast')
 source_id,source_hashes=snapshot()
 if not args.disable_self_ray_mask:
  tree=ET.parse(folder/'robot1.sdf')
  ET.SubElement(tree.find('model'),'plugin',{'name':'v5_single_self_ray_mask',
    'filename':str(ROOT/'install/gazebo_scene_audit/lib/libv5_self_ray_mask.so')})
  tree.write(folder/'robot1.sdf',encoding='unicode')
 if args.contact_sensors:
  tree=ET.parse(folder/'robot1.sdf')
  add_contact_sensors(tree)
  tree.write(folder/'robot1.sdf',encoding='unicode')
 manifest={'version':'V5_single_r039_events_2026-10-26','execution_policy':args.execution_policy,'world_id':args.world_id,'spawn_id':args.spawn_id,
  'run_seed':args.run_seed,'policy_seed':args.run_seed,'gazebo_seed':args.run_seed,'method':args.method,
  'split':args.split,'mode':'single','max_sim_seconds':budget,'gui':args.gui,
  'deployment':{'robot1':audit['spawns'][args.spawn_id]},
  'deployment_z_m':float(audit.get('floor_z',0.0))+.01,
  'deployment_z_source':'audited fixed world floor datum + nominal robot mounting clearance; no online truth-map control',
  'truth_npz':str(folder/'truth.npz'),
  'truth_sha256':sha(folder/'truth.npz'),'world_sha256':sha(folder/'world.sdf'),
  'termination':'ground-truth-assisted; no truth in target selection',
  'source_sha256':{str(q.relative_to(ROOT)):sha(q) for q in (ROOT/'src').rglob('*') if q.is_file() and q.suffix in ('.py','.cpp','.xml')},
  'nav_config_sha256':sha(folder/'robot1_nav2.yaml'),'slam_config_sha256':sha(folder/'robot1_slam.yaml')}
 manifest['experiment_cohort']='event_pipeline_2026-10-26'
 manifest['display_condition']='headless_no_gzclient_or_rviz'
 manifest['operational_launcher_sha256']=sha(Path(__file__))
 manifest['support_collision_names']=sorted({x['collision'] for x in json.loads((a/'floor_audit.json').read_text())['samples'] if x.get('collision')})
 manifest['odometry_profile']='ideal_Gazebo_WORLD_with_scan_matching_prior'
 manifest['slam_prior_disclosure']='Scan matching remains enabled; correction prior tightened for ideal simulator odometry; not a real-odometry generalization claim'
 manifest['perception_profile']='primary_2d_plus_17_layer_with_measured_dropoff_constraints_v3'
 manifest['negative_obstacle_projection']={'minimum_drop_m':.03,'maximum_hit_radius_m':1.5,'unresolved_lip_margin_m':.15,'semantics':'inferred traversability hazard projected into scan; not a directly measured vertical wall'}
 manifest['contact_storage_policy']='all_presence_and_nonfloor_geometry_at_sensor_rate; ordinary_floor_geometry_2Hz'
 manifest['sensor_change_disclosure']='Adds measured multi-layer lidar for low obstacles; requires suitable 3D/depth hardware on a real robot; no truth-map control input'
 manifest['physics_audit_enabled']=not args.no_physics_audit
 manifest['contact_sensors_enabled']=args.contact_sensors
 manifest['contact_sensor_links']=['base_link','wheel_left_link','wheel_right_link','caster_back_left_link','caster_back_right_link'] if args.contact_sensors else []
 manifest['self_ray_mask_enabled']=not args.disable_self_ray_mask
 manifest['audit_binary_sha256']=sha(ROOT/'install/gazebo_scene_audit/lib/libv5_audit.so')
 manifest['self_ray_mask_binary_sha256']=sha(ROOT/'install/gazebo_scene_audit/lib/libv5_self_ray_mask.so') if not args.disable_self_ray_mask else None
 manifest['robot_model_sha256']=sha(folder/'robot1.sdf')
 manifest['source_snapshot_id']=source_id
 (folder/'manifest.json').write_text(json.dumps(manifest,indent=2))
 env=environment();vendor=ROOT/'vendor/root/opt/ros/humble'
 env['RMW_IMPLEMENTATION']='rmw_cyclonedds_cpp'
 env['AMENT_PREFIX_PATH']=str(vendor)+':'+env.get('AMENT_PREFIX_PATH','')
 env['LD_LIBRARY_PATH']=str(vendor/'lib')+':'+str(vendor/'lib/x86_64-linux-gnu')+':'+env.get('LD_LIBRARY_PATH','')
 env['ROS_DOMAIN_ID']=str(30+int(uuid.uuid4().hex[:3],16)%160)
 env['GAZEBO_MASTER_URI']='http://127.0.0.1:'+str(13000+int(uuid.uuid4().hex[:4],16)%15000)
 env['IGN_PARTITION']='r039_'+uid
 env['GZ_PARTITION']=env['IGN_PARTITION']
 env['DISPLAY']=env.get('DISPLAY') or ':0'
 auth=sorted(Path(f'/run/user/{os.getuid()}').glob('.mutter-Xwaylandauth.*'),key=lambda q:q.stat().st_mtime)
 if auth:env['XAUTHORITY']=str(auth[-1])
 env['QT_X11_NO_MITSHM']='1';env['ROS_LOG_DIR']=str(folder/'ros_logs')
 env['V5_PHYSICS_AUDIT']=str(folder/'physical_audit.jsonl')
 if args.no_physics_audit:env.pop('V5_PHYSICS_AUDIT',None)
 env.pop('V5_TRUTH_OUTPUT',None)
 env.pop('V5_FLOOR_PROBES',None)
 env['V5_FLOOR_Z']=str(audit.get('floor_z',0.0))
 env.pop('V5_LEGACY_CONTACT_DIAG',None)
 if args.split=='formal':env.pop('V5_RAY_DIAGNOSTIC',None)
 cmd=['ros2','launch','active_slam_v4','v4_test.launch.py',f'run_dir:={folder}',f'world:={folder/"world.sdf"}',
      'mode:=single',f'gui:={args.gui}',f'max_sim_seconds:={budget}',f'map_seed:={args.run_seed}',f'policy_seed:={args.run_seed}']
 with (folder/'launch.log').open('x') as log:
  proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (folder/'launch.pid').write_text(str(proc.pid));(folder/'environment.json').write_text(json.dumps({k:env.get(k) for k in ['IGN_PARTITION','GZ_PARTITION','DISPLAY','XAUTHORITY','ROS_DOMAIN_ID','GAZEBO_MASTER_URI','GAZEBO_MODEL_PATH','GAZEBO_RESOURCE_PATH','RMW_IMPLEMENTATION']},indent=2))
 print('run_dir='+str(folder),flush=True)
 if args.wait:
  start=time.monotonic();reason='process_exit'
  profiler=ProcessProfiler(proc.pid,folder)
  try:
   while proc.poll() is None:
    profiler.sample()
    # Infrastructure watchdog: record separately; never fabricate algorithm success.
    if time.monotonic()-start>max(600,budget*5):reason='wall_watchdog';os.killpg(proc.pid,signal.SIGINT);break
    time.sleep(1)
   try:code=proc.wait(30)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
  finally:
   profiler.close()
   (folder/'process_exit.json').write_text(json.dumps({'reason':reason,'returncode':proc.poll(),'wall_s':time.monotonic()-start},indent=2))
  subprocess.run(['python3',str(ROOT/'scripts/summarize_run.py'),str(folder)],check=False)
  subprocess.run(['python3',str(ROOT/'scripts/export_telemetry.py'),str(folder)],check=False)
  return code
 return 0

if __name__=='__main__':raise SystemExit(main())
