#!/usr/bin/env python3
"""Fixed independent compact-world campaign: 3 interface checks + 36 paired runs."""
from pathlib import Path
import sys,json,hashlib,datetime,traceback,csv
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'visualization_tools'))
import isolated_queue_runner as wrapper
from queue_runner import write
from source_freeze import hashes,snapshot
from experiment_scope import require_allowed
C=ROOT/'campaigns/V5_r028_compact_2026-10-22'
MAPS=['M01','M02','M04']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def report(results,status):
 write(C/'COMPLETED.json',results)
 cols=['world_id','spawn_id','run_seed','method','split','source_snapshot_id','status','failure','joint_success','final_exploration_pct','final_roi_pct','explored_free_m2','reachable_free_m2','T90_sim_s','T95_sim_s','task_sim_s','physical_home_error_m','physical_path_m','navigation_failures','environment_contact_episodes','run_dir']
 with (ROOT/'reports/紧凑地图实验结果.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows(results)
 smokes=[r for r in results if r['split']=='smoke'];formal=[r for r in results if r['split']=='formal']
 text=f'# V5 r028 紧凑有界地图实验\n\n状态：{status}\n\n接口验收 {len(smokes)}/3；正式完成 {len(formal)}/36；联合成功 {sum(bool(r["joint_success"]) for r in formal)}。\n\n'
 text+='医院和Willow已排除。三个独立布局：M01 TurtleBot3 World、M02 TurtleBot3 House封闭衍生版、M04 AWS Bookstore。新批次不与旧结果混算，不宣称这些地图从未用于开发。\n\n'
 text+='每张图2个固定安全出生点×2个配对种子(11/29)×3种方法(B0/B1/B2)，共36次，顺序由20261022固定。种子不改变地图几何；跨地图泛化由三个不同布局检验，不称为36张随机地图。B2同时包含反馈与足迹检查，因此B1/B2差异不能单独归因于记忆。\n\n'
 text+='成功条件：可达空闲格探索率>95%，固定ROI已知率>90%，实际返航误差≤0.35m。ROI保持原审计定义（可达空闲格及相邻膨胀障碍边界），不等同整个外接矩形面积。WORLD理想里程计、真值辅助停止、有限高度栅格审计的限制保留。\n\n'
 text+='60秒接口检查只确认地图/导航/物理审计与对齐，不要求达成全图探索，超时不计正式成功率。正式算法失败保留并继续；基础设施或数据有效性问题停止，不补种子、不在线调参。传感器、SLAM/Nav2和探索算法与父版本保持一致，单次预算M01 900s、M02/M04 1800s，包含返航。\n\n'
 text+='每次独立保存原始地图PGM/YAML、统一配色8倍PNG、覆盖曲线、面积/时间/返航/接触与导航记录。\n'
 (ROOT/'reports/本批进度.md').write_text(text)
def validate_resources():
 lock=json.loads((ROOT/'protocol/ASSET_LOCK.json').read_text())
 for name,h in lock['sha256'].items():
  if sha(ROOT/name)!=h:raise RuntimeError('Resource mismatch: '+name)
 wrapper.require_display_gate()
def freeze(jobs):
 worlds={}
 for wid in MAPS:
  a=ROOT/'world_adapters'/wid;i=json.loads((a/'interface_audit.json').read_text());g=json.loads((a/'geometry_checklist.json').read_text());truth=json.loads((a/'truth_audit.json').read_text())
  if not i['passed'] or not g['automated_passed'] or not g['visual_review_passed'] or truth['component_touches_edge']:raise RuntimeError('Map not approved '+wid)
  truth.update(formal_eligible=True,reason='Compact map scope and current navigation/alignment/contact/envelope smoke passed; inherited unchanged geometry audit disclosed');write(a/'truth_audit.json',truth)
  worlds[wid]={'truth_sha256':sha(a/'truth.npz'),'world_sha256':sha(a/'world.sdf'),'spawns':truth['spawns'],'budget_sim_s':truth['budget_sim_s'],'interface_run':i['run_dir']}
 ident,source=snapshot();doc={'status':'frozen_before_compact_formal36','source_snapshot_id':ident,'source_sha256':source,'worlds':worlds,'formal_attempt_limit':36,'excluded_world_ids':['M05','M06'],'queue_sha256':sha(ROOT/'protocol/COMPACT_FORMAL_36.json'),'targets':{'free_pct_strict':95,'roi_pct_strict':90,'physical_home_error_m_max':.35},'approved_by_user':'给我找一些地图没那么大但是地图边界明确的图然后重新开始实验','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'historical_results':'Separate campaign and scope; preserve all old outcomes'};write(ROOT/'protocol/FORMAL_FREEZE.json',doc);return ident

def main():
 C.mkdir(exist_ok=False);results=[]
 try:
  jobs=json.loads((ROOT/'protocol/COMPACT_FORMAL_36.json').read_text());require_allowed(j['world_id'] for j in jobs)
  if len(jobs)!=36 or {j['world_id'] for j in jobs}!=set(MAPS):raise RuntimeError('Incorrect compact queue')
  smokes=[{'world_id':w,'spawn_id':'S01','run_seed':11,'method':'B2','split':'smoke','budget':60,'alignment_gate':True} for w in MAPS]
  write(C/'QUEUE.json',{'approved_for_execution':True,'formal_attempt_limit':36,'jobs':smokes+jobs,'excluded_world_ids':['M05','M06']});write(C/'CURRENT.json',{'status':'validating_resources'});report(results,'检查固定资源')
  validate_resources()
  for index,job in enumerate(smokes):
   result=wrapper.isolated_run_job(job,C,index);results.append(result);report(results,'接口验收')
   if result.get('_acceptance_error'):raise RuntimeError(result['_acceptance_error'])
  ident=freeze(jobs);write(C/'FORMAL_START.json',{'source_snapshot_id':ident,'authorized_count':36,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
  for index,job in enumerate(jobs,start=3):
   if hashes()!=json.loads((ROOT/'protocol/FORMAL_FREEZE.json').read_text())['source_sha256']:raise RuntimeError('Frozen source changed')
   result=wrapper.isolated_run_job(job,C,index);results.append(result);report(results,'正式实验')
   if not result.get('contact_sensors_verified') or not result.get('physical_return_pose_verified') or result.get('status')=='NO_RESULT' or result.get('failure')=='runtime_error' or result.get('process_exit',{}).get('reason')=='wall_watchdog':raise RuntimeError('Infrastructure/validity failure: retained, no automatic replacement')
  write(C/'CURRENT.json',{'status':'complete','formal_completed':36,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});report(results,'全部结束')
 except Exception as exc:
  write(C/'CURRENT.json',{'status':'needs_diagnosis','completed':len(results),'error':str(exc),'preserve_all_data':True});report(results,'停止待诊断');(C/'DIAGNOSIS_REQUIRED.md').write_text(traceback.format_exc());raise
if __name__=='__main__':main()
