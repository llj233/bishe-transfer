#!/usr/bin/env python3
"""Authorized finite batch: interface gates, freeze, exactly45 non-Hospital runs."""
from pathlib import Path
import os,sys,json,time,hashlib,datetime,traceback,shutil
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'visualization_tools'))
import isolated_queue_runner as wrapper
from queue_runner import write,run_job
from world_adapter import WORLDS
from source_freeze import snapshot,hashes
from experiment_scope import require_allowed
C=ROOT/'campaigns/V5_r027_formal_2026-10-22_assets_ready'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def report(results,status):
 write(C/'COMPLETED.json',results)
 import csv
 columns=['world_id','spawn_id','run_seed','method','split','source_snapshot_id','status','failure','joint_success','final_exploration_pct','final_roi_pct','T90_sim_s','T95_sim_s','task_sim_s','physical_home_error_m','physical_path_m','navigation_failures','environment_contact_episodes','run_dir']
 with (ROOT/'reports/正式实验与接口检查结果.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');w.writeheader();w.writerows(results)
 formal=[r for r in results if r['split']=='formal'];smokes=[r for r in results if r['split']=='smoke']
 text='# V5 非医院45次独立批次\n\n状态：'+status+'\n\n'+f'接口检查完成 {len(smokes)}/5；正式实验完成 {len(formal)}/45，联合成功 {sum(bool(r["joint_success"]) for r in formal)}。\n\n'
 text+='医院M05已排除；原r003的20次历史结果不与本批混合。保持原队列顺序、方法、出生点、种子和预算；算法失败保留并继续，基础设施/有效性错误停止。批次内不改模型、不补跑、不筛除失败。\n\n目标：探索>95%、ROI>90%、实际返航误差<=0.35m。真值仅用于评估与结束判据，仿真WORLD里程计限制保留。\n\n当前算法是主动探索启发式与Nav2组合，没有新增强化学习训练。统一保存8倍预览及原始地图。\n'
 (ROOT/'reports/本批进度.md').write_text(text)

def freeze(jobs):
 worlds={}
 for wid in sorted({j['world_id'] for j in jobs}):
  a=ROOT/'world_adapters'/wid;g=json.loads((a/'geometry_checklist.json').read_text());i=json.loads((a/'interface_audit.json').read_text());truth=json.loads((a/'truth_audit.json').read_text())
  if not g['automated_passed'] or not g.get('visual_review_passed') or not i['passed']:raise RuntimeError('Map gate failed '+wid)
  truth.update(formal_eligible=True,reason='Current fixed source passed measured-map alignment, navigation, contacts and physical envelope checks; geometry arrays unchanged')
  write(a/'truth_audit.json',truth)
  worlds[wid]={'truth_sha256':sha(a/'truth.npz'),'world_sha256':sha(a/'world.sdf'),'spawns':truth['spawns'],'budget_sim_s':truth['budget_sim_s'],'interface_run':i['run_dir']}
 ident,source=snapshot()
 doc={'status':'frozen_before_authorized_formal45','source_snapshot_id':ident,'source_sha256':source,'worlds':worlds,'methods':['B0','B1','B2'],'excluded_world_ids':['M05'],'formal_attempt_limit':45,'approved_by_user':'开始实验吧','approved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'queue_sha256':sha(ROOT/'protocol/AUTHORIZED_FORMAL_45.json'),'targets':{'free_pct_strict':95,'roi_pct_strict':90,'physical_home_error_m_max':.35},'failure_policy':'Retain all algorithm failures, no additional replacement launches, stop on infrastructure/validity faults','historical_comparison':'Separate source/version from r003 formal20; do not pool success rates'}
 write(ROOT/'protocol/FORMAL_FREEZE.json',doc);return ident

def main():
 results=[];C.mkdir(exist_ok=True)
 jobs=json.loads((ROOT/'protocol/AUTHORIZED_FORMAL_45.json').read_text());require_allowed(j['world_id'] for j in jobs)
 if len(jobs)!=45:raise RuntimeError('Authorized batch must contain exactly45 runs')
 if (C/'COMPLETED.json').exists():raise RuntimeError('Existing batch results: refusing duplicate launches')
 smokes=[{'world_id':w,'spawn_id':'S01','run_seed':11,'method':'B2','split':'smoke','budget':60,'alignment_gate':True} for w in ['M01','M02','M03','M04','M06']]
 write(C/'QUEUE.json',{'approved_for_execution':True,'formal_attempt_limit':45,'jobs':smokes+jobs,'phases':['interface5','formal45'],'hospital_excluded':True})
 try:
  # Cache archival is infrastructure only and must finish before formal timing.
  end=time.monotonic()+1200
  indices=[ROOT.parent/'V5_cache_archives_2026-10-22'/f'V5_single_r{n:03d}_2026-10-21_INDEX.json' for n in range(4,25)]
  while not all(p.exists() for p in indices):
   write(C/'CURRENT.json',{'status':'preparing_storage','completed':0,'archives_complete':sum(p.exists() for p in indices),'archives_total':len(indices)})
   if time.monotonic()>end:raise RuntimeError('Verified cache archival did not finish within20min')
   time.sleep(2)
  wrapper.require_display_gate()
  for index,job in enumerate(smokes):
   wid=job['world_id']
   result=wrapper.isolated_run_job(job,C,index)
   results.append(result);report(results,'接口验收')
   if result.get('_acceptance_error'):raise RuntimeError(result['_acceptance_error'])
  ident=freeze(jobs);write(C/'FORMAL_START.json',{'source_snapshot_id':ident,'authorized_count':45,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
  for number,job in enumerate(jobs):
   if hashes()!=json.loads((ROOT/'protocol/FORMAL_FREEZE.json').read_text())['source_sha256']:raise RuntimeError('Source changed during formal batch')
   result=wrapper.isolated_run_job(job,C,number+len(smokes));results.append(result);report(results,'正式实验')
   # A failed navigation is a valid outcome; missing telemetry is infrastructure.
   if not result.get('contact_sensors_verified') or not result.get('physical_return_pose_verified') or result.get('status')=='NO_RESULT' or result.get('failure')=='runtime_error' or result.get('process_exit',{}).get('reason')=='wall_watchdog':raise RuntimeError('Formal infrastructure/validity fault; attempt retained, no automatic replacement')
  write(C/'CURRENT.json',{'status':'complete','completed':len(results),'formal_completed':45,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});report(results,'全部结束')
 except Exception as exc:
  write(C/'CURRENT.json',{'status':'needs_diagnosis','completed':len(results),'formal_completed':sum(r['split']=='formal' for r in results),'error':str(exc),'preserve_all_data':True});report(results,'停止待诊断');(C/'DIAGNOSIS_REQUIRED.md').write_text(str(exc)+'\n'+traceback.format_exc());raise
if __name__=='__main__':main()
