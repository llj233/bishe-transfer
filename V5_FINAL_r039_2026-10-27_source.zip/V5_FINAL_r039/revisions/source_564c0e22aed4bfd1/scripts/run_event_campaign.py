#!/usr/bin/env python3
"""Bounded development search; never hides failures or promotes partial gates."""
import sys
import os,json,csv,hashlib,fcntl,statistics,datetime,traceback
from pathlib import Path
from source_freeze import ROOT,snapshot,hashes
import headless_runner as runner
C=ROOT/'campaigns/event_pipeline_2026-10-26';C.mkdir(parents=True,exist_ok=True);runner.C=C
class InfrastructureBlocked(RuntimeError):pass

def write(path,data):runner.write(path,data)
def safe(row):return row['joint_success'] and row.get('contact_sensors_verified') and row.get('environment_contact_episodes')==0

def export(rows,outcomes):
 write(C/'COMPLETED.json',rows);write(C/'PROFILE_OUTCOMES.json',outcomes)
 fields=['experiment_cohort','gui','profile','stage','case_id','case_attempt','world_id','execution_policy','run_seed','joint_success','status','failure','T95_sim_s','final_exploration_pct','final_roi_pct','physical_home_error_m','environment_contact_episodes','physical_path_m','planning_result_wait_sim_s','between_goals_idle_sim_s','between_goal_count','reverse_samples_1Hz','stop_samples_1Hz','run_dir','map_png']
 with (ROOT/'reports/event_pipeline_2026-10-26/持续优化逐次结果.csv').open('w',encoding='utf-8-sig',newline='') as out:
  w=csv.DictWriter(out,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
 lines=['# r039事件决策优化进度','',f'已记录{len(rows)}次实际尝试；所有失败和启动重启单独保留。','']
 for name,data in outcomes.items():lines.append(f"- {name}: {data['status']}，{data.get('reason','')}。")
 for r in rows:lines.append(f"- {r['profile']} / {r['stage']} / {r['world_id']} / {r['execution_policy']} / seed{r['run_seed']}: {r['status']}, T95={r.get('T95_sim_s')}s, home={r.get('physical_home_error_m')}m, contacts={r.get('environment_contact_episodes')}。")
 (ROOT/'reports/event_pipeline_2026-10-26/当前优化进度.md').write_text('\n'.join(lines)+'\n')

def main():
 lock=(C/'QUEUE.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 if (C/'STARTED.json').exists():raise RuntimeError('Already attempted; never overwrite search history')
 p=runner.load(ROOT/'protocol/HEADLESS_PROTOCOL.json');ident,frozen=snapshot();write(ROOT/'protocol/HEADLESS_SEARCH_FREEZE.json',{'source_snapshot_id':ident,'sha256':frozen,'protocol':p,'headless_operations_sha256':runner.operations_hashes()});write(C/'STARTED.json',{'pid':os.getpid(),'source_snapshot_id':ident,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 write(ROOT.parent/'V5_ACTIVE_CAMPAIGN.json',{'workspace':str(ROOT),'campaign':str(C),'version':'r039','stage':'event-driven serialized decisions; A/A diagnosis then fresh headless paired gates; retained r032 unchanged','source_snapshot_id':ident})
 rows=[];outcomes={};index=0
 def run(profile,wid,arm,seed,stage):
  nonlocal index
  case_id=f'{profile}_{stage}_{wid}_{arm}_{seed}'
  for attempt in range(2):
   assert hashes()==frozen,'Frozen search implementation changed'
   runner.verify_operations()
   for rel,digest in runner.load(ROOT/'protocol/ASSET_LOCK.json').items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest,rel
   index+=1
   row=runner.run_job({'world_id':wid,'execution_policy':arm,'run_seed':seed,'split':'development'},index,stage,ident)
   row.update(profile=profile,case_id=case_id,case_attempt=attempt+1);rows.append(row);export(rows,outcomes)
   invalid_boot=(row.get('failure')=='startup_failure' or (row.get('failure')=='runtime_error' and row.get('task_sim_s') is not None and row['task_sim_s']<=1.)) and row.get('final_exploration_pct') is None
   if invalid_boot and attempt==0:
    write(C/f'BOOT_RESTART_{index:03d}.json',{'failed_run':row['run_dir'],'case_id':case_id,'reason':'Predeclared one startup-only diagnostic restart; same seed/config, original failure retained','raw_input_observer':str(Path(row['run_dir'])/'boot_input_observer.jsonl')});continue
   if runner.infra(row):raise InfrastructureBlocked('Input/process infrastructure failure requires diagnosis: '+row['run_dir'])
   return row
  raise InfrastructureBlocked('Bootstrap case did not produce a valid evaluation')
 try:
  aa=[]
  for repeat in range(1,p['aa_repetitions']+1):
   aa.append(run('diagnostic_AA','N02','fast',29,'aa_repeat_'+str(repeat)))
  valid_aa=[x['T95_sim_s'] for x in aa if x.get('T95_sim_s') is not None]
  write(C/'AA_VARIABILITY.json',{'same_policy':'fast','same_world':'N02','same_seed':29,
       'attempts':len(aa),'joint_success':sum(x['joint_success'] for x in aa),'T95_sim_s':valid_aa,
       'range_sim_s':max(valid_aa)-min(valid_aa) if valid_aa else None,
       'two_repeats_are_diagnostic_not_statistical_proof':True})
  for profile in p['profiles']:
   diagnostic=run(profile,p['diagnostic_map'],profile,p['diagnostic_seed'],'return_regression')
   if not safe(diagnostic):
    outcomes[profile]={'status':'rejected','reason':'targeted return/safety regression failed'};export(rows,outcomes);continue
   outcomes[profile]={'status':'screening'};export(rows,outcomes)
   pilot={}
   screen_refs={}
   rejected=None
   for wid in ['N03','N04']:
    order=['fast',profile]
    for policy in order:
     row=run(profile,wid,policy,29,'screen')
     if policy=='fast':screen_refs[wid]=row
     else:pilot[wid]=row
     if not safe(row):rejected='screen safety/task failed on '+wid;break
    if rejected:break
   if rejected is None:
    relative=[(screen_refs[w]['T95_sim_s']-pilot[w]['T95_sim_s'])/screen_refs[w]['T95_sim_s'] for w in ['N03','N04']]
    if min(relative)<-.05 or statistics.mean(relative)<.03:rejected='fresh headless screening did not show sufficient benefit; no validation claim'
   if rejected:
    outcomes[profile]={'status':'rejected','reason':rejected,'screen_rows':pilot,'fresh_headless_screen_controls':screen_refs};export(rows,outcomes);continue
   outcomes[profile]={'status':'paired_validation','screen_rows':pilot,'fresh_headless_screen_controls':screen_refs};export(rows,outcomes)
   context_refs={}
   for wid in ['N01','N02']:
    row=run(profile,wid,'context',29,'headless_context_reference');context_refs[wid]=row
    if not safe(row):rejected='headless context reference failed '+wid;break
   if rejected:
    outcomes[profile]={'status':'rejected','reason':rejected};export(rows,outcomes);continue
   pairs={}
   for spec in p['paired_schedule']:
    wid,seed=spec['world_id'],spec['seed'];pairs[(wid,seed)]={}
    for arm in spec['order']:
     policy=profile if arm=='candidate' else 'fast';row=run(profile,wid,policy,seed,'paired');pairs[(wid,seed)][arm]=row
     if not safe(row):rejected='paired safety/task failed '+wid+' seed'+str(seed);break
    if rejected:break
   if not rejected:
    means={}
    for wid in ['N01','N02','N03','N04']:
     control=statistics.mean(pairs[(wid,s)]['control']['T95_sim_s'] for s in p['validation_seeds']);candidate=statistics.mean(pairs[(wid,s)]['candidate']['T95_sim_s'] for s in p['validation_seeds']);ratios=[pairs[(wid,s)]['candidate']['T95_sim_s']/pairs[(wid,s)]['control']['T95_sim_s'] for s in p['validation_seeds']]
     means[wid]={'control_mean':control,'candidate_mean':candidate,'relative_improvement':(control-candidate)/control,'individual_ratios':ratios}
    passed=(all(means[w]['relative_improvement']>=.05 for w in ['N03','N04']) and all(means[w]['candidate_mean']<=1.02*means[w]['control_mean'] for w in ['N01','N02']) and all(max(means[w]['individual_ratios'])<=1.15 for w in means) and all(pairs[(w,29)]['candidate']['T95_sim_s']<context_refs[w]['T95_sim_s'] for w in ['N01','N02']))
    write(C/f'{profile}_PAIRED_GATE.json',{'passed':passed,'means':means,'seeds':p['validation_seeds'],'all_maps_seen_development':True,'display_condition':'headless','context_references':context_refs})
    if not passed:rejected='paired improvement or protected-maze advantage gate failed'
   if rejected:
    outcomes[profile]={'status':'rejected','reason':rejected};export(rows,outcomes);continue
   for wid in ['N06','N05']:
    row=run(profile,wid,profile,29,'functional')
    if not safe(row):rejected='remaining-map safety/task failed on '+wid;break
   if rejected:
    outcomes[profile]={'status':'rejected','reason':rejected};export(rows,outcomes);continue
   outcomes[profile]={'status':'accepted','reason':'headless two-seed paired benefit and maze protection, all remaining-map functional gates passed'};export(rows,outcomes)
   write(ROOT/'protocol/HEADLESS_ACCEPTED_CANDIDATE.json',{'profile':profile,'source_snapshot_id':ident,'paired_gate':runner.load(C/f'{profile}_PAIRED_GATE.json'),'all_attempts':len(rows),'startup_failures_retained':sum(r.get('failure')=='startup_failure' for r in rows),'not_a_universal_or_statistical_guarantee':True})
   runner.status(status='complete',accepted_profile=profile,completed=len(rows),retained_r032_unchanged=True);return
  runner.status(status='needs_diagnosis',reason='All predeclared profiles failed acceptance; no promotion',completed=len(rows),retained_r032_unchanged=True)
 except BaseException as exc:
  export(rows,outcomes);runner.status(status='needs_diagnosis',error=str(exc),completed=len(rows),retained_r032_unchanged=True);(C/'DIAGNOSIS_REQUIRED.txt').write_text(traceback.format_exc());raise
if __name__=='__main__':main()
