"""World configuration only. Truth stays outside all target-selection code."""
from dataclasses import dataclass
from pathlib import Path
import hashlib,json,os,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'resources'

@dataclass(frozen=True)
class WorldAdapter:
 id:str
 name:str
 world_path:Path
 source_key:str

 @property
 def directory(self):return ROOT/'world_adapters'/self.id

 def prepare(self):
  self.directory.mkdir(parents=True,exist_ok=True)
  tree=ET.parse(self.world_path);world=tree.getroot().find('world')
  changes=[]
  for e in list(world):
   if e.tag in ('state','actor'):
    world.remove(e);changes.append('removed '+e.tag)
  # Freeze dynamic furniture consistently for static-scene evaluation.
  for parent in [world]+list(world.findall('.//model')):
   for include in parent.findall('include'):
    uri=include.findtext('uri','')
    if uri not in ('model://sun','model://ground_plane'):
     static=include.find('static')
     if static is None:static=ET.SubElement(include,'static')
     static.text='true'
  for m in world.findall('.//model'):
   s=m.find('static')
   if s is None:s=ET.SubElement(m,'static')
   s.text='true'
  changes.append('all scene models frozen static; robot spawned separately')
  if self.id in ('M02','M06'):
   # The original House has an open southern edge. Use its full floor, plus
   # a 0.3m outer margin, and physically bound it rather than clipping scores.
   if self.id=='M02':x0,x1,y0,y1=-7.9,7.9,-5.7,5.7
   else:x0,x1,y0,y1=-21.0,40.0,-22.0,27.0
   for name,x,y,w,d in [('west',x0,(y0+y1)/2,.15,y1-y0+.15),('east',x1,(y0+y1)/2,.15,y1-y0+.15),
                         ('south',(x0+x1)/2,y0,x1-x0+.15,.15),('north',(x0+x1)/2,y1,x1-x0+.15,.15)]:
    m=ET.SubElement(world,'model',{'name':'v5_scope_'+name});ET.SubElement(m,'static').text='true'
    ET.SubElement(m,'pose').text=f'{x} {y} .25 0 0 0'
    link=ET.SubElement(m,'link',{'name':'wall'})
    for kind in ('collision','visual'):
     c=ET.SubElement(link,kind,{'name':'wall'});g=ET.SubElement(c,'geometry')
     ET.SubElement(ET.SubElement(g,'box'),'size').text=f'{w} {d} .5'
   changes.append(f'{self.id} bounded derivative: physical outer walls x=[{x0},{x1}], y=[{y0},{y1}]; original meshes retained; interior unchanged')
  physics=world.find('physics')
  if physics is None:physics=ET.SubElement(world,'physics',{'name':'v5_ode','type':'ode'})
  for tag,value in [('max_step_size','0.001'),('real_time_update_rate','1000')]:
   e=physics.find(tag)
   if e is None:e=ET.SubElement(physics,tag)
   e.text=value
  world.attrib['name']='default'
  scene=world.find('scene')
  if scene is None:scene=ET.SubElement(world,'scene')
  e=scene.find('shadows')
  if e is None:e=ET.SubElement(scene,'shadows')
  e.text='false'
  target=self.directory/'world.sdf';tree.write(target,encoding='unicode')
  lock=(json.loads((RES/self.source_key/'RESOURCE_LOCK.json').read_text()) if self.source_key!='development'
        else {'repository':'frozen V4 local development room','commit':'parent SHA256 in provenance/PARENT.json'})
  manifest={'world_id':self.id,'name':self.name,'source':str(self.world_path.relative_to(ROOT)),
   'upstream_repository':lock['repository'],'commit':lock['commit'],
   'source_sha256':hashlib.sha256(self.world_path.read_bytes()).hexdigest(),
   'runtime_world_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
   'changes':changes,'truth_mode':'Gazebo loaded collision geometry; no robot',
   'termination':'ground-truth-assisted (coverage only; no truth in planning)',
   'evaluation_resolution_m':.1,'robot_inflation_m':.22,
   'truth_heights_m':json.loads((ROOT/'assets/truth_geometry.json').read_text())['projection_heights_m'],
   'status':'resources_prepared_truth_audit_pending'}
  (self.directory/'manifest.json').write_text(json.dumps(manifest,indent=2))
  return target

def model_paths():
 return [ROOT/'runtime_models',RES/'tb3/turtlebot3_gazebo/models',RES/'warehouse/models',RES/'bookstore/models',
         RES/'hospital/models',RES/'gazebo_models',RES/'fuel_models',
         Path('/opt/ros/humble/share/turtlebot3_gazebo/models')]

def environment():
 e=os.environ.copy()
 e['GAZEBO_MODEL_PATH']=':'.join(map(str,model_paths()))+':'+e.get('GAZEBO_MODEL_PATH','')
 e['GAZEBO_MODEL_DATABASE_URI']='' # Missing local assets must fail, not download silently.
 e['GAZEBO_RESOURCE_PATH']=':'.join(str(RES/n) for n in ('warehouse','bookstore','hospital','tb3'))+':/usr/share/gazebo-11:'+e.get('GAZEBO_RESOURCE_PATH','')
 e['OGRE_RESOURCE_PATH']=e.get('OGRE_RESOURCE_PATH') or '/usr/lib/x86_64-linux-gnu/OGRE-1.9.0'
 return e

WORLDS={w.id:w for w in [
 WorldAdapter('D07','V4 development room seed 7',ROOT/'development_worlds/room_seed7.sdf','development'),
 WorldAdapter('D09','V4 development room seed 9',ROOT/'development_worlds/room_seed9.sdf','development'),
 WorldAdapter('M01','TurtleBot3 World',RES/'tb3/turtlebot3_gazebo/worlds/turtlebot3_world.world','tb3'),
 WorldAdapter('M02','TurtleBot3 House',RES/'tb3/turtlebot3_gazebo/worlds/turtlebot3_house.world','tb3'),
 WorldAdapter('M03','AWS Small Warehouse',RES/'warehouse/worlds/small_warehouse/small_warehouse.world','warehouse'),
 WorldAdapter('M04','AWS Bookstore',RES/'bookstore/worlds/bookstore.world','bookstore'),
 WorldAdapter('M05','AWS Hospital single floor',RES/'hospital/worlds/hospital.world','hospital'),
 WorldAdapter('M06','Willow Garage',RES/'gazebo_classic/worlds/willowgarage.world','gazebo_classic'),
]}

def audit_uris(world):
 models={}
 for root in model_paths():
  if root.is_dir():
   for p in root.glob('*/model.config'):models.setdefault(p.parent.name,p.parent)
 seen=set();missing=[]
 def visit(path):
  path=path.resolve()
  if path in seen:return
  seen.add(path)
  tree=ET.parse(path)
  for u in tree.findall('.//uri'):
   uri=u.text or ''
   if uri.startswith('model://'):
    key=uri[8:].split('/',1);name=key[0]
    if name not in models:missing.append({'file':str(path),'uri':uri});continue
    if len(key)>1:
     if not (models[name]/key[1]).exists():missing.append({'file':str(path),'uri':uri})
    else:
     config=ET.parse(models[name]/'model.config')
     sdf=config.findall('sdf')[-1].text
     visit(models[name]/sdf)
   elif uri.startswith(('http:','https:')):
    missing.append({'file':str(path),'uri':uri,'error':'unlocked remote URI'})
   elif uri.startswith('file://'):
    tail=uri[7:]
    choices=[Path(tail),path.parent/tail,Path('/usr/share/gazebo-11')/tail]+[RES/n/tail for n in ('warehouse','bookstore','hospital')]
    if not any(p.exists() for p in choices):missing.append({'file':str(path),'uri':uri})
 return_doc={}
 visit(world)
 return {'passed':not missing,'missing':missing,'sdf_files_checked':len(seen)}


# Existing published maps, imported without geometry scaling or cropping.
WORLDS={}
WORLDS['E01']=WorldAdapter('E01','SC4_office_strip',ROOT/'development_worlds/E01.sdf','world_collection')
WORLDS['E02']=WorldAdapter('E02','F1_maze_s08_braid50_rb',ROOT/'development_worlds/E02.sdf','world_collection')
WORLDS['E03']=WorldAdapter('E03','F1_maze_s08_perfect_kr',ROOT/'development_worlds/E03.sdf','world_collection')

# Six additional published scenes, original geometry retained.
WORLDS['N01']=WorldAdapter('N01','F1_maze_s08_perfect_rb',ROOT/'development_worlds/N01.sdf','extra_maps/N01')
WORLDS['N02']=WorldAdapter('N02','F1_maze_s08_braid50_kr',ROOT/'development_worlds/N02.sdf','extra_maps/N02')
WORLDS['N03']=WorldAdapter('N03','rosnav_maze',ROOT/'development_worlds/N03.sdf','extra_maps/N03')
WORLDS['N04']=WorldAdapter('N04','rosnav_corridor',ROOT/'development_worlds/N04.sdf','extra_maps/N04')
WORLDS['N05']=WorldAdapter('N05','warehouse_docking',ROOT/'development_worlds/N05.sdf','extra_maps/N05')
WORLDS['N06']=WorldAdapter('N06','slam_warehouse',ROOT/'development_worlds/N06.sdf','extra_maps/N06')
