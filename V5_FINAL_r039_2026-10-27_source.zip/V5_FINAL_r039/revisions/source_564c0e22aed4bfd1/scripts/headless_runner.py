"""Operational cohort runner: same frozen algorithm, zero GUI processes."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from source_freeze import ROOT
from run_speed_campaign import enrich,infra,load,write

C=ROOT/'campaigns/event_pipeline_2026-10-26'
OPERATIONS=Path(__file__).resolve().parent


def operations_hashes():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(OPERATIONS.glob('*.py'))}


def verify_operations():
    lock=load(ROOT/'protocol/HEADLESS_OPERATIONS_LOCK.json')
    assert operations_hashes()==lock['sha256'],'Headless operation changed during cohort'
    assert hashlib.sha256((ROOT/'protocol/HEADLESS_PROTOCOL.json').read_bytes()).hexdigest()==lock['protocol_sha256']
    policy=load(ROOT.parent/'V5_EXPERIMENT_DISPLAY_POLICY.json')
    assert policy['default_gui'] is False


def status(**data):
    write(C/'CURRENT.json',{'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                          'display_condition':'headless',**data})


def run_job(job,index,stage,ident):
    verify_operations()
    if shutil.disk_usage(ROOT).free<2*1024**3:raise RuntimeError('Disk reserve below2GiB')
    args=[sys.executable,str(OPERATIONS/'run_v5.py'),
          '--world-id',job['world_id'],'--spawn-id','S01',
          '--run-seed',str(job['run_seed']),'--method','B2',
          '--execution-policy',job['execution_policy'],'--split',job['split'],
          '--gui','false','--contact-sensors','--max-sim-seconds','1800','--wait']
    with (C/f'job_{index:03d}.log').open('x') as log:
        worker=subprocess.Popen(args,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        status(status='running',stage=stage,index=index,job=job,
               worker_pid=worker.pid,source_snapshot_id=ident)
        with (C/f'job_{index:03d}_BOOT_OBSERVER.log').open('x') as observer_log:
            subprocess.Popen([sys.executable,str(ROOT/'scripts/boot_input_observer.py'),
                              '--campaign',str(C),'--index',str(index)],
                             stdout=observer_log,stderr=subprocess.STDOUT,start_new_session=True)
            worker.wait()
    text=(C/f'job_{index:03d}.log').read_text()
    folder=next((Path(s[8:]) for s in text.splitlines() if s.startswith('run_dir=')),None)
    if folder is None:raise RuntimeError('No run directory: see job log')
    manifest=load(folder/'manifest.json')
    assert manifest['gui']=='false' and manifest['experiment_cohort']=='event_pipeline_2026-10-26'
    if not (folder/'summary.json').exists():
        subprocess.run([sys.executable,str(ROOT/'scripts/summarize_run.py'),str(folder)],
                       check=True,stdout=subprocess.DEVNULL)
    write(folder/'OPERATIONAL_COHORT.json',{
        'condition':'headless','campaign':str(C),'source_snapshot_id':ident,
        'operations_sha256':operations_hashes(),
        'protocol_sha256':load(ROOT/'protocol/HEADLESS_OPERATIONS_LOCK.json')['protocol_sha256'],
        'gui_results_excluded':True})
    row=enrich(load(folder/'summary.json'),stage)
    events=[json.loads(s) for s in (folder/'mission_events.jsonl').read_text().splitlines()]
    waits=[e['result_wait_sim_s'] for e in events if e['event']=='planning_result_consumed' and e.get('result_wait_sim_s') is not None]
    idle=[];completed=None
    for event in events:
        if event['phase']!='EXPLORE':continue
        if event['event']=='goal_result' and event.get('result')=='success':completed=event['sim_time']
        if event['event']=='goal_assigned' and completed is not None:
            idle.append(event['sim_time']-completed);completed=None
    row.update(gui=False,experiment_cohort='event_pipeline_2026-10-26',
               planning_result_wait_sim_s=sum(waits),between_goals_idle_sim_s=sum(idle),between_goal_count=len(idle))
    return row
