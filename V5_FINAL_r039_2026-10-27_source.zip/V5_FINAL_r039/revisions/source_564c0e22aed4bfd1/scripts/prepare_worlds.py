#!/usr/bin/env python3
"""Sequential resource smoke and offline truth extraction, before experiments."""
import argparse,json,os,signal,subprocess,time,hashlib
from pathlib import Path
import numpy as np
from scipy import ndimage
from PIL import Image
from world_adapter import ROOT,WORLDS,environment,audit_uris

def process_truth(folder):
 meta=json.loads((folder/'collision.json').read_text())
 expected=json.loads((ROOT/'assets/truth_geometry.json').read_text())['projection_heights_m']
 if meta['heights']!=expected:raise ValueError('Native projection heights differ from the audited robot configuration')
 raw=np.fromfile(folder/'collision.bin',dtype=np.uint8).reshape(meta['height'],meta['width'])>0
 # Cells have finite area: add a half-diagonal to the physical 0.22m radius.
 distance=ndimage.distance_transform_edt(~raw)*meta['resolution']
 inflated=distance<=.22+meta['resolution']*2**.5/2
 labels,num=ndimage.label(~inflated)
 # Use the largest enclosed component, reject components touching extraction
 # edges (unbounded exterior), and register both poses before any method runs.
 edge_labels=set(np.r_[labels[0],labels[-1],labels[:,0],labels[:,-1]])
 options=[i for i in range(1,num+1) if i not in edge_labels]
 if not options:raise ValueError('No enclosed reachable component; physical scope audit required')
 component=max(options,key=lambda i:np.sum(labels==i))
 reachable=labels==component
 safe=reachable&(distance>=.55)
 ys,xs=np.where(safe)
 if not len(xs):raise ValueError('No legal spawn with 0.55m clearance')
 cx,cy=np.mean(xs),np.mean(ys)
 i=int(np.argmin((xs-cx)**2+(ys-cy)**2));x0,y0=int(xs[i]),int(ys[i])
 # Grid geodesic selects a separated second spawn in the same component.
 from collections import deque
 q=deque([(y0,x0)]);dist={(y0,x0):0}
 while q:
  y,x=q.popleft()
  for v,u in [(y-1,x),(y+1,x),(y,x-1),(y,x+1)]:
   if 0<=v<labels.shape[0] and 0<=u<labels.shape[1] and reachable[v,u] and (v,u) not in dist:
    dist[v,u]=dist[y,x]+1;q.append((v,u))
 y1,x1=max(zip(ys.tolist(),xs.tolist()),key=lambda p:(dist.get(p,-1),p))
 def pose(x,y):return [meta['origin'][0]+(x+.5)*.1,meta['origin'][1]+(y+.5)*.1,0.0]
 boundary=ndimage.binary_dilation(reachable,structure=ndimage.generate_binary_structure(2,1))&inflated
 roi=reachable|boundary
 np.savez_compressed(folder/'truth.npz',obstacles=inflated,reachable=reachable,roi=roi,
  resolution=meta['resolution'],origin=np.array(meta['origin']))
 rgb=np.full((*raw.shape,3),235,np.uint8);rgb[inflated]=[20,20,20];rgb[reachable]=[255,255,255]
 for y,x in [(y0,x0),(y1,x1)]:rgb[max(0,y-2):y+3,max(0,x-2):x+3]=[240,80,40]
 py,px=np.where(roi)
 crop=(max(0,int(px.min())-3),max(0,int(py.min())-3),min(raw.shape[1],int(px.max())+4),min(raw.shape[0],int(py.max())+4))
 view=rgb[crop[1]:crop[3],crop[0]:crop[2]]
 Image.fromarray(np.flipud(view)).resize((view.shape[1]*8,view.shape[0]*8),Image.Resampling.NEAREST if hasattr(Image,'Resampling') else Image.NEAREST).save(folder/'truth_preview_8x.png')
 area=float(reachable.sum())*.01
 audit={'automated_checks_passed':True,'manual_geometry_audit_passed':False,
  'formal_eligible':False,'reason':'Door/thin obstacle/height and registration visual audit still required',
  'free_cells':int(reachable.sum()),'roi_cells':int(roi.sum()),'reachable_area_m2':area,
  'budget_sim_s':900 if area<=100 else 1800 if area<=500 else 3600,
  'spawns':{'S01':pose(x0,y0),'S02':pose(x1,y1)},
  'component_touches_edge':False,'component_count':num,
  'preview_crop_cells':crop,'preview_crop_only':True,
  'radius_m':.22,'raster_margin_m':.1*2**.5/2,'floor_z':meta.get('floor_z',0.0),
  'truth_sha256':hashlib.sha256((folder/'truth.npz').read_bytes()).hexdigest(),
  'height_config':json.loads((ROOT/'assets/truth_geometry.json').read_text()),
  'limitations':['Ten height samples in audited 0.16m robot envelope; thin intermediate geometry needs audit','Collision boundary rasterization, flood excludes solid interiors','Largest enclosed component; full selected floor must be visually verified']}
 if folder.name.startswith('D'):
  ix=int((-1.7-meta['origin'][0])/.1);iy=int((-2.5-meta['origin'][1])/.1)
  if not reachable[iy,ix] or distance[iy,ix]<.4:raise ValueError('Frozen development deployment is not safe in extracted truth')
  audit['spawns']['S01']=[-1.7,-2.5,0.0]
 (folder/'truth_audit.json').write_text(json.dumps(audit,indent=2))
 return audit

def prepare(wid):
 adapter=WORLDS[wid];folder=adapter.directory
 world=adapter.prepare()
 uris=audit_uris(world);(folder/'uri_audit.json').write_text(json.dumps(uris,indent=2))
 if not uris['passed']:raise ValueError('Unresolved resource URI; see uri_audit.json')
 if not (folder/'collision.json').exists():
  env=environment();env['V5_TRUTH_OUTPUT']=str(folder/'collision')
  env.pop('V5_FLOOR_PROBES',None)
  floor_audit=folder/'floor_audit.json'
  if floor_audit.exists():
   floor=json.loads(floor_audit.read_text())
   if not floor['passed']:raise ValueError('Floor datum audit failed')
   env['V5_FLOOR_Z']=str(floor['floor_z'])
  env['GAZEBO_MASTER_URI']='http://127.0.0.1:'+str(21000+int(wid[1:]))
  plugin=ROOT/'install/gazebo_scene_audit/lib/libv5_audit.so'
  with (folder/('truth_extraction_'+str(time.time_ns())+'.log')).open('x') as log:
   proc=subprocess.Popen(['gzserver','--verbose','-s',str(plugin),str(world)],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   start=time.monotonic()
   try:
    while not (folder/'collision.json').exists():
     if proc.poll() is not None:raise RuntimeError('Gazebo exited during extraction')
     if time.monotonic()-start>600:raise TimeoutError('Resource/extraction wall watchdog 600s')
     time.sleep(.5)
   finally:
    if proc.poll() is None:os.killpg(proc.pid,signal.SIGINT)
    try:proc.wait(15)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
  (folder/'extraction_timing.json').write_text(json.dumps({'wall_s':time.monotonic()-start,'exit_code':proc.returncode}))
 result=process_truth(folder)
 print(wid,json.dumps(result),flush=True)

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--world-id',nargs='+',default=list(WORLDS));args=parser.parse_args()
 failed=[]
 for wid in args.world_id:
  try:prepare(wid)
  except Exception as e:
   print('FAILED',wid,type(e).__name__,str(e),flush=True);failed.append(wid)
 raise SystemExit(bool(failed))
