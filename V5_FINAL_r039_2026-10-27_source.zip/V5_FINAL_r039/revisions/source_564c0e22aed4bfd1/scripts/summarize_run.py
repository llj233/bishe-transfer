#!/usr/bin/env python3
"""Include failures and censored times; physical truth is evaluation only."""
import csv,json,math,sys
import hashlib
from pathlib import Path
import numpy as np

def load(path,default):return json.loads(path.read_text()) if path.exists() else default
def lines(path):
 if not path.exists():return []
 result=[]
 for line in path.read_text().splitlines():
  try:result.append(json.loads(line))
  except json.JSONDecodeError:pass
 return result

def summarize(folder):
 folder=folder.resolve()
 m=load(folder/'manifest.json',{});r=load(folder/'result.json',{})
 ev=list(csv.DictReader((folder/'evaluation.csv').open())) if (folder/'evaluation.csv').exists() else []
 physics=lines(folder/'physical_audit.jsonl');events=lines(folder/'mission_events.jsonl')
 contacts=lines(folder/'body_contacts.jsonl')
 episodes=0;last_contact=False
 for cmsg in contacts:
  active=bool(cmsg.get('contact'))
  episodes+=bool(active and not last_contact);last_contact=active
 def episodes_for(key):
  if not any(key in r for r in contacts):return None
  last=False;count=0
  for r in contacts:
   state=bool(r.get(key));count+=bool(state and not last);last=state
  return count
 budget=m['max_sim_seconds'];spawn=m['deployment']['robot1']
 error=math.hypot(physics[-1]['x']-spawn[0],physics[-1]['y']-spawn[1]) if physics else None
 t=[float(v['sim_time']) for v in ev];c=[float(v['exploration_pct']) for v in ev]
 normalized_auc=float(np.trapz([0]+c+([c[-1]] if c else [0]),[0]+t+[max(budget,t[-1] if t else 0)]))/budget/100 if ev else None
 returned=bool(r.get('returned',{}).get('robot1'))
 terminal_time=next((e['sim_time'] for e in reversed(events) if e.get('event')=='terminal'),r.get('sim_seconds'))
 terminal_pose=min(physics,key=lambda p:abs(p['sim_time']-terminal_time)) if physics and terminal_time is not None else None
 physical_sample_age=abs(terminal_pose['sim_time']-terminal_time) if terminal_pose else None
 if terminal_pose:error=math.hypot(terminal_pose['x']-spawn[0],terminal_pose['y']-spawn[1])
 physical_verified=physical_sample_age is not None and physical_sample_age<=.5
 complete=r.get('status')=='COMPLETE'
 final_coverage_passed=bool(ev) and float(ev[-1]['exploration_pct'])>95 and float(ev[-1]['roi_known_pct'])>90
 gate=next((e for e in events if e.get('event')=='return_gate'),None)
 explore_end=gate.get('sim_time') if gate else None
 nav_results=[e for e in events if e.get('event')=='goal_result']
 explore_path=return_path=0.
 for a,b in zip(physics,physics[1:]):
  distance=math.hypot(b['x']-a['x'],b['y']-a['y'])
  if explore_end is None or b['sim_time']<=explore_end:explore_path+=distance
  elif a['sim_time']>=explore_end:return_path+=distance
  else:
   ratio=(explore_end-a['sim_time'])/max(1e-9,b['sim_time']-a['sim_time'])
   explore_path+=distance*ratio;return_path+=distance*(1-ratio)
 contacts_seen=set(s for msg in contacts for s in msg.get('sensors_seen',[]))
 eligible=m.get('split')=='formal'
 summary={'execution_policy':m.get('execution_policy'),'world_id':m.get('world_id'),'spawn_id':m.get('spawn_id'),'run_seed':m.get('run_seed'),
  'source_snapshot_id':m.get('source_snapshot_id','pre_snapshot_'+hashlib.sha256(json.dumps(m.get('source_sha256',{}),sort_keys=True).encode()).hexdigest()[:16]),
  'truth_sha256':m.get('truth_sha256'),
  'method':m.get('method'),'split':m.get('split'),'status':r.get('status','NO_RESULT'),
  'failure':r.get('failure'),'formal_eligible':eligible,
  'exploration_success':bool(r.get('exploration_reached')),
  'return_success':returned and error is not None and error<=.35 and physical_verified,
  'joint_success':complete and returned and error is not None and error<=.35 and physical_verified and bool(r.get('exploration_reached')) and final_coverage_passed,
  'final_coverage_passed':final_coverage_passed,
  'T90_sim_s':next((t[i] for i,x in enumerate(c) if x>90),None),
  'T95_sim_s':next((t[i] for i,x in enumerate(c) if x>95),None),
  'T95_censored':not any(x>95 for x in c),'budget_sim_s':budget,
  'exploration_end_sim_s':explore_end,'total_task_end_sim_s':next((e['sim_time'] for e in reversed(events) if e.get('event')=='terminal'),r.get('sim_seconds')),
  'return_phase_sim_s':terminal_time-explore_end if explore_end is not None and terminal_time is not None else None,
  'final_exploration_pct':c[-1] if c else None,
  'final_roi_pct':float(ev[-1]['roi_known_pct']) if ev else None,
  'explored_free_m2':int(ev[-1]['reachable_free_seen'])*.01 if ev else None,
  'reachable_free_m2':int(ev[-1]['reachable_free_total'])*.01 if ev else None,
  'normalized_coverage_auc':normalized_auc,'task_sim_s':terminal_time,
  'runner_recorded_elapsed_s':r.get('sim_seconds'),
  'physical_home_error_m':error,'odom_home_error_m':r.get('home_error_odom_m',{}).get('robot1'),
  'physical_pose_sample_age_s':physical_sample_age,'physical_return_pose_verified':physical_verified,
  'contact_measurement_version':next((r.get('contact_measurement_version') for r in contacts if r.get('contact_measurement_version')),None),
  'raw_contact_log':str(folder/'raw_contacts.jsonl.gz') if (folder/'raw_contacts.jsonl.gz').exists() else None,
  'contact_episodes':episodes if contacts and m.get('contact_sensors_enabled',False) else None,
  'environment_contact_episodes':episodes_for('environment_contact'),
  'support_mesh_lateral_episodes':episodes_for('support_mesh_lateral_contact'),
  'contact_scope':m.get('contact_sensor_links',['legacy_body'] if m.get('contact_sensors_enabled') else []),
  'contact_sensors_verified':bool(m.get('contact_sensors_enabled')) and set(m.get('contact_sensor_links',['legacy_body'])).issubset(contacts_seen),
  'physical_path_m':sum(math.hypot(b['x']-a['x'],b['y']-a['y']) for a,b in zip(physics,physics[1:])),
  'exploration_path_m':explore_path,'return_path_m':return_path,
  'navigation_attempts':len(nav_results),'navigation_successes':sum(e.get('result')=='success' for e in nav_results),
  'navigation_timeouts':sum(e.get('result')=='timeout' for e in nav_results),
  'navigation_failures':sum(e.get('result')!='success' for e in nav_results),
  'premature_goal_replacements':sum(e.get('event')=='goal_canceled' for e in events),
  'process_exit':load(folder/'process_exit.json',{}),
  'termination':'ground-truth-assisted; not autonomous online stopping',
  'run_dir':str(folder)}
 (folder/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
 print(json.dumps(summary,ensure_ascii=False),flush=True)
 return summary

if __name__=='__main__':summarize(Path(sys.argv[1]))
