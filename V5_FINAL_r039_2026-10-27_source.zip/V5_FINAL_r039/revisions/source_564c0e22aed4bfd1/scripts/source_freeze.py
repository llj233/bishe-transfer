"""Content-addressed algorithm snapshots; report rendering may update separately."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RUN_SCRIPTS=['run_event_campaign.py','headless_runner.py','run_frontier_search.py','boot_input_observer.py','run_speed_campaign.py','run_p1_development.py', 'start_compact_batch.py', 'start_authorized_batch.py', 'experiment_scope.py', 'source_freeze.py', 'queue_runner.py', 'run_v5.py', 'run_test.py', 'world_adapter.py', 'prepare_worlds.py', 'summarize_run.py', 'audit_map_alignment.py', 'export_telemetry.py', 'audit_floor_datums.py']

def hashes():
 paths=[p for name in ('src','assets','development_worlds') for p in (ROOT/name).rglob('*') if p.is_file() and '__pycache__' not in str(p)]
 paths += [ROOT/'scripts'/name for name in RUN_SCRIPTS]
 policy=ROOT/'protocol/EXPERIMENT_SCOPE_POLICY.json'
 if policy.exists():paths.append(policy)
 asset_lock=ROOT/'protocol/ASSET_LOCK.json'
 if asset_lock.exists():paths.append(asset_lock)
 for name in ['FRONTIER_PROTOCOL.json','HEADLESS_PROTOCOL.json','RESOURCE_LOCK.json','NEW_SIX_MAPS.json']:
  protocol=ROOT/'protocol'/name
  if protocol.exists():paths.append(protocol)
 paths += sorted((ROOT/'operations').glob('*.py'))
 return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}

def snapshot():
 d=hashes();ident=hashlib.sha256(json.dumps(d,sort_keys=True).encode()).hexdigest()[:16]
 folder=ROOT/'revisions'/('source_'+ident)
 if not folder.exists():
  folder.mkdir(parents=True)
  for key in d:
   target=folder/key;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/key,target)
  (folder/'HASHES.json').write_text(json.dumps(d,indent=2))
 return ident,d
