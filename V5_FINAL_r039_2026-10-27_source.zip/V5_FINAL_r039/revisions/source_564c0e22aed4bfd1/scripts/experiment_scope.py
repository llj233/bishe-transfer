"""User-defined experiment scope; historical frozen results remain immutable."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def blocked_world_ids():
    blocked=set()
    for path in [ROOT/'protocol/EXPERIMENT_SCOPE_POLICY.json',ROOT.parent/'V5_EXPERIMENT_SCOPE_POLICY.json']:
        if path.exists():blocked.update(json.loads(path.read_text())['excluded_world_ids'])
    return blocked

def require_allowed(world_ids):
    blocked=sorted(set(world_ids)&blocked_world_ids())
    if blocked:raise ValueError('Maps excluded by explicit user scope; blocked maps: '+','.join(blocked))
