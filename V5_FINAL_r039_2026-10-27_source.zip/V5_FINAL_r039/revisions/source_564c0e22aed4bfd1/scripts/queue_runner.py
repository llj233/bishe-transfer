#!/usr/bin/env python3
"""Sequential campaign monitor. Never edits algorithm code or hides failures."""
import argparse,datetime,json,os,random,subprocess,time,uuid,shutil
from pathlib import Path
from world_adapter import ROOT,WORLDS
from source_freeze import snapshot,hashes
from experiment_scope import require_allowed, blocked_world_ids
from audit_map_alignment import audit as alignment_audit

def write(path,data):
 temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,indent=2,ensure_ascii=False));temp.replace(path)

def reports():
 for script in ['export_report.py','build_beginner_pdf.py']:
  with (ROOT/'reports/campaign_report_updates.log').open('a') as log:
   subprocess.run(['python3',str(ROOT/'scripts'/script)],stdout=log,stderr=subprocess.STDOUT)

def run_job(job,folder,index):
 if shutil.disk_usage(ROOT).free<2*1024**3:raise RuntimeError('Disk free below predeclared 2GiB infrastructure reserve')
 args=['python3',str(ROOT/'scripts/run_v5.py'),'--world-id',job['world_id'],'--spawn-id',job.get('spawn_id','S01'),
  '--run-seed',str(job['run_seed']),'--method',job['method'],'--split',job['split'],'--gui','true','--contact-sensors','--wait']
 if job.get('budget'):args+=['--max-sim-seconds',str(job['budget'])]
 log=folder/f'job_{index:03d}.log'
 with log.open('x') as f:
  proc=subprocess.Popen(args,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  write(folder/'CURRENT.json',{'status':'running','index':index,'job':job,'worker_pid':proc.pid,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'job_log':str(log)})
  proc.wait()
 text=log.read_text();run_dir=next((Path(s[len('run_dir='):]) for s in text.splitlines() if s.startswith('run_dir=')),None)
 if run_dir is None:raise RuntimeError('Launcher did not create a run directory; inspect '+str(log))
 summary_file=run_dir/'summary.json'
 if not summary_file.exists():
  subprocess.run(['python3',str(ROOT/'scripts/summarize_run.py'),str(run_dir)],check=False,stdout=subprocess.DEVNULL)
 summary=json.loads(summary_file.read_text())
 subprocess.run(['python3',str(ROOT/'scripts/export_telemetry.py'),str(run_dir)],stdout=subprocess.DEVNULL,check=False)
 if job.get('alignment_gate'):
  health=list((run_dir/'navigation_health.csv').read_text().splitlines()) if (run_dir/'navigation_health.csv').exists() else []
  events=[json.loads(s) for s in (run_dir/'mission_events.jsonl').read_text().splitlines()] if (run_dir/'mission_events.jsonl').exists() else []
  nav_success=any(e.get('event')=='goal_result' and e.get('result')=='success' for e in events)
  aligned=alignment_audit(run_dir)
  volume_path=run_dir/'physical_audit.jsonl.volume.json'
  volume=json.loads(volume_path.read_text()) if volume_path.exists() else {'inside_audited_envelope':False}
  # A short smoke intentionally times out on coverage; it must still execute
  # navigation and provide independently consistent observed landmarks.
  if not aligned['passed'] or not nav_success or not summary['contact_sensors_verified'] or not volume['inside_audited_envelope']:
   summary['_acceptance_error']='Interface/alignment/contact gate failed: '+str(run_dir)
  else:
   adapter=WORLDS[job['world_id']].directory
   write(adapter/'interface_audit.json',{'passed':True,'navigation_success_observed':True,'contacts_verified':True,'alignment':aligned,'robot_volume':volume,'run_dir':str(run_dir)})
 if job.get('must_succeed') and not summary['joint_success']:summary['_acceptance_error']='V5 acceptance failed: '+str(run_dir)
 return summary

def formal_freeze():
 if blocked_world_ids():raise RuntimeError('Original full-plan generator disabled by scope amendment; use the reviewed deferred queue without Hospital')
 worlds={}
 for wid in ['M01','M02','M03','M04','M05','M06']:
  p=WORLDS[wid].directory
  geometry=json.loads((p/'geometry_checklist.json').read_text());interface=json.loads((p/'interface_audit.json').read_text())
  if not geometry.get('visual_review_passed') or not geometry['automated_passed'] or not interface['passed']:raise RuntimeError('Unapproved map '+wid)
  a=json.loads((p/'truth_audit.json').read_text());a.update(manual_geometry_audit_passed=True,formal_eligible=True,reason='Resource, geometry outline, physical/height regression and interface alignment gates passed; finite sampling limitations retained')
  write(p/'truth_audit.json',a);worlds[wid]={'spawns':a['spawns'],'budget_sim_s':a['budget_sim_s'],'truth_sha256':a['truth_sha256'],'reachable_area_m2':a['reachable_area_m2'],'floor_z':a['floor_z']}
 ident,source=snapshot()
 freeze={'status':'frozen_before_formal','source_snapshot_id':ident,'source_sha256':source,'worlds':worlds,'methods':['B0','B1','B2'],'run_seeds':[11,29],'randomization_seed':20261020,
  'termination':'ground-truth-assisted','targets':{'free_pct_strict':95,'roi_pct_strict':90,'physical_home_error_m_max':.35},
  'budget_includes':['startup','exploration','return'],'failure_policy':'All algorithm failures retained; continue fixed approved batch, no post-outcome seed deletion or per-map tuning',
  'batch_policy':json.loads((ROOT/'protocol/FORMAL_BATCH_POLICY.json').read_text()),
  'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 write(ROOT/'protocol/FORMAL_FREEZE.json',freeze)
 rng=random.Random(20261020);jobs=[]
 blocks=[(wid,spawn,seed) for wid in worlds for spawn in ['S01','S02'] for seed in [11,29]];rng.shuffle(blocks)
 for wid,spawn,seed in blocks:
  methods=['B0','B1','B2'];rng.shuffle(methods)
  jobs.extend({'world_id':wid,'spawn_id':spawn,'run_seed':seed,'method':m,'split':'formal','must_succeed':False} for m in methods)
 return jobs

def selected_formal_jobs(jobs, completed_count, attempt_limit):
 """Absolute launch cap: a failed attempt consumes one slot too."""
 if completed_count < 0 or attempt_limit < 0:raise ValueError('Negative attempt count/limit')
 return jobs[completed_count:attempt_limit]

def main():
 p=argparse.ArgumentParser();p.add_argument('--queue',type=Path,required=True);p.add_argument('--formal-after-gates',action='store_true')
 p.add_argument('--resume-active-development',action='store_true',help='Adopt existing development run without launching it twice')
 args=p.parse_args();folder=args.queue.parent;doc=json.loads(args.queue.read_text());jobs=doc['jobs']
 if doc.get('approved_for_execution') is False:p.error('Prepared queue only; execution has not been authorized')
 try:require_allowed(j['world_id'] for j in jobs)
 except ValueError as error:p.error(str(error))
 results=json.loads((folder/'COMPLETED.json').read_text()) if args.resume_active_development else []
 try:
  if args.resume_active_development:
   current=json.loads((folder/'CURRENT.json').read_text())
   if current.get('job',{}).get('split')!='development' or current['index']!=len(results):raise RuntimeError('Cannot adopt inconsistent development state')
   log=Path(current['job_log']);active=next((Path(s[8:]) for s in log.read_text().splitlines() if s.startswith('run_dir=')),None)
   if active is None:raise RuntimeError('Active development has no run directory')
   while not (active/'process_exit.json').exists() or not (active/'summary.json').exists():time.sleep(2)
   subprocess.run(['python3',str(ROOT/'scripts/summarize_run.py'),str(active)],check=True,stdout=subprocess.DEVNULL)
   result=json.loads((active/'summary.json').read_text())
   results.append(result);write(folder/'COMPLETED.json',results);reports()
   if current['job'].get('must_succeed') and not result['joint_success']:raise RuntimeError('Active development acceptance failed: '+str(active))
  index=len(results)
  for job in jobs[index:]:
   result=run_job(job,folder,index);results.append(result);write(folder/'COMPLETED.json',results);reports();index+=1
   if result.get('_acceptance_error'):raise RuntimeError(result['_acceptance_error'])
  if args.formal_after_gates:
   control=json.loads((folder/'BATCH_CONTROL.json').read_text());limit=int(control['formal_attempt_limit'])
   jobs=formal_freeze();write(folder/'FORMAL_QUEUE.json',jobs)
   completed_formal=sum(r['split']=='formal' for r in results)
   batch=selected_formal_jobs(jobs,completed_formal,limit)
   write(folder/'APPROVED_FORMAL_BATCH.json',batch)
   write(folder/'DEFERRED_FORMAL_QUEUE.json',jobs[limit:])
   for job in batch:
    # Count launches, not just successful outcomes. Never launch attempt 21.
    if sum(r['split']=='formal' for r in results)>=limit:raise RuntimeError('Formal cap invariant violated')
    result=run_job(job,folder,index);results.append(result);write(folder/'COMPLETED.json',results);reports();index+=1
    if result.get('_acceptance_error'):raise RuntimeError(result['_acceptance_error'])
   write(folder/'CURRENT.json',{'status':'awaiting_user_approval','completed':len(results),'formal_completed':sum(r['split']=='formal' for r in results),
      'approved_formal_limit':limit,'deferred_formal_runs':len(jobs[limit:]),'resume_requires_explicit_user_approval':True,
      'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
   (folder/'WAITING_FOR_USER_APPROVAL.md').write_text('# 首批正式实验已结束\n\n已达到本批授权上限。报告与原始失败记录保留；未启动后续实验。必须获得用户明确同意才可继续。\n')
  else:write(folder/'CURRENT.json',{'status':'complete','completed':len(results),'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 except Exception as error:
  write(folder/'CURRENT.json',{'status':'needs_diagnosis','completed':len(results),'error':str(error),'preserve_all_data':True})
  (folder/'DIAGNOSIS_REQUIRED.md').write_text('# 后续任务需要诊断\n\n'+str(error)+'\n\n已停止继续计入正式比较，所有已产生的结果保留。\n')
  reports();raise
 reports()

if __name__=='__main__':main()
