#!/usr/bin/env python3
"""One fixed paired development queue. Failure stops for diagnosis, never retries."""
import csv,datetime,fcntl,hashlib,json,os,shutil,subprocess,sys,time,traceback
from pathlib import Path
from source_freeze import ROOT,snapshot,hashes
C=ROOT/'campaigns/p1_paired6';C.mkdir(parents=True,exist_ok=True)
def write(p,d):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(d,ensure_ascii=False,indent=2));q.replace(p)
def export(results):
 fields=['world_id','spawn_id','run_seed','execution_policy','status','joint_success','failure','T95_sim_s','final_exploration_pct','final_roi_pct','explored_free_m2','total_task_end_sim_s','physical_home_error_m','environment_contact_episodes','navigation_failures','run_dir']
 with (ROOT/'reports/P1开发对照结果.csv').open('w',encoding='utf-8-sig',newline='') as out:
  writer=csv.DictWriter(out,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(results)
 text='# P1 开发对照进度\n\n'+f'已完成 {len(results)}/6。开发筛查数据，不构成正式泛化结论。失败原样保留。\n\n'
 for r in results:text+=f"- {r['world_id']} / {r['execution_policy']}: {r['status']}, 探索率 {r.get('final_exploration_pct')}%, ROI {r.get('final_roi_pct')}%, T95 {r.get('T95_sim_s')}s, 原部署点误差 {r.get('physical_home_error_m')}m。\n"
 (ROOT/'reports/P1开发对照进度.md').write_text(text)
def main():
 lock=(C/'QUEUE.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 safety=json.loads((ROOT/'provenance/SAFETY_GATE_REUSE.json').read_text())
 for rel,digest in safety['sha256'].items():
  if hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()!=digest:raise RuntimeError('Safety source or tested binary changed: '+rel)
 protocol=json.loads((ROOT/'protocol/DEVELOPMENT_PAIRED_6.json').read_text());results=[]
 if (C/'STARTED.json').exists():raise RuntimeError('Queue already attempted; inspect rather than silently restart')
 for gate in ['ROTATION_GUARD_GATE.json','LOW_CURB_PROJECTION_GATE.json']:
  if not json.loads((ROOT/'regressions'/gate).read_text())['passed']:raise RuntimeError('Physical gate failed '+gate)
 if not json.loads((ROOT/'display_checks/r031_externalmaps/DISPLAY_GATE.json').read_text())['passed']:raise RuntimeError('Display gate failed')
 ident,frozen=snapshot();write(ROOT/'protocol/DEVELOPMENT_FREEZE.json',{'source_snapshot_id':ident,'sha256':frozen,'queue_sha256':hashlib.sha256((ROOT/'protocol/DEVELOPMENT_PAIRED_6.json').read_bytes()).hexdigest()})
 write(C/'STARTED.json',{'pid':os.getpid(),'source':ident,'time':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 write(ROOT.parent/'V5_ACTIVE_CAMPAIGN.json',{'workspace':str(ROOT),'campaign':str(C),'version':'r030','stage':'paired development; not formal','source_snapshot_id':ident})
 try:
  for i,job in enumerate(protocol['jobs'],1):
   if hashes()!=frozen:raise RuntimeError('Frozen source changed during queue')
   if shutil.disk_usage(ROOT).free<2*1024**3:raise RuntimeError('Disk reserve below2GiB')
   args=[sys.executable,str(ROOT/'scripts/run_v5.py'),'--world-id',job['world_id'],'--spawn-id',job['spawn_id'],'--run-seed',str(job['run_seed']),'--method',job['method'],'--execution-policy',job['execution_policy'],'--split','development','--gui','true','--contact-sensors','--wait','--max-sim-seconds',str(job['budget'])]
   with (C/f'job_{i:03d}.log').open('x') as log:
    proc=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    write(C/'CURRENT.json',{'status':'running','index':i,'total':6,'job':job,'worker_pid':proc.pid,'source_snapshot_id':ident})
    with (C/f'job_{i:03d}_DISPLAY.log').open('x') as display:
     viewer=subprocess.Popen([sys.executable,str(ROOT/'display_checks/watch_run_display.py'),'--campaign',str(C),'--index',str(i)],stdout=display,stderr=subprocess.STDOUT,start_new_session=True)
     proc.wait()
   text=(C/f'job_{i:03d}.log').read_text();folder=next((Path(s[8:]) for s in text.splitlines() if s.startswith('run_dir=')),None)
   if folder is None:raise RuntimeError('No run directory; see job log')
   if not (folder/'summary.json').exists():subprocess.run([sys.executable,str(ROOT/'scripts/summarize_run.py'),str(folder)],check=True,stdout=subprocess.DEVNULL)
   result=json.loads((folder/'summary.json').read_text());results.append(result);write(C/'COMPLETED.json',results);export(results)
   # A failure remains in the denominator; no automatic same-job replacement.
   if not result['joint_success'] or not result['contact_sensors_verified']:
    raise RuntimeError('Development failure retained for diagnosis: '+str(folder))
  write(C/'CURRENT.json',{'status':'complete','completed':6,'source_snapshot_id':ident,'next':'review paired outcomes before P2; no automatic formal batch'})
 except BaseException as exc:
  write(C/'CURRENT.json',{'status':'needs_diagnosis','completed':len(results),'error':str(exc),'source_snapshot_id':ident})
  (C/'DIAGNOSIS_REQUIRED.txt').write_text(traceback.format_exc());export(results);raise
if __name__=='__main__':main()
