#!/usr/bin/env python3
"""Screen speed on seen maps; freeze; compare on exactly six new maps."""
import csv,datetime,fcntl,hashlib,json,os,shutil,subprocess,sys,time,traceback,statistics
from pathlib import Path
from source_freeze import ROOT,snapshot,hashes
C=ROOT/'campaigns/speed_then_new6';C.mkdir(parents=True,exist_ok=True)

def write(p,d):
 q=p.with_suffix('.tmp');q.write_text(json.dumps(d,ensure_ascii=False,indent=2));q.replace(p)
def load(p):return json.loads(p.read_text())
def status(**data):write(C/'CURRENT.json',{'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**data})
def enrich(row,stage):
 row=dict(row);row['stage']=stage;p=Path(row['run_dir']);h=list(csv.DictReader((p/'navigation_health.csv').open())) if (p/'navigation_health.csv').exists() else []
 h=[x for x in h if x['phase']=='EXPLORE'];row['reverse_samples_1Hz']=sum(float(x['output_v'])<-.02 for x in h);row['stop_samples_1Hz']=sum(abs(float(x['output_v']))<.02 and abs(float(x['output_w']))<.06 for x in h)
 row['map_png']=str(p/'fused_slam_map_preview.png');return row

def export(rows):
 fields=['stage','world_id','execution_policy','run_seed','status','joint_success','failure','T95_sim_s','final_exploration_pct','final_roi_pct','explored_free_m2','total_task_end_sim_s','return_phase_sim_s','physical_home_error_m','physical_path_m','reverse_samples_1Hz','stop_samples_1Hz','navigation_failures','environment_contact_episodes','run_dir','map_png']
 with (ROOT/'reports/提速与新六图实验结果.csv').open('w',encoding='utf-8-sig',newline='') as out:
  writer=csv.DictWriter(out,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
 write(C/'COMPLETED.json',rows)
 text='# 提速与新六张地图实验进度\n\n'+f"开发复测已完成{sum(r['stage']=='development' for r in rows)}/3；新六图配对已完成{sum(r['stage']=='new_six' for r in rows)}/12。\n\n"
 for r in rows:text+=f"- {r['stage']} {r['world_id']} {r['execution_policy']}: {r['status']}, T95={r.get('T95_sim_s')}s, 探索={r.get('final_exploration_pct')}%, ROI={r.get('final_roi_pct')}%, 返航误差={r.get('physical_home_error_m')}m。\n"
 (ROOT/'reports/当前实验进度.md').write_text(text)

def run_job(job,index,stage,ident):
 if shutil.disk_usage(ROOT).free<2*1024**3:raise RuntimeError('Disk reserve below2GiB')
 args=[sys.executable,str(ROOT/'scripts/run_v5.py'),'--world-id',job['world_id'],'--spawn-id','S01','--run-seed',str(job['run_seed']),'--method','B2','--execution-policy',job['execution_policy'],'--split',job['split'],'--gui','true','--contact-sensors','--max-sim-seconds','1800','--wait']
 with (C/f'job_{index:03d}.log').open('x') as log:
  proc=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  status(status='running',stage=stage,index=index,job=job,worker_pid=proc.pid,source_snapshot_id=ident)
  with (C/f'job_{index:03d}_DISPLAY.log').open('x') as display:
   viewer=subprocess.Popen([sys.executable,str(ROOT/'display_checks/watch_run_display.py'),'--campaign',str(C),'--index',str(index)],stdout=display,stderr=subprocess.STDOUT,start_new_session=True)
   with (C/f'job_{index:03d}_BOOT_OBSERVER.log').open('x') as observer_log:
    subprocess.Popen([sys.executable,str(ROOT/'scripts/boot_input_observer.py'),'--campaign',str(C),'--index',str(index)],stdout=observer_log,stderr=subprocess.STDOUT,start_new_session=True)
   proc.wait()
 text=(C/f'job_{index:03d}.log').read_text();folder=next((Path(s[8:]) for s in text.splitlines() if s.startswith('run_dir=')),None)
 if folder is None:raise RuntimeError('No run directory: see job log')
 if not (folder/'summary.json').exists():subprocess.run([sys.executable,str(ROOT/'scripts/summarize_run.py'),str(folder)],check=True,stdout=subprocess.DEVNULL)
 return enrich(load(folder/'summary.json'),stage)

def infra(row):
 return (row['status']=='NO_RESULT' or row.get('failure')=='runtime_error' or not row.get('contact_sensors_verified') or row.get('process_exit',{}).get('reason')=='wall_watchdog')

def final_report(rows):
 tests=[r for r in rows if r['stage']=='new_six'];groups={arm:[r for r in tests if r['execution_policy']==arm] for arm in ['context','fast']};stats={}
 for arm,items in groups.items():
  stats[arm]={'n':len(items),'joint_success':sum(r['joint_success'] for r in items),'T95_budget_capped_mean_sim_s':statistics.mean(r['T95_sim_s'] if r['T95_sim_s'] is not None else 1800. for r in items),'environment_contacts':sum(r.get('environment_contact_episodes') or 0 for r in items)}
 write(ROOT/'reports/新六图统计.json',stats)
 text='# 新六张地图固定候选对照报告\n\n'+f"完成{len(tests)}/12次，六张此前未做探索的发布地图，每图策略/仿真种子29，context与fast各一次。同图同出生点同预算。失败全部保留，未达95%者以1800秒计入预算截断T95统计。\n\n旧新结果：\n\n"
 for arm,s in stats.items():text+=f"- {arm}: 联合成功{s['joint_success']}/{s['n']}，预算截断平均T95 {s['T95_budget_capped_mean_sim_s']:.1f}仿真秒，记录环境接触{s['environment_contacts']}次。\n"
 text+='\n一图一种子，当前对照用于发现机制问题；不能宣称每次均成功或具有统计泛化优势。所有地图、源码快照、传感器、任务阈值及原始数据分别保存。\n'
 (ROOT/'reports/新六图实验报告.md').write_text(text)

def main():
 lock=(C/'QUEUE.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 if (C/'STARTED.json').exists():raise RuntimeError('Already attempted; preserve results, inspect before resume')
 safety=load(ROOT/'provenance/SAFETY_SCOPE.json')
 for rel,digest in safety['sha256'].items():
  if hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()!=digest:raise RuntimeError('Safety implementation changed: '+rel)
 protocol=load(ROOT/'protocol/SPEED_PROTOCOL.json');write(C/'STARTED.json',{'pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});rows=[]
 write(ROOT.parent/'V5_ACTIVE_CAMPAIGN.json',{'workspace':str(ROOT),'campaign':str(C),'version':'r032','stage':'speed development -> six new published maps paired validation'})
 try:
  first_log=ROOT/'reports/fast_E01_candidate1.log';first=next((Path(s[8:]) for s in first_log.read_text().splitlines() if s.startswith('run_dir=')),None)
  if first is None:raise RuntimeError('First speed candidate was not launched')
  status(status='running',stage='speed_development',development_index=1,run_dir=str(first),new_map_tests_completed=0)
  while not (first/'summary.json').exists():
   if (first/'process_exit.json').exists() and time.time()-(first/'process_exit.json').stat().st_mtime>90:raise RuntimeError('First run exited without summary')
   time.sleep(2)
  rows.append(enrich(load(first/'summary.json'),'development'));export(rows)
  if infra(rows[-1]) or not rows[-1]['joint_success']:raise RuntimeError('First speed regression failed; preserve and diagnose')
  # Scene audits run between exploration missions to avoid extra Gazebo CPU
  # load contaminating a measured exploration episode.
  status(status='auditing_new_maps',stage='native_geometry_floor_display',development_completed=1,new_map_tests_completed=0)
  with (ROOT/'reports/new_six_audit.log').open('x') as log:subprocess.run([sys.executable,str(ROOT/'scripts/prepare_new_six.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
  ident,frozen=snapshot();write(ROOT/'protocol/DEVELOPMENT_SPEED_FREEZE.json',{'source_snapshot_id':ident,'sha256':frozen})
  for index,wid in enumerate(['E02','E03'],1):
   if hashes()!=frozen:raise RuntimeError('Source changed during development replication')
   row=run_job({'world_id':wid,'run_seed':11,'execution_policy':'fast','split':'development'},index,'development',ident);rows.append(row);export(rows)
   if infra(row) or not row['joint_success']:raise RuntimeError('Speed development failure retained: '+row['run_dir'])
  parent=load(ROOT.parent/'V5_single_r031_externalmaps_2026-10-24/campaigns/p1_paired6/COMPLETED.json');base={r['world_id']:r for r in parent if r['execution_policy']=='context'};differences=[r['T95_sim_s']-base[r['world_id']]['T95_sim_s'] for r in rows];ratios=[r['T95_sim_s']/base[r['world_id']]['T95_sim_s'] for r in rows]
  passed=statistics.median(differences)<0 and max(ratios)<=1.1 and all(r['joint_success'] and (r.get('environment_contact_episodes')==0) for r in rows)
  gate={'passed':passed,'paired_T95_changes_sim_s':differences,'median_change_sim_s':statistics.median(differences),'worst_ratio':max(ratios),'parent_source_snapshot':'126f5ce9440dff54','development_rows':rows,'single_seed_historical_reference':True};write(ROOT/'protocol/SPEED_GATE.json',gate)
  if not passed:raise RuntimeError('Speed improvement gate not passed; no unseen-map testing or parameter changes silently applied')
  # Freeze once before opening any new-map task outcome.
  write(ROOT/'protocol/NEW_SIX_FREEZE.json',{'source_snapshot_id':ident,'sha256':frozen,'protocol_sha256':hashlib.sha256((ROOT/'protocol/SPEED_PROTOCOL.json').read_bytes()).hexdigest(),'speed_gate':gate,'failure_policy':protocol['new_six_policy']})
  for index,job in enumerate(protocol['new_six_jobs'],3):
   if hashes()!=frozen:raise RuntimeError('Frozen source changed during new-map comparison')
   for file,digest in load(ROOT/'protocol/ASSET_LOCK.json').items():
    if hashlib.sha256((ROOT/file).read_bytes()).hexdigest()!=digest:raise RuntimeError('Audited map changed: '+file)
   row=run_job(job,index,'new_six',ident);rows.append(row);export(rows)
   if infra(row):raise RuntimeError('Infrastructure failure retained: '+row['run_dir'])
  final_report(rows);status(status='complete',development_completed=3,new_map_trials_completed=12,new_map_count=6,source_snapshot_id=ident)
 except BaseException as exc:
  export(rows);status(status='needs_diagnosis',completed=len(rows),error=str(exc),preserve_all_data=True);(C/'DIAGNOSIS_REQUIRED.txt').write_text(traceback.format_exc());raise
if __name__=='__main__':main()
