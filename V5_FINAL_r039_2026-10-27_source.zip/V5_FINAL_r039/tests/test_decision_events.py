from concurrent.futures import Future
from pathlib import Path
from types import SimpleNamespace
from nav_msgs.msg import OccupancyGrid
from active_slam_v4.allocator import Allocator
from active_slam_v4.mission import Mission
from active_slam_v4.model import Candidate,Pose2,Phase
from active_slam_v4.ros_runtime import TestExecutor as Executor


def test_plan_ready_signals_guard_without_running_mission_in_worker():
    signals=[]
    state=SimpleNamespace(now=lambda:12.5,plan_ready_sim=None,
                          decision_wakeup=SimpleNamespace(trigger=lambda:signals.append('ready')))
    Executor.on_plan_ready(state,Future())
    assert state.plan_ready_sim==12.5 and signals==['ready']
    state.decision_wakeup=None
    Executor.on_plan_ready(state,Future())
    assert signals==['ready']


def dispatch_state(policy):
    msg=OccupancyGrid();msg.info.width=msg.info.height=20;msg.info.resolution=.1
    msg.info.origin.position.x=msg.info.origin.position.y=-1.
    msg.info.origin.orientation.w=1.;msg.data=[0]*400
    msg.data[11*20+11]=100  # target centre stays free, padded footprint does not
    target=Pose2(.05,.05)
    c=Candidate('candidate','robot1','region',target,target,1,10,1.,.5,1.)
    future=Future();future.set_result(([c],{}))
    mission=Mission(robots=('robot1',));mission.phase=Phase.EXPLORE
    sent=[]
    state=SimpleNamespace(navigation_busy=lambda _:False,pending_backtrack={},
        backtrack_future=None,plan_future=future,plan_ready_sim=99.8,
        mission=mission,goal_regions={},map_version=1,execution_policy=policy,
        execution_memory={'robot1':SimpleNamespace(blocked=lambda *_:False)},
        latest={'robot1':{'pose':Pose2(-.6,0),'odom_pose':Pose2(-.6,0),'map':msg}},
        allocator=Allocator(),no_candidate_since={},names=('robot1',),
        trigger_pub=SimpleNamespace(publish=lambda _:None),
        send_navigation=lambda *args:sent.append(args))
    return state,sent


def test_event_dispatch_rejects_changed_footprint_while_control_is_unchanged():
    candidate,sent=dispatch_state('event_fast')
    Executor.schedule_explore(candidate,100.)
    assert not sent and not candidate.mission.active
    assert any(x['event']=='dispatch_footprint_rejected' for x in candidate.mission.events)
    control,sent=dispatch_state('fast')
    Executor.schedule_explore(control,100.)
    assert len(sent)==1  # original control behaviour remains available to Nav2


def test_frontier_selection_is_byte_identical_to_frozen_r032():
    root=Path(__file__).resolve().parents[1]
    rel='src/active_slam_v4/active_slam_v4/planner.py'
    assert (root/rel).read_bytes()==(root.parent/'V5_single_r032_speed_2026-10-24'/rel).read_bytes()
