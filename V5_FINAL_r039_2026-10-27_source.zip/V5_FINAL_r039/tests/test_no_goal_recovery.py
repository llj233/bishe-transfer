from types import SimpleNamespace
from active_slam_v4.ros_runtime import TestExecutor as Executor
from active_slam_v4.mission import Mission
from active_slam_v4.model import Pose2,Phase
from active_slam_v4.health import RecoveryEpisode

def test_idle_failed_planning_recovers_without_overlapping_navigation():
 m=Mission(robots=('robot1',));m.phase=Phase.EXPLORE
 state=SimpleNamespace(names=('robot1',),mission=m,navigation_busy=lambda _:False,
  planning_idle_since={'robot1':None},query_failure_count={'robot1':3},
  plan_future=None,backtrack_future=None,pending_backtrack={'robot1':[]},
  recovery_episodes={'robot1':RecoveryEpisode()},latest={'robot1':{'odom_pose':Pose2(0,0)}},
  pending_escape={},trigger_pub=SimpleNamespace(publish=lambda _:None))
 Executor.monitor_planning_idle(state,100.,True)
 Executor.monitor_planning_idle(state,124.,True)
 assert not state.pending_escape
 Executor.monitor_planning_idle(state,126.,True)
 assert state.pending_escape=={'robot1':126.} and not m.active
 assert m.phase==Phase.EXPLORE
 state.pending_escape.clear();state.navigation_busy=lambda _:True
 Executor.monitor_planning_idle(state,160.,True)
 assert not state.pending_escape and state.planning_idle_since['robot1'] is None
