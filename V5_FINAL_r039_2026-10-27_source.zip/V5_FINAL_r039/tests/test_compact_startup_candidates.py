"""Replay the measured initial SLAM map that produced 48 near-goal rejections."""
import json,math
from pathlib import Path
from active_slam_v4.planner import CandidatePlanner,footprint_fits
from active_slam_v4.model import Grid,Pose2,Transform2

def test_short_observation_requires_safe_footprint_and_nav2_path():
 root=Path(__file__).resolve().parents[1]
 p=root/'tests/fixtures/legacy_initial_map.json'
 m=json.loads(p.read_text());d=m['info']
 g=Grid(d['width'],d['height'],d['resolution'],Pose2(d['origin']['position']['x'],d['origin']['position']['y']),tuple(m['data']),2.,'robot1/map')
 current=Pose2(6.7502,-5.5501,-.0019);planner=CandidatePlanner(method='B2',max_path_queries=12)
 for _ in range(2):
  r,_=planner.plan('robot1',g,current,Transform2(0,0,0,0),1,lambda _:None)
  assert not r
 queries=[]
 def path(goal):
  assert footprint_fits(g,goal)
  distance=math.hypot(goal.x-current.x,goal.y-current.y)
  assert .25<=distance<.60
  queries.append(goal)
  return distance
 r,_=planner.plan('robot1',g,current,Transform2(0,0,0,0),1,path)
 assert queries and r
 r,_=planner.plan('robot1',g,current,Transform2(0,0,0,0),1,lambda _:None)
 assert not r  # a safe endpoint alone is never declared reachable
