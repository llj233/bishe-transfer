#!/usr/bin/env python3
"""Create an isolated V4 single or dual GUI test and start ROS/Gazebo."""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET

import yaml
from map_variants import generate_room
from active_slam_v4.swept_safety import FOOTPRINT


ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / 'assets/robot.sdf'
NAV2 = Path('/opt/ros/humble/share/nav2_bringup/params/nav2_params.yaml')
SLAM = Path('/opt/ros/humble/share/slam_toolbox/config/mapper_params_online_async.yaml')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_rpp_config(controller):
    follow = controller['FollowPath']
    tolerance = max(controller[name]['xy_goal_tolerance']
                    for name in controller['goal_checker_plugins'])
    if follow['use_rotate_to_heading'] and follow['min_lookahead_dist'] <= tolerance:
        raise ValueError('RPP minimum lookahead must exceed every XY goal tolerance')


def make_model(name, path):
    root = ET.parse(MODEL).getroot()
    root.find('.//plugin[@name="turtlebot3_laserscan"]/frame_name').text = f'{name}/base_scan'
    laser = root.find('.//sensor[@name="hls_lfcd_lds"]')
    laser.find('./ray/range/max').text = '10.0'
    laser.find('./ray/scan/horizontal/samples').text = '180'
    laser.find('./update_rate').text = '3'
    primary = root.find('.//plugin[@name="turtlebot3_laserscan"]')
    primary.find('./ros/remapping').text='~/out:=scan_raw'
    link=root.find('.//link[@name="base_scan"]')
    auxiliary=ET.SubElement(link,'sensor',{'name':'downward_multilayer_safety','type':'ray'})
    ET.SubElement(auxiliary,'always_on').text='true';ET.SubElement(auxiliary,'update_rate').text='3'
    ET.SubElement(auxiliary,'pose').text='-.064 0 .121 0 0 0';ET.SubElement(auxiliary,'visualize').text='false'
    ray=ET.SubElement(auxiliary,'ray');scan=ET.SubElement(ray,'scan')
    for section,values in [('horizontal',{'samples':'180','resolution':'1','min_angle':'0','max_angle':'6.28'}),('vertical',{'samples':'17','resolution':'1','min_angle':'-.8','max_angle':'0'})]:
     node=ET.SubElement(scan,section)
     for tag,value in values.items():ET.SubElement(node,tag).text=value
    limits=ET.SubElement(ray,'range')
    for tag,value in [('min','.12'),('max','6.0'),('resolution','.01')]:ET.SubElement(limits,tag).text=value
    plugin=ET.SubElement(auxiliary,'plugin',{'name':'near_ground_lidar','filename':'libgazebo_ros_ray_sensor.so'})
    ros=ET.SubElement(plugin,'ros');ET.SubElement(ros,'namespace').text=f'/{name}';ET.SubElement(ros,'remapping').text='~/out:=near_ground_points'
    ET.SubElement(plugin,'output_type').text='sensor_msgs/PointCloud2';ET.SubElement(plugin,'frame_name').text=f'{name}/base_scan'
    drive = root.find('.//plugin[@name="turtlebot3_diff_drive"]')
    drive.find('odometry_frame').text = f'{name}/odom'
    drive.find('robot_base_frame').text = f'{name}/base_footprint'
    camera = root.find('.//sensor[@name="camera"]')
    if camera is not None:
        for link in root.findall('.//link'):
            if camera in list(link):
                link.remove(camera)
                break
    for visual in root.findall('.//sensor/visualize'):
        visual.text = 'false'
    ET.ElementTree(root).write(path, encoding='unicode', xml_declaration=False)


def validate_slam_config(slam):
    # A strong odometry prior needs the predicted pose to be sampled exactly.
    # Non-integral coarse angle grids can exclude zero correction entirely.
    if slam.get('distance_variance_penalty',.5)<.01:
        angle=slam['coarse_search_angle_offset']/slam['coarse_angle_resolution']
        translation=slam['correlation_search_space_dimension']/(4*slam['correlation_search_space_resolution'])
        if not math.isclose(angle,round(angle),abs_tol=1e-6):
            raise ValueError('SLAM coarse angular grid excludes the odometry prediction')
        if not math.isclose(translation,round(translation),abs_tol=1e-6):
            raise ValueError('SLAM coarse translation grid excludes the odometry prediction')


def make_configs(name, folder, local_controller="mppi"):
    slam = yaml.safe_load(SLAM.read_text())['slam_toolbox']['ros__parameters']
    slam.update({'odom_frame': f'{name}/odom', 'map_frame': f'{name}/map',
                 'base_frame': f'{name}/base_footprint', 'scan_topic': f'/{name}/scan',
                 'resolution': .1, 'map_update_interval': 2.0,
                 'minimum_travel_distance': .25, 'minimum_travel_heading': .25,
                 'max_laser_range': 10.0, 'do_loop_closing': False,
                 'transform_publish_period': .05, 'transform_timeout': .6,
                 # Ideal WORLD odometry prior: prevent unconstrained corridor scan slip.
                 'correlation_search_space_dimension': .20,
                 'distance_variance_penalty': .003, 'minimum_distance_penalty': .05,
                 'angle_variance_penalty': .003, 'minimum_angle_penalty': .05,
                 'coarse_search_angle_offset': .1047,
                 'use_sim_time': True})
    validate_slam_config(slam)
    (folder / f'{name}_slam.yaml').write_text(yaml.safe_dump(
        {f'/{name}/slam_toolbox': {'ros__parameters': slam}}, sort_keys=False))
    nav = yaml.safe_load(NAV2.read_text())
    bt = nav['bt_navigator']['ros__parameters']
    bt['global_frame'] = f'{name}/map'
    bt['robot_base_frame'] = f'{name}/base_footprint'
    bt['odom_topic'] = f'/{name}/odom'
    shutil.copy2(ROOT / 'assets/navigate_bounded.xml', folder / 'navigate_bounded.xml')
    (folder / 'navigate_return.xml').write_text(
        (ROOT / 'assets/navigate_bounded.xml').read_text().replace(
            'general_goal_checker', 'deployment_goal_checker'))
    bt['default_nav_to_pose_bt_xml'] = str(folder / 'navigate_bounded.xml')
    controller = nav['controller_server']['ros__parameters']
    controller['controller_frequency'] = 8.0
    controller['progress_checker']['required_movement_radius'] = .12
    controller['progress_checker']['movement_time_allowance'] = 12.0
    controller['general_goal_checker']['xy_goal_tolerance'] = .12
    controller['general_goal_checker']['yaw_goal_tolerance'] = .20
    controller['goal_checker_plugins'] = ['general_goal_checker', 'deployment_goal_checker']
    controller['deployment_goal_checker'] = dict(controller['general_goal_checker'])
    controller['deployment_goal_checker']['xy_goal_tolerance'] = .20
    # A 360-degree lidar observation needs a position region, not a final yaw.
    # Deployment keeps its original independent position/heading tolerances.
    controller['general_goal_checker']['xy_goal_tolerance'] = .25
    controller['general_goal_checker']['yaw_goal_tolerance'] = math.pi
    controller['FollowPath'] = {
        'plugin': 'nav2_regulated_pure_pursuit_controller::RegulatedPurePursuitController',
        'desired_linear_vel': .28, 'lookahead_dist': .40,
        'min_lookahead_dist': .45, 'max_lookahead_dist': .70,
        'lookahead_time': 1.5, 'use_velocity_scaled_lookahead_dist': True,
        'rotate_to_heading_angular_vel': .6, 'transform_tolerance': .3,
        'min_approach_linear_velocity': .05, 'approach_velocity_scaling_dist': .6,
        'use_collision_detection': True, 'max_allowed_time_to_collision_up_to_carrot': 1.2,
        'use_regulated_linear_velocity_scaling': True,
        'use_cost_regulated_linear_velocity_scaling': True,
        'cost_scaling_dist': .6, 'cost_scaling_gain': 1.0, 'inflation_cost_scaling_factor': 3.0,
        'regulated_linear_scaling_min_radius': .9,
        'regulated_linear_scaling_min_speed': .08,
        'use_rotate_to_heading': True, 'rotate_to_heading_min_angle': .7,
        'max_angular_accel': 3.2, 'max_robot_pose_search_dist': 10.0,
        'use_interpolation': True,
    }
    validate_rpp_config(controller)
    if local_controller == 'dwb':
        controller['FollowPath'] = {
            'plugin': 'dwb_core::DWBLocalPlanner',
            'debug_trajectory_details': False,
            'min_vel_x': -.08, 'max_vel_x': .26,
            'min_vel_y': 0., 'max_vel_y': 0.,
            'max_vel_theta': .6, 'min_speed_xy': 0.,
            'max_speed_xy': .26, 'min_speed_theta': 0.,
            'acc_lim_x': .5, 'acc_lim_y': 0., 'acc_lim_theta': 1.5,
            'decel_lim_x': -.6, 'decel_lim_y': 0., 'decel_lim_theta': -1.5,
            'vx_samples': 15, 'vy_samples': 1, 'vtheta_samples': 21,
            'sim_time': 1.5, 'linear_granularity': .025,
            'angular_granularity': .025, 'transform_tolerance': .3,
            'xy_goal_tolerance': .12, 'trans_stopped_velocity': .02,
            'short_circuit_trajectory_evaluation': True, 'stateful': True,
            'critics': ['RotateToGoal', 'Oscillation', 'ObstacleFootprint', 'PreferForward',
                        'PathAlign', 'GoalAlign', 'PathDist', 'GoalDist'],
            'ObstacleFootprint.scale': .02,
            # Soft cost for no progress; collision rejection remains absolute.
            'PreferForward.scale': .6, 'PreferForward.penalty': 1.,
            'PreferForward.strafe_x': .02, 'PreferForward.strafe_theta': .05,
            'PreferForward.theta_scale': .05,
            'PathAlign.scale': 16., 'PathAlign.forward_point_distance': .1,
            'GoalAlign.scale': 12., 'GoalAlign.forward_point_distance': .1,
            'PathDist.scale': 24., 'GoalDist.scale': 24.,
            'RotateToGoal.scale': 16., 'RotateToGoal.slowing_factor': 5.,
            'RotateToGoal.lookahead_time': -1.,
        }
    elif local_controller == 'mppi':
        controller['FollowPath'] = {
            'plugin': 'nav2_mppi_controller::MPPIController',
            'motion_model': 'DiffDrive', 'model_dt': .125,
            'time_steps': 24, 'batch_size': 1000, 'iteration_count': 1,
            'vx_max': .26, 'vx_min': -.08, 'vy_max': 0., 'wz_max': .6,
            'vx_std': .15, 'vy_std': .0, 'wz_std': .3,
            'temperature': .3, 'gamma': .015, 'reset_period': 1.,
            'retry_attempt_limit': 1, 'regenerate_noises': False,
            'prune_distance': 1.7, 'transform_tolerance': .3,
            # Humble publishes the consumed path through this visualizer.
            # Only one sampled trajectory and 24 optimal points are prepared.
            'visualize': True,
            'TrajectoryVisualizer': {'trajectory_step': 1000, 'time_step': 24},
            'critics': ['ConstraintCritic', 'CostCritic', 'GoalCritic',
                        'GoalAngleCritic', 'PathAlignCritic', 'PathFollowCritic',
                        'PathAngleCritic', 'PreferForwardCritic'],
            'ConstraintCritic': {'enabled': True, 'cost_power': 1, 'cost_weight': 4.},
            'CostCritic': {'enabled': True, 'consider_footprint': True,
                           'cost_power': 1, 'cost_weight': 3.81,
                           'critical_cost': 300., 'collision_cost': 1000000.,
                           'near_goal_distance': .5},
            'GoalCritic': {'enabled': True, 'cost_power': 1,
                           'cost_weight': 5., 'threshold_to_consider': 1.4},
            'GoalAngleCritic': {'enabled': True, 'cost_power': 1,
                                'cost_weight': 3., 'threshold_to_consider': .5},
            'PathAlignCritic': {'enabled': True, 'cost_power': 1,
                                'cost_weight': 10., 'threshold_to_consider': .5,
                                'offset_from_furthest': 10,
                                'trajectory_point_step': 4,
                                'max_path_occupancy_ratio': .07,
                                'use_path_orientations': False},
            'PathFollowCritic': {'enabled': True, 'cost_power': 1,
                                 'cost_weight': 5., 'threshold_to_consider': 1.4,
                                 'offset_from_furthest': 5},
            'PathAngleCritic': {'enabled': True, 'cost_power': 1,
                                'cost_weight': 2., 'threshold_to_consider': .5,
                                'offset_from_furthest': 4,
                                'max_angle_to_furthest': .785398, 'mode': 0},
            'PreferForwardCritic': {'enabled': True, 'cost_power': 1,
                                    'cost_weight': 5., 'threshold_to_consider': .5},
        }
        # The full-circle lidar has no required terminal observation heading.
        # Keep an independent strict deployment controller, selected by return BT.
        controller['controller_plugins'] = ['FollowPath', 'ReturnPath']
        controller['ReturnPath'] = copy.deepcopy(controller['FollowPath'])
        controller['FollowPath']['GoalAngleCritic']['enabled'] = False
        # Retain path guidance until the true deployment acceptance neighborhood.
        # A 1.4m switch previously replaced corridor following too early.
        controller['ReturnPath']['PathFollowCritic']['threshold_to_consider'] = .35
        controller['ReturnPath']['GoalCritic']['threshold_to_consider'] = .45
        controller['ReturnPath']['PathAlignCritic']['threshold_to_consider'] = .25
        controller['ReturnTransitPath'] = copy.deepcopy(controller['ReturnPath'])
        controller['ReturnTransitPath']['GoalAngleCritic']['enabled'] = False
        controller['controller_plugins'].append('ReturnTransitPath')
        planner = nav['planner_server']['ros__parameters']
        planner['planner_plugins'] = ['GridBased','ReturnGrid']
        planner['ReturnGrid'] = {
            'plugin':'nav2_smac_planner/SmacPlannerHybrid',
            'tolerance':.15, 'allow_unknown':False,
            'downsample_costmap':False, 'angle_quantization_bins':72,
            'motion_model_for_search':'REEDS_SHEPP',
            'minimum_turning_radius':.25, 'reverse_penalty':2.0,
            'change_penalty':0.0, 'non_straight_penalty':1.2,
            'cost_penalty':2.0, 'cache_obstacle_heuristic':False,
            'analytic_expansion_ratio':3.5,'analytic_expansion_max_length':1.5,
            'lookup_table_size':5.0,'max_iterations':100000,
            'max_on_approach_iterations':1000,'max_planning_time':2.0,
            'smooth_path':True}
        # All navigation phases now use orientation/footprint feasible routes.
        # Exploration rewards/ranking remain unchanged across B0/B1/B2.
        planner['GridBased'] = copy.deepcopy(planner['ReturnGrid'])
        for label in ['FollowPath','ReturnPath','ReturnTransitPath']:
            controller[label]['PathFollowCritic']['threshold_to_consider'] = .35
            controller[label]['GoalCritic']['threshold_to_consider'] = .45
            controller[label]['PathAlignCritic']['threshold_to_consider'] = .25
            controller[label]['PathAlignCritic']['use_path_orientations'] = True
            controller[label]['PathAngleCritic']['forward_preference'] = False
            controller[label]['PreferForwardCritic']['enabled'] = False
        return_tree = folder / 'navigate_return.xml'
        return_tree.write_text(return_tree.read_text().replace(
            'controller_id="FollowPath"', 'controller_id="ReturnPath"').replace(
            'planner_id="GridBased"', 'planner_id="ReturnGrid"'))
        (folder / 'navigate_return_transit.xml').write_text(return_tree.read_text().replace(
            'controller_id="ReturnPath"', 'controller_id="ReturnTransitPath"').replace(
            'deployment_goal_checker', 'general_goal_checker'))
        if abs(controller['FollowPath']['model_dt']*controller['controller_frequency']-1)>1e-8:
            raise ValueError('MPPI model step must equal controller period')
    elif local_controller != 'rpp':
        raise ValueError('Unknown local controller: '+local_controller)
    for layer, frame in (('local_costmap', f'{name}/odom'),
                         ('global_costmap', f'{name}/map')):
        costmap = nav[layer][layer]['ros__parameters']
        costmap['global_frame'] = frame
        costmap['robot_base_frame'] = f'{name}/base_footprint'
        # Enclose the rear-offset body and wheels, including rotation corners.
        costmap['footprint'] = str([list(p) for p in FOOTPRINT])
        costmap['footprint_padding'] = .05
        costmap['update_frequency'] = 2.0 if layer == 'local_costmap' else 1.0
        costmap['publish_frequency'] = 1.0
        for key in ('obstacle_layer', 'voxel_layer'):
            if key in costmap:
                costmap[key]['scan']['topic'] = f'/{name}/scan'
        # Both planners must consume the same measured near-body hazards.
        # A static-only global map can plan directly through a lethal local
        # cell, making MPPI correctly stop while the planner repeats the route.
        costmap['obstacle_layer'] = {
            'plugin': 'nav2_costmap_2d::ObstacleLayer',
            'observation_sources': 'scan static_memory',
            'static_memory': {'topic': f'/{name}/retained_static_obstacles',
                             'data_type': 'PointCloud2', 'marking': True,
                             'clearing': False, 'observation_persistence': 0.,
                             'obstacle_min_range': 0., 'obstacle_max_range': 1.3,
                             # This cloud already contains filtered 2D hazards at virtual z=.08.
                             # SLAM map height need not equal the odometry floor datum.
                             'min_obstacle_height': -1., 'max_obstacle_height': 1.},
            'scan': {'topic': f'/{name}/scan', 'data_type': 'LaserScan',
                     'clearing': True, 'marking': True, 'inf_is_valid': True,
                     'obstacle_max_range': 3.0, 'raytrace_max_range': 3.5}}
        if layer == 'local_costmap':
            costmap['plugins'] = ['obstacle_layer', 'inflation_layer']
            costmap['width'] = 4
            costmap['height'] = 4
            costmap['inflation_layer']['inflation_radius'] = .65
        else:
            costmap['plugins'] = ['static_layer', 'obstacle_layer', 'inflation_layer']
            costmap['static_layer']['map_topic'] = f'/{name}/map'
            costmap['static_layer']['map_subscribe_transient_local'] = True
            costmap['inflation_layer']['inflation_radius'] = .70
    nav['planner_server']['ros__parameters']['GridBased']['allow_unknown'] = False
    nav['behavior_server']['ros__parameters']['global_frame'] = f'{name}/odom'
    nav['behavior_server']['ros__parameters']['robot_base_frame'] = f'{name}/base_footprint'
    nav['velocity_smoother']['ros__parameters']['odom_topic'] = f'/{name}/odom'
    (folder / f'{name}_nav2.yaml').write_text(yaml.safe_dump(nav, sort_keys=False))
    make_model(name, folder / f'{name}.sdf')


def main():
    raise SystemExit('V5: use scripts/run_v5.py; this legacy module supplies shared configuration helpers only.')
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('single',), default='single')
    parser.add_argument('--world', type=Path, default=ROOT / 'worlds/room.world')
    parser.add_argument('--map-seed', type=int, required=True)
    parser.add_argument('--policy-seed', type=int, required=True)
    parser.add_argument('--max-sim-seconds', type=float, default=180.0)
    parser.add_argument('--gui', choices=('true', 'false'), default='true')
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--wait', action='store_true',
                        help='Keep this launcher alive until the ROS test exits')
    args = parser.parse_args()
    if not all(p.is_file() for p in (args.world, MODEL, NAV2, SLAM)):
        parser.error('world/model/Nav2/SLAM inputs missing')
    if args.world.name != 'room.world':
        parser.error('This seeded evaluator supports room.world only; ROBOTIS models need mesh/include truth support')
    if not 0 <= args.map_seed < 2**32 or args.policy_seed < 0:
        parser.error('map seed must be uint32 and policy seed nonnegative')
    if args.max_sim_seconds <= 0:
        parser.error('max-sim-seconds must be positive')
    uid = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '_' + uuid.uuid4().hex[:8]
    folder = (ROOT / 'experiments' / args.mode / args.world.stem /
              f'map_seed_{args.map_seed:06d}' / f'policy_seed_{args.policy_seed:06d}' / uid)
    folder.mkdir(parents=True, exist_ok=False)
    map_generation = generate_room(args.world, folder / 'world.sdf', args.map_seed)
    names = ['robot1']
    for name in names:
        make_configs(name, folder)
    domain = 20 + int(uuid.uuid4().hex[:4], 16) % 180
    port = 12000 + int(uuid.uuid4().hex[:4], 16) % 16000
    env = os.environ.copy()
    env['ROS_DOMAIN_ID'] = str(domain)
    env['GAZEBO_MASTER_URI'] = f'http://127.0.0.1:{port}'
    # Installed Fast DDS is 2.6: configure transport with its documented XML,
    # rather than depending on a newer built-in transport environment flag.
    shutil.copy2(ROOT / 'assets/fastdds_udp.xml', folder / 'fastdds_udp.xml')
    env.pop('FASTDDS_BUILTIN_TRANSPORTS', None)
    env['FASTRTPS_DEFAULT_PROFILES_FILE'] = str(folder / 'fastdds_udp.xml')
    env['RMW_FASTRTPS_PUBLICATION_MODE'] = 'ASYNCHRONOUS'
    # This separate version changes only the middleware from its parent trial.
    # Vendor packages are extracted locally, leaving /opt/ros unchanged.
    vendor_prefix = ROOT / 'vendor/root/opt/ros/humble'
    if not (vendor_prefix / 'lib/librmw_cyclonedds_cpp.so').is_file():
        parser.error('isolated Cyclone DDS vendor libraries are missing')
    tf_version = ET.parse(vendor_prefix / 'share/tf2/package.xml').getroot().findtext('version')
    if tf_version != '0.25.24':
        parser.error('this version requires the isolated tf2 0.25.24 deadlock fix')
    env['RMW_IMPLEMENTATION'] = 'rmw_cyclonedds_cpp'
    env['AMENT_PREFIX_PATH'] = str(vendor_prefix) + ':' + env.get('AMENT_PREFIX_PATH', '')
    env['LD_LIBRARY_PATH'] = (str(vendor_prefix / 'lib') + ':' +
                              str(vendor_prefix / 'lib/x86_64-linux-gnu') + ':' +
                              env.get('LD_LIBRARY_PATH', ''))
    env.pop('FASTRTPS_DEFAULT_PROFILES_FILE', None)
    env.pop('RMW_FASTRTPS_PUBLICATION_MODE', None)
    env['DISPLAY'] = env.get('DISPLAY') or ':0'
    if not env.get('XAUTHORITY') or not Path(env['XAUTHORITY']).is_file():
        authorities = sorted(Path(f'/run/user/{os.getuid()}').glob('.mutter-Xwaylandauth.*'),
                             key=lambda path: path.stat().st_mtime)
        if authorities:
            env['XAUTHORITY'] = str(authorities[-1])
    env['QT_X11_NO_MITSHM'] = '1'
    env['ROS_LOG_DIR'] = str(folder / 'ros_logs')
    env['V4_SCENE_AUDIT_OUTPUT'] = str(folder / 'scene_actual_poses.json')
    manifest = {'version': 'v4_single_native_audit_2026-10-18', 'mode': args.mode,
                'world_source_sha256': sha(args.world),
                'world_sha256': sha(folder / 'world.sdf'),
                'map_seed': args.map_seed, 'policy_seed': args.policy_seed,
                'gazebo_seed': args.map_seed, 'map_generation': map_generation,
                'max_sim_seconds': args.max_sim_seconds, 'gui': args.gui,
                'ros_domain_id': domain, 'gazebo_master_uri': env['GAZEBO_MASTER_URI'],
                'rmw_implementation': env['RMW_IMPLEMENTATION'],
                'tf2_vendor_version': tf_version,
                'vendor_libraries_sha256': {str(p.relative_to(vendor_prefix)): sha(p) for p in
                                          sorted((vendor_prefix / 'lib').rglob('*.so*'))
                                          if p.is_file()},
                'behavior_tree_sha256': sha(folder / 'navigate_bounded.xml'),
                'return_behavior_tree_sha256': sha(folder / 'navigate_return.xml'),
                'robots': names, 'map_alignment': 'simulator_start_relation_validated_by_overlap',
                'runner_sha256': sha(Path(__file__)),
                'map_generator_sha256': sha(ROOT / 'scripts/map_variants.py'),
                'source_sha256': {str(p.relative_to(ROOT)): sha(p)
                                  for p in sorted((ROOT / 'src').rglob('*'))
                                  if p.is_file() and (p.suffix in ('.py', '.cpp', '.hpp', '.xml')
                                                     or p.name == 'CMakeLists.txt')}}
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    cmd = ['ros2', 'launch', 'active_slam_v4', 'v4_test.launch.py',
           f'run_dir:={folder}', f'world:={folder / "world.sdf"}',
           f'mode:={args.mode}', f'gui:={args.gui}',
           f'map_seed:={args.map_seed}', f'policy_seed:={args.policy_seed}',
           f'max_sim_seconds:={args.max_sim_seconds}']
    print(f'run_dir={folder}', flush=True)
    print(' '.join(cmd), flush=True)
    if args.dry_run:
        return
    log = (folder / 'launch.log').open('w', encoding='utf-8')
    proc = subprocess.Popen(cmd, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                            stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    (folder / 'launch.pid').write_text(str(proc.pid))
    audit_log = (folder / 'scene_audit.log').open('w', encoding='utf-8')
    audit_proc = subprocess.Popen([sys.executable, str(ROOT/'scripts/audit_scene.py'),
                                  '--run-dir', str(folder)], cwd=ROOT, env=env,
                                 stdout=audit_log, stderr=subprocess.STDOUT)
    (folder/'scene_audit.pid').write_text(str(audit_proc.pid))
    print(f'launch_pid={proc.pid} domain={domain} display={env["DISPLAY"]}', flush=True)
    if args.wait:
        raise SystemExit(proc.wait())


if __name__ == '__main__':
    main()
