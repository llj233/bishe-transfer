"""Verify the measured folded path has cusps and generated controllers honor them."""
from pathlib import Path
import json,sys,ast,yaml
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from run_test import make_configs

def test_native_folded_path_and_inversion_configuration(tmp_path):
 source=ROOT/'tests/fixtures/legacy_folded_path.json'
 p=json.loads(source.read_text())['poses'];xy=[(v['pose']['position']['x'],v['pose']['position']['y']) for v in p]
 cusps=[i for i in range(1,len(xy)-1) if sum((xy[i][a]-xy[i-1][a])*(xy[i+1][a]-xy[i][a]) for a in [0,1])<0]
 assert len(cusps)>=2
 make_configs('robot1',tmp_path)
 nav=yaml.safe_load((tmp_path/'robot1_nav2.yaml').read_text())
 c=nav['controller_server']['ros__parameters']
 for label in ['FollowPath','ReturnPath','ReturnTransitPath']:
  assert c[label]['enforce_path_inversion']
  assert c[label]['inversion_xy_tolerance']==.15
  assert c[label]['GoalAngleCritic']['enabled']
 for name in ['navigate_bounded.xml','navigate_return.xml','navigate_return_transit.xml']:
  assert 'hz="0.1"' in (tmp_path/name).read_text()
 # The robot generator is unchanged from the exact prior frozen snapshot.
 old=(ROOT/'tests/fixtures/legacy_run_test_reference.py').read_text()
 def model(text):return ast.dump(next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='make_model'))
 assert model(old)==model((ROOT/'scripts/run_test.py').read_text())
