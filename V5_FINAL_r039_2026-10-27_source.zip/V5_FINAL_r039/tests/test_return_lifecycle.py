import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src/active_slam_v4'))
from active_slam_v4.model import Pose2,Phase
from active_slam_v4.mission import Mission
from active_slam_v4.health import RecoveryEpisode

def test_transit_success_is_not_home():
 m=Mission(robots=('robot1',));m.phase=Phase.RETURN
 m.dispatch_return('robot1',Pose2(1,0),1,1.,True,final=False)
 m.on_navigation_result('robot1','success',2.)
 assert m.phase==Phase.RETURN and not m.returned['robot1']
 m.dispatch_return('robot1',Pose2(0,0),2,3.,True,final=True)
 m.on_navigation_result('robot1','success',4.)
 assert m.phase==Phase.COMPLETE and m.returned['robot1']

def test_real_departure_clears_episode_during_action():
 e=RecoveryEpisode(origin=Pose2(0,0),failures=2,escapes=3)
 assert not e.observe(Pose2(.3,0))
 assert e.escapes==3
 assert not e.observe(Pose2(1.1,0),100.)
 assert not e.observe(Pose2(1.2,0),109.)
 assert e.observe(Pose2(1.3,0),110.)
 assert e.origin is None and e.escapes==0
