from active_slam_v4.travel_cost import estimate_path
from active_slam_v4.model import Pose2
import math

def test_reverse_is_slower_and_cusp_is_charged():
 f=estimate_path([Pose2(0,0),Pose2(1,0)])
 b=estimate_path([Pose2(0,0),Pose2(-1,0)])
 assert f==b==1 and b.travel_time_s>f.travel_time_s
 c=estimate_path([Pose2(0,0),Pose2(1,0),Pose2(0,0)])
 assert c.forward_m==c.reverse_m==1 and c.cusps==1
 assert abs(c.travel_time_s-(1/.22+1/.08+1+2))<1e-8

def test_turn_time_and_yaw_wrap_are_physical():
 c=estimate_path([Pose2(0,0,math.pi-.05),Pose2(0,0,-math.pi+.05)])
 assert abs(c.travel_time_s-(.1/.6+2))<1e-8
 c=estimate_path([Pose2(0,0),Pose2(0,0,math.pi)])
 assert c.travel_time_s>7
