import math
from active_slam_v4.execution_context import ExecutionMemory,physical_context,path_signature
from active_slam_v4.health import RecoveryEpisode
from active_slam_v4.model import Pose2

def test_context_survives_slam_translation_and_rotation_but_not_new_approach():
 a=physical_context(Pose2(0,0),Pose2(2,2),Pose2(4,0))
 b=physical_context(Pose2(10,10,math.pi/2),Pose2(2,2),Pose2(10,14))
 m=ExecutionMemory()
 assert not m.failure(a,10,'blocked')
 assert m.failure(b,20,'controller_stall')
 assert m.blocked(a,21)
 assert not m.blocked(a,81)
 assert not m.blocked(physical_context(Pose2(0,0,math.pi),Pose2(2,2,math.pi),Pose2(-4,0)),21)

def test_old_failure_does_not_create_new_cooldown_or_blacklist_other_room():
 a=physical_context(Pose2(0,0),Pose2(0,0),Pose2(4,0))
 m=ExecutionMemory()
 m.failure(a,1,'blocked')
 assert not m.failure(a,62,'blocked')
 assert not m.blocked(a,63)
 assert not m.failure(a,63,'tf_stale')
 assert m.failure(a,64,'timeout')
 assert not m.blocked(physical_context(Pose2(3,0),Pose2(3,0),Pose2(4,0)),65)

def test_recovery_rejects_spin_and_out_and_back_and_terminal_success():
 e=RecoveryEpisode(origin=Pose2(0,0),failures=2,escapes=3)
 for t in range(20):assert not e.observe(Pose2(0,0,t),t)
 assert not e.observe(Pose2(1.1,0),20)
 assert not e.observe(Pose2(.5,0),29)
 assert not e.navigation_result(Pose2(1.1,0),'success',1.1)
 assert e.escapes==3
 assert not e.observe(Pose2(1.1,0),30)
 assert e.observe(Pose2(1.6,0),40)
 assert e.escapes==0

def test_path_cusps_are_kept_in_diagnostic_signature():
 path=[Pose2(0,0),Pose2(.3,0),Pose2(.6,0),Pose2(.3,0),Pose2(0,0)]
 assert path_signature(path)['cusps']==[3]
