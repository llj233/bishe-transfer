"""No-path must lead to bounded recovery even when no Nav2 action exists."""
from types import SimpleNamespace
from concurrent.futures import Future
from active_slam_v4.ros_runtime import TestExecutor as Executor
from active_slam_v4.mission import Mission
from active_slam_v4.model import Pose2,Phase
from active_slam_v4.health import RecoveryEpisode

def test_two_return_queries_without_path_queue_recovery_and_do_not_finish():
 m=Mission(robots=('robot1',));m.phase=Phase.RETURN
 published=[]
 state=SimpleNamespace(navigation_busy=lambda _:False,return_future=None,
  return_path_failures={'robot1':0},trigger_pub=SimpleNamespace(publish=published.append),
  mission=m,recovery_episodes={'robot1':RecoveryEpisode()},
  latest={'robot1':{'odom_pose':Pose2(1,1)}},pending_escape={})
 for now in [10.,12.]:
  f=Future();f.set_result(('robot1',Pose2(0,0),3,None,True));state.return_future=f
  Executor.schedule_return(state,now)
 assert state.pending_escape=={'robot1':12.}
 assert m.phase==Phase.RETURN and not m.returned['robot1']
 assert not m.active
 assert m.retries['robot1']==2
 assert len(published)==2
 assert any(e['event']=='return_no_path_escape_queued' for e in m.events)
