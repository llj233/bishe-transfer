#!/usr/bin/env python3
"""Publish a release pointer only after every frozen, predeclared gate passes.

This observer never edits source or replaces an experiment result. Failed
candidates produce a diagnostic notice, never a new baseline.
"""
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from source_freeze import hashes
C=ROOT/'campaigns/event_pipeline_2026-10-26'


def read(p):return json.loads(p.read_text())


def write(p,data):
    temporary=p.with_suffix('.publish.tmp')
    temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2))
    temporary.replace(p)


def main():
    while True:
        state=read(C/'CURRENT.json')
        if state['status'] in ('complete','needs_diagnosis'):break
        time.sleep(10)
    if state['status']!='complete':
        write(C/'NO_PROMOTION.json',{'reason':state,'retained_baseline':'r032',
            'next_action':'Inspect preserved failure/performance evidence; isolate and freeze next revision before rerunning. Optimization is not complete.'})
        return
    accepted=read(ROOT/'protocol/HEADLESS_ACCEPTED_CANDIDATE.json')
    frozen=read(ROOT/'protocol/HEADLESS_SEARCH_FREEZE.json')
    assert hashes()==frozen['sha256'],'Source changed after acceptance'
    from headless_runner import verify_operations, operations_hashes
    verify_operations()
    assert operations_hashes()==frozen['headless_operations_sha256']
    assert accepted['source_snapshot_id']==frozen['source_snapshot_id']
    profile=accepted['profile'];gate=read(C/f'{profile}_PAIRED_GATE.json')
    assert gate['passed'] and accepted['paired_gate']==gate
    rows=read(C/'COMPLETED.json');selected=[r for r in rows if r['profile']==profile]
    for r in selected:
        assert r.get('gui') is False and r.get('experiment_cohort')=='event_pipeline_2026-10-26'
        if not r['joint_success']:
            boot=(r.get('failure')=='startup_failure' or
                  (r.get('failure')=='runtime_error' and r.get('task_sim_s') is not None and r['task_sim_s']<=1.))
            assert boot and r.get('final_exploration_pct') is None,'Non-startup task failure'
            continue
        assert r['contact_sensors_verified'] and r['environment_contact_episodes']==0
        assert r['physical_home_error_m']<=.35
        assert r['final_exploration_pct']>95 and r['final_roi_pct']>90
        assert r['source_snapshot_id']==frozen['source_snapshot_id']
    valid=[r for r in selected if r['joint_success']]
    assert {r['world_id'] for r in valid if r['stage']=='functional'}=={'N05','N06'}
    pairs=[r for r in valid if r['stage']=='paired']
    assert len(pairs)==16
    assert {(r['world_id'],r['run_seed'],r['execution_policy']) for r in pairs}=={
        (w,s,a) for w in ['N01','N02','N03','N04'] for s in [29,47] for a in ['fast',profile]}
    release={'version':'r039','workspace':str(ROOT),'execution_policy':profile,
        'source_snapshot_id':frozen['source_snapshot_id'],
        'display_condition':'headless','experiment_cohort':'event_pipeline_2026-10-26',
        'operations_sha256':operations_hashes(),
        'previous_baseline':str(ROOT.parent/'V5_single_r032_speed_2026-10-24'),
        'previous_baseline_retained':True,'accepted_utc':datetime.now(timezone.utc).isoformat(),
        'paired_gate':gate,'all_actual_attempts':len(rows),'candidate_profile_attempts':len(selected),'aa_diagnostic_attempts':sum(x['profile']=='diagnostic_AA' for x in rows),
        'joint_successful_attempts':sum(x['joint_success'] for x in rows),'development_maps_only':True,
        'limits':'Two paired seeds on seen development maps and one functional seed on N05/N06; no guarantee of every future task or unseen-map generalization.'}
    write(ROOT/'protocol/HEADLESS_RELEASE.json',release)
    launcher=ROOT/'START_ACCEPTED_BASELINE.sh'
    launcher.write_text('#!/usr/bin/env bash\nset -e\ncd -- "$(dirname -- "${BASH_SOURCE[0]}")"\nsource /opt/ros/humble/setup.bash\nsource install/setup.bash\nexec python3 scripts/run_v5.py --gui false --execution-policy '+profile+' "$@"\n')
    launcher.chmod(0o755)
    write(ROOT.parent/'V5_CURRENT_BASELINE.json',release)
    with (ROOT.parent/'毕设版本索引.md').open('a') as out:
        out.write('\n- r039通过预声明全部验收，当前默认基线见V5_CURRENT_BASELINE.json；r032源代码和结果保留，未覆盖。\n')
    lines=['# r039验收与基线替换报告','',
        '无窗口候选通过全部预声明验收，全部速度参考也为无窗口；当前基线指针已更新，r032完整保留。',
        f"实际尝试{len(rows)}次（包含A/A），联合成功{sum(x.get('joint_success',False) for x in rows)}次。启动失败也保留在实际尝试分母。",'',
        '|地图|fast平均T95仿真秒|候选平均T95仿真秒|改善|','|---|---:|---:|---:|']
    for w,m in gate['means'].items():
        lines.append(f"|{w}|{m['control_mean']:.1f}|{m['candidate_mean']:.1f}|{100*m['relative_improvement']:.1f}%|")
    lines+=['','所有原始运行数据、建图PNG/PGM、参数和种子留在experiments中。',
        '这是已见开发地图上的两种子配对验收，不是未见地图泛化或每次任务必成功的证明。']
    (ROOT/'reports/event_pipeline_2026-10-26/最终验收与基线替换.md').write_text('\n'.join(lines)+'\n')


if __name__=='__main__':main()
