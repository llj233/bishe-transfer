"""Verify worker readiness wakes the serialized ROS executor, without Gazebo."""
import json
from pathlib import Path
import threading
import time
from concurrent.futures import Future,ThreadPoolExecutor
import rclpy
from rclpy.node import Node
from rclpy.executors import SingleThreadedExecutor
from active_slam_v4.ros_runtime import TestExecutor


def main():
    rclpy.init();node=Node('r039_decision_guard_probe')
    executor=SingleThreadedExecutor();executor.add_node(node)
    main_thread=threading.get_ident();callbacks=[];worker_threads=[]
    guard=node.create_guard_condition(lambda:callbacks.append(threading.get_ident()))
    node.decision_wakeup=guard;node.plan_ready_sim=None;node.now=lambda:10.
    worker=ThreadPoolExecutor(max_workers=1)
    def ready():
        worker_threads.append(threading.get_ident())
        TestExecutor.on_plan_ready(node,Future())
    worker.submit(ready).result(timeout=2.)
    assert not callbacks,'Worker executed the ROS callback inline'
    deadline=time.monotonic()+2.
    while not callbacks and time.monotonic()<deadline:executor.spin_once(timeout_sec=.05)
    assert callbacks==[main_thread] and worker_threads[0]!=main_thread
    assert node.plan_ready_sim==10.
    result={'passed':True,'worker_thread':worker_threads[0],'callback_thread':callbacks[0],
            'serialized_executor_thread':main_thread,'no_gazebo_or_gui':True}
    root=Path(__file__).resolve().parents[1]
    (root/'reports/guard_probe.json').write_text(json.dumps(result,indent=2))
    worker.shutdown();executor.shutdown();node.destroy_node();rclpy.shutdown()
    print(json.dumps(result))


if __name__=='__main__':main()
