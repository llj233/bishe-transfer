#!/usr/bin/env python3
"""Honest live report: smoke, development and formal results never pooled."""
import csv,json,datetime
import statistics,hashlib,subprocess
from pathlib import Path
from world_adapter import ROOT,WORLDS
from summarize_run import summarize

def main():
 out=ROOT/'reports';out.mkdir(exist_ok=True)
 rows=[]
 for result in sorted((ROOT/'experiments').rglob('result.json')):
  if 'ros_logs' in str(result):continue
  row=summarize(result.parent)
  row['infrastructure_diagnostic']=(result.parent/'infrastructure_diagnosis.json').exists()
  rows.append(row)
 completed_dirs={r['run_dir'] for r in rows}
 for manifest in sorted((ROOT/'experiments').rglob('manifest.json')):
  if str(manifest.parent) in completed_dirs:continue
  folder=manifest.parent;log=(folder/'launch.log').read_text(errors='replace') if (folder/'launch.log').exists() else ''
  ended=(folder/'process_exit.json').exists() or ('[test_executor-' in log and 'process has died' in log and 'sending signal' in log)
  if not ended:continue
  row=summarize(folder);row['infrastructure_diagnostic']=(folder/'infrastructure_diagnosis.json').exists();rows.append(row)
 if rows:
  keys=[k for k in rows[0] if k!='process_exit']
  with (out/'ALL_RUNS.csv').open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rows)
 for row in rows:
  review=Path(row['run_dir'])/'validity_review.json'
  assessment=json.loads(review.read_text()) if review.exists() else {}
  row['valid_for_formal']=assessment.get('valid_for_formal',row['split']=='formal')
  row['validity_category']=assessment.get('category','accepted_or_not_formal')
 if rows:
  with (out/'ALL_RUNS.csv').open('w',newline='') as f:
   keys=[k for k in rows[0] if k!='process_exit']
   w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader();w.writerows(rows)
 formal=[r for r in rows if r['split']=='formal' and r['valid_for_formal']]
 development=[r for r in rows if r['split']=='development']
 status={'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'formal_runs_completed':len(formal),'invalid_formal_runs':sum(r['split']=='formal' and not r['valid_for_formal'] for r in rows),'formal_joint_successes':sum(r['joint_success'] for r in formal),
  'development_runs_completed':len(development),'development_joint_successes':sum(r['joint_success'] for r in development),
  'smoke_runs_completed':sum(r['split']=='smoke' for r in rows),
  'status':'formal_not_started' if not formal else 'formal_complete' if len(formal)>=72 else 'formal_in_progress',
  'success_rate_claim':'No universal success guarantee; report finite paired sample results only',
  'worlds':{wid:json.loads((w.directory/'truth_audit.json').read_text()) for wid,w in WORLDS.items() if (w.directory/'truth_audit.json').exists()}}
 campaign=ROOT/'campaigns/V5_r024_2026-10-21/CURRENT.json'
 if campaign.exists():
  status['campaign']=json.loads(campaign.read_text())
  if status['campaign']['status']=='needs_diagnosis':status['status']='needs_diagnosis'
  elif status['campaign']['status']=='awaiting_user_approval':status['status']='formal_batch_complete_waiting_approval'
 control=ROOT/'campaigns/V5_r024_2026-10-21/BATCH_CONTROL.json'
 if control.exists():status['approved_batch']=json.loads(control.read_text())
 status['report_generator_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 (out/'STATUS.json').write_text(json.dumps(status,indent=2,ensure_ascii=False))
 lines=['# V5 单机实验进度与结果','',f'更新时间（UTC）：{status["updated_utc"]}','',
  '## 当前验收状态','', '冻结 r003 首批20次已结束（12成功、8失败）。当前 r019 只做用户选择的隔离修复回归，剩余52次尚未启动；修改后的结果不混入旧正式统计。','',f'正式运行完成 {len(formal)} 次；开发运行完成 {len(development)} 次。接口诊断不计为正式泛化成功率。','',
  '成功条件：可达空闲覆盖率严格超过 95%，ROI 已知率严格超过 90%，预算内返回部署点，物理位置误差不超过 0.35m。当前停止门槛使用评估真值，明确属于真值辅助停止。','',
  '## 全部已结束运行（保留失败）','','| 地图 | 阶段 | 方法 | 覆盖率% | ROI% | 时间s | 结果 |','|---|---|---|---:|---:|---:|---|']
 for r in rows:
  fmt=lambda v:'—' if v is None else f'{v:.2f}'
  lines.append(f'| {r["world_id"]} | {r["split"]} | {r["method"]} | {fmt(r["final_exploration_pct"])} | {fmt(r["final_roi_pct"])} | {fmt(r["task_sim_s"])} | {r["failure"] or r["status"]} |')
 lines+=['','## 复现与证据','',
  '每次运行保留独立目录、代码哈希、地图与真值哈希、配置、种子、部署点、CSV、事件、地图文件、导航健康状态和退出原因。失败不会从结果表删除。','',
  'M02 为有外部物理边界的 House 派生场景；M06 为有外部物理边界的 Willow 主楼派生场景。原模型及下载哈希保留，不能把它们表述成完全未修改的公开世界。','',
  '原 V4 冻结版本位于相邻独立目录；V5 构建、依赖覆盖层、资源与实验均在 V5 根目录内。','']
 (out/'实验报告_实时.md').write_text('\n'.join(lines))
 matrix={}
 for r in rows:
  reason=r['failure'] or ('success' if r['joint_success'] else 'final_coverage_or_physical_return_not_passed' if r['status']=='COMPLETE' else r['status'])
  key=(r['split'],r['world_id'],r['method'],reason);matrix[key]=matrix.get(key,0)+1
 with (out/'FAILURE_MATRIX.csv').open('w',newline='') as f:
  writer=csv.writer(f);writer.writerow(['split','world_id','method','result_or_failure','attempts'])
  for key,count in sorted(matrix.items()):writer.writerow([*key,count])
 map_rows=[]
 for wid in ['M01','M02','M03','M04','M05','M06']:
  for method in ['B0','B1','B2']:
   group=[r for r in formal if r['world_id']==wid and r['method']==method]
   if not group:continue
   n=len(group)
   map_rows.append({'world_id':wid,'method':method,'attempts':n,
    'joint_successes':sum(r['joint_success'] for r in group),'joint_success_rate':sum(r['joint_success'] for r in group)/n,
    'T95_not_reached':sum(r['T95_censored'] for r in group),
    'T95_capped_mean_s':statistics.mean(r['T95_sim_s'] if r['T95_sim_s'] is not None else r['budget_sim_s'] for r in group),
    'final_coverage_mean_pct':statistics.mean(r['final_exploration_pct'] if r['final_exploration_pct'] is not None else 0 for r in group),
    'coverage_auc_mean':statistics.mean(r['normalized_coverage_auc'] if r['normalized_coverage_auc'] is not None else 0 for r in group),
    'missing_map_metrics':sum(r['final_exploration_pct'] is None for r in group)})
 if map_rows:
  with (out/'FORMAL_PER_MAP.csv').open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=list(map_rows[0]));w.writeheader();w.writerows(map_rows)
  equal=[]
  for method in ['B0','B1','B2']:
   selected=[r for r in map_rows if r['method']==method]
   if not selected:continue
   equal.append({'method':method,'maps_observed':len(selected),'six_maps_complete':len(selected)==6 and all(r['attempts']>=4 for r in selected),
    'equal_map_joint_success_rate':statistics.mean(r['joint_success_rate'] for r in selected),
    'worst_map_joint_success_rate':min(r['joint_success_rate'] for r in selected),
    'equal_map_final_coverage_pct':statistics.mean(r['final_coverage_mean_pct'] for r in selected),
    'map_mean_coverage_sd':statistics.stdev(r['final_coverage_mean_pct'] for r in selected) if len(selected)>1 else 0,
    'equal_map_coverage_auc':statistics.mean(r['coverage_auc_mean'] for r in selected)})
  with (out/'FORMAL_EQUAL_MAP_SUMMARY.csv').open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=list(equal[0]));w.writeheader();w.writerows(equal)
  keys=sorted({(r['world_id'],r['spawn_id'],r['run_seed']) for r in formal})
  with (out/'FORMAL_PAIRED_RESULTS.csv').open('w',newline='') as f:
   fields=['world_id','spawn_id','run_seed']+[m+'_'+metric for m in ['B0','B1','B2'] for metric in ['joint_success','T95_sim_s','final_exploration_pct','physical_home_error_m']]
   writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
   for wid,spawn,seed in keys:
    row={'world_id':wid,'spawn_id':spawn,'run_seed':seed}
    for r in formal:
     if (r['world_id'],r['spawn_id'],r['run_seed'])==(wid,spawn,seed):
      for metric in ['joint_success','T95_sim_s','final_exploration_pct','physical_home_error_m']:row[r['method']+'_'+metric]=r[metric]
    writer.writerow(row)
 subprocess.run(['python3',str(ROOT/'scripts/plot_results.py')],check=False,stdout=subprocess.DEVNULL)
 subprocess.run(['python3',str(ROOT/'scripts/profile_report.py')],check=False,stdout=subprocess.DEVNULL)
 return status

if __name__=='__main__':main()
