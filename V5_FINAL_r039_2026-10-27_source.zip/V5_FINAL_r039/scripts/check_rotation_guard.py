#!/usr/bin/env python3
"""Physical corner-turn regression with real laser, gate and wall contacts."""
import os,json,signal,subprocess,time,uuid,xml.etree.ElementTree as ET
from pathlib import Path
import rclpy
from sensor_msgs.msg import LaserScan
from rclpy.qos import qos_profile_sensor_data
from geometry_msgs.msg import Twist
from gazebo_msgs.msg import ContactsState
from world_adapter import ROOT,environment
from run_test import make_configs

def run(guard,low_curb=False,projection=True,duration_s=5,curb_height_m=.09,curb_width_m=3.):
 folder=ROOT/'regressions'/('rotation_'+('guard' if guard else 'control')+'_'+uuid.uuid4().hex[:8]);folder.mkdir(parents=True)
 make_configs('robot1',folder);model=ET.parse(folder/'robot1.sdf').find('model');model.set('name','robot1');model.find('pose').text='0 0 .01 0 0 0'
 for ros in model.findall('.//plugin/ros'):
  ns=ros.find('namespace')
  if ns is None:ns=ET.SubElement(ros,'namespace')
  ns.text='/robot1'
 ET.SubElement(model,'plugin',{'name':'self_ray_mask','filename':str(ROOT/'install/gazebo_scene_audit/lib/libv5_self_ray_mask.so')})
 sensor=ET.SubElement(model.find('link[@name="base_link"]'),'sensor',{'name':'contact','type':'contact'});ET.SubElement(sensor,'always_on').text='true';ET.SubElement(sensor,'update_rate').text='20'
 ET.SubElement(ET.SubElement(sensor,'contact'),'collision').text='base_collision';plug=ET.SubElement(sensor,'plugin',{'name':'bumper','filename':'libgazebo_ros_bumper.so'});ros=ET.SubElement(plug,'ros');ET.SubElement(ros,'remapping').text='bumper_states:=/regression/contacts';ET.SubElement(plug,'frame_name').text='world'
 root=ET.Element('sdf',{'version':'1.6'});world=ET.SubElement(root,'world',{'name':'default'});ET.SubElement(ET.SubElement(world,'include'),'uri').text='model://ground_plane'
 wall=ET.SubElement(world,'model',{'name':'corner_wall'});ET.SubElement(wall,'static').text='true';ET.SubElement(wall,'pose').text=f'.8 0 {curb_height_m/2} 0 0 0' if low_curb else '-.23 0 .25 0 0 0';link=ET.SubElement(wall,'link',{'name':'wall'});g=ET.SubElement(ET.SubElement(link,'collision',{'name':'collision'}),'geometry');ET.SubElement(ET.SubElement(g,'box'),'size').text=f'.15 {curb_width_m} {curb_height_m}' if low_curb else '.04 3 .5'
 phy=ET.SubElement(world,'physics',{'name':'ode','type':'ode'});ET.SubElement(phy,'max_step_size').text='.001';ET.SubElement(phy,'real_time_update_rate').text='1000';world.append(model);ET.ElementTree(root).write(folder/'fixture.sdf',encoding='unicode')
 env=environment();env['ROS_DOMAIN_ID']=os.environ['ROS_DOMAIN_ID'];env['GAZEBO_MASTER_URI']='http://127.0.0.1:'+str(24500+int(uuid.uuid4().hex[:3],16));env['V5_PHYSICS_AUDIT']=str(folder/'physical.jsonl');env.pop('V5_TRUTH_OUTPUT',None);env.pop('V5_FLOOR_PROBES',None)
 node=rclpy.create_node('rotation_fixture');contacts=[];scans=[];outputs=[]
 subs=[node.create_subscription(ContactsState,'/regression/contacts',lambda m:contacts.append(any('corner_wall' in s.collision1_name or 'corner_wall' in s.collision2_name for s in m.states)),10),node.create_subscription(LaserScan,'/robot1/scan',lambda m:scans.append(time.monotonic()),qos_profile_sensor_data),node.create_subscription(Twist,'/robot1/cmd_vel',lambda m:outputs.append([m.linear.x,m.angular.z]),10)]
 relay=node.create_publisher(LaserScan,'/robot1/scan',qos_profile_sensor_data)
 if not projection:subs.append(node.create_subscription(LaserScan,'/robot1/scan_raw',lambda msg:relay.publish(msg),qos_profile_sensor_data))
 raw_front=[]
 subs.append(node.create_subscription(LaserScan,'/robot1/scan_raw',lambda m:raw_front.append(float(m.ranges[0])),qos_profile_sensor_data))
 pub=node.create_publisher(Twist,'/robot1/cmd_vel_unchecked' if guard else '/robot1/cmd_vel',10)
 processes=[]
 with (folder/'gazebo.log').open('w') as log:
  processes.append(subprocess.Popen(['gzserver','-s','libgazebo_ros_init.so','-s',str(ROOT/'install/gazebo_scene_audit/lib/libv5_audit.so'),str(folder/'fixture.sdf')],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True))
  gate_log=(folder/'gate.log').open('w')
  if projection:processes.append(subprocess.Popen(['ros2','run','active_slam_v4','project_near_ground','--ros-args','-p','use_sim_time:=true'],env=env,stdout=gate_log,stderr=subprocess.STDOUT,start_new_session=True))
  if guard:processes.append(subprocess.Popen(['ros2','run','active_slam_v4','single_safety_gate','--ros-args','-p','use_sim_time:=true'],env=env,stdout=gate_log,stderr=subprocess.STDOUT,start_new_session=True))
  try:
   start=time.monotonic();command_start=None;last_publish=-1e9
   while time.monotonic()-start<duration_s+12:
    rclpy.spin_once(node,timeout_sec=.05)
    if scans:
     if command_start is None:command_start=time.monotonic()
     if time.monotonic()-last_publish>=.05:
      command=Twist();command.linear.x=.26 if low_curb else 0.;command.angular.z=0. if low_curb else .6;pub.publish(command);last_publish=time.monotonic()
     if time.monotonic()-command_start>duration_s:break
  finally:
   for p in processes:
    if p.poll() is None:os.killpg(p.pid,signal.SIGINT)
   for p in processes:
    try:p.wait(10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   gate_log.close();node.destroy_node()
 rows=[json.loads(x) for x in (folder/'physical.jsonl').read_text().splitlines()] if (folder/'physical.jsonl').exists() else []
 result={'guard_enabled':guard,'low_curb':low_curb,'projection_enabled':projection,'curb_height_m':curb_height_m if low_curb else None,'curb_width_m':curb_width_m if low_curb else None,'raw_front_clear':all(x>2 for x in raw_front) if raw_front else False,'max_x':max(x['x'] for x in rows) if rows else None,'scan_messages':len(scans),'wall_contact_messages':sum(contacts),'physical_samples':len(rows),'max_abs_yaw':max(abs(x['yaw']) for x in rows) if rows else None,'nonzero_output_samples':sum(abs(v)+abs(w)>.01 for v,w in outputs),'folder':str(folder)}
 result['passed']=bool(rows) and bool(scans) and ((result['wall_contact_messages']==0 and result['max_abs_yaw']<.1) if guard else result['wall_contact_messages']>0)
 if low_curb:result['passed']=bool(rows) and bool(scans) and result['raw_front_clear'] and (result['wall_contact_messages']==0 and result['max_x']<.6 if projection else result['wall_contact_messages']>0)
 (folder/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True);return result
if __name__=='__main__':
 os.environ['ROS_DOMAIN_ID']='210';rclpy.init()
 try:results=[run(False),run(True)]
 finally:rclpy.shutdown()
 (ROOT/'regressions/ROTATION_GUARD_GATE.json').write_text(json.dumps({'passed':all(x['passed'] for x in results),'results':results},indent=2))
