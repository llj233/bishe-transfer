from pathlib import Path
import sys,json,hashlib,xml.etree.ElementTree as E,random,csv
r=Path(__file__).resolve().parents[1];sys.path[:0]=[str(r/'src/v4_evaluator')]
from v4_evaluator.truth import GroundTruth
if (r/'campaigns/p1_paired6/STARTED.json').exists():raise RuntimeError('Development queue started; geometry is immutable')
v4=r.parent/'V4_optimized_frozen_2026-10-18';records=[]
for p in sorted((v4/'experiments/single/room').glob('map_seed_*/policy_seed_*/*/world.sdf')):
 t=GroundTruth.from_sdf(p,[(-1.7,-2.5)],resolution=.2)
 records.append({'world':str(p),'reachable_m2':len(t.reachable_free)*.04})
reference=sum(x['reachable_m2'] for x in records)/len(records)
(r/'provenance/V4_AREA_REFERENCE.json').write_text(json.dumps({'reference_envelope_m':[20.15,20.15],'nominal_wall_centres_m':[-10,10,-10,10],'nominal_enclosed_area_m2':400,'resolution_m':.2,'inflation_m':.22,'reference_reachable_mean_m2':reference,'runs':records,'selection_rule':'20m x 20m wall-centre boundary; reachable area within +/-10% of V4 mean at identical .2m raster and .22m inflation'},indent=2))
def box(world,name,x,y,w,d,h=.8):
 m=E.SubElement(world,'model',name=name);E.SubElement(m,'static').text='true';E.SubElement(m,'pose').text=f'{x} {y} {h/2} 0 0 0';l=E.SubElement(m,'link',name='link')
 for kind in ['collision','visual']:
  q=E.SubElement(l,kind,name=kind);E.SubElement(E.SubElement(E.SubElement(q,'geometry'),'box'),'size').text=f'{w} {d} {h}'
  if kind=='visual':
   mat=E.SubElement(q,'material');E.SubElement(mat,'ambient').text='0.7 0.73 0.78 1';E.SubElement(mat,'diffuse').text='0.7 0.73 0.78 1'
seeds=[1001,1002,1003,1004,1005,2001,2002,3001,3002,3003,3004,3005];rows=[]
for index,seed in enumerate(seeds):
 root=E.Element('sdf',version='1.6');w=E.SubElement(root,'world',name='default')
 for uri in ['model://sun','model://ground_plane']:E.SubElement(E.SubElement(w,'include'),'uri').text=uri
 for a in [('west',-10,0,.15,20.15),('east',10,0,.15,20.15),('south',0,-10,20,.15),('north',0,10,20,.15)]:box(w,*a)
 # Wide doorways and no blind, unconnected regions. Layout changes are physical.
 rng=random.Random(seed);doors=[-5+rng.uniform(-.8,.8),5+rng.uniform(-.8,.8)];left=-9.925
 for j,d in enumerate(doors+[10.725]):
  end=d-.8
  if end>left:box(w,f'partition_x_{j}',0,(left+end)/2,.15,end-left)
  left=d+.8
 # A second, lateral partition produces an alternative cross-room route.
 side=-1 if seed%2 else 1;door=side*(4.5+rng.uniform(-.5,.5));lo,hi=sorted([side*9.925,side*.075]);last=lo
 for j,end in enumerate([door-.8,hi]):
  if end>last:box(w,f'partition_y_{j}',(last+end)/2,0,end-last,.15)
  last=door+.8
 placed=[]
 for j in range(6):
  for attempt in range(1000):
   x,y=rng.uniform(-8.5,8.5),rng.uniform(-8.5,8.5)
   if abs(x)<1.3 or abs(y)<1.3 or (x+1.7)**2+(y+2.5)**2<4 or any((x-a)**2+(y-b)**2<5 for a,b in placed):continue
   placed.append((x,y));box(w,f'obstacle_{j}',x,y,rng.uniform(.45,.7),rng.uniform(.45,.7),.6);break
  else:raise ValueError('obstacle rejection exhausted')
 path=r/'development_worlds'/f'room_{seed}.sdf';E.ElementTree(root).write(path,encoding='unicode')
 t=GroundTruth.from_sdf(path,[(-1.7,-2.5)],resolution=.2);area=len(t.reachable_free)*.04
 assert .9*reference<=area<=1.1*reference,(seed,area)
 rows.append({'world_id':f'R{seed}','geometry_seed':seed,'split':'development' if seed<2000 else 'validation' if seed<3000 else 'test','wall_centre_width_m':20,'wall_centre_height_m':20,'nominal_area_m2':400,'reachable_area_0p2m_m2':round(area,2),'relative_to_V4_mean':area/reference,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'path':str(path.relative_to(r)),'door_clear_width_m':1.6,'audit':'offline geometry passed; native truth, display and navigation pending'})
(r/'protocol/MAP_SELECTION.json').write_text(json.dumps({'reference':reference,'policy_seeds':[11,29,47],'maps':rows,'test_sealed':True,'selection_uses_exploration_outcome':False},indent=2))
with (r/'reports/地图面积对照.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
print('Map generation completed; adapters are declared independently in world_adapter.py')
