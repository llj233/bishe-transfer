#!/usr/bin/env python3
"""Read-only campaign status, optionally shown beside the Gazebo window."""
import argparse,csv,json,math,os
from pathlib import Path
from world_adapter import ROOT

CAMPAIGN=ROOT/'campaigns/V5_r028_compact_2026-10-22'

def get_progress():
 current=json.loads((CAMPAIGN/'CURRENT.json').read_text());data={'campaign':current}
 control=CAMPAIGN/'BATCH_CONTROL.json';data['formal_limit']=json.loads(control.read_text())['formal_attempt_limit'] if control.exists() else 0
 log=Path(current['job_log']) if current.get('job_log') else None
 if log and log.exists():
  folder=next((Path(s[8:]) for s in log.read_text().splitlines() if s.startswith('run_dir=')),None)
  if folder:
   data['run_dir']=str(folder);data['manifest']=json.loads((folder/'manifest.json').read_text())
   p=folder/'evaluation.csv'
   if p.exists():
    rows=list(csv.DictReader(p.open()));data['evaluation']=rows[-1] if rows else {}
   p=folder/'mission_events.jsonl'
   if p.exists():
    for s in reversed(p.read_text().splitlines()):
     try:data['event']=json.loads(s);break
     except json.JSONDecodeError:pass
   p=folder/'physical_audit.jsonl'
   if p.exists():
    with p.open('rb') as f:
     f.seek(max(0,p.stat().st_size-4096));last=f.read().decode(errors='replace').splitlines()
    for s in reversed(last):
     try:
      pose=json.loads(s);home=data['manifest']['deployment']['robot1']
      data['home_distance_m']=math.hypot(pose['x']-home[0],pose['y']-home[1]);data['sim_time']=pose['sim_time'];break
     except (json.JSONDecodeError,KeyError):pass
 completed=CAMPAIGN/'COMPLETED.json'
 finished=json.loads(completed.read_text()) if completed.exists() else []
 data['interface_completed']=sum(r['split']=='smoke' for r in finished)
 data['regression_completed']=sum(r['split']=='development' for r in finished)
 queue=CAMPAIGN/'QUEUE.json';data['regression_total']=len(json.loads(queue.read_text())['jobs']) if queue.exists() else 0
 data['formal_completed']=sum(r['split']=='formal' for r in json.loads(completed.read_text())) if completed.exists() else 0
 return data

def window():
 import tkinter as tk
 from tkinter import ttk
 root=tk.Tk();root.title('V5 单机实验 · 实时进度');root.geometry('440x390+20+75')
 root.configure(bg='#f0f5f7')
 title=tk.StringVar(value='读取实验状态…');details=tk.StringVar();free=tk.StringVar();roi=tk.StringVar();phase=tk.StringVar();distance=tk.StringVar();count=tk.StringVar()
 for variable,size in [(title,16),(details,11),(phase,13),(free,14)]:tk.Label(root,textvariable=variable,font=('DejaVu Sans',size),bg='#f0f5f7',fg='#133651',wraplength=420).pack(pady=7)
 bar=ttk.Progressbar(root,orient='horizontal',length=390,maximum=100);bar.pack(pady=4)
 for variable in [roi,distance,count]:tk.Label(root,textvariable=variable,font=('DejaVu Sans',11),bg='#f0f5f7',fg='#133651',wraplength=420).pack(pady=7)
 tk.Label(root,text='目标：探索率 >95% · ROI >90% · 返回部署点',bg='#f0f5f7',fg='#526575',wraplength=420).pack(pady=10)
 def refresh():
  try:
   d=get_progress();c=d['campaign'];m=d.get('manifest',{});e=d.get('evaluation',{});job=c.get('job',{})
   stages={'smoke':'接口检查','development':'紧凑地图验收','formal':'正式泛化测试'}
   title.set(stages.get(job.get('split'),c.get('status','准备中'))+' · '+job.get('method',''))
   details.set(f'{m.get("world_id","")} / {m.get("spawn_id","")} / seed {m.get("run_seed","")}')
   names={'STARTUP':'初始化','EXPLORE':'探索','RETURN':'返航','COMPLETE':'完成','FAILED':'失败'}
   state=d.get('event',{}).get('phase','STARTUP');phase.set(names.get(state,state)+f'  {d.get("sim_time",0):.1f} / {m.get("max_sim_seconds",0):.0f}s')
   pct=float(e.get('exploration_pct',0));free.set(f'地图探索率  {pct:.2f}%');bar['value']=pct
   roi.set(f'ROI 已知率  {float(e.get("roi_known_pct",0)):.2f}%')
   distance.set(f'距部署点  {d["home_distance_m"]:.3f}m' if 'home_distance_m' in d else '等待物理位置更新')
   count.set(f'开发回归 {d.get("regression_completed",0)}/16 · 正式实验 {d.get("formal_completed",0)}/36')
   if c['status']=='safety_validation':
    title.set('r024 · 物理安全验证中');details.set('正在检查旋转、9cm/3cm低障碍及窄障碍')
    phase.set('全部安全门通过后启动完整地图');free.set('完整探索尚未开始');bar['value']=0
    roi.set('地图、ROI与返航门槛保持原标准');distance.set('当前为独立物理夹具测试')
   elif c['status']=='needs_diagnosis':phase.set('需要诊断：数据已保留');details.set(c.get('error',''))
   elif c['status']=='awaiting_user_approval':title.set('首批实验已结束');phase.set('等待用户同意，后续实验未启动')
   elif c['status']=='paused_by_user':
    title.set('实验已按要求暂停');phase.set('第32次结束后暂停 · 剩余4次');details.set('等待用户继续指令，从第33次续跑');free.set('已记录32/36次结果');roi.set('冻结算法与结果已保存');distance.set('仿真与导航已停止');bar['value']=0
   elif c['status']=='complete':title.set('实验队列已结束')
  except Exception as error:details.set('等待状态更新：'+str(error)[:80])
  root.after(1500,refresh)
 refresh();root.mainloop()

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--window',action='store_true');parser.add_argument('--campaign',type=Path);args=parser.parse_args()
 if args.campaign:CAMPAIGN=args.campaign.resolve()
 if args.window:window()
 else:print(json.dumps(get_progress(),indent=2,ensure_ascii=False))
