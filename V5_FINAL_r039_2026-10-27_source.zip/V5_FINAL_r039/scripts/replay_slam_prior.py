#!/usr/bin/env python3
"""Controlled real slam_toolbox replay: recorded fused scans + odometry only."""
import os,json,math,subprocess,signal,time,uuid,sys
from pathlib import Path
import rclpy
from rclpy.node import Node
from rclpy.time import Time
from rclpy.qos import qos_profile_sensor_data
from rosgraph_msgs.msg import Clock
from geometry_msgs.msg import TransformStamped
from sensor_msgs.msg import LaserScan
from tf2_ros import TransformBroadcaster,StaticTransformBroadcaster,Buffer,TransformListener,TransformException
from world_adapter import ROOT
from run_test import make_configs

def stamp(t):
 c=Clock();c.clock.sec=int(t);c.clock.nanosec=int((t-int(t))*1e9);return c.clock

def main():
 parent=ROOT.parent/'V5_single_r006_2026-10-21'
 trace=next((parent/'experiments/development/M06/S02/seed_29/B2').rglob('laser_guard_trace.jsonl'))
 rows=[json.loads(s) for s in trace.read_text().splitlines()];rows=[r for r in rows if r['odom'] and r['sim_time']<=160]
 folder=ROOT/'regressions'/('slam_prior_replay_'+uuid.uuid4().hex[:8]);folder.mkdir(parents=True);make_configs('robot1',folder)
 os.environ['ROS_DOMAIN_ID']='211';rclpy.init();node=Node('slam_prior_replayer');clock=node.create_publisher(Clock,'/clock',10);scan=node.create_publisher(LaserScan,'/robot1/scan',qos_profile_sensor_data)
 broadcaster=TransformBroadcaster(node);static=StaticTransformBroadcaster(node);buffer=Buffer();listener=TransformListener(buffer,node)
 fixed=TransformStamped();fixed.header.frame_id='robot1/base_footprint';fixed.child_frame_id='robot1/base_scan';fixed.transform.translation.x=-.064;fixed.transform.translation.z=.131;fixed.transform.rotation.w=1.;static.sendTransform(fixed)
 samples=[]
 def spin_for(seconds):
  end=time.monotonic()+seconds
  while time.monotonic()<end:rclpy.spin_once(node,timeout_sec=min(.01,max(0,end-time.monotonic())))
 with (folder/'slam.log').open('w') as log:
  p=subprocess.Popen(['ros2','run','slam_toolbox','async_slam_toolbox_node','--ros-args','-r','__ns:=/robot1','-r','__node:=slam_toolbox','--params-file',str(folder/'robot1_slam.yaml')],env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   for _ in range(30):clock.publish(Clock());spin_for(.1)
   for row in rows:
    t=row['sim_time'];x,y,yaw=row['odom'];s=stamp(t);clock.publish(Clock(clock=s))
    tf=TransformStamped();tf.header.stamp=s;tf.header.frame_id='robot1/odom';tf.child_frame_id='robot1/base_footprint';tf.transform.translation.x=x;tf.transform.translation.y=y;tf.transform.rotation.z=math.sin(yaw/2);tf.transform.rotation.w=math.cos(yaw/2);broadcaster.sendTransform(tf)
    msg=LaserScan();msg.header.stamp=s;msg.header.frame_id='robot1/base_scan';msg.angle_min=row['angle_min'];msg.angle_increment=row['angle_increment'];msg.angle_max=msg.angle_min+msg.angle_increment*(len(row['ranges'])-1);msg.range_min=row['range_min'];msg.range_max=row['range_max'];msg.scan_time=1/3;msg.ranges=[float(v) for v in row['ranges']];scan.publish(msg);spin_for(.09)
    try:
     tr=buffer.lookup_transform('robot1/map','robot1/odom',Time()).transform;q=tr.rotation;a=2*math.atan2(q.z,q.w);expected_x=tr.translation.x+math.cos(a)*x-math.sin(a)*y;expected_y=tr.translation.y+math.sin(a)*x+math.cos(a)*y
     samples.append({'sim_time':t,'correction_distance_at_robot_m':math.hypot(expected_x-x,expected_y-y),'yaw_correction_rad':abs(math.atan2(math.sin(a),math.cos(a)))})
    except TransformException:pass
   spin_for(1.)
  finally:
   if p.poll() is None:os.killpg(p.pid,signal.SIGINT)
   try:p.wait(10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   node.destroy_node();rclpy.shutdown()
 peak=max((s['correction_distance_at_robot_m'] for s in samples),default=math.inf)
 result={'passed':len(samples)>100 and peak<1.,'scope':'Recorded fused-scan and ideal-odometry SLAM replay only, not exploration success','source_trace':str(trace),'samples':len(samples),'peak_position_correction_m':peak,'last':samples[-1] if samples else None,'folder':str(folder)}
 (folder/'corrections.json').write_text(json.dumps(samples,indent=2));(folder/'result.json').write_text(json.dumps(result,indent=2));(ROOT/'regressions/SLAM_PRIOR_REPLAY_GATE.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
 if not result['passed']:raise SystemExit(1)
if __name__=='__main__':main()
