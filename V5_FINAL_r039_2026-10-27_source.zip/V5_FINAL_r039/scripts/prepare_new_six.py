#!/usr/bin/env python3
"""Audit external source geometry before any new-map exploration outcome."""
import json,os,signal,subprocess,time,csv,hashlib
from pathlib import Path
from world_adapter import ROOT,WORLDS,environment
from prepare_worlds import prepare

def floor_preflight():
 adapter=WORLDS['N05'];world=adapter.prepare();evidence=adapter.directory/'floor_preflight';evidence.mkdir(exist_ok=False)
 env=environment();env.update(V5_TRUTH_OUTPUT=str(evidence/'collision'),V5_FLOOR_PROBES='0 0;1 0',V5_FLOOR_Z='.01',GAZEBO_MASTER_URI='http://127.0.0.1:28705',IGN_PARTITION='r032_n05_floor',GZ_PARTITION='r032_n05_floor')
 for key in ['V5_PHYSICS_AUDIT']:env.pop(key,None)
 with (evidence/'gazebo.log').open('x') as log:
  proc=subprocess.Popen(['gzserver','-s',str(ROOT/'install/gazebo_scene_audit/lib/libv5_audit.so'),str(world)],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   deadline=time.monotonic()+90;output=evidence/'collision.floor.json'
   while not output.exists():
    if proc.poll() is not None:raise RuntimeError('Floor preflight process exited')
    if time.monotonic()>deadline:raise TimeoutError('Floor preflight90s')
    time.sleep(.3)
   data=json.loads(output.read_text());assert data['passed'] and abs(data['floor_z']-.01)<.001
   data['evidence_dir']=str(evidence);(adapter.directory/'floor_audit.json').write_text(json.dumps(data,indent=2))
  finally:
   if proc.poll() is None:os.killpg(proc.pid,signal.SIGINT)
   try:proc.wait(15)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()

def main():
 if (ROOT/'protocol/NEW_SIX_AUDIT_COMPLETE.json').exists():raise RuntimeError('Native audit already exists; do not overwrite')
 floor_preflight()
 for wid in ['N01','N02','N03','N04','N05','N06']:prepare(wid)
 subprocess.run(['python3',str(ROOT/'scripts/audit_floor_datums.py'),'--maps','N01','N02','N03','N04','N05','N06'],check=True)
 subprocess.run(['python3',str(ROOT/'display_checks/check_all_maps.py'),'--maps','N01','N02','N03','N04','N05','N06'],check=True)
 gate=json.loads((ROOT/'display_checks/r032_new_six/DISPLAY_GATE.json').read_text());assert gate['passed']
 rows=[];locks={}
 for wid in ['N01','N02','N03','N04','N05','N06']:
  folder=WORLDS[wid].directory;a=json.loads((folder/'truth_audit.json').read_text());assert not a['component_touches_edge']
  rows.append({'world_id':wid,'name':WORLDS[wid].name,'reachable_area_m2':a['reachable_area_m2'],'ROI_m2':round(a['roi_cells']*.01,2),'spawn':a['spawns']['S01'],'floor_z':a['floor_z'],'task_budget_sim_s':1800,'native_display_passed':True})
  for leaf in ['world.sdf','truth.npz','truth_audit.json','floor_audit.json','manifest.json']:
   q=folder/leaf;locks[str(q.relative_to(ROOT))]=hashlib.sha256(q.read_bytes()).hexdigest()
 with (ROOT/'reports/新六张地图原生核验.csv').open('w',encoding='utf-8-sig',newline='') as out:
  writer=csv.DictWriter(out,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 (ROOT/'protocol/ASSET_LOCK.json').write_text(json.dumps(locks,indent=2))
 (ROOT/'protocol/NEW_SIX_AUDIT_COMPLETE.json').write_text(json.dumps({'passed':True,'rows':rows,'not_formal_navigation_gate':True},indent=2))
if __name__=='__main__':main()
