#!/usr/bin/env python3
"""Virtual-only regression: overlap robot body with a wall, check real contacts.

The same fixture runs with and without the self-ray mask. It is not an
exploration trial, and is stored outside experiments/formal.
"""
import json,os,signal,subprocess,time,xml.etree.ElementTree as ET,uuid
from pathlib import Path
import rclpy
from gazebo_msgs.msg import ContactsState
from world_adapter import ROOT,environment
from run_test import make_configs

def run(mask):
 folder=ROOT/'regressions'/('physical_contacts_'+('masked' if mask else 'control')+'_'+uuid.uuid4().hex[:8]);folder.mkdir(parents=True)
 make_configs('robot1',folder)
 model=ET.parse(folder/'robot1.sdf').find('model');model.set('name','robot1');model.find('pose').text='.75 0 .01 0 0 0'
 if mask:ET.SubElement(model,'plugin',{'name':'v5_single_self_ray_mask','filename':str(ROOT/'install/gazebo_scene_audit/lib/libv5_self_ray_mask.so')})
 body=model.find('link[@name="base_link"]')
 sensor=ET.SubElement(body,'sensor',{'name':'regression_body_contacts','type':'contact'})
 ET.SubElement(sensor,'always_on').text='true';ET.SubElement(sensor,'update_rate').text='20'
 ET.SubElement(ET.SubElement(sensor,'contact'),'collision').text='base_collision'
 plugin=ET.SubElement(sensor,'plugin',{'name':'bumper','filename':'libgazebo_ros_bumper.so'})
 ros=ET.SubElement(plugin,'ros');ET.SubElement(ros,'remapping').text='bumper_states:=/v5/regression_contacts'
 ET.SubElement(plugin,'frame_name').text='world'
 root=ET.Element('sdf',{'version':'1.6'});world=ET.SubElement(root,'world',{'name':'default'})
 ET.SubElement(ET.SubElement(world,'include'),'uri').text='model://ground_plane'
 wall=ET.SubElement(world,'model',{'name':'regression_wall'});ET.SubElement(wall,'static').text='true';ET.SubElement(wall,'pose').text='.8 0 .25 0 0 0'
 link=ET.SubElement(wall,'link',{'name':'wall'});geo=ET.SubElement(ET.SubElement(link,'collision',{'name':'collision'}),'geometry');ET.SubElement(ET.SubElement(geo,'box'),'size').text='.1 3 .5'
 physics=ET.SubElement(world,'physics',{'type':'ode','name':'ode'});ET.SubElement(physics,'max_step_size').text='.001';ET.SubElement(physics,'real_time_update_rate').text='1000'
 world.append(model);ET.ElementTree(root).write(folder/'fixture.sdf',encoding='unicode')
 env=environment();env['ROS_DOMAIN_ID']=os.environ['ROS_DOMAIN_ID'];env['GAZEBO_MASTER_URI']='http://127.0.0.1:'+str(18000+int(uuid.uuid4().hex[:3],16));env['V5_PHYSICS_AUDIT']=str(folder/'physical.jsonl');env.pop('V5_RAY_DIAGNOSTIC',None)
 node=rclpy.create_node('contact_fixture_observer');messages=[]
 sub=node.create_subscription(ContactsState,'/v5/regression_contacts',lambda msg:messages.append({'count':len(msg.states),'pairs':[[s.collision1_name,s.collision2_name] for s in msg.states]}),10)
 with (folder/'gazebo.log').open('w') as log:
  proc=subprocess.Popen(['gzserver','-s','libgazebo_ros_init.so','-s',str(ROOT/'install/gazebo_scene_audit/lib/libv5_audit.so'),str(folder/'fixture.sdf')],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  start=time.monotonic()
  while time.monotonic()-start<12 and proc.poll() is None:rclpy.spin_once(node,timeout_sec=.1)
 finally:
  if proc.poll() is None:os.killpg(proc.pid,signal.SIGINT)
  try:proc.wait(10)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
  node.destroy_node()
 rows=[json.loads(s) for s in (folder/'physical.jsonl').read_text().splitlines()] if (folder/'physical.jsonl').exists() else []
 wall_contacts=[m for m in messages if any('regression_wall' in a or 'regression_wall' in b for a,b in m['pairs'])]
 result={'mask_enabled':mask,'received_contact_messages':len(messages),'wall_contact_messages':len(wall_contacts),'first_x':rows[0]['x'] if rows else None,'last_x':rows[-1]['x'] if rows else None,'passed':bool(wall_contacts) and bool(rows) and rows[-1]['x']<.74,'folder':str(folder)}
 (folder/'result.json').write_text(json.dumps(result,indent=2));(folder/'contacts.json').write_text(json.dumps(messages));print(json.dumps(result),flush=True)
 return result

if __name__=='__main__':
 os.environ['ROS_DOMAIN_ID']='77';rclpy.init()
 try:results=[run(False),run(True)]
 finally:rclpy.shutdown()
 (ROOT/'regressions/PHYSICAL_CONTACT_GATE.json').write_text(json.dumps({'passed':all(r['passed'] for r in results),'results':results},indent=2))
