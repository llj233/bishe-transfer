#!/usr/bin/env python3
"""Analytic Gazebo regression for thin legs and multiple observation heights."""
import json,os,signal,subprocess,time,uuid,xml.etree.ElementTree as ET
import numpy as np
from world_adapter import ROOT,environment

def main(floor_z=0.):
 folder=ROOT/'regressions'/('truth_sampling_'+uuid.uuid4().hex[:8]);folder.mkdir(parents=True)
 root=ET.Element('sdf',{'version':'1.6'});world=ET.SubElement(root,'world',{'name':'default'})
 ground=ET.SubElement(world,'include');ET.SubElement(ground,'uri').text='model://ground_plane';ET.SubElement(ground,'pose').text=f'0 0 {floor_z} 0 0 0'
 def box(name,x,y,z,w,d,h):
  m=ET.SubElement(world,'model',{'name':name});ET.SubElement(m,'static').text='true'
  ET.SubElement(m,'pose').text=f'{x} {y} {z+floor_z} 0 0 0';link=ET.SubElement(m,'link',{'name':'link'})
  g=ET.SubElement(ET.SubElement(link,'collision',{'name':'collision'}),'geometry')
  ET.SubElement(ET.SubElement(g,'box'),'size').text=f'{w} {d} {h}'
 for name,x,y,w,d in [('west',-2,0,.1,4.1),('east',2,0,.1,4.1),('south',0,-2,4.1,.1),('north',0,2,4.1,.1)]:box(name,x,y,.3,w,d,.6)
 box('thin_leg_between_cell_diagonals',-.025,-.05,.1,.012,.012,.2)
 box('low_obstacle',.65,.65,.025,.08,.08,.05)
 box('body_height_overhang',-.65,.65,.12,.08,.08,.02)
 box('unrelated_high_overhang',-1.25,-.65,.30,.08,.08,.04)
 box('above_robot',.65,-.65,.8,.08,.08,.08)
 ET.ElementTree(root).write(folder/'fixture.sdf',encoding='unicode')
 env=environment();env['V5_TRUTH_OUTPUT']=str(folder/'collision');env['GAZEBO_MASTER_URI']='http://127.0.0.1:24999'
 env.pop('V5_PHYSICS_AUDIT',None);env.pop('V5_RAY_DIAGNOSTIC',None);env.pop('V5_FLOOR_PROBES',None);env['V5_FLOOR_Z']=str(floor_z)
 with (folder/'gazebo.log').open('w') as log:
  proc=subprocess.Popen(['gzserver','--verbose','-s',str(ROOT/'install/gazebo_scene_audit/lib/libv5_audit.so'),str(folder/'fixture.sdf')],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   start=time.monotonic()
   while not (folder/'collision.json').exists():
    if proc.poll() is not None:raise RuntimeError('Gazebo fixture exited')
    if time.monotonic()-start>60:raise TimeoutError('Truth fixture watchdog')
    time.sleep(.1)
  finally:
   if proc.poll() is None:os.killpg(proc.pid,signal.SIGINT)
   try:proc.wait(10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
 meta=json.loads((folder/'collision.json').read_text());raw=np.fromfile(folder/'collision.bin',np.uint8).reshape(meta['height'],meta['width'])
 checks=[]
 for name,x,y,expected in [('thin_leg',-.025,-.05,True),('low_obstacle',.65,.65,True),('overhang',-.65,.65,True),('unrelated_0p30m_overhang',-1.25,-.65,False),('above_body',.65,-.65,False),('ordinary_free',1.15,1.15,False)]:
  ix=int((x-meta['origin'][0])/meta['resolution']);iy=int((y-meta['origin'][1])/meta['resolution'])
  observed=bool(raw[iy,ix]);checks.append({'case':name,'occupied':observed,'expected_occupied':expected,'passed':observed==expected})
 result={'floor_z':floor_z,'passed':all(c['passed'] for c in checks),'checks':checks,'folder':str(folder),'sampling':meta.get('cell_sampling'),
  'limitations':['Heights are finite samples; structures entirely between sampled heights require an additional audit','Grid truth uses conservative raster inflation, not exact continuous configuration space']}
 (folder/'result.json').write_text(json.dumps(result,indent=2));(ROOT/'regressions/TRUTH_SAMPLING_GATE.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
 return 0 if result['passed'] else 1

if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--floor-z',type=float,default=0.);args=parser.parse_args()
 raise SystemExit(main(args.floor_z))
