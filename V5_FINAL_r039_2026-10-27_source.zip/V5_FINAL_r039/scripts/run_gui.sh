#!/usr/bin/env bash
set -e
task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
source /opt/ros/humble/setup.bash
source "$task_root/install/local_setup.bash"
cd "$task_root"
exec python3 scripts/run_v5.py --world-id D09 --spawn-id S01 --run-seed 13 --method B2 --split development --contact-sensors --gui true --max-sim-seconds 900 --wait "$@"
