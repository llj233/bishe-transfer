#!/usr/bin/env python3
"""Pinned public resources; never changes the frozen V4 or system ROS."""
from pathlib import Path
import concurrent.futures, hashlib, json, tarfile, urllib.request, time

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'resources'
SPECS = [
 ('tb3','ROBOTIS-GIT/turtlebot3_simulations','a35a56c8b04877dc89772b598084d8ce648a9023',None),
 ('warehouse','aws-robotics/aws-robomaker-small-warehouse-world','ee0af733315e78432408c3cd98d378ecee5f767c',None),
 ('bookstore','aws-robotics/aws-robomaker-bookstore-world','f5a2aaacd5418f9ecfa30f79e788856417f17c13',None),
 ('hospital','aws-robotics/aws-robomaker-hospital-world','7161eb8448f5cba6a469da7a79ae5d660b0b7f58',None),
 ('gazebo_classic','gazebosim/gazebo-classic','b22c6e15e52299865b31093b8feebc9ca19e26e8',['worlds/willowgarage.world','LICENSE']),
 ('gazebo_models','osrf/gazebo_models','8163eb4b5e7e21985c6591d1c0bfb56468c0093f',['willowgarage/','ground_plane/','sun/']),
 ('map_plugin','robotics-upo/gazebo_ros2_2Dmap_plugin','74a8939e09f0aeeec63e221875429b2ea5e45f7d',None),
]

def get(url, target=None):
 for attempt in range(4):
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'V5-reproducible-experiment'}),timeout=90) as response:
    if target:
     with target.open('wb') as out:
      while True:
       block=response.read(1024*1024)
       if not block: break
       out.write(block)
     return
    return response.read()
  except Exception:
   if attempt==3: raise
   time.sleep(2*(attempt+1))

def fetch(spec):
 name,repo,ref,selected=spec
 folder=DEST/name; folder.mkdir(parents=True,exist_ok=True)
 lock=folder/'RESOURCE_LOCK.json'
 if lock.exists(): return name+' already locked'
 commit=json.loads(get(f'https://api.github.com/repos/{repo}/commits/{ref}'))['sha']
 print(f'{name}: {commit}',flush=True)
 if selected:
  tree=json.loads(get(f'https://api.github.com/repos/{repo}/git/trees/{commit}?recursive=1'))
  if tree.get('truncated'): raise RuntimeError('Truncated source tree')
  for item in tree['tree']:
   p=item['path']
   if item['type']!='blob' or not any(p==s or p.startswith(s) for s in selected): continue
   dest=folder/p;dest.parent.mkdir(parents=True,exist_ok=True)
   get(f'https://raw.githubusercontent.com/{repo}/{commit}/{p}',dest)
 else:
  archive=DEST/(name+'.tar.gz')
  get(f'https://codeload.github.com/{repo}/tar.gz/{commit}',archive)
  with tarfile.open(archive) as tar:
   for member in tar:
    tail=member.name.split('/',1)
    if len(tail)<2 or not tail[1]: continue
    member.name=tail[1]
    if member.issym() or member.islnk() or '..' in Path(member.name).parts: raise RuntimeError('Unsafe archive member')
    tar.extract(member,folder)
  archive.unlink()
 hashes={str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(folder.rglob('*')) if p.is_file()}
 lock.write_text(json.dumps({'repository':repo,'commit':commit,'files_sha256':hashes},indent=2))
 return f'{name}: {len(hashes)} files locked'

if __name__=='__main__':
 DEST.mkdir(exist_ok=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  futures={pool.submit(fetch,s):s[0] for s in SPECS}
  for future in concurrent.futures.as_completed(futures):
   try: print(future.result(),flush=True)
   except Exception as exc: print(f'FAILED {futures[future]}: {exc}',flush=True)
