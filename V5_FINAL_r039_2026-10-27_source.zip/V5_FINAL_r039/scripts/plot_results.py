#!/usr/bin/env python3
"""Standalone coverage figures and full-scope maps made only from SLAM cells."""
import csv,json,shutil,os,sys
from pathlib import Path
import numpy as np,yaml
from PIL import Image
from world_adapter import ROOT
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'reports/.mplconfig'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def full_scope_map(folder):
 if not (folder/'fused_slam_map.pgm').exists():return
 cached=folder/'full_scope_built_map_preview_8x.png'
 if cached.exists() and cached.stat().st_mtime>=(folder/'fused_slam_map.pgm').stat().st_mtime:return
 truth=np.load(folder/'truth.npz');yy,xx=np.where(truth['roi'])
 x0=max(0,int(xx.min())-3);x1=min(truth['roi'].shape[1],int(xx.max())+4)
 y0=max(0,int(yy.min())-3);y1=min(truth['roi'].shape[0],int(yy.max())+4)
 res=float(truth['resolution']);ox,oy=truth['origin']
 y,x=np.mgrid[y0:y1,x0:x1];wx=ox+(x+.5)*res;wy=oy+(y+.5)*res
 cfg=yaml.safe_load((folder/'fused_slam_map.yaml').read_text());sx,sy,a=cfg['origin'];r=cfg['resolution']
 raw=np.flipud(np.asarray(Image.open(folder/'fused_slam_map.pgm')))
 dx,dy=wx-sx,wy-sy
 ix=np.floor((np.cos(a)*dx+np.sin(a)*dy)/r).astype(int);iy=np.floor((-np.sin(a)*dx+np.cos(a)*dy)/r).astype(int)
 valid=(ix>=0)&(iy>=0)&(ix<raw.shape[1])&(iy<raw.shape[0])
 data=np.full(ix.shape,205,np.uint8);data[valid]=raw[iy[valid],ix[valid]]
 Image.fromarray(np.flipud(data)).save(folder/'full_scope_built_map.pgm')
 colors=np.empty((*data.shape,3),np.uint8);colors[:]=[241,190,95];colors[data==254]=[224,244,255];colors[data==0]=[25,32,42]
 im=Image.fromarray(np.flipud(colors));im.resize((im.width*8,im.height*8),Image.NEAREST).save(folder/'full_scope_built_map_preview_8x.png')
 (folder/'full_scope_built_map.yaml').write_text(yaml.safe_dump({'image':'full_scope_built_map.pgm','resolution':res,'origin':[float(ox+x0*res),float(oy+y0*res),0.0],'negate':0,'occupied_thresh':.65,'free_thresh':.196}))
 (folder/'report_canvas.json').write_text(json.dumps({'uses_truth_extent_only':True,'occupancy_source':'SLAM PGM only; no ground-truth obstacles copied','original_slam_map_retained':True,'unknown_outside_slam_extent':True,'scale':8,'palette':'frozen V4'},indent=2))

def main():
 out=ROOT/'reports';csv_file=out/'ALL_RUNS.csv'
 if not csv_file.exists():return
 rows=list(csv.DictReader(csv_file.open()))
 for row in rows:full_scope_map(Path(row['run_dir']))
 successes=[row for row in rows if row['joint_success']=='True' and row['split']!='smoke' and row.get('valid_for_formal','True')!='False' or row['joint_success']=='True' and row['split']=='development']
 if successes:
  last=max(successes,key=lambda r:Path(r['run_dir']).name);folder=Path(last['run_dir'])
  if (folder/'full_scope_built_map_preview_8x.png').exists():shutil.copy2(folder/'full_scope_built_map_preview_8x.png',out/'latest_success_built_map.png')
  (out/'LATEST_SUCCESS.json').write_text(json.dumps(last,indent=2))
 dev=[row for row in rows if row['split']=='development']
 if dev:
  fig,ax=plt.subplots(figsize=(8.5,4.8))
  for row in dev:
   p=Path(row['run_dir'])/'evaluation.csv'
   if not p.exists():continue
   ev=list(csv.DictReader(p.open()));ax.plot([float(e['sim_time']) for e in ev],[float(e['exploration_pct']) for e in ev],label=row['world_id']+' / '+row['method']+' / seed '+row['run_seed'])
  ax.axhline(95,color='#bb5533',ls='--',lw=1,label='95% target')
  ax.set(xlabel='Simulation time (s)',ylabel='Reachable-free coverage (%)',ylim=(0,101),title='Development examples (not a formal generalization comparison)');ax.grid(alpha=.2);ax.legend(fontsize=8)
  fig.tight_layout();fig.savefig(out/'development_coverage_curves.png',dpi=180);fig.savefig(out/'development_coverage_curves.svg');plt.close(fig)
 formal=[row for row in rows if row['split']=='formal' and row.get('valid_for_formal','True')!='False']
 if formal:
  fig,axs=plt.subplots(3,2,figsize=(12,12))
  palette={'B0':'#777777','B1':'#2774a7','B2':'#0a8b6f'}
  for wid,ax in zip(['M01','M02','M03','M04','M05','M06'],axs.ravel()):
   for row in formal:
    if row['world_id']!=wid:continue
    p=Path(row['run_dir'])/'evaluation.csv'
    if not p.exists():continue
    ev=list(csv.DictReader(p.open()));ax.plot([float(e['sim_time']) for e in ev],[float(e['exploration_pct']) for e in ev],color=palette[row['method']],alpha=.65,lw=1)
   ax.axhline(95,color='#bb5533',ls='--',lw=.7);ax.set(title=wid,xlabel='Simulation time (s)',ylabel='Coverage (%)',ylim=(0,101));ax.grid(alpha=.2)
  from matplotlib.lines import Line2D
  fig.legend([Line2D([0],[0],color=c) for c in palette.values()],list(palette),loc='upper center',ncol=3)
  fig.tight_layout(rect=(0,0,1,.97));fig.savefig(out/'formal_coverage_curves.png',dpi=180);fig.savefig(out/'formal_coverage_curves.svg');plt.close(fig)

if __name__=='__main__':main()
