#!/usr/bin/env python3
"""Offline runtime diagnostics; never changes control or formal inclusion."""
import csv,json,statistics,math
from collections import defaultdict
from pathlib import Path
from world_adapter import ROOT

def rows(path):
 return list(csv.DictReader(path.open())) if path.exists() else []
def lines(path):
 if not path.exists():return []
 out=[]
 for s in path.read_text().splitlines():
  try:out.append(json.loads(s))
  except json.JSONDecodeError:pass
 return out
def quantile(v,q):
 if not v:return None
 a=sorted(v);pos=(len(a)-1)*q;lo=math.floor(pos);hi=math.ceil(pos)
 return a[lo]*(hi-pos)+a[hi]*(pos-lo) if lo!=hi else a[lo]
def save(path,data):
 if not data:return
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
def main():
 roles=[];runs=[]
 for p in sorted((ROOT/'experiments').rglob('summary.json')):
  d=p.parent;s=json.loads(p.read_text());common={k:s[k] for k in ['world_id','spawn_id','run_seed','method','split']};common['run_dir']=str(d)
  profiles=rows(d/'process_profile.csv');by_pid=defaultdict(list);by_role=defaultdict(list)
  for r in profiles:by_pid[r['pid']].append(r);by_role[r['role']].append(r)
  cpu_seconds=defaultdict(float)
  for group in by_pid.values():
   a,b=group[0],group[-1];cpu_seconds[b['role']]+=max(0,float(b['user_cpu_s'])+float(b['system_cpu_s'])-float(a['user_cpu_s'])-float(a['system_cpu_s']))
  for role,group in by_role.items():
   cpu=[float(r['cpu_percent_one_core']) for r in group if r['cpu_percent_one_core']]
   memory=defaultdict(float)
   for r in group:memory[r['wall_elapsed_s']]+=float(r['rss_mib'])
   roles.append({**common,'role':role,'sampled_cpu_s':cpu_seconds[role],'cpu_percent_one_core_p95':quantile(cpu,.95),'peak_sampled_rss_sum_mib':max(memory.values()),'samples':len(group)})
  physical=lines(d/'physical_audit.jsonl');rtf=None
  if len(physical)>1:
   a,b=physical[0],physical[-1];dw=b['wall_epoch_s']-a['wall_epoch_s']
   if dw>0:rtf=(b['sim_time']-a['sim_time'])/dw
  queries=rows(d/'path_queries.csv');decisions=lines(d/'decisions.jsonl');health=rows(d/'navigation_health.csv')
  commanded=[r for r in health if abs(float(r.get('nav_v') or 0))>.03]
  clamped=sum(abs(float(r.get('output_v') or 0))<.01 for r in commanded)
  runs.append({**common,'rtf_physics_span':rtf,'wall_elapsed_s':s.get('process_exit',{}).get('wall_s'),'sampled_total_cpu_s':sum(cpu_seconds.values()),'path_queries':len(queries),'path_query_failed':sum(r['outcome']!='success' for r in queries),'path_query_wall_p95_s':quantile([float(r['wall_s']) for r in queries],.95),'decision_wall_p95_s':quantile([r['planning_wall_s'] for r in decisions if 'planning_wall_s' in r],.95),'safety_translation_stop_fraction_of_command_samples':clamped/len(commanded) if commanded else None,'contact_episodes':s.get('contact_episodes'),'navigation_failures':s.get('navigation_failures'),'navigation_timeouts':s.get('navigation_timeouts')})
 save(ROOT/'reports/PROCESS_RUNTIME.csv',roles);save(ROOT/'reports/RUN_RUNTIME_DIAGNOSTICS.csv',runs)
 (ROOT/'reports/运行性能指标说明.md').write_text('''# 运行性能指标说明\n\nPROCESS_RUNTIME.csv 按实验与进程角色汇总约5秒采样。CPU百分比以单核100%计，多线程进程可超过100%；CPU秒只累计各PID首尾采样之差，短命进程可能遗漏。RSS为同角色采样和，包含共享内存重复计数，不等于系统独占内存。\n\nRUN_RUNTIME_DIAGNOSTICS.csv 的RTF来自独立物理位置首尾时间戳，不含仿真加载时间；墙上总时间另列。path_query与decision的P95是记录的墙上耗时。安全门停车比例只在有直线速度请求的1Hz样本上统计，不能当成碰撞率。接触事件与导航失败另列。所有阶段分开保留，接口超时不能用于正式效率结论。\n''')
 print('Runtime diagnostics exported:',len(runs),'runs')
if __name__=='__main__':main()
