#!/usr/bin/env python3
"""Run measured low-curb physical control and treatment before full missions."""
import os,json
os.environ['ROS_DOMAIN_ID']='210'
import rclpy
from check_rotation_guard import run
from world_adapter import ROOT
rclpy.init()
try: results=[run(True,low_curb=True,projection=False),run(True,low_curb=True,projection=True,duration_s=40),run(True,low_curb=True,projection=False,curb_height_m=.03),run(True,low_curb=True,projection=True,duration_s=40,curb_height_m=.03),run(True,low_curb=True,projection=False,curb_height_m=.03,curb_width_m=.2),run(True,low_curb=True,projection=True,duration_s=40,curb_height_m=.03,curb_width_m=.2)]
finally:rclpy.shutdown()
gate={'passed':all(r['passed'] for r in results),'results':results,'scope':'Actual9cm and3cm curb controls and40s treatment; not full task success'}
(ROOT/'regressions/LOW_CURB_PROJECTION_GATE.json').write_text(json.dumps(gate,indent=2))
if not gate['passed']:raise SystemExit(1)
