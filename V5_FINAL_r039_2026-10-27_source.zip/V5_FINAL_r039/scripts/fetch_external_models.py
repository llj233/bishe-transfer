#!/usr/bin/env python3
"""Resolve every hospital/house include, with immutable version and hashes."""
from fetch_resources import ROOT,DEST,get
from pathlib import Path
import concurrent.futures,hashlib,json,urllib.parse,xml.etree.ElementTree as ET,zipfile,io

MODEL_ROOTS=[DEST/'tb3/turtlebot3_gazebo/models',DEST/'warehouse/models',DEST/'bookstore/models',DEST/'hospital/models',DEST/'gazebo_models',DEST/'fuel_models']

def fuel(name):
 folder=DEST/'fuel_models'/name
 if (folder/'RESOURCE_LOCK.json').exists():return name+' locked'
 api='https://fuel.gazebosim.org/1.0/OpenRobotics/models/'+urllib.parse.quote(name)
 global_lock=ROOT/'provenance/RESOURCE_LOCKS.json'
 pin=json.loads(global_lock.read_text()).get('fuel_models',{}).get(name) if global_lock.exists() else None
 metadata=pin['metadata'] if pin else json.loads(get(api));version=str(pin['version'] if pin else metadata['version'])
 url=pin['source'] if pin else api+'/'+version+'/'+urllib.parse.quote(name)+'.zip'
 data=get(url)
 if pin and hashlib.sha256(data).hexdigest()!=pin['archive_sha256']:raise ValueError('Pinned Fuel archive checksum mismatch: '+name)
 folder.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  for m in z.infolist():
   if '..' in Path(m.filename).parts or m.filename.startswith('/'):raise ValueError('unsafe Fuel path')
  z.extractall(folder)
 (folder/'RESOURCE_LOCK.json').write_text(json.dumps({'source':url,'version':version,'archive_sha256':hashlib.sha256(data).hexdigest(),'metadata':metadata,'files_sha256':{str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}},indent=2))
 return name+' version '+version

if __name__=='__main__':
 # Enumerate actual single-floor hospital world, not its three-floor sibling.
 sources=[DEST/'hospital/worlds/hospital.world',DEST/'tb3/turtlebot3_gazebo/models/turtlebot3_house/model.sdf']
 known={p.parent.name for root in MODEL_ROOTS for p in root.rglob('model.config')}
 required=set()
 for p in sources:
  for u in ET.parse(p).findall('.//include/uri'):
   if u.text.startswith('model://'): required.add(u.text[8:].split('/')[0])
 missing=sorted(required-known)
 print('Missing external includes:',missing,flush=True)
 # The four house props come from the same pinned Classic model repository.
 house={'mailbox','cafe_table','first_2015_trash_can','table_marble'}
 sha=json.loads((DEST/'gazebo_models/RESOURCE_LOCK.json').read_text())['commit']
 tree=json.loads(get(f'https://api.github.com/repos/osrf/gazebo_models/git/trees/{sha}?recursive=1'))
 for item in tree['tree']:
  p=item['path']
  if item['type']=='blob' and p.split('/')[0] in house:
   target=DEST/'gazebo_models'/p;target.parent.mkdir(parents=True,exist_ok=True)
   if not target.exists():get(f'https://raw.githubusercontent.com/osrf/gazebo_models/{sha}/{p}',target)
 print('House props retrieved',flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  futures={pool.submit(fuel,n):n for n in missing if n not in house}
  for f in concurrent.futures.as_completed(futures):
   try:print(f.result(),flush=True)
   except Exception as e:print('FAILED',futures[f],str(e),flush=True)
