#!/usr/bin/env python3
"""Read-only audit of frozen r003; never edits its results or sources."""
from pathlib import Path
import csv,json,collections,datetime
from world_adapter import ROOT
PARENT=ROOT.parent/'V5_single_r003_2026-10-20'
def json_lines(p):
 if not p.exists():return []
 return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def main():
 raw=json.loads((PARENT/'campaigns/V5_r003_2026-10-20/COMPLETED.json').read_text());runs=[r for r in raw if r['split']=='formal'];rows=[];pause_s=0.
 for r in runs:
  p=Path(r['run_dir']);events=json_lines(p/'mission_events.jsonl');progress=json_lines(p/'online_progress.jsonl');dec=json_lines(p/'decisions.jsonl')
  query=list(csv.DictReader((p/'path_queries.csv').open()));telem=list(csv.DictReader((p/'telemetry_5s.csv').open()));t=telem[-1] if telem else {}
  contacts=json_lines(p/'body_contacts.jsonl');floor=json.loads((PARENT/'world_adapters'/r['world_id']/'floor_audit.json').read_text());support={x['collision'] for x in floor['samples'] if x.get('collision')}
  support_records=environment_records=0
  for e in contacts:
   pairs=e.get('pairs',[])
   support_records+=bool(pairs and any(a in support or b in support for a,b in pairs))
   environment_records+=bool(pairs and any(a not in support and b not in support for a,b in pairs))
  last=None
  with (p/'physical_audit.jsonl').open() as stream:
   for line in stream:
    pose=json.loads(line)
    if last:
     dw=pose['wall_epoch_s']-last['wall_epoch_s'];ds=pose['sim_time']-last['sim_time']
     if dw>10:pause_s+=max(0,dw-ds)
    last=pose
  stationary_fail=[x for x in progress if x['result'] in ('blocked','timeout','controller_stall') and x['movement_m']<.15]
  rows.append({k:r.get(k) for k in ['world_id','method','spawn_id','run_seed','joint_success','failure','task_sim_s','final_exploration_pct','final_roi_pct','physical_home_error_m','contact_episodes','run_dir']} | {
   'planning_wall_s':sum(x['planning_wall_s'] for x in dec),'path_query_wall_s':sum(float(x['wall_s']) for x in query),
   'path_query_count':len(query),'path_query_non_successes':sum(x['outcome']!='success' for x in query),'decision_count':len(dec),
   'stationary_failed_goals':len(stationary_fail),'stationary_failures_ignored_by_gain_memory':sum(not x['feedback_eligible'] for x in stationary_fail),
   'physical_path_m':t.get('physical_path_m'),'reentered_path_proxy_m':t.get('reentered_cell_path_m_0p25'),'translation_stopped_s':t.get('stopped_translation_s'),
   'recorded_support_pair_messages':support_records,'recorded_non_support_pair_messages':environment_records})
 out=ROOT/'reports';out.mkdir(exist_ok=True)
 with (out/'PARENT_BATCH20_DIAGNOSIS.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 fail=[r for r in runs if not r['joint_success']];success=[r for r in runs if r['joint_success']]
 totals={'formal_attempts':len(runs),'successes':len(success),'failures':len(fail),'sim_hours':sum(r['task_sim_s'] for r in runs)/3600,
 'failed_task_sim_hours':sum(r['task_sim_s'] for r in fail)/3600,'active_runner_wall_hours':sum(r['process_exit']['wall_s'] for r in runs)/3600,
 'large_wall_clock_gaps_hours':pause_s/3600,'successful_task_min_s':min(r['task_sim_s'] for r in success),'successful_task_max_s':max(r['task_sim_s'] for r in success),
 'failures_reached_return_gate':sum(r['exploration_success'] for r in fail),'failure_causes':dict(collections.Counter(r['failure'] for r in fail)),
 'scope':'Partial, unbalanced 20-run frozen batch over 5 maps; not complete six-map generalization. New repairs use failed maps as development evidence.'}
 (out/'PARENT_BATCH20_SUMMARY.json').write_text(json.dumps(totals,indent=2,ensure_ascii=False))
 md=['# V5 首批20次：诊断与修复依据','',f'读取冻结工作区：{PARENT}。原源码、原失败与原统计均不改写。','',
 f'完成20次，12次联合成功，8次失败。仿真累计 {totals["sim_hours"]:.2f} 小时；失败占 {totals["failed_task_sim_hours"]:.2f} 小时；运行器累计活跃墙上时间 {totals["active_runner_wall_hours"]:.2f} 小时。另有约 {totals["large_wall_clock_gaps_hours"]:.2f} 小时长墙钟间隔，可能是VM/宿主机暂停或时钟跳变，不解释为算法探索时间。','',
 '## 已有证据','',
 '1. 8次失败全部在覆盖率达标前，未进入返航；12次成功均已返航。因此当前主修复点是探索中的执行与等待，不是假设所有失败都是返航接口问题。',
 '2. M06/B2末段19个blocked与2个timeout，M05/B2种子11末段20个blocked；连续原地失败被位移阈值过滤，未进入在线反馈。安全节点存在有限后退入口，但任务层从未发出请求。',
 '3. 实际车体向后偏置，原Nav2圆半径0.22米不足以完整包含约0.237米的后角。旧安全门只检查前后35度且允许原地转动，不能检查转弯时的侧面与后角。新版本采用包络多边形与激光全向足迹扫掠，停车/退让仍需新鲜扫描。',
 '4. M05/B2种子29累计路径查询约1196秒、规划约1418秒；M06/B1查询约901秒、规划约1198秒。每轮最多40条串行查询使车在目标之间等待。这些耗时与停驶时间有重叠，不能直接相加当成互斥分解。',
 '5. 医院的原始接触对主要是轮子与地板网格；Willow有明确walls碰撞。原始contact_episodes是状态片段，不等于独立撞击次数。原统计不覆盖，新版本另列精确地面碰撞对与非地面接触，真实物理碰撞始终保留。','',
 '## r004 / r005 修复与验证边界','',
 '- r004：实际车体包络；低速靠墙；扫描全角度转动扫掠；20秒里程计停滞检查；两次原地失败后等Nav2取消终止再有限后退和回溯。最多3次无有效进展脱困，失败保留，禁止无限换目标。',
 '- r005：加入有独立失败通道的在线记忆；每轮优先取得6条可行Nav2路径，通常最多12次请求，连续空结果时扩到24；不以欧氏距离声明可达。四邻域前沿用SciPy计算，局部反馈只扫描目标附近。',
 '- 总任务预算和覆盖/ROI/物理返航成功门槛保持一致；不靠放宽95%覆盖或增大超时制造成功。',
 '- M05/M06已用于修复设计，后续仅称失败回归/开发验证；要声称泛化，必须追加未用于调参的新场景。',
 '- 全部修复尚需全程复测，不把单元测试通过等同于复杂地图全部成功。','',
 '| 地图 | 方法 | 种子 | 成功 | 覆盖% | 时间s | 路径查询等待s | 停驶s |','|---|---|---:|---|---:|---:|---:|---:|']
 for x in rows:md.append(f'| {x["world_id"]} | {x["method"]} | {x["run_seed"]} | {x["joint_success"]} | {x["final_exploration_pct"]:.2f} | {x["task_sim_s"]:.1f} | {x["path_query_wall_s"]:.1f} | {float(x["translation_stopped_s"] or 0):.1f} |')
 md+=['','详细逐次证据：PARENT_BATCH20_DIAGNOSIS.csv。旧接触日志为事件/心跳，接触对字段有缺失窗口，不能据此精确重建所有历史墙体撞击次数。']
 (out/'首批20次诊断与修复依据.md').write_text('\n'.join(md));print(json.dumps(totals,ensure_ascii=False))
if __name__=='__main__':main()
