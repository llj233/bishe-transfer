#!/usr/bin/env python3
"""Resolve upstream path/case/XML defects in derived resources, keeping originals."""
from pathlib import Path
import shutil,xml.etree.ElementTree as ET,json,hashlib,re
from world_adapter import ROOT,RES,model_paths

def main():
 dest=ROOT/'runtime_models';dest.mkdir(exist_ok=True)
 source_roots=[p for p in model_paths() if p!=dest]
 origins={}
 for root in source_roots:
  if not root.exists():continue
  for config in root.glob('*/model.config'):
   origins.setdefault(config.parent.name,config.parent)
 changes=[]
 for name,source in origins.items():
  target=dest/name
  if not target.exists():shutil.copytree(source,target)
  else:
   # Regenerate derived SDF from pinned originals on every preparation.
   # A downloaded workspace may contain file:// paths from another machine.
   for original in source.rglob('*.sdf'):
    derived=target/original.relative_to(source);derived.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,derived)
  # Gazebo needs only model name and an SDF path; upstream human metadata
  # can contain unescaped ampersands/angle brackets. Preserve it in originals.
  sdf=next((n for n in ('model.sdf','model-1_4.sdf','model-1_3.sdf') if (target/n).is_file()),None)
  if sdf is None:
   try:sdf=ET.parse(source/'model.config').findall('sdf')[-1].text
   except Exception:
    if not list(target.glob('*.sdf')):
     changes.append({'model':name,'note':'asset-only model directory; no SDF required'})
     continue
    raise ValueError('No readable SDF: '+str(source))
  config=ET.Element('model');ET.SubElement(config,'name').text=name
  ET.SubElement(config,'version').text='1.0'
  ET.SubElement(config,'sdf',{'version':'1.6'}).text=sdf
  ET.ElementTree(config).write(target/'model.config',encoding='unicode')
 for p in dest.rglob('*.sdf'):
  tree=ET.parse(p)
  for u in tree.findall('.//uri'):
   uri=u.text or ''
   if not uri.startswith('file://models/'):continue
   tail=uri[len('file://models/'):].split('/')
   q=dest/tail[0]
   for part in tail[1:]:
    if (q/part).exists():q=q/part
    else:
     matches=[x for x in q.iterdir() if x.name.lower()==part.lower()] if q.is_dir() else []
     if len(matches)!=1:raise ValueError('Unresolved mesh '+uri)
     q=matches[0]
   if not q.exists():raise ValueError('Missing asset '+uri)
   u.text='file://'+str(q);changes.append({'file':str(p.relative_to(ROOT)),'from':uri,'to':u.text})
  # Keep nested props and people fixed for repeatable static experiments.
  for m in tree.findall('.//model'):
   s=m.find('static')
   if s is None:s=ET.SubElement(m,'static')
   s.text='true'
  tree.write(p,encoding='unicode')
 lock={'originals_unchanged':True,'source_models':{n:str(p) for n,p in origins.items()},
       'config_normalization':'name/version/sdf only; original author/license metadata retained in resources',
       'mesh_path_fixes':changes,'all_nested_models_static':True,
       'sha256':{str(p.relative_to(dest)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.rglob('*') if p.is_file()}}
 (ROOT/'provenance/RUNTIME_MODELS.json').write_text(json.dumps(lock,indent=2))
 print(len(origins),'derived model folders;',len(changes),'explicit mesh path fixes')

if __name__=='__main__':main()
