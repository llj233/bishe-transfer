#!/usr/bin/env python3
"""Prepare resource/geometry review evidence; interface gates remain separate."""
from pathlib import Path
import hashlib,json
from PIL import Image,ImageDraw,ImageFont
from world_adapter import ROOT,WORLDS,audit_uris

def main():
 font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',22)
 sheet=Image.new('RGB',(1800,1400),'#e9eef3');draw=ImageDraw.Draw(sheet)
 for i,wid in enumerate(['M01','M02','M03','M04','M05','M06']):
  w=WORLDS[wid];p=w.directory
  image=Image.open(p/'truth_preview_8x.png').convert('RGB');image.thumbnail((560,620))
  x=(i%3)*600;y=(i//3)*700
  draw.text((x+20,y+15),wid+' '+w.name,font=font,fill='#133651')
  sheet.paste(image,(x+(600-image.width)//2,y+65+(620-image.height)//2))
  meta=json.loads((p/'collision.json').read_text());audit=json.loads((p/'truth_audit.json').read_text())
  check={'resources_complete':audit_uris(p/'world.sdf')['passed'],'no_robot_in_truth':not meta['robot_present'],
    'all_top_level_scene_models_static':all(m['static'] for m in meta['models']),
    'closed_component':not audit['component_touches_edge'],
    'dense_cell_sampling':meta.get('cell_sampling')=='10 concentric square perimeters',
    'floor_datum_probed':json.loads((p/'floor_audit.json').read_text())['passed'],
    'thin_height_fixture_passed':json.loads((ROOT/'regressions/TRUTH_SAMPLING_GATE.json').read_text())['passed']}
  (p/'geometry_checklist.json').write_text(json.dumps({'checks':check,'automated_passed':all(check.values()),
    'visual_review_pending':True,'truth_sha256':audit['truth_sha256'],
    'review_scope':'Geometry/floor/spawn outline; finite-height and raster limitations retained'},indent=2))
 out=ROOT/'reports/geometry_review_r003.png';sheet.save(out);print(out)

if __name__=='__main__':main()
