# 双机共享奖励探索：VM 运行步骤

这是 ROS 2 Humble + Gazebo Classic 的最小双机闭环。两台 Waffle Pi 使用不同 ROS 命名空间；每台订阅自己的相机、激光与里程计，发布自己的速度。一个 `q_explorer` 节点维护共享访问网格、共享视觉签名集合和共享 Q 表。每 0.5 秒收集两台机器人观测，计算一个团队奖励，再用同一个奖励更新两台机器人的转移。空旷处直行速度为 0.18 m/s，前方 0.55 m 内由避障控制接管。该基线可检验双机协同训练的数据链路，不是 MAPPO，也不是完整的 SLAM 地图覆盖率算法。

## 1. 解压和编译

把新版 `dual_ros2_prototype_vm.zip` 上传到 GitHub 的 `llj233/bishe-transfer` 仓库并在 VM 的 `~/bishe-transfer-new` 执行 `git pull`，或通过共享文件夹复制到 VM。然后运行：

```bash
cd ~
unzip -o ~/bishe-transfer-new/dual_ros2_prototype_vm.zip -d ~
source /opt/ros/humble/setup.bash
cd ~/single_ros2_prototype
colcon build --symlink-install
source install/setup.bash
ros2 pkg prefix dual_explore
```

## 2. 启动双机

```bash
cd ~/single_ros2_prototype
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch dual_explore dual_explore.launch.py world:=$PWD/worlds/prepared/room.world
```

Gazebo 中应出现两台机器人，初始坐标约为 `(-2, -2.5)` 和 `(-2, 3.5)`。Gazebo 启动后 5 秒、8 秒分别生成它们。两个机器人都有有效观测之后，日志每 20 步出现各自的 `ready steps=... image_frames=... visited=... team_reward=...`。

## 3. 检查话题与学习记录

在新终端执行：

```bash
source /opt/ros/humble/setup.bash
source ~/single_ros2_prototype/install/setup.bash
ros2 topic list | grep -E '^/robot[12]/(camera/image_raw|scan|odom|cmd_vel)$'
ros2 topic echo /robot1/cmd_vel --once
ros2 topic echo /robot2/cmd_vel --once
head -n 5 ~/dual_explore.csv
tail -n 10 ~/dual_explore.csv
ls -lh ~/.dual_explore_q.json
```

预期有 8 个机器人话题。CSV 中 `robot1` 与 `robot2` 的 `step` 和 `image_frames` 持续增加；同一控制周期的两行 `reward` 相等，因为它是团队共享奖励。`visited_cells` 是两台机器人共同访问的 0.5 m 网格数，正常移动时应逐渐增加。`control_mode` 列显示当前由学习策略、转向避障、后退避障或沿墙寻找门洞的脱困控制。Q 表每 20 步保存一次，也会在正常 Ctrl+C 时保存。

如只出现等待相机或激光的消息，运行 `ros2 topic list` 检查实际话题，并检查 Gazebo 中两个实体是否成功生成。虚拟机图形加速不足时，可先通过话题和 CSV 验证链路。

## 4. 当前协同方式与房间脱困

两台机器人各有自己的 `/robot1/...`、`/robot2/...` 传感器和速度话题，但由同一个 `q_explorer` 节点控制。节点中只有一个 `SharedLearner`：两台机器人访问过的 0.5 m 网格、图像颜色签名和 Q 表都合并保存。每个控制周期先计算一次团队奖励，再用同一个奖励分别更新两台机器人的状态转移。这个共享奖励和共享策略是当前的协同范围；尚无 SLAM 地图融合、边界点分配、路径规划或机器人间避碰。

正常时策略每 0.5 秒从前进、左转、右转中选择动作，避障层可接管速度。激光另计算窄前方和左右侧距离，避免把门框误判成整面墙。若某台机器人连续 12 秒没有到达新的 0.5 m 网格，它会暂时沿一侧墙前进；侧面出现开口时转入并穿过。脱困控制持续最多 120 秒，然后切换沿墙方向并重新尝试。CSV 的 `control_mode` 可用于查看 `escape_seek`、`escape_follow`、`escape_gap_turn`、`escape_cross` 等阶段。这是局部脱困策略，不能保证从任意复杂房间或封闭区域离开。
