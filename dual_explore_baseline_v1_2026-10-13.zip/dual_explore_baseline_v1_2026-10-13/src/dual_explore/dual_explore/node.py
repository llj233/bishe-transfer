"""ROS 2 入口：收两台机器人传感器、调用共享学习器、发布各自速度。

这一个节点同时管理 robot1/robot2；没有两个分布式训练进程。
阅读顺序：__init__ 建连 -> on_* 收传感器 -> tick 控制循环 -> close 保存。
"""
import csv
import math
import os
import time

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image, LaserScan

from .core import EscapeNavigator, SharedLearner, image_signature, safe_motion, scan_bins, state_from_sensors


class Explorer(Node):
    """一个 ROS 节点，内部保存每台机器人状态和一份共享学习器。"""

    def __init__(self):
        # 注册 ROS 节点名，ros2 node list 中可看到 /q_explorer。
        super().__init__('q_explorer')
        # 参数可由启动文件传入；默认值也让单机器人启动成为可能。
        self.declare_parameter('robot_names', ['robot'])
        self.declare_parameter('train', True)
        self.declare_parameter('image_topic', '/camera/image_raw')
        self.declare_parameter('image_suffix', 'camera/image_raw')
        self.declare_parameter('spawn_offsets', [-2.0, -2.5, -2.0, 3.5])
        self.declare_parameter('log_path', os.path.expanduser('~/dual_explore.csv'))
        self.declare_parameter('q_path', os.path.expanduser('~/.dual_explore_q.json'))
        self.declare_parameter('sensor_timeout', 3.0)
        # ROS 参数值可能是字符串或字符串列表，统一转成 names 列表。
        name_value = self.get_parameter('robot_names').value
        names = [name_value] if isinstance(name_value, str) else list(name_value)
        self.training = bool(self.get_parameter('train').value)
        self.q_path = os.path.expanduser(self.get_parameter('q_path').value)
        # spawn_offsets 是机器人在 Gazebo 中的初始 (x,y)，用于里程计估位。
        offsets = list(self.get_parameter('spawn_offsets').value)
        if len(names) not in (1, 2):
            raise ValueError('robot_names must contain one or two names')
        if len(names) == 2 and len(offsets) != 4:
            raise ValueError('spawn_offsets must be [x1,y1,x2,y2]')
        self.learner = SharedLearner()  # 全部机器人只创建这一份 Q 表和奖励统计。
        if os.path.exists(self.q_path):
            # 重新运行时恢复已学习的 Q 表；访问网格不会恢复。
            self.learner.load(self.q_path)
        self.robots = {}  # 名称 -> 该机器人的最新传感器、里程计和脱困状态。
        self.cmd_publishers = {}  # 名称 -> 该机器人的 /cmd_vel 发布器。
        self.subscriptions_ = []  # 保留订阅对象引用，防止被回收。
        for i, name in enumerate(names):
            # 双机时分别使用 /robot1、/robot2；单机默认使用根话题。
            prefix = '' if len(names) == 1 and name == 'robot' else f'/{name}'
            image_topic = (self.get_parameter('image_topic').value if not prefix
                           else f"{prefix}/{self.get_parameter('image_suffix').value.lstrip('/')}")
            # 每台机器人的字典独立；只有 self.learner 是共享的。
            self.robots[name] = {'scan': None, 'image': None, 'odom': None,
                                 'scan_time': 0.0, 'image_time': 0.0, 'odom_time': 0.0,
                                 'frames': 0, 'steps': 0, 'last': None, 'odom_origin': None,
                                 'avoid_turn': 0, 'local_cells': set(),
                                 'last_new_cell': time.monotonic(), 'escape': None,
                                 'escape_started': 0.0, 'next_hand': -1 if i == 0 else 1,
                                 'offset': (0.0, 0.0) if len(names) == 1 else (offsets[i * 2], offsets[i * 2 + 1])}
            # Twist.linear.x 是前后速度，Twist.angular.z 是左右旋转速度。
            self.cmd_publishers[name] = self.create_publisher(Twist, f'{prefix}/cmd_vel', 10)
            # lambda 中的 n=name 固定当前循环的机器人名，防止回调全指向最后一台。
            self.subscriptions_.append(self.create_subscription(
                LaserScan, f'{prefix}/scan', lambda msg, n=name: self.on_scan(n, msg), qos_profile_sensor_data))
            self.subscriptions_.append(self.create_subscription(
                Odometry, f'{prefix}/odom', lambda msg, n=name: self.on_odom(n, msg), qos_profile_sensor_data))
            self.subscriptions_.append(self.create_subscription(
                Image, image_topic, lambda msg, n=name: self.on_image(n, msg), qos_profile_sensor_data))
            self.get_logger().info(f'{name}: scan={prefix}/scan odom={prefix}/odom image={image_topic} cmd={prefix}/cmd_vel')
        # CSV 是人可读的运行记录；每次启动以 w 模式重新创建。
        log_path = os.path.expanduser(self.get_parameter('log_path').value)
        self.log_file = open(log_path, 'w', newline='', encoding='utf-8')
        self.writer = csv.writer(self.log_file)
        self.writer.writerow(['wall_time', 'robot', 'step', 'image_frames', 'visited_cells',
                              'image_signatures', 'action', 'control_mode', 'reward',
                              'x_world', 'y_world', 'front_m'])
        # 每 0.5 秒执行一次控制与学习，不等于 Gazebo 物理更新频率。
        self.timer = self.create_timer(0.5, self.tick)

    def on_scan(self, name, msg):
        """激光回调：只缓存距离摘要及其到达时间。"""
        self.robots[name]['scan'] = scan_bins(msg.ranges, msg.range_min, msg.range_max)
        self.robots[name]['scan_time'] = time.monotonic()

    def on_odom(self, name, msg):
        """里程计回调：保存平面位移；没有 SLAM 位姿校正。"""
        p = msg.pose.pose.position
        robot = self.robots[name]
        robot['odom'] = (p.x, p.y)
        if robot['odom_origin'] is None:
            # 首帧作为相对位移的原点，之后和 spawn_offsets 相加。
            robot['odom_origin'] = (p.x, p.y)
        robot['odom_time'] = time.monotonic()

    def on_image(self, name, msg):
        """相机回调：保存 3 个颜色特征，而非完整图像或地图。"""
        robot = self.robots[name]
        robot['image'] = image_signature(msg.data, msg.width, msg.height, msg.step, msg.encoding)
        robot['frames'] += 1
        robot['image_time'] = time.monotonic()

    def publish_velocity(self, name, command=(0.0, 0.0)):
        """把 (直线速度, 角速度) 发给指定机器人的底盘。"""
        msg = Twist()
        msg.linear.x, msg.angular.z = command
        self.cmd_publishers[name].publish(msg)

    def tick(self):
        """一轮控制：检查数据 -> 算团队奖励 -> 各自选动作 -> 保存日志。"""
        now = time.monotonic()
        timeout = float(self.get_parameter('sensor_timeout').value)
        ready = True
        # 必须两台机器人的激光、里程计和图像都在 3 秒内更新。
        for name, robot in self.robots.items():
            if (robot['scan'] is None or robot['odom'] is None or robot['image'] is None or
                    any(now - robot[k] > timeout for k in ('scan_time', 'image_time', 'odom_time'))):
                self.get_logger().info(f'{name}: waiting for fresh scan/odom/rgb8 image')
                ready = False
        if not ready:
            # 当前实现是同步团队控制：任一台缺传感器，两台都停。
            for name in self.robots:
                self.publish_velocity(name)
            return

        # 把每台机器人的最新观测整理成 state 和近似世界坐标。
        observations = {}
        for name, robot in self.robots.items():
            scan, image = robot['scan'], robot['image']
            state = state_from_sensors(scan, image)
            # 这只是“出生位置 + 里程计相对位移”，不是 SLAM 定位。
            x = robot['offset'][0] + robot['odom'][0] - robot['odom_origin'][0]
            y = robot['offset'][1] + robot['odom'][1] - robot['odom_origin'][1]
            observations[name] = (state, x, y, scan, image)

        # 合并两台机器人的新网格、颜色和碰撞风险，产生同一个团队奖励。
        reward = self.learner.reward_batch(
            (x, y, image, scan[0]) for _, x, y, scan, image in observations.values())
        for name, robot in self.robots.items():
            state, x, y, scan, image = observations[name]
            # local_cells 只用于判断“这台机器人自己是否卡住”。
            cell = (math.floor(x / 0.5), math.floor(y / 0.5))
            if cell not in robot['local_cells']:
                robot['local_cells'].add(cell)
                robot['last_new_cell'] = now
            if robot['escape'] is not None and now - robot['escape_started'] > 120.0:
                # 一轮沿墙搜索最多 120 秒；下次改用另一只“手”沿墙。
                robot['escape'] = None
                robot['next_hand'] *= -1
                robot['last_new_cell'] = now
            if robot['escape'] is None and now - robot['last_new_cell'] > 12.0:
                # 连续 12 秒没进入新网格，临时接管策略去找门洞。
                robot['escape'] = EscapeNavigator(robot['next_hand'])
                robot['escape_started'] = now
                robot['avoid_turn'] = 0
                self.get_logger().info(f'{name}: no new cell for 12 s; following a wall to find a doorway')
            if self.training and robot['last'] is not None:
                # robot['last'] 是这台机器人上一轮的 (状态,动作)。
                # 两台机器人分别更新，但更新的是同一张 self.learner.q。
                prev_state, prev_action = robot['last']
                self.learner.learn(prev_state, prev_action, reward, state)
            # epsilon-greedy 从共享 Q 表选出动作编号 0/1/2。
            action = self.learner.choose(state, self.training)
            if robot['escape'] is None:
                # 平常先经过安全层：太靠近墙会覆盖 Q 动作。
                command, robot['avoid_turn'], mode = safe_motion(
                    scan, action, robot['avoid_turn'])
            else:
                # 脱困期间沿墙找开口；它不是 Q 学习得到的动作。
                command, mode = robot['escape'].step(scan)
            self.publish_velocity(name, command)
            # 只对真正执行的学习动作建立下一次转移；安全接管不训练。
            robot['last'] = (state, action) if mode == 'learn' else None
            robot['steps'] += 1
            self.writer.writerow([round(time.time(), 2), name, robot['steps'], robot['frames'],
                                  len(self.learner.visited), len(self.learner.images), action, mode,
                                  round(reward, 3), round(x, 3), round(y, 3), round(scan[0], 3)])
            self.log_file.flush()
            # 每 20 步打印一次状态，约每 10 秒一次。
            if robot['steps'] % 20 == 0:
                self.get_logger().info(f'{name}: ready steps={robot["steps"]} image_frames={robot["frames"]} visited={len(self.learner.visited)} team_reward={reward:.2f}')
        # 两台机器人步数都到 20 的倍数时，持久化共享 Q 表。
        if self.training and all(robot['steps'] % 20 == 0 for robot in self.robots.values()):
            self.learner.save(self.q_path)

    def close(self):
        """退出时尝试停车、保存 Q 表并关闭 CSV。"""
        if rclpy.ok():
            for name in self.robots:
                self.publish_velocity(name)
        if self.training:
            self.learner.save(self.q_path)
        self.log_file.close()


def main():
    """ros2 run/launch 进入程序的入口。"""
    rclpy.init()
    node = Explorer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.close()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
