# 双机器人共享 Q-learning 探索：实验基线 v1

冻结日期：2026-10-13。源目录：`/home/lemuel/single_ros2_prototype`。
来源：用户 GitHub 仓库 `llj233/bishe-transfer` 的下载版，在 VM 中完成 ROS 2 Humble 编译、运行和本地改动；此压缩包是当前 VM 状态快照，不代表 GitHub 已更新。

## 基线内容

- `src/dual_explore/`：带中文注释的 ROS 2 节点、共享 Q-learning、启动文件、包配置。
- `worlds/`：原始和已准备好的 Gazebo 场景。
- `scripts/`、`tests/`：场景准备脚本和核心测试。
- `CODE_WALKTHROUGH.zh-CN.md`：代码阅读指南。
- `runtime/`：冻结时的 Q 表及 CSV 日志快照。它们是实验结果，不是干净训练的初始状态。
- `MANIFEST.json`：归档内每个文件的 SHA-256。

不包含 `build/`、`install/`、`log/`、`__pycache__/`；需在目标环境重新编译。

## 算法与配置

两台 TurtleBot3 Waffle Pi，一个 `q_explorer` ROS 节点；各有相机、激光、里程计和速度话题，共享访问网格、视觉颜色签名、团队奖励和一张 Q 表。Q-learning 参数：alpha=0.2、gamma=0.9、epsilon=0.2；控制周期 0.5 秒；动作：0.18 m/s 前进或 ±0.9 rad/s 原地转向。安全层及 12 秒未访问新网格后的沿墙找门策略可覆盖学习动作。启动场景：`worlds/prepared/room.world`。

这是强化学习协同探索原型，不是 SLAM，也没有占据地图、闭环定位、地图融合或基于信息增益的规划。`visited_cells` 是里程计估算坐标经过的 0.5 m 网格数，不是地图覆盖率。

## 验证记录

- `python3 -m pytest -p no:cacheprovider -s tests/test_core.py -q`：8 passed（2026-10-13）。
- 冻结时 CSV 记录行数：4394；最大共享访问网格数：414；Q 表状态数：27。
- 上述 CSV 和 Q 表只反映一次已有运行；不能据此声称所有地图均可完成探索。

## 在 ROS 2 Humble VM 中运行

```bash
unzip dual_explore_baseline_v1_2026-10-13.zip -d ~
cd ~/dual_explore_baseline_v1_2026-10-13
source /opt/ros/humble/setup.bash
colcon build --symlink-install
source install/setup.bash
ros2 launch dual_explore dual_explore.launch.py world:=$PWD/worlds/prepared/room.world
```

依赖：`ros-humble-gazebo-ros-pkgs`、`ros-humble-turtlebot3-gazebo`。在新目录运行时，节点默认读取 `~/.dual_explore_q.json`：若该文件已存在，它会续训；要复现实验的训练初始状态，请使用没有该文件的独立用户环境。若需从本次已训练状态继续，先把 `runtime/q_table_snapshot.json` 复制到该默认路径。GUI 由当前显示环境决定；在虚拟机图形会话中运行可看到 Gazebo 窗口。

压缩包外同名 `.sha256` 文件可校验整个归档。压缩包内每个文件的校验值在 `MANIFEST.json` 中。
