import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src' / 'dual_explore'))
from dual_explore.core import EscapeNavigator, SharedLearner, image_signature, safe_motion, scan_bins, state_from_sensors


class CoreTest(unittest.TestCase):
    def test_image_signature_and_state(self):
        data = bytes([255, 0, 0] * 16)
        sig = image_signature(data, 4, 4, 12, 'rgb8')
        self.assertEqual(sig, (3, 0, 0))
        self.assertEqual(state_from_sensors((0.2, 1.0, 0.5), sig), (0, 2, 1, 3, 0, 0))

    def test_shared_visit_reward(self):
        learner = SharedLearner(epsilon=0)
        first = learner.reward(0.1, 0.1, (1, 0, 0), 1.0)
        second = learner.reward(0.2, 0.2, (1, 0, 0), 1.0)
        self.assertGreater(first, second)
        self.assertEqual(len(learner.visited), 1)

    def test_team_reward_counts_shared_cell_once(self):
        learner = SharedLearner(epsilon=0)
        team = learner.reward_batch(((0.1, 0.1, (1, 0, 0), 1.0),
                                     (0.2, 0.2, (1, 0, 0), 1.0)))
        self.assertAlmostEqual(team, 1.09)
        self.assertEqual(len(learner.visited), 1)

    def test_q_update(self):
        learner = SharedLearner(epsilon=0)
        s = (1, 1, 1, 0, 0, 0)
        learner.learn(s, 0, 1.0, s)
        self.assertGreater(learner.q[s][0], 0)

    def test_scan(self):
        scan = scan_bins([1.0] * 360, 0.1, 4.0)
        self.assertEqual(scan, (1.0,) * 7)
        self.assertEqual(scan_bins([float('inf')] * 360, 0.1, 4.0), (4.0,) * 7)

    def test_doorway_is_clear_ahead_despite_wall_at_edge(self):
        ranges = [2.0] * 360
        ranges[30] = 0.4
        scan = scan_bins(ranges, 0.1, 4.0)
        self.assertEqual(scan[0], 0.4)
        self.assertEqual(scan[4], 2.0)
        self.assertEqual(safe_motion(scan, 0), ((0.18, 0.0), 0, 'learn'))

    def test_safe_motion_speeds_up_and_avoids_wall(self):
        command, turn, mode = safe_motion((2.0, 2.0, 1.0, 2.0, 2.0, 2.0, 1.0), 0)
        self.assertEqual((command, turn, mode), ((0.18, 0.0), 0, 'learn'))
        command, turn, mode = safe_motion((0.4, 2.0, 1.0, 2.0, 0.4, 2.0, 1.0), 0)
        self.assertEqual((command, turn, mode), ((0.0, 0.9), 1, 'turn'))
        self.assertEqual(safe_motion((0.6, 1.0, 2.0, 2.0, 0.6, 1.0, 2.0), 0, turn),
                         ((0.0, 0.9), 1, 'turn'))
        self.assertEqual(safe_motion((0.9, 1.0, 2.0, 2.0, 0.9, 1.0, 2.0), 0, turn),
                         ((0.18, 0.0), 0, 'learn'))
        self.assertEqual(safe_motion((0.2, 1.0, 2.0, 1.0, 0.2, 1.0, 2.0), 0),
                         ((-0.08, 0.0), -1, 'back'))

    def test_escape_follows_wall_and_enters_side_opening(self):
        navigator = EscapeNavigator(hand=-1)
        clear = (2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0)
        wall = (0.6, 1.0, 0.5, 2.0, 0.6, 1.0, 0.5)
        opening = (0.8, 1.0, 1.5, 2.0, 0.8, 1.0, 1.5)
        self.assertEqual(navigator.step(clear)[1], 'escape_seek')
        self.assertEqual(navigator.step(wall)[1], 'escape_follow')
        self.assertEqual(navigator.step(opening), ((0.0, -0.9), 'escape_gap_turn'))
        self.assertEqual(navigator.step(opening)[1], 'escape_gap_turn')
        self.assertEqual(navigator.step(opening)[1], 'escape_gap_turn')
        self.assertEqual(navigator.step(opening), ((0.16, 0.0), 'escape_cross'))


if __name__ == '__main__':
    unittest.main()
