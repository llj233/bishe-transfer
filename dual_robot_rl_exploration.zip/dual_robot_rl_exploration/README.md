# 双机协同强化学习探索 最小可运行骨架

本项目按“单车传感器与控制 → 单车在线 Q 学习 → 双车共享策略和覆盖奖励 → SLAM 地图融合”的顺序推进。当前代码实现前 3 步的 ROS 节点；地图融合、真正的全局覆盖率和深度强化学习属于下一阶段。不要把当前的访问网格数当作已建图面积。单车和双车流程统一使用 `worlds/empty_home_1_approx.world`，这是依据 L2E 论文 Fig. 3(a) 的 **Empty home 1** 外墙和隔墙做的近似图，非论文原始 `.world` 文件。

## 1 运行位置与环境

全部安装、编译、仿真和强化学习命令都在 Ubuntu 虚拟机的终端执行，不需要 VS Code。建议 Ubuntu 22.04 + ROS 2 Humble，VM 至少分配 4 vCPU、8 GB RAM；双车 Gazebo GUI 更建议 16 GB RAM。VM 的显卡加速与宿主机驱动有关，卡顿时先用 `gzserver` 无界面运行。首先核对版本：

```bash
lsb_release -ds
source /opt/ros/humble/setup.bash
echo "$ROS_DISTRO"
```

以下命令以 Humble 为例；若输出不是 Humble，先不要照搬包名。

```bash
sudo apt update
sudo apt install -y git python3-rosdep ros-humble-gazebo-ros-pkgs ros-humble-slam-toolbox ros-humble-rviz2 python3-colcon-common-extensions
source /opt/ros/humble/setup.bash
mkdir -p ~/turtlebot3_ws/src
cd ~/turtlebot3_ws/src
git clone -b humble https://github.com/ROBOTIS-GIT/DynamixelSDK.git
git clone -b humble https://github.com/ROBOTIS-GIT/turtlebot3_msgs.git
git clone -b humble https://github.com/ROBOTIS-GIT/turtlebot3.git
git clone -b humble https://github.com/ROBOTIS-GIT/turtlebot3_simulations.git
cd ~/turtlebot3_ws
colcon build --symlink-install
source install/setup.bash
export TURTLEBOT3_MODEL=waffle_pi
ros2 pkg prefix turtlebot3_gazebo
```

以上按 ROBOTIS 官方 `humble` 分支从源码编译，避免混用 `main` 分支。若 `colcon` 提示依赖缺失，在 `~/turtlebot3_ws` 运行 `rosdep install --from-paths src --ignore-src -r -y --rosdistro humble` 后重建。参考链接见文末。

## 2 在虚拟机终端建立工作空间

把交付的 `dual_robot_rl_exploration.zip` 复制到虚拟机的“下载”目录，然后在虚拟机终端解压并编译：

```bash
sudo apt install -y unzip
unzip ~/Downloads/dual_robot_rl_exploration.zip -d ~
source /opt/ros/humble/setup.bash
source ~/turtlebot3_ws/install/setup.bash
cd ~/dual_robot_rl_exploration
colcon build --symlink-install
source install/setup.bash
python3 -m unittest discover -s tests -v
```

每个虚拟机终端都要先 `source /opt/ros/humble/setup.bash`，再 `source ~/turtlebot3_ws/install/setup.bash`，最后 `source ~/dual_robot_rl_exploration/install/setup.bash`。当前项目仅用 Python 标准库和 ROS 2 消息，不需要 PyTorch。

## 3 先跑单车

终端 A：

```bash
source /opt/ros/humble/setup.bash
source ~/turtlebot3_ws/install/setup.bash
export TURTLEBOT3_MODEL=waffle_pi
cd ~/dual_robot_rl_exploration
python3 scripts/make_empty_home1_launch.py
ros2 launch /tmp/empty_home1_single.launch.py
```

终端 B 核对真实话题名称：

```bash
source /opt/ros/humble/setup.bash
source ~/turtlebot3_ws/install/setup.bash
ros2 topic list | grep -E 'TB3_1/(scan|odom|camera/image_raw|cmd_vel)'
ros2 topic hz /TB3_1/camera/image_raw
```

终端 C：

```bash
source /opt/ros/humble/setup.bash
source ~/turtlebot3_ws/install/setup.bash
cd ~/dual_robot_rl_exploration && source install/setup.bash
ros2 run dual_explore q_explorer --ros-args -p robot_names:="['TB3_1']" -p train:=true -p log_path:=$HOME/dual_explore_single.csv
```

期望：日志出现 `ready`、`image_frames>0`、`steps>0`；机器人有移动，CSV 持续增长。按 Ctrl+C 停止后会保存 Q 表到 `~/.dual_explore_q.json`。若相机实际名称不同，用 `-p image_suffix:=实际后缀`。首次运行请人工监护，低速动作和激光安全阈值不能保证零碰撞。

地图链路另开终端 D 启动：

```bash
source /opt/ros/humble/setup.bash
source ~/turtlebot3_ws/install/setup.bash
cd ~/dual_robot_rl_exploration
python3 scripts/prepare_slam_config.py
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/tmp/empty_home1_tb3_1_slam.yaml use_sim_time:=true
```

再开终端 E，查询是否已有地图：

```bash
source /opt/ros/humble/setup.bash
ros2 topic echo /map --once
```

这一阶段的 Q 学习奖励采用“首次访问的位姿网格 + 首次见到的粗图像特征 − 碰撞风险”，属于探索代理指标。`/map` 只用于验证建图管线；最终论文覆盖率须用地图与仿真真值计算。

## 4 再跑双车

ROBOTIS Humble 官方 `multi_robot.launch.py` 硬编码为 4 车。下面生成加载同一张 Empty home 1 近似地图的 2 车副本。先关闭单车 Gazebo 和学习节点，然后运行：

```bash
source /opt/ros/humble/setup.bash
source ~/turtlebot3_ws/install/setup.bash
export TURTLEBOT3_MODEL=waffle_pi
cd ~/dual_robot_rl_exploration
python3 scripts/make_empty_home1_launch.py
ros2 launch /tmp/empty_home1_dual.launch.py
```

先运行 `ros2 topic list | grep -E 'TB3_1|TB3_2'`，确认两车各自的 `/scan`、`/odom`、`/camera/image_raw`、`/cmd_vel`。然后：

```bash
cd ~/dual_robot_rl_exploration && source install/setup.bash
ros2 run dual_explore q_explorer --ros-args -p robot_names:="['TB3_1','TB3_2']" -p train:=true -p log_path:=$HOME/dual_explore_two.csv
```

两个机器人共享同一 Q 表和一个粗位置访问集合；当其中一车先进入一个网格，该网格不再给另一车新区域奖励。这是最小协同机制。本近似地图设置初始位置 `[-2,-2.5]` 与 `[-2,2.5]`，已同步到节点的 `spawn_offsets` 默认值；如果修改出生点，要同步改参数。共享网格只是实验代理指标，不是地图融合。第二车启动后若缺少图像或扫描，程序会打印等待状态并保持停车。

若之后取得论文原版 Gazebo `.world` 文件，可用 `python3 scripts/make_empty_home1_launch.py --world /原始文件/路径.world` 生成启动文件。原版若引用独立 `models/` 或材质文件，还必须把这些资源放进 Gazebo 可搜索路径；出生点也需按原版障碍物位置核对，不能直接假设本近似图的坐标安全。

## 5 验收与故障定位

```bash
ros2 topic list | grep -E 'scan|odom|image_raw|cmd_vel|map'
ros2 topic hz /TB3_1/camera/image_raw
ros2 topic hz /TB3_2/camera/image_raw
tail -n 5 ~/dual_explore_two.csv
```

看不到图像：确认 `waffle_pi` 而不是 `burger`，并用 `ros2 topic list` 找到实际相机话题后设置 `image_suffix` 或单车 `image_topic`。看到图像但车不动：检查 `/scan`、`/odom` 是否持续发布，以及 `cmd_vel` 是否在对应命名空间。若 Gazebo GUI 很慢，先单车；后续可关掉 `gzclient` 只保留服务器。Gazebo Classic 已结束维护，本方案锁定 Humble/Classic 是为了复现现有 TurtleBot3 栈。

## 6 后续研究改进

1. 用 `slam_toolbox` 为每车建图；建立共同世界坐标，合并地图后用新增已知栅格和重复覆盖率替换访问网格奖励。
2. 增加前沿基线。保持同一仿真场景、初始位置和时限，比较随机、最近前沿、共享 Q 学习。
3. 若 VM 资源足够，再把表格 Q 策略替换为参数共享 PPO 或 MADDPG；复杂网络训练不作为最小验收条件。

## 参考实现

- ROBOTIS TurtleBot3 Humble 仿真：<https://github.com/ROBOTIS-GIT/turtlebot3_simulations/tree/humble>
- ROS 2 Humble 多机器人 MADDPG 项目：<https://github.com/i1Cps/multi-robot-exploration-rl>
- ROS 2 Humble 建图导航组合示例：<https://github.com/econsystems/ros2-multi-robot-automap>
- MAANS 论文与代码：<https://arxiv.org/abs/2110.05734>，<https://github.com/zoeyuchao/maans>
- Empty home 1 图片来源，L2E 论文：<https://mit-spark.github.io/robotRepresentations-RSS2023/assets/papers/2.pdf>

第三方仓库仅供比较或后续复现，本项目不依赖直接运行它们。具体安装命令以对应仓库的 `humble` 分支与实际 apt 包为准。
