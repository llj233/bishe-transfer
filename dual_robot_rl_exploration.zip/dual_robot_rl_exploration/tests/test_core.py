import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src' / 'dual_explore'))
from dual_explore.core import SharedLearner, image_signature, scan_bins, state_from_sensors


class CoreTest(unittest.TestCase):
    def test_image_signature_and_state(self):
        data = bytes([255, 0, 0] * 16)
        sig = image_signature(data, 4, 4, 12, 'rgb8')
        self.assertEqual(sig, (3, 0, 0))
        self.assertEqual(state_from_sensors((0.2, 1.0, 0.5), sig), (0, 2, 1, 3, 0, 0))

    def test_shared_visit_reward(self):
        learner = SharedLearner(epsilon=0)
        first = learner.reward(0.1, 0.1, (1, 0, 0), 1.0)
        second = learner.reward(0.2, 0.2, (1, 0, 0), 1.0)
        self.assertGreater(first, second)
        self.assertEqual(len(learner.visited), 1)

    def test_q_update(self):
        learner = SharedLearner(epsilon=0)
        s = (1, 1, 1, 0, 0, 0)
        learner.learn(s, 0, 1.0, s)
        self.assertGreater(learner.q[s][0], 0)

    def test_scan(self):
        scan = scan_bins([1.0] * 360, 0.1, 4.0)
        self.assertEqual(scan, (1.0, 1.0, 1.0))


if __name__ == '__main__':
    unittest.main()
