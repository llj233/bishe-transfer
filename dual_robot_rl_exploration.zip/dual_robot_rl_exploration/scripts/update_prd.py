"""Revise the existing PRD in place, keeping an untouched v2 backup."""
from pathlib import Path
import shutil
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

root = Path(__file__).resolve().parents[2]
target = root / '地图不确定性感知的移动机器人主动探索系统_PRD_本科毕设版.docx'
backup = root / '地图不确定性感知的移动机器人主动探索系统_PRD_本科毕设版_v2备份.docx'
if not backup.exists():
    shutil.copy2(target, backup)

d = Document()
sec = d.sections[0]
sec.page_width, sec.page_height = Cm(21), Cm(29.7)
sec.top_margin = sec.bottom_margin = Cm(2.2)
sec.left_margin = sec.right_margin = Cm(2.4)
styles = d.styles
for name in ('Normal', 'Title', 'Subtitle', 'Heading 1', 'Heading 2'):
    style = styles[name]
    style.font.name = 'Microsoft YaHei'
    style.font.color.rgb = RGBColor(0, 0, 0)
    style._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    pPr = style._element.pPr
    if pPr is not None:
        border = pPr.find(qn('w:pBdr'))
        if border is not None:
            pPr.remove(border)
styles['Normal'].font.size = Pt(10.5)
styles['Normal'].paragraph_format.space_after = Pt(6)
styles['Normal'].paragraph_format.line_spacing = 1.2
styles['Title'].font.size = Pt(20)
styles['Title'].font.bold = True
styles['Heading 1'].font.size = Pt(14)
styles['Heading 1'].font.bold = True
styles['Heading 1'].paragraph_format.space_before = Pt(15)
styles['Heading 1'].paragraph_format.space_after = Pt(7)
styles['Heading 2'].font.size = Pt(11.5)
styles['Heading 2'].font.bold = True


def p(text, style=None):
    return d.add_paragraph(text, style)


def table(headers, rows, widths=None):
    t = d.add_table(rows=1, cols=len(headers))
    t.style = 'Table Grid'
    t.autofit = False
    for i, h in enumerate(headers):
        t.rows[0].cells[i].text = h
        if widths: t.columns[i].width = Cm(widths[i])
    header_props = t.rows[0]._tr.get_or_add_trPr()
    repeat = OxmlElement('w:tblHeader')
    repeat.set(qn('w:val'), 'true')
    header_props.append(repeat)
    for row in rows:
        cells = t.add_row().cells
        for i, value in enumerate(row): cells[i].text = value
    for ri, row in enumerate(t.rows):
        row_props = row._tr.get_or_add_trPr()
        no_split = OxmlElement('w:cantSplit')
        row_props.append(no_split)
        for cell in row.cells:
            cell.vertical_alignment = 1
            tcPr = cell._tc.get_or_add_tcPr()
            shd = OxmlElement('w:shd')
            shd.set(qn('w:fill'), 'DDEAF6' if ri == 0 else ('F6F9FC' if ri % 2 == 0 else 'FFFFFF'))
            tcPr.append(shd)
            for para in cell.paragraphs:
                para.paragraph_format.space_after = Pt(3)
                para.paragraph_format.space_before = Pt(3)
                for run in para.runs:
                    run.font.size = Pt(9)
                    if ri == 0: run.bold = True
    d.add_paragraph()


p('基于视觉观测与共享奖励的双机协同强化学习地图探索系统', 'Title')
p('本科毕业设计产品需求文档 PRD', 'Subtitle')
p('版本 v3.1    日期 2026 年 10 月    目标平台 Ubuntu 22.04 与 ROS 2 Humble')
p('本稿将原单机地图不确定性选点课题调整为双机协同探索。验收优先级为仿真、RGB 图像、强化学习决策和运动控制形成可重复的闭环，再补足 SLAM 建图和双车地图比较。算法性能提升需要实验检验，不写成预设结论。')

p('1 研究问题与范围', 'Heading 1')
p('研究问题：在同一未知二维场景中，两台移动机器人能否利用共享的新区域奖励与视觉观测，减少重复巡航并提高有限时间内的探索覆盖？最小方法采用参数共享的表格 Q 学习；每台车根据激光距离、RGB 图像的轻量特征与自身运动状态选择前进、左转或右转。位置访问网格仅用于工程联调，不等同于最终地图覆盖率。')
p('主线只做两台同型号 TurtleBot3 Waffle Pi、室内静态场景、Gazebo 仿真和二维栅格地图。RGB 相机是视觉链路输入；激光雷达负责安全阈值与 slam_toolbox 建图。多车全局一致地图、视觉目标检测和深度多智能体强化学习均作为进阶模块，不作为首轮跑通条件。')
p('首轮跑通场景固定为 L2E 论文 Fig. 3(a) 的 Empty home 1 布局。由于目前只有论文插图而无原始 Gazebo world 资产，工程上先使用按图构造的外墙与隔墙近似地图 empty_home_1_approx.world；单车与双车共用这张图。近似地图不是论文原版，实验数值不得与 L2E 表格直接比较。')
p('研究假设 H1：在相同场景、初始位置和时间限制下，共享新区域奖励的双车策略比“两个独立策略”有更低的重复访问比例，或有更高的地图覆盖率。H0：改善不稳定或不存在。若 H1 不成立，仍分析通信、奖励、地图对齐与训练次数的原因。')

p('2 文献依据与课题切口', 'Heading 1')
table(['文献', '主要启发', '本课题取舍'], [
    ('MAANS（Yu 等，2022）', '将视觉感知、神经 SLAM 和多智能体强化学习规划串联，用于协同视觉探索。', '借鉴模块分层；不复现 Habitat 中的大模型。'),
    ('NeuralCoMapping（Ye 等，2022）', '以图匹配分配多车探索目标，强调完整建图与效率。', '把重复访问和地图覆盖设为评价指标；最小版本不做图匹配。'),
    ('MANTM（Yang 等，2024）', '采用视觉编码、拓扑图与分层 RL 选择全局目标。', '证明高层协调有价值；先做低资源共享奖励，后续再升级高层目标选择。'),
    ('多机器人协同探索综述（Wang 等，2025）', '将定位建图、协同规划和通信作为三个关键模块。', '把地图坐标对齐与通信成本写入风险及实验记录。'),
], [3.6, 6.4, 6.2])
p('聚焦创新点是面向低资源 ROS 2 虚拟机的可复现双车闭环，以及“独立奖励和共享奖励”的受控比较。相较论文级新算法，本课题把实现、观测有效性和消融证据放在第一位。')

p('3 系统方案', 'Heading 1')
p('数据流：Gazebo Waffle Pi 相机 → sensor_msgs/Image 特征提取；激光 → 避障和 slam_toolbox；里程计 → 位置网格；以上状态 → 共享 Q 表 → 两车各自 /cmd_vel。记录 RGB 帧数、动作、奖励、位姿和访问网格数。第二阶段把每车 OccupancyGrid 对齐到共同坐标，并用新增已知栅格数替代位置访问奖励。')
table(['阶段', '必做功能', '通过证据'], [
    ('P0 单车闭环', 'Gazebo 单车、RGB/scan/odom、在线 Q 更新、cmd_vel、CSV。', '图像帧数和步数持续增加；车能运动；Q 表非空。'),
    ('P1 双车闭环', '两车命名空间、各自图像和速度话题、共享 Q 表及访问奖励。', '两车均有独立日志；共享访问网格增长；互不抢占 cmd_vel。'),
    ('P2 建图与对照', 'slam_toolbox 单车地图、双车地图对齐或地图合并、独立与共享策略比较。', '可视化两车地图；生成覆盖率和重复率曲线。'),
    ('P3 选做', '参数共享 PPO/MADDPG、前沿候选目标、简单视觉标记识别。', '只有 P0–P2 稳定后实施。'),
], [2.5, 6.6, 7.1])

p('4 算法与实验设计', 'Heading 1')
p('最小状态：激光前/左/右距离三级离散值，加 RGB 图像 3×3 采样的粗颜色特征。动作为低速直行、左转、右转。奖励为首次访问 0.5 m 网格 +1、首次看到粗视觉特征 +0.1、近障 −1、每步 −0.01。Q 学习 α=0.2、γ=0.9、ε=0.2；这些数值先用于链路验证，再在独立调参场景中固定。')
p('双机协同采用一个 Q 表和一个共享访问集合。另一台车已访问的网格不再给新区域奖励。正式实验必须将位置访问集合替换为共同地图中的新增可观测栅格；在此之前只能报告工程代理指标，不得写成真实地图覆盖率。使用 Gazebo 已知初始位姿进行坐标对齐，记录该假设；真实部署需另行求相对位姿。')
table(['比较组', '目的', '最低实验量'], [
    ('单车 Q 学习', '验证传感器与奖励能够驱动运动。', '同场景运行至少 3 个种子。'),
    ('双车独立奖励', '基线：各自维护 Q 表和访问集合。', '与共享组配对至少 5 个种子。'),
    ('双车共享奖励', '检验降低重复探索的效果。', '与独立组相同出生点、地图、时限。'),
    ('随机或最近前沿', '若 P2 完成，补充非 RL 基线。', '同样按配对种子比较。'),
], [3.3, 7.1, 5.8])
p('主要指标：相同仿真时间下真值可通行区域覆盖率、重复覆盖比例、达到目标覆盖率的时间。次要指标：碰撞/近障次数、行驶距离、每秒仿真计算耗时、图像与地图帧率。真值栅格需从场景文件构建并人工核查；未完成时只能记录位置访问网格和地图未知比例作调试。所有组固定世界、传感器、控制频率、初始位置和时限。')

p('5 环境与实施计划', 'Heading 1')
p('当前虚拟机仅安装 ROS 2。全部安装、编译、仿真和训练均在 Ubuntu 虚拟机终端完成，不依赖 VS Code。先安装 Gazebo ROS 包、TurtleBot3 仿真、slam_toolbox、RViz 与 colcon；使用 Waffle Pi，因为 Humble 仿真模型包含 RGB 相机。单车与双车启动文件均指定 Empty home 1 近似地图，先核对 ROS_DISTRO 与两车各自的图像、激光和里程计话题，再启动学习节点。')
table(['时间', '里程碑', '退出条件'], [
    ('第 1–2 周', '安装依赖、单车世界与图像话题。', 'Gazebo 稳定运行，RGB/激光/里程计有数据。'),
    ('第 3–4 周', '单车 Q 学习与 CSV；slam_toolbox 建图。', '单车闭环视频、地图截图、日志。'),
    ('第 5–7 周', '双车命名空间、共享奖励与独立奖励对照。', '两车均运动，无话题串扰，有配对记录。'),
    ('第 8 周以后', '地图对齐与覆盖评价，补实验和论文。', '可复现实验脚本、图表和限制分析。'),
], [2.5, 6.8, 6.9])
p('主要风险：虚拟机图形性能不足时先跑单车或无 GUI Gazebo；相机话题名称因模型和命名空间变化而不同，必须以 ros2 topic list 实测；官方四车 launch 需转为两车；地图对齐若未完成，协同结果仅说明代理奖励有效，不能宣称完成全局地图探索。强化学习不一定优于前沿法，论文应如实报告。')

p('6 参考资料与开源方案', 'Heading 1')
for item in [
    'Yu, C. 等（2022）Learning Efficient Multi-Agent Cooperative Visual Exploration. https://arxiv.org/abs/2110.05734',
    'Ye, K. 等（2022）Multi-Robot Active Mapping via Neural Bipartite Graph Matching. https://arxiv.org/abs/2203.16319',
    'Yang, X. 等（2024）Active Neural Topological Mapping for Multi-Agent Exploration. https://arxiv.org/abs/2311.00252',
    'Wang 等（2025）Multi-Robot System for Cooperative Exploration in Unknown Environments: A Survey. https://arxiv.org/abs/2503.07278',
    'ROBOTIS TurtleBot3 simulations，humble 分支。https://github.com/ROBOTIS-GIT/turtlebot3_simulations/tree/humble',
    'i1Cps，多机器人 ROS 2 Humble / Gazebo / MADDPG 开源项目。https://github.com/i1Cps/multi-robot-exploration-rl',
    'econsystems，ROS 2 Humble 多车建图导航参考项目。https://github.com/econsystems/ros2-multi-robot-automap',
    'Liu, Z. 等（2023）Learning to Explore (L2E): Deep Reinforcement Learning-based Autonomous Exploration for Household Robot，Fig. 3(a) Empty home 1。https://mit-spark.github.io/robotRepresentations-RSS2023/assets/papers/2.pdf',
]: p(item, 'List Bullet')

footer = sec.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
footer.add_run('本科毕业设计 PRD v3.1')
d.save(target)
print(target)
print('Backup:', backup)
