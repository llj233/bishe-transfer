"""Create a local two-robot copy of ROBOTIS Humble's four-robot launch."""
from pathlib import Path
import re

try:
    from ament_index_python.packages import get_package_share_directory
except ImportError as exc:
    raise SystemExit('Source ROS 2 Humble before running this script') from exc

source = Path(get_package_share_directory('turtlebot3_gazebo')) / 'launch' / 'multi_robot.launch.py'
text = source.read_text(encoding='utf-8')
needle = 'number_of_robots = 4'
if text.count(needle) != 1:
    raise SystemExit(f'Expected one {needle!r} in {source}; inspect launch manually')
text = text.replace(needle, 'number_of_robots = 2')
text, count = re.subn(
    r"save_path = os\.path\.join\(.*?\n\s*\)\n(?=\s*launch_file_dir)",
    "save_path = os.path.join('/tmp', f'turtlebot3_{TURTLEBOT3_MODEL}_')\n",
    text,
    count=1,
    flags=re.DOTALL,
)
if count != 1:
    raise SystemExit('Could not relocate temporary SDF path; inspect source launch manually')
out = Path('/tmp/dual_explore_two_robot.launch.py')
out.write_text(text, encoding='utf-8')
print(out)
print('Temporary SDF files are written to /tmp rather than the read-only package share path.')
