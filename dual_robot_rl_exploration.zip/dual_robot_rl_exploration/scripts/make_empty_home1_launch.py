"""Make local one/two Waffle Pi launch files for the approximate Empty home 1 world."""
from pathlib import Path
import argparse
import re

from ament_index_python.packages import get_package_share_directory

project = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--world', type=Path, default=project / 'worlds' / 'empty_home_1_approx.world',
                    help='Gazebo Classic .world/.sdf file; defaults to the figure-based approximation')
args = parser.parse_args()
world = args.world.expanduser().resolve()
if not world.is_file():
    raise SystemExit(f'World file not found: {world}')
source = Path(get_package_share_directory('turtlebot3_gazebo')) / 'launch' / 'multi_robot.launch.py'
original = source.read_text(encoding='utf-8')


def replace_once(text, pattern, replacement, description):
    new, count = re.subn(pattern, replacement, text, count=1, flags=re.DOTALL)
    if count != 1:
        raise SystemExit(f'Cannot locate {description} in {source}; inspect your humble branch')
    return new


for count, label in ((1, 'single'), (2, 'dual')):
    text = original
    text = replace_once(text, r'number_of_robots\s*=\s*4',
                        f'number_of_robots = {count}', 'robot count')
    text = replace_once(text, r'pose\s*=\s*\[\[-2, -0\.5\], \[0\.5, -2\], \[2, 0\.5\], \[-0\.5, 2\]\]',
                        'pose = [[-2, -2.5], [-2, 2.5]]', 'spawn positions')
    text = replace_once(text,
                        r'world\s*=\s*os\.path\.join\(.*?\n\s*\)\n(?=\s*gzserver_cmd)',
                        f'world = {str(world)!r}\n', 'world path')
    text = replace_once(text,
                        r'save_path\s*=\s*os\.path\.join\(.*?\n\s*\)\n(?=\s*launch_file_dir)',
                        "save_path = os.path.join('/tmp', f'empty_home1_{TURTLEBOT3_MODEL}_')\n",
                        'temporary SDF path')
    out = Path('/tmp') / f'empty_home1_{label}.launch.py'
    out.write_text(text, encoding='utf-8')
    print(f'{label}: {out}')
print(f'world: {world}')
if world.name == 'empty_home_1_approx.world':
    print('NOTE: this is a layout approximation from the paper figure, not the original asset.')
