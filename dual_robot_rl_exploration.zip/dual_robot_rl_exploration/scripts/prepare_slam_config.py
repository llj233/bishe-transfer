"""Copy Humble's SLAM Toolbox defaults and adjust them for TB3_1."""
from pathlib import Path
import re

from ament_index_python.packages import get_package_share_directory

source = Path(get_package_share_directory('slam_toolbox')) / 'config' / 'mapper_params_online_async.yaml'
data = source.read_text(encoding='utf-8')
changes = {
    'odom_frame': 'TB3_1/odom',
    'base_frame': 'TB3_1/base_footprint',
    'map_frame': 'map',
    'scan_topic': '/TB3_1/scan',
}
for key, value in changes.items():
    pattern = rf'(?m)^([ \t]*{key}:[ \t]*)[^\n#]+'
    data, count = re.subn(pattern, lambda m: m.group(1) + value, data, count=1)
    if count != 1:
        raise SystemExit(f'Missing {key} in {source}; inspect package config manually')
out = Path('/tmp/empty_home1_tb3_1_slam.yaml')
out.write_text(data, encoding='utf-8')
print(out)
