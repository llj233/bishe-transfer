# 双机共享奖励探索：VM 运行步骤

这是 ROS 2 Humble + Gazebo Classic 的最小双机闭环。两台 Waffle Pi 使用不同 ROS 命名空间；每台订阅自己的相机、激光与里程计，发布自己的速度。一个 `q_explorer` 节点维护共享访问网格、共享视觉签名集合和共享 Q 表。每秒收集两台机器人观测，计算一个团队奖励，再用同一个奖励更新两台机器人的转移。该基线可检验双机协同训练的数据链路，不是 MAPPO，也不是完整的 SLAM 地图覆盖率算法。

## 1. 解压和编译

把新版 `dual_ros2_prototype_vm.zip` 上传到 GitHub 的 `llj233/bishe-transfer` 仓库并在 VM 的 `~/bishe-transfer-new` 执行 `git pull`，或通过共享文件夹复制到 VM。然后运行：

```bash
cd ~
unzip -o ~/bishe-transfer-new/dual_ros2_prototype_vm.zip -d ~
source /opt/ros/humble/setup.bash
cd ~/single_ros2_prototype
colcon build --symlink-install
source install/setup.bash
ros2 pkg prefix dual_explore
```

## 2. 启动双机

```bash
cd ~/single_ros2_prototype
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch dual_explore dual_explore.launch.py world:=$PWD/worlds/prepared/room.world
```

Gazebo 中应出现两台机器人，初始坐标约为 `(-2, -2.5)` 和 `(-2, 3.5)`。Gazebo 启动后 5 秒、8 秒分别生成它们。两个机器人都有有效观测之后，日志每 10 步出现各自的 `ready steps=... image_frames=... visited=... team_reward=...`。

## 3. 检查话题与学习记录

在新终端执行：

```bash
source /opt/ros/humble/setup.bash
source ~/single_ros2_prototype/install/setup.bash
ros2 topic list | grep -E '^/robot[12]/(camera/image_raw|scan|odom|cmd_vel)$'
ros2 topic echo /robot1/cmd_vel --once
ros2 topic echo /robot2/cmd_vel --once
head -n 5 ~/dual_explore.csv
tail -n 10 ~/dual_explore.csv
ls -lh ~/.dual_explore_q.json
```

预期有 8 个机器人话题。CSV 中 `robot1` 与 `robot2` 的 `step` 和 `image_frames` 持续增加；同一控制周期的两行 `reward` 相等，因为它是团队共享奖励。`visited_cells` 是两台机器人共同访问的 0.5 m 网格数，正常移动时应逐渐增加。Q 表每 10 步保存一次，也会在正常 Ctrl+C 时保存。

如只出现等待相机或激光的消息，运行 `ros2 topic list` 检查实际话题，并检查 Gazebo 中两个实体是否成功生成。虚拟机图形加速不足时，可先通过话题和 CSV 验证链路。
