"""Two namespaced Waffle Pi robots with a shared visual Q learner."""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    gazebo_share = get_package_share_directory('gazebo_ros')
    tb3_share = get_package_share_directory('turtlebot3_gazebo')
    model = os.path.join(tb3_share, 'models', 'turtlebot3_waffle_pi', 'model.sdf')
    if not os.path.isfile(model):
        raise FileNotFoundError(f'Waffle Pi model missing: {model}')

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(gazebo_share, 'launch', 'gazebo.launch.py')),
        launch_arguments={'world': LaunchConfiguration('world'), 'verbose': 'true'}.items())

    def spawn(name, x, y):
        return Node(
            package='gazebo_ros', executable='spawn_entity.py', output='screen',
            arguments=['-entity', name, '-robot_namespace', f'/{name}',
                       '-file', model, '-x', str(x), '-y', str(y), '-z', '0.01'])

    learner = Node(
        package='dual_explore', executable='q_explorer', output='screen',
        parameters=[{'robot_names': ['robot1', 'robot2'],
                     'spawn_offsets': [-2.0, -2.5, -2.0, 3.5],
                     'image_suffix': 'camera/image_raw', 'train': True}])
    return LaunchDescription([
        DeclareLaunchArgument('world', description='Absolute path to a prepared Explore-Bench .world'),
        SetEnvironmentVariable('GAZEBO_MODEL_PATH',
                               os.path.join(tb3_share, 'models') + os.pathsep +
                               os.environ.get('GAZEBO_MODEL_PATH', '')),
        gazebo,
        TimerAction(period=5.0, actions=[spawn('robot1', -2.0, -2.5)]),
        TimerAction(period=8.0, actions=[spawn('robot2', -2.0, 3.5)]),
        learner,
    ])
