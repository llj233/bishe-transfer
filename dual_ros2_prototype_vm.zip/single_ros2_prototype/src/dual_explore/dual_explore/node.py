"""ROS 2 adapter for two robots sharing a small online Q table."""
import csv
import math
import os
import time

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image, LaserScan

from .core import ACTIONS, SharedLearner, image_signature, scan_bins, state_from_sensors


class Explorer(Node):
    def __init__(self):
        super().__init__('q_explorer')
        self.declare_parameter('robot_names', ['robot'])
        self.declare_parameter('train', True)
        self.declare_parameter('image_topic', '/camera/image_raw')
        self.declare_parameter('image_suffix', 'camera/image_raw')
        self.declare_parameter('spawn_offsets', [-2.0, -2.5, -2.0, 3.5])
        self.declare_parameter('log_path', os.path.expanduser('~/dual_explore.csv'))
        self.declare_parameter('q_path', os.path.expanduser('~/.dual_explore_q.json'))
        self.declare_parameter('sensor_timeout', 3.0)
        name_value = self.get_parameter('robot_names').value
        names = [name_value] if isinstance(name_value, str) else list(name_value)
        self.training = bool(self.get_parameter('train').value)
        self.q_path = os.path.expanduser(self.get_parameter('q_path').value)
        offsets = list(self.get_parameter('spawn_offsets').value)
        if len(names) not in (1, 2):
            raise ValueError('robot_names must contain one or two names')
        if len(names) == 2 and len(offsets) != 4:
            raise ValueError('spawn_offsets must be [x1,y1,x2,y2]')
        self.learner = SharedLearner()
        if os.path.exists(self.q_path):
            self.learner.load(self.q_path)
        self.robots = {}
        self.cmd_publishers = {}
        self.subscriptions_ = []
        for i, name in enumerate(names):
            prefix = '' if len(names) == 1 and name == 'robot' else f'/{name}'
            image_topic = (self.get_parameter('image_topic').value if not prefix
                           else f"{prefix}/{self.get_parameter('image_suffix').value.lstrip('/')}")
            self.robots[name] = {'scan': None, 'image': None, 'odom': None,
                                 'scan_time': 0.0, 'image_time': 0.0, 'odom_time': 0.0,
                                 'frames': 0, 'steps': 0, 'last': None, 'odom_origin': None,
                                 'offset': (0.0, 0.0) if len(names) == 1 else (offsets[i * 2], offsets[i * 2 + 1])}
            self.cmd_publishers[name] = self.create_publisher(Twist, f'{prefix}/cmd_vel', 10)
            self.subscriptions_.append(self.create_subscription(
                LaserScan, f'{prefix}/scan', lambda msg, n=name: self.on_scan(n, msg), qos_profile_sensor_data))
            self.subscriptions_.append(self.create_subscription(
                Odometry, f'{prefix}/odom', lambda msg, n=name: self.on_odom(n, msg), qos_profile_sensor_data))
            self.subscriptions_.append(self.create_subscription(
                Image, image_topic, lambda msg, n=name: self.on_image(n, msg), qos_profile_sensor_data))
            self.get_logger().info(f'{name}: scan={prefix}/scan odom={prefix}/odom image={image_topic} cmd={prefix}/cmd_vel')
        log_path = os.path.expanduser(self.get_parameter('log_path').value)
        self.log_file = open(log_path, 'w', newline='', encoding='utf-8')
        self.writer = csv.writer(self.log_file)
        self.writer.writerow(['wall_time', 'robot', 'step', 'image_frames', 'visited_cells',
                              'image_signatures', 'action', 'reward', 'x_world', 'y_world', 'front_m'])
        self.timer = self.create_timer(1.0, self.tick)

    def on_scan(self, name, msg):
        self.robots[name]['scan'] = scan_bins(msg.ranges, msg.range_min, msg.range_max)
        self.robots[name]['scan_time'] = time.monotonic()

    def on_odom(self, name, msg):
        p = msg.pose.pose.position
        robot = self.robots[name]
        robot['odom'] = (p.x, p.y)
        if robot['odom_origin'] is None:
            robot['odom_origin'] = (p.x, p.y)
        robot['odom_time'] = time.monotonic()

    def on_image(self, name, msg):
        robot = self.robots[name]
        robot['image'] = image_signature(msg.data, msg.width, msg.height, msg.step, msg.encoding)
        robot['frames'] += 1
        robot['image_time'] = time.monotonic()

    def publish_action(self, name, action):
        msg = Twist()
        if action is not None:
            msg.linear.x, msg.angular.z = ACTIONS[action]
        self.cmd_publishers[name].publish(msg)

    def tick(self):
        now = time.monotonic()
        timeout = float(self.get_parameter('sensor_timeout').value)
        ready = True
        for name, robot in self.robots.items():
            if (robot['scan'] is None or robot['odom'] is None or robot['image'] is None or
                    any(now - robot[k] > timeout for k in ('scan_time', 'image_time', 'odom_time'))):
                self.get_logger().info(f'{name}: waiting for fresh scan/odom/rgb8 image')
                ready = False
        if not ready:
            for name in self.robots:
                self.publish_action(name, None)
            return

        observations = {}
        for name, robot in self.robots.items():
            scan, image = robot['scan'], robot['image']
            state = state_from_sensors(scan, image)
            x = robot['offset'][0] + robot['odom'][0] - robot['odom_origin'][0]
            y = robot['offset'][1] + robot['odom'][1] - robot['odom_origin'][1]
            observations[name] = (state, x, y, scan, image)

        reward = self.learner.reward_batch(
            (x, y, image, scan[0]) for _, x, y, scan, image in observations.values())
        for name, robot in self.robots.items():
            state, x, y, scan, image = observations[name]
            if self.training and robot['last'] is not None:
                prev_state, prev_action = robot['last']
                self.learner.learn(prev_state, prev_action, reward, state)
            action = self.learner.choose(state, self.training)
            if scan[0] < 0.28 and action == 0:
                action = 1 if scan[1] >= scan[2] else 2
            self.publish_action(name, action)
            robot['last'] = (state, action)
            robot['steps'] += 1
            self.writer.writerow([round(time.time(), 2), name, robot['steps'], robot['frames'],
                                  len(self.learner.visited), len(self.learner.images), action,
                                  round(reward, 3), round(x, 3), round(y, 3), round(scan[0], 3)])
            self.log_file.flush()
            if robot['steps'] % 10 == 0:
                self.get_logger().info(f'{name}: ready steps={robot["steps"]} image_frames={robot["frames"]} visited={len(self.learner.visited)} team_reward={reward:.2f}')
        if self.training and all(robot['steps'] % 10 == 0 for robot in self.robots.values()):
            self.learner.save(self.q_path)

    def close(self):
        for name in self.robots:
            self.publish_action(name, None)
        if self.training:
            self.learner.save(self.q_path)
        self.log_file.close()


def main():
    rclpy.init()
    node = Explorer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.close()
        node.destroy_node()
        rclpy.shutdown()
